-- Create LastModifiedOn trigger

USE MyWebsiteDB
GO

IF OBJECT_ID ('dbo.uPosts','TR') IS NOT NULL
   DROP TRIGGER dbo.uPosts 
GO

CREATE TRIGGER dbo.uPosts 
   ON  dbo.Posts 
   AFTER UPDATE
AS UPDATE dbo.Posts SET LastModifiedOn = GETDATE() FROM inserted WHERE inserted.id = dbo.Posts.id
GO

