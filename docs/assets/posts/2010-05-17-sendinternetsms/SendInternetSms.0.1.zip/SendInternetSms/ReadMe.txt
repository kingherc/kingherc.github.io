SendInternetSms 0.1
===================

SendInternetSms contains Visual Studio solutions that can help one send an SMS message easily via internet websites. License is included in the LICENSE file. The solutions included are:

* SendSmsLib: A .NET (Compact) Framework library that defines an ISmsService interface. It allows easy configuration and loading of ISmsServices from different assemblies. After being configured, one can use SendSmsLib to easily send a SMS message.

* SendInternetSms: Contains the SmsRerouter program. It allows automatic interception of outgoing SMS messages from a Windows Mobile 5 or 6 device (either Smartphone or PocketPC). It uses SendSmsLib. It contains a native C++ project and a C# program.

* WebSms: An ASP.NET website that uses SendSmsLib to send SMS messages. My many thanks to my friend Alexandros Sigaras (a.k.a. mazohack in the www.studentguru.gr community) who made the design of the website! Default username and password are "user" and "pass", they're in the web.config file.

If you're just here for the Windows Mobile program, and you're not a develop, skip ahead to "Installing and Using SmsRerouter". If you find it confusing, don't hesitate to ask, visit my website (Contact details are at the end of this ReadMe file).

Available ISmsServices
======================

* SmsServiceOtenet: Implements ISmsService for the OTENET web sms website (http://tools.otenet.gr).

* SmsServiceOtenetCorporate: Implements ISmsService for Otenet Corporate web sms website (http://corpmail.otenet.gr).

You have the responsibility of using any of the ISmsServices. These given ISmsServices log into the websites with your username and password, and try to send an SMS message in the background. If these actions, violate in any way the "Terms of Use" of the websites, you should not use them at all!

As you see, only some greek websites are included. But you can develop your own ISmsServices, by following the same logic. I've developed the aforementioned, using mainly Fiddler to see which were the most important HTTP requests and responses.

More ISmsServices to come, watch my website.

Note: Different ISmsServices use different SMS formatting that may restrain an SMS's available characters. For example, Otenet appends the user's email to the SMS message, using up some characters, and thus the available characters are less than 160. Because SendSmsLib cannot count characters or foresee how many characters are available, please use short messages so as to be sure that the ISmsService won't deny the message.

Configuration
=============

SmsRerouter and WebSms, both use SendSmsLib. SendSmsLib requires a "config.xml" file with the user's configuration. Most importantly, it contains the ISmsServices to be loaded and used.

config.xml is given in both SmsRerouter and WebSms, but only include the "FakeSmsService" ISmsService. This ISmsService doesn't make use of any website, it's only for testing purposes. It just pretends to successfully send an sms. To add more ISmsServices, you must manually edit the XML file and add them. Each added entry should point to an assembly (.dll), that should exist either in the working directory of SmsRerouter or in the references of the WebSms. For example, to use SmsServiceOtenet first and SmsServiceOtenetCorporate second, the config.xml should be like this:

<?xml version="1.0" encoding="utf-8" ?>
<SendSmsLib>
  <SmsServices>
  	<add type="SmsServiceOtenet.Otenet, SmsServiceOtenet" username="..." password="..." />
	<add type="SmsServiceOtenetCorporate.OtenetCorporate, SmsServiceOtenetCorporate" username="..." password="..." /> 
  </SmsServices>
  <AppendToMessage></AppendToMessage>
  <SendOnlyWhenConnected value="true" />
</SendSmsLib>

The .dlls for both ISmsServices can be found in the "bin\Debug" folder of each project. Of course, the order of the ISmsServices in the config.xml is important.

The other configuration options are:
- AppendToMessage: The given text is appended to any SMS before being sent.
- SendOnlyWhenConnected: If true, SendSmsLib sends the SMS only if the device/PC is connected to a network. This prevents Windows Mobile devices from opening an internet connection. Be careful though, because it does not check for internet connectivity. So, if for example, your Windows Mobile device is connected to Windows Mobile Device Center or to a Wi-Fi network without internet connectivity, it will try to open a GPRS connection for sending the SMS. If you have an unlimited data plan, feel free to make this entry "false".

Installing and using SmsRerouter
================================

To install this program, copy the file "SendInternetSms\SmsRerouterSetup\Debug\SmsRerouterSetup.CAB" to your device and run it. This installs the program and also puts it in the Startup folder of Windows.

Be sure to modify as you wish the config.xml file (as shown above), which will be at the installation directory, and include any required ISmsService .dlls in the installation directory (e.g. "\Program Files\SmsRerouter" folder), as shown above. After you do those, be sure to run the program from File Explorer, by clicking on SmsRerouter.exe. This will give you the chance to authorize the .dlls of the ISmsServices.

After this, restart your device. When the application starts, it notifies you of the ISmsServices loaded successfully. Also it creates a "Special" folder under the "Outbox" folder of the device's SMS Message Store.

When an unread message comes into the Outbox folder, it tries to quickly divert it into the Special subfolder, preventing Windows Mobile from sending the SMS.

For each message that comes into the Special folder, it tries to send it through SendSmsLib. If it succeeds, it popups a notification and moves the message to the "Sent" folder. If it fails, it moves the message (as read, so as not to pick it up again) to the Outbox folder, where Windows Mobile will handle it as usual.

Developer Comments
==================

These projects were in development for several weeks now. They're purely amateur-style and not professional. They require Visual Studio 2008 and Windows Mobile 6 Professional SDK.

The hardest project of all was advisesinklibrary, the C++ project that accompanies SmsRerouter. As I had no previous experience with C++, I only tried to make things work. The source is very unorganized. For example, I've used global variables, and have not paid much attention to freeing memory etc. Because C++ gives me the chills, I've not tried to re-organize the code, because frankly it's so much time-consuming and I don't have the time right-now. If anyone feels that he can improve the code, feel free, it's under GPL so you can do it! Anyways, it works.

I would like to point out some of the development issues addressed/showed in SendInternetSms for Windows Mobile:
- .NET Compact Framework for Windows Mobile devices. How to make a background process.
- How to use Windows Mobile native API. E.g. Implementing the IMAPIAdviseSink for intercepting outgoing SMS messages and using MAPI.
- Multithreading using ManualResetEvent and the ThreadPool.
- Platform Invoke: How the managed application calls the C++ project's functions. How callback functions can be used.
- Smartphone/PocketPC compatibility. Detect the type of the current device and show accordingly either a taskbar notification or a message box.

When I have the time, I'll write a guide on the internals of the project, especially the C++ project.

Notes:
- A problem that I've noticed is that the SendSmsLib can't handle new lines, or "\n". It just treats them like spaces. Will get into that in the future.
- When an ISmsService tries to send a message, it should first clean the recipient string. This is done with the given ISmsServices. Helper methods exist to remove the "+XXX" country codes and any illegal character (like parentheses or spaces).
- Keep in mind that SendInternetSms won't work with the upcoming Windows Phone 7. The reason is that Windows Phone 7 devices won't allow native C++ development, nor will they include .NET Compact Framework. Only Silverlight and XNA is currently supported on Windows Phone 7.

Contact
=======

Iraklis Psaroudakis a.k.a. kingherc
http://www.studentguru.gr/blogs/kingherc
http://www.kingherc.com
kingherc@gmail.com