/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "stdafx.h"
#include "advisesinklibrary.h"
#include "CAdviseSink.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// Variables

IMAPISession * g_pSession;
IMsgStore   * g_pStore;
CAdviseSink * g_pAdviseSink;
ULONG g_ulConnection;
int notifications;

// My platform invoke functions

extern "C" __declspec(dllexport) BOOL WINAPI StartCollectingOutbox() {
	return g_pAdviseSink->StartCollectingOutbox();
}

extern "C" __declspec(dllexport) void WINAPI SetCallbackFunction(ADVISENOTIFY lpCheckFunc) {
	g_pAdviseSink->SetCallbackFunction(lpCheckFunc);
}

extern "C" __declspec(dllexport) void WINAPI GetSpecialMessages() {
	g_pAdviseSink->GetSpecialMessages();
}

extern "C" __declspec(dllexport) BOOL WINAPI AreMessagesEqual(ULONG itemIdSize1, LPENTRYID itemIdPtr1, ULONG itemIdSize2, LPENTRYID itemIdPtr2) {
	return g_pAdviseSink->AreMessagesEqual(itemIdSize1, itemIdPtr1, itemIdSize2, itemIdPtr2);
}

extern "C" __declspec(dllexport) BOOL WINAPI SetMessageReadFlag(ULONG itemIdSize, LPENTRYID itemIdPtr, BOOL readFlag) {
	return g_pAdviseSink->SetMessageReadFlag(itemIdSize, itemIdPtr, readFlag);
}

extern "C" __declspec(dllexport) BOOL WINAPI MoveSpecialMessageToOutbox(ULONG itemIdSize, LPENTRYID itemIdPtr) {
	return g_pAdviseSink->MoveSpecialMessageToOutbox(itemIdSize, itemIdPtr);
}

extern "C" __declspec(dllexport) BOOL WINAPI MoveSpecialMessageToSent(ULONG itemIdSize, LPENTRYID itemIdPtr) {
	return g_pAdviseSink->MoveSpecialMessageToSent(itemIdSize, itemIdPtr);
}

extern "C" __declspec(dllexport) void WINAPI NotifyUser(DWORD seconds, LPCWSTR title, LPCWSTR htmlMessage, LPCWSTR closeButtonTitle) {
	SHNOTIFICATIONDATA sn  = {0};

	sn.cbStruct = sizeof(sn);
	sn.dwID = (notifications++);
	sn.npPriority = SHNP_INFORM;
	sn.csDuration = seconds;
	sn.grfFlags = 0;
	sn.pszTitle = title;
	sn.pszHTML = htmlMessage;
	sn.rgskn[0].pszTitle = closeButtonTitle;
	sn.rgskn[0].skc.wpCmd = 100;
	sn.rgskn[0].skc.grfFlags = NOTIF_SOFTKEY_FLAGS_DISMISS;

	//Add the notification to the tray
	SHNotificationAdd(&sn);
}

BOOL __declspec(dllexport) WINAPI AreMessagesEqual(ULONG itemIdSize1, LPENTRYID itemIdPtr1, ULONG itemIdSize2, LPENTRYID itemIdPtr2);

// CadvisesinklibraryApp

BEGIN_MESSAGE_MAP(CadvisesinklibraryApp, CWinApp)
END_MESSAGE_MAP()

// CadvisesinklibraryApp construction

CadvisesinklibraryApp::CadvisesinklibraryApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CadvisesinklibraryApp object

CadvisesinklibraryApp theApp;

// CadvisesinklibraryApp initialization

BOOL CadvisesinklibraryApp::InitInstance()
{
	CWinApp::InitInstance();

	notifications = 1;
	HRESULT hr;
	IMAPITable * pTable = NULL;
	SRowSet * psrs = NULL;
	ULONG cValues = 0;
	SPropValue * rgprops = NULL;
	ULONG rgTags[] = { 1, PR_DISPLAY_NAME};
	BOOL fSucceeded = FALSE;

	// Log on to MAPI

	hr = MAPILogonEx(NULL, NULL, NULL, NULL, &g_pSession);
	if (FAILED(hr))
	{
		goto FuncExit;
	}

	// Open the message store table

	hr = g_pSession->GetMsgStoresTable(MAPI_UNICODE, &pTable);
	if (FAILED(hr))
	{
		goto FuncExit;
	}

	// Loop to find SMS message store

	while (SUCCEEDED(pTable->QueryRows(1, NULL, &psrs)))
	{
		// Check for the end of the table.
		if (psrs->cRows != 1)
		{
			break;
		}

		if (psrs->aRow[0].lpProps[0].ulPropTag != PR_ENTRYID) {
			hr = E_FAIL;
			break;
		}

		// Open current message store
		IMsgStore* pMsgStore = NULL;

		hr = g_pSession->OpenMsgStore(NULL, psrs->aRow[0].lpProps[0].Value.bin.cb, (LPENTRYID)psrs->aRow[0].lpProps[0].Value.bin.lpb, NULL, 0, &pMsgStore);
		if (FAILED(hr))
		{
			goto FuncExit;
		}

		// Get its name
		hr = pMsgStore->GetProps((SPropTagArray *)rgTags, MAPI_UNICODE, &cValues, &rgprops);
		if (FAILED(hr))
		{
			goto FuncExit;
		}

		// Compare the name with "SMS"
		if (rgprops[0].ulPropTag == PR_DISPLAY_NAME)
		{
			if (wcscmp(rgprops[0].Value.lpszW, L"SMS") != 0)
			{
				FreeProws(psrs);
				if (pMsgStore)
					pMsgStore->Release();
				MAPIFreeBuffer(rgprops);  
				continue;
			}
		}

		// Found "SMS" message store
		g_pStore = pMsgStore;

		MAPIFreeBuffer(rgprops);       

		// Initilize my advise sink
		g_pAdviseSink = new CAdviseSink(g_pStore);
		hr = g_pSession->Advise(0, NULL, fnevObjectCreated | fnevObjectMoved | fnevObjectCopied, g_pAdviseSink, &g_ulConnection);

		FreeProws(psrs);          
		rgprops = NULL;    
		psrs = NULL;       

		if (pTable)
			pTable->Release();

		fSucceeded = TRUE;
		break;
	}

	return fSucceeded;

FuncExit:
	//Clean up
	MAPIFreeBuffer(rgprops);
	FreeProws(psrs);

	if (g_pStore)
		g_pStore->Release();
	if (pTable)
		pTable->Release();
	if (g_pSession)
		g_pSession->Release();

	return FALSE;
}
