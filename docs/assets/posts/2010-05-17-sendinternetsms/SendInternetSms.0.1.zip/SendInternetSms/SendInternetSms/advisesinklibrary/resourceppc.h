/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by advisesinklibraryppc.RC
//

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE	2000
#define _APS_NEXT_CONTROL_VALUE		2000
#define _APS_NEXT_SYMED_VALUE		2000
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
