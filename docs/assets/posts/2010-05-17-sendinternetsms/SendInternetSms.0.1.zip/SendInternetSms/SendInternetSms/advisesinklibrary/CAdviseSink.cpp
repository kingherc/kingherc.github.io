/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "stdafx.h"
#define INITGUID
#include <initguid.h>
#define USES_IID_IMAPIAdviseSink
#include <mapiguid.h>
#include "stdafx.h"
#include <afxpriv.h>

BOOL isInitialized; // Whether the initialization completed correctly and we have all are variables.
BOOL doCollectOutbox; // Whether the outbox messages should be moved to the subfolder, preventing them from being sent.

// Variables

ULONG g_ref;
ADVISENOTIFY lpFunc; // Callback function. Notifies the program about a message in the subfolder.
IMAPISession* pSession;
SBinary bOutboxEntryId;
SBinary bSpecialEntryId;
SBinary bSentEntryId;
IMAPIFolder* pOutboxFolder;
IMAPIFolder* pSpecial;
IMAPIFolder* pSentFolder;

class CAdviseSink : public  IMAPIAdviseSink
{
public:
	__declspec(dllexport) WINAPI CAdviseSink(IMsgStore* pMsgStore) : m_pMsgStore(pMsgStore)
	{
		doCollectOutbox = FALSE;
		isInitialized = FALSE;

		HRESULT hr;

		// Log in to MAPI

		hr = MAPILogonEx(NULL, NULL, NULL, NULL, &pSession);
		if (FAILED(hr))
		{
			goto ExitInitializing;
		}

		// Get Outbox and Sent folders' entry ids

		SPropValue * rgpropsOutboxEntry = NULL;
		ULONG rgTagsOutboxEntry[]       = {2, PR_IPM_OUTBOX_ENTRYID, PR_IPM_SENTMAIL_ENTRYID};
		ULONG cCountOutboxEntry         = 0;

		hr = m_pMsgStore->GetProps((LPSPropTagArray) rgTagsOutboxEntry, MAPI_UNICODE, &cCountOutboxEntry, &rgpropsOutboxEntry);
		if (FAILED(hr))
		{
			goto ExitInitializing;
		}

		// Be careful, if we dispose of SPropValues, the global variables will be lost too
		bOutboxEntryId = rgpropsOutboxEntry[0].Value.bin;
		bSentEntryId = rgpropsOutboxEntry[1].Value.bin;

		// Get Sent folder

		pSentFolder = NULL;

		hr = m_pMsgStore->OpenEntry(bSentEntryId.cb, (LPENTRYID)bSentEntryId.lpb, NULL, 0, NULL, (LPUNKNOWN *) &pSentFolder);
		if (FAILED(hr))
		{
			goto ExitInitializing;
		}	

		// Get Outbox folder

		pOutboxFolder = NULL;

		hr = m_pMsgStore->OpenEntry(bOutboxEntryId.cb, (LPENTRYID)bOutboxEntryId.lpb, NULL, 0, NULL, (LPUNKNOWN *) &pOutboxFolder);
		if (FAILED(hr))
		{
			goto ExitInitializing;
		}	

		// Create our subfolder and/or open it

		hr = pOutboxFolder->CreateFolder(NULL, L"Special", NULL, NULL, (MAPI_UNICODE | OPEN_IF_EXISTS), &pSpecial);
		if (FAILED(hr))
		{
			goto ExitInitializing;
		}	

		// Get Special folder's entry id

		SPropValue * rgpropsSpecialEntry = NULL;
		ULONG rgTagsSpecialEntry[]       = {1, PR_ENTRYID};
		ULONG cCountSpecialEntry         = 0;

		hr = pSpecial->GetProps((LPSPropTagArray) rgTagsSpecialEntry, MAPI_UNICODE, &cCountSpecialEntry, &rgpropsSpecialEntry);
		if (FAILED(hr))
		{
			goto ExitInitializing;
		}

		bSpecialEntryId = rgpropsSpecialEntry[0].Value.bin; // Be careful, if we dispose of SPropValue, this will be lost too...

		// All ok

		isInitialized = TRUE;

ExitInitializing:
		MAPIFreeBuffer((LPVOID)&rgTagsOutboxEntry);
		MAPIFreeBuffer((LPVOID)&rgTagsSpecialEntry);
	}

	__declspec(dllexport) BOOL WINAPI StartCollectingOutbox() {
		if (isInitialized && !doCollectOutbox) {

			// Elevate my thread's priority, in order to be able to delete outgoing messages before they are sent out
			HANDLE g_hThread;
			g_hThread = GetCurrentThread();
			BOOL bPriority = SetThreadPriority(g_hThread, THREAD_PRIORITY_TIME_CRITICAL);

			if (!bPriority) {
				goto ExitCollecting;
			}

			// Finally toggle collecting mode

			doCollectOutbox = TRUE;

ExitCollecting:

			// Clean up

			g_hThread = NULL;
			bPriority = NULL;
		}

		return doCollectOutbox;
	}

	__declspec(dllexport) void WINAPI SetCallbackFunction(ADVISENOTIFY lpCheckFunc) {
		lpFunc = lpCheckFunc;
	}

	__declspec(dllexport) ADVISENOTIFY WINAPI GetFunction() {
		return lpFunc;
	}

	__declspec(dllexport) void WINAPI GetSpecialMessages() {
		HRESULT hr = E_FAIL;

		// Get Mapi table for Special folder

		IMAPITable* lpTable = NULL;
		hr = pSpecial->GetContentsTable(NULL, &lpTable);
		if (FAILED(hr))
		{
			goto ExitSpecialMessages;
		}

		// Set the columns we wish to query

		ULONG rgTagsColumns[] = {2, PR_ENTRYID, PR_SUBJECT};
		SRowSet * psrs = NULL;

		hr = lpTable->SetColumns((LPSPropTagArray) rgTagsColumns, 0);
		if (FAILED(hr))
		{
			goto ExitSpecialMessages;
		}

		// Loop through the messages in the folder

		while (SUCCEEDED(lpTable->QueryRows(1, NULL, &psrs)))
		{
			// Check for the end of the table.
			if (psrs->cRows != 1)
			{
				break;
			}

			// Open message

			IMessage* pSpecialMessage = NULL;
			
			if (psrs->aRow[0].lpProps[0].ulPropTag == PR_ENTRYID)
			{
				LPWSTR mes = NULL;
				LPWSTR rec = NULL;
				ReadMessage(psrs->aRow[0].lpProps[0].Value.bin.cb, (LPENTRYID) psrs->aRow[0].lpProps[0].Value.bin.lpb, &rec, &mes);

				if (lpFunc) {
					lpFunc(psrs->aRow[0].lpProps[0].Value.bin.cb, (LPENTRYID) psrs->aRow[0].lpProps[0].Value.bin.lpb, rec, mes);
				}
			}
		}

		goto ContSpecialMessages;

ExitSpecialMessages:
		;

ContSpecialMessages:
		// Clean up
		FreeProws(psrs);
		if (lpTable)
			lpTable->Release();
		MAPIFreeBuffer((LPVOID)&rgTagsColumns);

		return ;
	}

	__declspec(dllexport) BOOL WINAPI AreMessagesEqual(ULONG itemIdSize1, LPENTRYID itemIdPtr1, ULONG itemIdSize2, LPENTRYID itemIdPtr2) {
		if (isInitialized) {

			ULONG compare = NULL;
			HRESULT hr = E_FAIL;

			hr = pSession->CompareEntryIDs(itemIdSize1, itemIdPtr1, itemIdSize2, itemIdPtr2, NULL, &compare);
			if (FAILED(hr))
			{
				return FALSE;
			}

			if (compare == TRUE) {
				return TRUE;
			} else {
				return FALSE;
			}

		}

		return FALSE;
	}

	__declspec(dllexport) BOOL WINAPI MoveSpecialMessageToOutbox(ULONG itemIdSize, LPENTRYID itemIdPtr) {
		return MoveSpecialMessageToFolder(itemIdSize, itemIdPtr, TRUE);
	}

	__declspec(dllexport) BOOL WINAPI MoveSpecialMessageToSent(ULONG itemIdSize, LPENTRYID itemIdPtr) {
		return MoveSpecialMessageToFolder(itemIdSize, itemIdPtr, FALSE);
	}

	__declspec(dllexport) BOOL WINAPI SetMessageReadFlag(ULONG itemIdSize, LPENTRYID itemIdPtr, BOOL readFlag) {
		BOOL didIt = FALSE;

		if (isInitialized) {
			HRESULT hr = E_FAIL;
			IMessage* pMsg = NULL;

			// Open Message

			hr = m_pMsgStore->OpenEntry(itemIdSize, itemIdPtr, NULL, 0, NULL, (LPUNKNOWN *) &pMsg);
			if (FAILED(hr))
			{
				//wsprintf(logBuffer, L"SetMessageReadFlag: Cannot open message, error %#lx or %ld.\r\n", hr, hr);
				//WriteToLog(logBuffer);
				goto ExitMarkRead;
			}

			// Get the message's flags

			SPropValue * rgpropsFlags = NULL;
			ULONG rgTagsFlags[]       = {1, PR_MESSAGE_FLAGS};
			ULONG cCountFlags         = 0;

			hr = pMsg->GetProps((LPSPropTagArray) rgTagsFlags, MAPI_UNICODE, &cCountFlags, &rgpropsFlags);
			if (FAILED(hr))
			{
				goto ExitMarkRead;
			}

			// Set the message's flag

			if (readFlag) {
				rgpropsFlags[0].Value.ul |= MSGFLAG_READ;
				rgpropsFlags[0].Value.ul &= ~MSGFLAG_UNSENT;
			} else {
				rgpropsFlags[0].Value.ul &= ~MSGFLAG_READ;
				rgpropsFlags[0].Value.ul |= MSGFLAG_UNSENT;
			}
			
			hr = pMsg->SetProps(1, rgpropsFlags, NULL);
			if (FAILED(hr))
			{
				goto ExitMarkRead;
			}

			didIt = TRUE;

			goto ContMarkRead;

ExitMarkRead:
			;

ContMarkRead:
			// Clean up
			;
			if (pMsg)
				pMsg->Release();
			if (rgpropsFlags)
				MAPIFreeBuffer(rgpropsFlags);
			if (rgTagsFlags)
				MAPIFreeBuffer((LPVOID)&rgTagsFlags);
		}

		return didIt;
	}

private:

	BOOL MoveSpecialMessageToFolder(ULONG itemIdSize, LPENTRYID itemIdPtr, BOOL TrueForOutboxFalseForSent) {
		BOOL didIt = FALSE;

		if (isInitialized) {
			HRESULT hr = E_FAIL;

			// Move the message

			ENTRYLIST lstMoving;
			SBinary sbinMoving;

			lstMoving.cValues = 1;
			sbinMoving.cb = itemIdSize;
			sbinMoving.lpb = (LPBYTE) itemIdPtr;
			lstMoving.lpbin = &sbinMoving;

			if (TrueForOutboxFalseForSent == TRUE) {
				hr = pSpecial->CopyMessages(&lstMoving, NULL, pOutboxFolder, NULL, NULL, MESSAGE_MOVE);
			} else {
				hr = pSpecial->CopyMessages(&lstMoving, NULL, pSentFolder, NULL, NULL, MESSAGE_MOVE);
			}
			
			if (FAILED(hr))
			{
				goto ExitMoveMessage;
			}

			didIt = TRUE;

			goto ContMoveMessage;

ExitMoveMessage:
			;

ContMoveMessage:
			// Clean up
			MAPIFreeBuffer((LPVOID)&lstMoving);
			MAPIFreeBuffer((LPVOID)&sbinMoving);
		}

		return didIt;
	}

	void ReadMessage(ULONG itemIdSize, LPENTRYID itemIdPtr, LPWSTR * lpszRecipients, LPWSTR * lpszMessage) {
		HRESULT hr = E_FAIL;
		IMessage* pMsg = NULL;

		// Open Message

		hr = m_pMsgStore->OpenEntry(itemIdSize, itemIdPtr, NULL, 0, NULL, (LPUNKNOWN *) &pMsg);
		if (FAILED(hr))
		{
			goto ExitReadMessage;
		}

		// Read Subject

		SPropValue * rgpropsFlags = NULL;
		ULONG rgTagsFlags[]       = {1, PR_SUBJECT};
		ULONG cCountFlags         = 0;

		hr = pMsg->GetProps((LPSPropTagArray) rgTagsFlags, MAPI_UNICODE, &cCountFlags, &rgpropsFlags);
		if (FAILED(hr))
		{
			goto ExitReadMessage;
		}

		if (rgpropsFlags[0].ulPropTag == PR_SUBJECT)
		{
			(*lpszMessage) = rgpropsFlags[0].Value.lpszW;
		}

		// Get Recipients Table

		IMAPITable * rtable;

		hr = pMsg->GetRecipientTable(0, &rtable);
		if (FAILED(hr))
		{
			goto ExitReadMessage;
		}

		// Query recipients

		SRowSet * psrsRecipients = NULL;

		// Create a dynamically sized string for the recipients
		WCHAR * bufRecipients;
		bufRecipients = (WCHAR *)calloc(1, sizeof(WCHAR));
		wcscpy_s(bufRecipients, 1, L"");

		while (SUCCEEDED(rtable->QueryRows(1, NULL, &psrsRecipients))) {

			// Check for the end of the table.
			if (psrsRecipients->cRows != 1)
			{
				break;
			}

			// Loop through the recipient's properties to find the number
			for (int i = 0; i < psrsRecipients->aRow[0].cValues; i++) {
				if (psrsRecipients->aRow[0].lpProps[i].ulPropTag == PR_EMAIL_ADDRESS) {
					// Make a new string containing the old recipients and the new recipient, seperated by a ";".
					LPWSTR newRecipient = psrsRecipients->aRow[0].lpProps[i].Value.lpszW;
					WCHAR * bufNewRecipients;
					size_t newSize = wcslen(bufRecipients) + wcslen(newRecipient) + 2;
					bufNewRecipients = (WCHAR *)calloc(newSize, sizeof(WCHAR));
					wcscpy_s(bufNewRecipients, newSize, bufRecipients);
					wcscat_s(bufNewRecipients, newSize, newRecipient);
					wcscat_s(bufNewRecipients, newSize, L";");
					free(bufRecipients);
					bufRecipients = bufNewRecipients;
				}
			}

		}

		(*lpszRecipients) = (LPWSTR)bufRecipients;

		goto ContReadMessage;

ExitReadMessage:
		;

ContReadMessage:
		// Clean up
		if (pMsg)
			pMsg->Release();
		// Do not delete rgpropsFlags because it contains the message
		//if (rgpropsFlags)
		//	MAPIFreeBuffer(rgpropsFlags);
		if (rgTagsFlags)
			MAPIFreeBuffer((LPVOID)&rgTagsFlags);
		if (rtable)
			rtable->Release();
		FreeProws(psrsRecipients);
	}

	ULONG STDMETHODCALLTYPE OnNotify(ULONG cNotif, LPNOTIFICATION lpNotifications)
	{
		ULONG result = 0;
		HRESULT hr = E_FAIL;

		// Are the variables initialized?

		if (isInitialized != TRUE) {
			goto ExitNotify;
		}

		// Compare message's folder to the Outbox

		ULONG compareOutbox = NULL;
		
		hr = pSession->CompareEntryIDs(bOutboxEntryId.cb, (LPENTRYID)bOutboxEntryId.lpb, lpNotifications->info.obj.cbParentID, (LPENTRYID)lpNotifications->info.obj.lpParentID, NULL, &compareOutbox);
		if (FAILED(hr))
		{
			goto ExitNotify;
		}

		if (compareOutbox == TRUE) {
			// If the message's in the outbox, call the relevant function
			result = OnNotifyOutbox(cNotif, lpNotifications);
		}

		// Compare message's folder to the Special folder

		ULONG compareSpecial = NULL;

		hr = pSession->CompareEntryIDs(bSpecialEntryId.cb, (LPENTRYID)bSpecialEntryId.lpb, lpNotifications->info.obj.cbParentID, (LPENTRYID)lpNotifications->info.obj.lpParentID, NULL, &compareSpecial);
		if (FAILED(hr))
		{
			goto ExitNotify;
		}

		if (compareSpecial == TRUE) {
			// If the message's in the Special folder, call the relevant function
			result = OnNotifySpecial(cNotif, lpNotifications);
		}

		// All ok

		goto ContNotify;

ExitNotify:
		result = 2;

ContNotify:
		// Clean up
		compareOutbox = NULL;
		compareSpecial = NULL;

		return result;
	}

	ULONG STDMETHODCALLTYPE OnNotifySpecial(ULONG cNotif, LPNOTIFICATION lpNotifications)
	{
		ULONG result = 0;
		HRESULT hr = E_FAIL;
		IMessage* pMsg = NULL;

		// Open Message

		hr = m_pMsgStore->OpenEntry(lpNotifications->info.obj.cbEntryID, lpNotifications->info.obj.lpEntryID, NULL, 0, NULL, (LPUNKNOWN *) &pMsg);
		if (FAILED(hr))
		{
			goto ExitSpecial;
		}

		// Read again the entry id

		SPropValue * rgpropsFlags = NULL;
		ULONG rgTagsFlags[]       = {1, PR_ENTRYID};
		ULONG cCountFlags         = 0;

		hr = pMsg->GetProps((LPSPropTagArray) rgTagsFlags, MAPI_UNICODE, &cCountFlags, &rgpropsFlags);
		if (FAILED(hr))
		{
			goto ExitSpecial;
		}

		if (rgpropsFlags[0].ulPropTag != PR_ENTRYID)
		{
			goto ExitSpecial;
		}

		// Call callback function

		LPWSTR mes = NULL;
		LPWSTR rec = NULL;
		ReadMessage(rgpropsFlags[0].Value.bin.cb, (LPENTRYID) rgpropsFlags[0].Value.bin.lpb, &rec, &mes);

		if (lpFunc) {
			lpFunc(rgpropsFlags[0].Value.bin.cb, (LPENTRYID) rgpropsFlags[0].Value.bin.lpb, rec, mes);
		}

		goto ContSpecial;

ExitSpecial:
		result = 3;

ContSpecial:
		// Clean up
		if (pMsg)
			pMsg->Release();
		// Do not delete rgpropsFlags, it's given to the lpFunc callback function.
		//if (rgpropsFlags)
		//	MAPIFreeBuffer(rgpropsFlags);
		if (rgTagsFlags)
			MAPIFreeBuffer((LPVOID)&rgTagsFlags);

		return result;
	}

	ULONG STDMETHODCALLTYPE OnNotifyOutbox(ULONG cNotif, LPNOTIFICATION lpNotifications)
	{
		BOOL fail = FALSE;
		HRESULT hr = E_FAIL;
		IMessage* pMsg = NULL;

		// Are we collecting the outbox?

		if (doCollectOutbox != TRUE) {
			goto ExitOutbox;
		}

		// Open Message

		hr = m_pMsgStore->OpenEntry(lpNotifications->info.obj.cbEntryID, lpNotifications->info.obj.lpEntryID, NULL, 0, NULL, (LPUNKNOWN *) &pMsg);
		if (FAILED(hr))
		{
			goto ExitOutbox;
		}

		// Get the message's flags

		SPropValue * rgpropsFlags = NULL;
		ULONG rgTagsFlags[]       = {1, PR_MESSAGE_FLAGS};
		ULONG cCountFlags         = 0;

		hr = pMsg->GetProps((LPSPropTagArray) rgTagsFlags, MAPI_UNICODE, &cCountFlags, &rgpropsFlags);
		if (FAILED(hr))
		{
			goto ExitOutbox;
		}

		// Check that's unread

		if (rgpropsFlags[0].Value.ul & MSGFLAG_READ) {
			goto ExitOutbox;
		}

		// Copy the message

		ENTRYLIST lstMoving;
		SBinary sbinMoving;

		lstMoving.cValues = 1;
		sbinMoving.cb = lpNotifications->info.obj.cbEntryID;
		sbinMoving.lpb = (LPBYTE) lpNotifications->info.obj.lpEntryID;
		lstMoving.lpbin = &sbinMoving;

		hr = pOutboxFolder->CopyMessages(&lstMoving, NULL, pSpecial, NULL, NULL, NULL);
		if (FAILED(hr))
		{
			goto ExitOutbox;
		}

		// Delete message

		ENTRYLIST lstDeleting;
		SBinary sbinDeleting;

		lstDeleting.cValues = 1;
		sbinDeleting.cb = lpNotifications->info.obj.cbEntryID;
		sbinDeleting.lpb = (LPBYTE) lpNotifications->info.obj.lpEntryID;
		lstDeleting.lpbin = &sbinDeleting;

		hr = pOutboxFolder->DeleteMessages(&lstDeleting, NULL, NULL, 0);
		if (FAILED(hr))
		{
			goto ExitOutbox;
		}

		goto ContOutbox;

ExitOutbox:
		fail = TRUE;

ContOutbox:
		// Clean up
		if (pMsg)
			pMsg->Release();
		if (rgpropsFlags)
			MAPIFreeBuffer(rgpropsFlags);
		if (rgTagsFlags)
			MAPIFreeBuffer((LPVOID)&rgTagsFlags);
		MAPIFreeBuffer((LPVOID)&lstMoving);
		MAPIFreeBuffer((LPVOID)&sbinMoving);
		MAPIFreeBuffer((LPVOID)&lstDeleting);
		MAPIFreeBuffer((LPVOID)&sbinDeleting);

		if (fail) {
			return 1;
		} else {
			return 0;
		}
	}

	ULONG AddRef(void)
	{
		return ++g_ref;
	}

	ULONG Release(void)
	{
		--g_ref;
		if(g_ref == 0)
		{
			// Clean up
			if (pSession)
				pSession->Release();
			if (pOutboxFolder)
				pOutboxFolder->Release();
			if (pSpecial)
				pSpecial->Release();
			MAPIFreeBuffer((LPVOID)&bOutboxEntryId);
			MAPIFreeBuffer((LPVOID)&bSpecialEntryId);
			g_ref = NULL;
			lpFunc = NULL;
			delete this;
		}
		return g_ref;
	}

	HRESULT QueryInterface(REFIID iid, void** ppvObject)
	{
		HRESULT hr = E_NOINTERFACE;

		if(iid == IID_IUnknown || iid == IID_IMAPIAdviseSink)
		{
			hr = S_OK;
			*ppvObject = this;
		}
		return hr;
	}

	// Function to WriteToLog. Isn't used now.
	void WriteToLog(LPCWSTR message) {
		/*
		char AnsiBuffer[500];
		WideCharToMultiByte(CP_ACP, 0, message, wcslen(message)+1, AnsiBuffer , sizeof(AnsiBuffer), NULL, NULL);

		HANDLE hAppend;
		DWORD dwBytesWritten, dwPos;

		hAppend = CreateFile (TEXT("\\My Documents\\MyLog.txt"),
			GENERIC_WRITE,
			0,                      // Do not share
			NULL,                   // No security
			OPEN_ALWAYS,            // Open or create
			FILE_ATTRIBUTE_NORMAL,  // Normal file
			NULL);                  // No template file

		if (hAppend == INVALID_HANDLE_VALUE)
		{
			return ;
		}

		dwPos = SetFilePointer (hAppend, 0, NULL, FILE_END);
		WriteFile (hAppend, AnsiBuffer, wcslen(message), &dwBytesWritten, NULL);

		CloseHandle (hAppend);
		*/
	}


private:
	IMsgStore*	m_pMsgStore;

};
