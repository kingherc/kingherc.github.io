/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resourceppc.h"
#include "stdafx.h"

class CadvisesinklibraryApp : public CWinApp
{
public:
	CadvisesinklibraryApp();
	BOOL __declspec(dllexport) WINAPI StartCollectingOutbox();
	void __declspec(dllexport) WINAPI SetCallbackFunction(ADVISENOTIFY lpCheckFunc);
	void __declspec(dllexport) WINAPI GetSpecialMessages();
	BOOL __declspec(dllexport) WINAPI AreMessagesEqual(ULONG itemIdSize1, LPENTRYID itemIdPtr1, ULONG itemIdSize2, LPENTRYID itemIdPtr2);
	BOOL __declspec(dllexport) WINAPI SetMessageReadFlag(ULONG itemIdSize, LPENTRYID itemIdPtr, BOOL readFlag);
	BOOL __declspec(dllexport) WINAPI MoveSpecialMessageToOutbox(ULONG itemIdSize, LPENTRYID itemIdPtr);
	BOOL __declspec(dllexport) WINAPI MoveSpecialMessageToSent(ULONG itemIdSize, LPENTRYID itemIdPtr);
	void __declspec(dllexport) WINAPI NotifyUser(DWORD seconds, LPCWSTR title, LPCWSTR htmlMessage, LPCWSTR closeButtonTitle);

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};

