/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

class CAdviseSink : public  IMAPIAdviseSink
{
public:
	__declspec(dllexport) WINAPI CAdviseSink(IMsgStore* pMsgStore);
	__declspec(dllexport) BOOL WINAPI StartCollectingOutbox();
	__declspec(dllexport) void WINAPI SetCallbackFunction(ADVISENOTIFY lpCheckFunc);
	__declspec(dllexport) void WINAPI GetSpecialMessages();
	__declspec(dllexport) ADVISENOTIFY WINAPI GetFunction();
	__declspec(dllexport) BOOL WINAPI AreMessagesEqual(ULONG itemIdSize1, LPENTRYID itemIdPtr1, ULONG itemIdSize2, LPENTRYID itemIdPtr2);
	__declspec(dllexport) BOOL WINAPI SetMessageReadFlag(ULONG itemIdSize, LPENTRYID itemIdPtr, BOOL readFlag);
	__declspec(dllexport) BOOL WINAPI MoveSpecialMessageToOutbox(ULONG itemIdSize, LPENTRYID itemIdPtr);
	__declspec(dllexport) BOOL WINAPI MoveSpecialMessageToSent(ULONG itemIdSize, LPENTRYID itemIdPtr);

private:
	ULONG STDMETHODCALLTYPE OnNotify(ULONG cNotif, LPNOTIFICATION lpNotifications);
	void OnObjectMoved(LPNOTIFICATION lpNotifications);
	ULONG AddRef(void);
	ULONG Release(void);
	HRESULT QueryInterface(REFIID iid, void** ppvObject);

};