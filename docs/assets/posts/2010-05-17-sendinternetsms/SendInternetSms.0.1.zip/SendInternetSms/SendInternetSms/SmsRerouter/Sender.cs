﻿/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using SmsRerouter.SubSource;
using SmsRerouter.Native;
using System.Threading;
using SendSmsLib;
using System.Net;
using System.Xml;
using System.Windows.Forms;

namespace SmsRerouter
{

    public static class Sender
    {

        public static void MonitorOutgoingMessagesList(Object outgoingMessagesList)
        {
            OutgoingMessagesList list = (OutgoingMessagesList) outgoingMessagesList;

            while (true)
            {
                // Wait until list has items
                list.HasItems.WaitOne();

                // Get first message
                OutgoingMessage message = list[0];

                // Count recipients and get the first recipient
                int countRecipients = 0;
                String recipientSingle = "";
                String[] recipients = message.Recipients.Split(new Char[] { ';' });
                foreach (String recipient in recipients)
                {
                    if (!(String.IsNullOrEmpty(recipient) || recipient.Trim().CompareTo("") == 0))
                    {
                        countRecipients++;
                        recipientSingle = recipient;
                    }
                }

                // Message body summary to display in popup
                String messageToDisplay = "\"" + ((message.Message.Length > 60) ? (message.Message.Substring(0, 60) + "...") : message.Message) + "\"";

                // Send message
                if (countRecipients == 1)
                {
                    // Send message through the program
                    ISmsService service = SmsServicesContainer.Instance.SendSmsMessage(recipientSingle, message.Message);
                    if (service != null)
                    {
                        Program.ShowNotification(messageToDisplay + " was sent successfully using the following SMS Service:\n\n" + service.Name);
                        message.SetReadFlag(true);
                        message.MoveSpecialMessageToSent();
                    }
                    else
                    {
                        // Program.ShowNotification(messageToDisplay + " failed to be sent by SmsRerouter. The SMS will be handed over to the platform.");
                        message.SetReadFlag(true);
                        message.MoveSpecialMessageToOutbox();
                    }
                    ;
                }
                else
                {
                    // The program cannot handle yet multiple recipients. This message will be sent as usual through the outbox.
                    // It must be made read, so that it won't be picked up again by the program.
                    // Program.ShowNotification(messageToDisplay + " has multiple recipients. SmsRerouter cannot handle multiple recipients yet. The SMS will be handed over to the platform.");
                    message.SetReadFlag(true);
                    message.MoveSpecialMessageToOutbox();
                }

                // Sleep a bit
                Thread.Sleep(500);

                // Remove message from the list
                list.Remove(message);
            }
        }

    }
}
