﻿For more information visit either
http://www.studentguru.gr/blogs/kingherc
or
http://www.kingherc.com

SmsRerouter is part of SendInternetSms. The license for SendInternetSms is the GNU GPLv3. You should have received the license with your copy of SendInternetSms.