﻿/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace SmsRerouter.SubSource
{

    public class OutgoingMessagesList : System.Collections.Generic.List<OutgoingMessage>
    {

        // Properties
        private ManualResetEvent hasItems = new ManualResetEvent(false);
        public ManualResetEvent HasItems
        {
            get
            {
                return hasItems;
            }
        }

        // Methods

        public new void Add(OutgoingMessage message)
        {
            // Contains checks to see if there's the same message already in the list.
            // It uses the OutgoingMessage's IEquatable.Equals method.
            if (!this.Contains(message))
            {
                base.Add(message);
                if (this.Count > 0)
                {
                    hasItems.Set();
                }
            }
        }

        public new bool Remove(OutgoingMessage message)
        {
            if (base.Remove(message))
            {
                if (this.Count <= 0)
                {
                    hasItems.Reset();
                }
                return true;
            }
            else
            {
                return false;
            }

        }

        public override String ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach(OutgoingMessage message in this) {
                sb.AppendLine(message.ToString());
            }
            return sb.ToString();
        }

    }
}
