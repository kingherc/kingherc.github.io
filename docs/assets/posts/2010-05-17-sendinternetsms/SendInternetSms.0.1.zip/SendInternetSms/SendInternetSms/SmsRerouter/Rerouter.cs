﻿/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using SmsRerouter.SubSource;
using SmsRerouter.Native;
using System.Threading;
using SendSmsLib;
using System.IO;

namespace SmsRerouter
{
    public class Rerouter
    {

        // Properties

        private OutgoingMessagesList messagesList;
        public OutgoingMessagesList MessagesList
        {
            get
            {
                return messagesList;
            }
        }

        // Fields

        private NewMessageCallback newMessageCallback; // The callback variable should stay here, so that the garbage collector does not collect it.

        // Constructor

        public Rerouter()
        {
            // Create Message list
            messagesList = new OutgoingMessagesList();

            // Start collecting outbox unread messages and move them to the Special folder.
            if (NativeCalls.StartCollectingOutbox() > 0)
            {
                // Set callback function that notifies us for new messages in the Special folder.
                newMessageCallback = new NewMessageCallback(this.NewMessage);
                NativeCalls.SetCallbackFunction(newMessageCallback);
            }

            // Also get the messages that are currently in the Special folder
            NativeCalls.GetSpecialMessages();
        }

        // Methods

        public void NewMessage(
            uint itemIdSize,
            IntPtr itemIdPtr,
            string lpszRecipients,
            string lpszMessage)
        {
            OutgoingMessage message = new OutgoingMessage(itemIdSize, itemIdPtr, lpszRecipients, lpszMessage);
            messagesList.Add(message);
        }

    }
}
