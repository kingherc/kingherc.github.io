﻿/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using SendSmsLib;
using SmsRerouter.Native;
using SmsRerouter.SubSource;
using System.IO;
using System.Windows.Forms;

namespace SmsRerouter
{
    class Program
    {

        public static Rerouter mainRerouter = null;

        [MTAThread]
        static void Main(string[] args)
        {
            // Configure thread priority
            Thread.CurrentThread.Priority = ThreadPriority.Highest;

            // Configure SendSmsLib
            Configurator.Configure();

            // Start monitoring Outbox
            mainRerouter = new Rerouter();

            // Get SMS Services loaded by SendSmsLib
            int serviceNumber = 1;
            String services = "";
            foreach (ISmsService service in SmsServicesContainer.Instance)
            {
                services += serviceNumber + ") " + service.Name + "\n";
                serviceNumber++;
            }

            // Show up popup
            if (GetPlatformType() == PlatformType.Smartphone)
            {
                ShowNotification("Started monitoring the SMS Outbox folder. The SMS Services loaded, are:\n\n" + services);
            }
            else
            {
                NativeCalls.NotifyUser(10, "SmsRerouter", "Started monitoring the SMS Outbox folder. The SMS Services loaded, are:<br /><br /><textarea rows=\"4\" cols=\"40\">" + services + "</textarea>", "Dismiss");
            }

            // Start Sender thread

            if (!ThreadPool.QueueUserWorkItem(new WaitCallback(Sender.MonitorOutgoingMessagesList), mainRerouter.MessagesList))
            {
                ShowNotification("Could not start Sender thread.");
            }

            // Keep program alive
            while (true)
            {
                System.Windows.Forms.Application.DoEvents();
                Thread.Sleep(10);
            }
        }

        // Helpful Methods

        public static void ShowNotification(String message)
        {
            if (GetPlatformType() == PlatformType.Smartphone)
            {
                MessageBox.Show(message, "SmsRerouter", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
            }
            else
            {
                NativeCalls.NotifyUser(5, "SmsRerouter", message.Replace("\n", "<br />"), "Dismiss");
            }
        }

        private static PlatformType? CurrentPlatformType = null;
        public static PlatformType GetPlatformType()
        {
            if (!CurrentPlatformType.HasValue)
            {
                Byte[] buffer = new Byte[100];
                String rc = "";
                NativeCalls.SystemParametersInfo(257, buffer.Length, buffer, 0);
                rc = Encoding.Unicode.GetString(buffer, 0, buffer.Length).ToLower();
                if (rc.Contains("Smartphone".ToLower()))
                {
                    return PlatformType.Smartphone;
                }
                else
                {
                    return PlatformType.PocketPC;
                }
            }
            else
            {
                return CurrentPlatformType.Value;
            }
        }

        public enum PlatformType
        {
            PocketPC,
            Smartphone
        }

    }
}
