﻿/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace SmsRerouter.Native
{

    public delegate void NewMessageCallback(
    uint itemIdSize,
    IntPtr itemIdPtr,
    [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPWStr)]
            string lpszRecipients,
    [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPWStr)]
            string lpszMessage);

    public static class NativeCalls
    {

        [DllImport("coredll.dll", EntryPoint = "SystemParametersInfo")]
        public static extern int SystemParametersInfo(int uiAction, int uiParam, Byte[] pvParam, int fWinIni);

        [DllImport("advisesinklibrary.dll", EntryPoint = "StartCollectingOutbox")]
        public static extern int StartCollectingOutbox();

        [DllImport("advisesinklibrary.dll", EntryPoint = "SetCallbackFunction")]
        public static extern int SetCallbackFunction(NewMessageCallback x);

        [DllImport("advisesinklibrary.dll", EntryPoint = "GetSpecialMessages")]
        public static extern int GetSpecialMessages();

        [DllImport("advisesinklibrary.dll", EntryPoint = "NotifyUser")]
        public static extern int NotifyUser(
            uint seconds,
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPWStr)]
            string title,
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPWStr)]
            string htmlMessage,
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPWStr)]
            string closeButtonTitle
        );

        [DllImport("advisesinklibrary.dll", EntryPoint = "MoveSpecialMessageToOutbox")]
        public static extern int MoveSpecialMessageToOutbox(
            uint itemIdSize,
            IntPtr itemIdPtr
        );

        [DllImport("advisesinklibrary.dll", EntryPoint = "MoveSpecialMessageToSent")]
        public static extern int MoveSpecialMessageToSent(
            uint itemIdSize,
            IntPtr itemIdPtr
        );

        [DllImport("advisesinklibrary.dll", EntryPoint = "AreMessagesEqual")]
        public static extern int AreMessagesEqual(
            uint itemIdSize1,
            IntPtr itemIdPtr1,
            uint itemIdSize2,
            IntPtr itemIdPtr2
        );

        [DllImport("advisesinklibrary.dll", EntryPoint = "SetMessageReadFlag")]
        public static extern int SetMessageReadFlag(
            uint itemIdSize,
            IntPtr itemIdPtr,
            int readFlag
        );

    }
}
