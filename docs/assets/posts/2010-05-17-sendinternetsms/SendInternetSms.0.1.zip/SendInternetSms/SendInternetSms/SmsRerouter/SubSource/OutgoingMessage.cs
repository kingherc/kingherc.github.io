﻿/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using SmsRerouter.Native;

namespace SmsRerouter.SubSource
{
    public class OutgoingMessage : IEquatable<OutgoingMessage>
    {

        // Properties

        public uint ItemIdSize { get; set; }

        public IntPtr ItemIdPtr { get; set; }

        public string Recipients { get; set; }

        public string Message { get; set; }

        // Constructor

        public OutgoingMessage(uint itemIdSize, IntPtr itemIdPtr, string recipients, string message)
        {
            ItemIdSize = itemIdSize;
            ItemIdPtr = itemIdPtr;
            Recipients = recipients;
            Message = message;
        }

        // Methods

        public Boolean SetReadFlag(Boolean readFlag)
        {
            return (NativeCalls.SetMessageReadFlag(this.ItemIdSize, this.ItemIdPtr, readFlag ? 1 : 0) > 0);
        }

        public Boolean MoveSpecialMessageToOutbox()
        {
            return (NativeCalls.MoveSpecialMessageToOutbox(this.ItemIdSize, this.ItemIdPtr) > 0);
        }

        public Boolean MoveSpecialMessageToSent()
        {
            return (NativeCalls.MoveSpecialMessageToSent(this.ItemIdSize, this.ItemIdPtr) > 0);
        }

        public override String ToString()
        {
            return "[ " + Recipients + " | " + Message + " ]";
        }


        #region IEquatable<OutgoingMessage> Members

        public bool Equals(OutgoingMessage other)
        {
            return (NativeCalls.AreMessagesEqual(this.ItemIdSize, this.ItemIdPtr, other.ItemIdSize, other.ItemIdPtr) > 0);
        }

        #endregion
    }
}
