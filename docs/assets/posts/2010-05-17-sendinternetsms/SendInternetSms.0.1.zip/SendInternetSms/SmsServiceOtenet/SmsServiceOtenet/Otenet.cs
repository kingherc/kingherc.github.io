﻿using System;

using System.Collections.Generic;
using System.Text;
using SendSmsLib;
using SendSmsLib.WebHelper;
using System.Net;
using System.IO;

namespace SmsServiceOtenet
{
    public class Otenet : ISmsService
    {

        // Properties

        private string UsernameGiven { get; set; }
        private string PasswordGiven { get; set; }

        public string Name
        {
            get { return "Otenet Tools (" + UsernameGiven + ")"; }
        }

        // Methods

        public bool Init(Dictionary<string, string> parameters)
        {
            UsernameGiven = parameters["username"];
            PasswordGiven = parameters["password"];
            return true;
        }

        public bool SendSmsMessage(string recipient, string message)
        {
            // Strips special characters and country codes
            String formattedRecipient = Helper.StripStringOfCountryCodes(Helper.FormatPhoneNumber(recipient));

            CookieManager cookieManager = new CookieManager();

            // 1. Visit the website to get a cookie

            HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create("https://tools.otenet.gr/tools/index.do");
            myRequest.KeepAlive = false;
            // Remember to use "using" with responses, so as to close the response stream.
            // If it stays open, the connection will stay open. Because, by default, only
            // 2 peristent connections are allowed to a server, following requests will fail.
            using (HttpWebResponse response = (HttpWebResponse)myRequest.GetResponse())
            {
                cookieManager.StoreCookies(response);
            }

            // 2. Log into the website. Get newer cookie.

            myRequest = (HttpWebRequest)WebRequest.Create("https://tools.otenet.gr/tools/tiles/login/login.do");
            myRequest.Method = "POST";
            myRequest.Referer = "https://tools.otenet.gr/tools/index.do";
            myRequest.ContentType = "application/x-www-form-urlencoded";
            String postData = "username=" + UriEscape.EscapeUriDataStringRfc3986(UsernameGiven) + "&password=" + UriEscape.EscapeUriDataStringRfc3986(PasswordGiven) + "&logontry=true";
            cookieManager.PublishCookies(myRequest);

            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] postDataBytes = encoding.GetBytes(postData);
            myRequest.ContentLength = postDataBytes.Length;
            Stream newStream = myRequest.GetRequestStream();
            newStream.Write(postDataBytes, 0, postDataBytes.Length);
            newStream.Close();

            myRequest.AllowAutoRedirect = false;
            myRequest.AllowWriteStreamBuffering = false;
            myRequest.KeepAlive = false;

            HttpWebResponse response2;
            try
            {
                using (response2 = (HttpWebResponse)myRequest.GetResponse())
                {
                    ;
                }
            }
            catch (WebException e)
            {
                cookieManager.StoreCookies((HttpWebResponse)e.Response);
                e.Response.Close();
            }

            // 3. Send SMS

            HttpWebRequest myRequest3 = (HttpWebRequest)WebRequest.Create("http://tools.otenet.gr/tools/tiles/web2sms/sendsms.do?showPage=smsSend&mnu=smenu23");
            myRequest3.Method = "POST";
            myRequest3.Referer = "http://tools.otenet.gr/tools/tiles/web2sms.do?showPage=smsSend&mnu=smenu23";
            myRequest3.ContentType = "application/x-www-form-urlencoded";
            String postData3 = @"phone=" + UriEscape.EscapeUriDataStringRfc3986(formattedRecipient) + "&message=" + UriEscape.EscapeUriDataStringRfc3986(message).Replace("%20", "+") + "&laterfinal=null";
            cookieManager.PublishCookies(myRequest3);

            ASCIIEncoding encoding3 = new ASCIIEncoding();
            byte[] postDataBytes3 = encoding.GetBytes(postData3);
            myRequest3.ContentLength = postDataBytes3.Length;
            Stream newStream3 = myRequest3.GetRequestStream();
            newStream3.Write(postDataBytes3, 0, postDataBytes3.Length);
            newStream3.Close();

            myRequest3.KeepAlive = false;

            String result;
            using (HttpWebResponse response3 = (HttpWebResponse)myRequest3.GetResponse())
            {
                result = Helper.StreamToString(response3.GetResponseStream()).ToLower();
            }

            if (result.IndexOf("επιτυχώς") < 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

    }
}
