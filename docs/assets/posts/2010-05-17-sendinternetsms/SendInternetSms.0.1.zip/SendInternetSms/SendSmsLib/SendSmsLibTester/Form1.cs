﻿/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SendSmsLib;

namespace SendSmsLibTester
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

            Configurator.Configure();

            foreach (ISmsService service in SmsServicesContainer.Instance)
            {
                this.lstServices.Items.Add(service.Name);
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            ISmsService service = SmsServicesContainer.Instance.SendSmsMessage(txtRecipient.Text, txtMessage.Text);
            if (service == null)
            {
                MessageBox.Show("The SMS message failed to be sent.");
            }
            else
            {
                MessageBox.Show("The SMS message was sent successfully using the following SMS Service:\n\"" + service.Name + "\"");
            }
        }

    }
}
