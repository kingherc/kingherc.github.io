﻿/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.Text;
using SendSmsLib;
using SendSmsLib.WebHelper;

namespace FakeSmsService
{
    public class FakeSmsService : ISmsService
    {

        // Properties

        protected String UsernameGiven { get; set; }
        protected String PasswordGiven { get; set; }

        public string Name
        {
            get { return "Fake SMS Service (" + UsernameGiven + ")"; }
        }

        // Methods

        public bool Init(Dictionary<string, string> parameters)
        {
            UsernameGiven = parameters["username"];
            PasswordGiven = parameters["password"];
            return true;
        }

        public bool SendSmsMessage(string recipient, string message)
        {
            // Strips special characters and country codes
            String formattedRecipient = Helper.StripStringOfCountryCodes(Helper.FormatPhoneNumber(recipient));

            // Fake authentication
            if (UsernameGiven.CompareTo("fakeusername") == 0 && PasswordGiven.CompareTo("fakepassword") == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
