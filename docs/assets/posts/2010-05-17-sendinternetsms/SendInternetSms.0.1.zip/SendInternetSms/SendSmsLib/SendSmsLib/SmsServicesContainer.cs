﻿/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;

using System.Collections.Generic;
using System.Text;

namespace SendSmsLib
{
    public class SmsServicesContainer : IEnumerable<ISmsService>
    {

        #region Singleton

        class Nested
        {
            static Nested() { }
            internal static readonly SmsServicesContainer instance = new SmsServicesContainer();
        }

        public static SmsServicesContainer Instance {
            get {
                return Nested.instance;
            }
        }

        private SmsServicesContainer()
        {
        }

        #endregion

        #region IEnumerable<ISmsService> Members

        public IEnumerator<ISmsService> GetEnumerator()
        {
            return new SmsServicesContainerEnumerator(this);
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return new SmsServicesContainerEnumerator(this);
        }

        private class SmsServicesContainerEnumerator : IEnumerator<ISmsService>
        {
            private int enumCounter = -1;
            private SmsServicesContainer t;

            public SmsServicesContainerEnumerator(SmsServicesContainer t)
            {
                this.t = t;
            }

            public bool MoveNext()
            {
                enumCounter++;
                return (enumCounter < t.smsServices.Count);
            }

            public void Reset()
            {
                enumCounter = -1;
            }

            public ISmsService Current
            {
                get { return t.smsServices[enumCounter]; }
            }

            object System.Collections.IEnumerator.Current
            {
                get
                {
                    return t.smsServices[enumCounter];
                }
            }

            public void Dispose()
            {
                ;
            }
        }

        #endregion

        private List<ISmsService> smsServices = new List<ISmsService>();

        public void AddSmsService(ISmsService smsService, Dictionary<String, String> parameters)
        {
            try
            {
                if (smsService.Init(parameters))
                {
                    smsServices.Add(smsService);
                }
            }
            catch (Exception e)
            {
                ;
            }
        }


        /// <summary>
        /// Sends an SMS Message with one of the appointed SMS Services. It tries each SMS Service in order until one of them sends the message successfully.
        /// </summary>
        /// <param name="recipient">The recipient of the SMS message.</param>
        /// <param name="message">The SMS message itself. Configurator.AppendToMessage is appended to the message.</param>
        /// <returns>Returns the ISmsService that sent the SMS successfully. If all ISmsServices failed, it returns null.</returns>
        public ISmsService SendSmsMessage(String recipient, String message)
        {
            if (Configurator.SendOnlyWhenConnected && !Configurator.IsConnected())
            {
                return null;
            }

            String messageToSend = message;
            messageToSend += Configurator.AppendToMessage;

            foreach (ISmsService service in this)
            {
                try
                {
                    if (service.SendSmsMessage(recipient, messageToSend))
                    {
                        return service;
                    }
                }
                catch (Exception e)
                {
                    ;
                }
            }
            return null;
        }

    }
}
