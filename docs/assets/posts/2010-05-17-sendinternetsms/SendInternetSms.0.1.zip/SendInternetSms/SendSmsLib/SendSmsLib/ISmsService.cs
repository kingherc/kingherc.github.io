﻿/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;

using System.Collections.Generic;
using System.Text;

namespace SendSmsLib
{
    public interface ISmsService
    {

        // Properties

        /// <summary>
        /// A friendly name to show for this service. It should usually be the service name, plus the username used (if any).
        /// e.g. "Fake SMS Service (mary)"
        /// </summary>
        String Name { get; }

        // Methods

        /// <summary>
        /// Initilizes the service with the parameters given. The parameters are usually these are loaded automatically from the Configurator, by  getting them from the configuration file. The parameters should be stored internally if the service requires them for sending an SMS. The parameters can include things like a username and a password.
        /// </summary>
        /// <param name="parameters">Any parameters required by the service. Usually these are loaded automatically from the Configurator, by  getting them from the configuration file.</param>
        /// <returns>True if the initialization completed successfully. Otherwise, False.</returns>
        Boolean Init(Dictionary<String, String> parameters);

        /// <summary>
        /// Sends the SMS message through this service.
        /// </summary>
        /// <param name="recipient">The recipient of the SMS message.</param>
        /// <param name="message">The body of the SMS message.</param>
        /// <returns>True if the SMS message was sent successfully. Otherwise, False.</returns>
        Boolean SendSmsMessage(String recipient, String message);

    }
}
