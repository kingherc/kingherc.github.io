﻿/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace SendSmsLib.WebHelper
{
    public static class Helper
    {

        /// <summary>
        /// Gets a String out of a Stream.
        /// </summary>
        public static String StreamToString(Stream s)
        {
            String contents = null;
            using (StreamReader reader = new StreamReader(s))
            {
                contents = reader.ReadToEnd();
            }
            return contents;
        }

        /// <summary>
        /// Strips any non-numeric character from the given string. The only special character that will be allowed is +.
        /// </summary>
        public static String FormatPhoneNumber(String str)
        {
            String newstr = "";
            foreach (char c in str)
            {
                if (Char.IsNumber(c) || c == '+')
                {
                    newstr += c;
                }
            }
            return newstr;
        }

        /// <summary>
        /// Tries to strip country codes (in the format of "+n") from the given string.
        /// </summary>
        public static String StripStringOfCountryCodes(String str)
        {
            String newstr = str;
            foreach (String countrycode in countryCodes)
            {
                newstr = newstr.Replace(countrycode, "");
            }
            return newstr;
        }

        private static List<String> countryCodes = new List<String>(new String[] {
"+7",
"+93",
"+355",
"+213",
"+684",
"+376",
"+244",
"+1264",
"+1268",
"+54",
"+374",
"+297",
"+61",
"+43",
"+994",
"+1242",
"+973",
"+880",
"+375",
"+32",
"+501",
"+229",
"+975",
"+591",
"+387",
"+267",
"+55",
"+673",
"+359",
"+226",
"+257",
"+855",
"+287",
"+1",
"+238",
"+56",
"+506",
"+86",
"+57",
"+269",
"+242",
"+243",
"+385",
"+53",
"+357",
"+420",
"+45",
"+253",
"+1767",
"+670",
"+593",
"+20",
"+503",
"+240",
"+291",
"+372",
"+251",
"+679",
"+358",
"+33",
"+220",
"+995",
"+49",
"+233",
"+350",
"+30",
"+1473",
"+502",
"+224",
"+245",
"+592",
"+509",
"+504",
"+852",
"+36",
"+354",
"+91",
"+62",
"+98",
"+964",
"+353",
"+972",
"+39",
"+225",
"+876",
"+81",
"+962",
"+254",
"+381",
"+377",
"+965",
"+996",
"+856",
"+371",
"+961",
"+266",
"+218",
"+423",
"+370",
"+352",
"+853",
"+389",
"+261",
"+265",
"+60",
"+960",
"+223",
"+356",
"+222",
"+230",
"+52",
"+373",
"+382",
"+976",
"+212",
"+258",
"+95",
"+674",
"+977",
"+31",
"+64",
"+505",
"+234",
"+850",
"+47",
"+968",
"+92",
"+970",
"+507",
"+675",
"+595",
"+51",
"+63",
"+48",
"+351",
"+974",
"+40",
"+250",
"+685",
"+378",
"+239",
"+966",
"+221",
"+248",
"+232",
"+65",
"+421",
"+386",
"+27",
"+82",
"+34",
"+94",
"+249",
"+597",
"+268",
"+46",
"+41",
"+963",
"+886",
"+992",
"+255",
"+66",
"+228",
"+216",
"+90",
"+993",
"+256",
"+380",
"+971",
"+44",
"+598",
"+998",
"+678",
"+58",
"+84",
"+967",
"+260",
"+263"
    });

    }
}
