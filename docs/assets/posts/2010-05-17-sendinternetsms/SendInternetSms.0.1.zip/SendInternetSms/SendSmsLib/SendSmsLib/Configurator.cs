﻿/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;

using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.IO;
using System.Xml;
using System.Net;

namespace SendSmsLib
{
    public static class Configurator
    {

        private static string configFilePath;
        public static String AppendToMessage { get; set; }
        public static Boolean SendOnlyWhenConnected { get; set; }

        public static void Configure()
        {
            // Check for config.xml

            if (Environment.OSVersion.Platform == PlatformID.WinCE)
            {
                configFilePath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
            }
            else
            {
                configFilePath = Directory.GetCurrentDirectory();
            }
            configFilePath += @"\config.xml";

            Configure(configFilePath);
        }

        public static void Configure(String ConfigFilePath)
        {
            configFilePath = ConfigFilePath;
            if (!File.Exists(configFilePath))
                throw new Exception("The configuration file " + configFilePath + " could not be found.");

            // Load xml document

            XmlDocument xdoc = new XmlDocument();
            xdoc.Load(configFilePath);
            XmlElement xroot = xdoc.DocumentElement;

            // Load SMS Services

            XmlElement xSmsServices = (XmlElement) xroot.GetElementsByTagName("SmsServices").Item(0);
            XmlNodeList xSmsServiceList = xSmsServices.ChildNodes;

            foreach (XmlNode xSmsServiceNode in xSmsServiceList) {
                try
                {
                    XmlElement xSmsService = (XmlElement)xSmsServiceNode;
                    String typeQualifiedName = String.Empty;

                    // Get all parameters
                    Dictionary<String, String> parameters = new Dictionary<string, string>();
                    foreach (XmlAttribute xAttribute in xSmsService.Attributes)
                    {
                        if (xAttribute.Name.CompareTo("type") == 0)
                        {
                            typeQualifiedName = xAttribute.Value;
                        }
                        else
                        {
                            if (!parameters.ContainsKey(xAttribute.Name))
                            {
                                parameters.Add(xAttribute.Name, xAttribute.Value);
                            }
                        }
                    }

                    ISmsService service = LoadObject<ISmsService>(typeQualifiedName);
                    SmsServicesContainer.Instance.AddSmsService(service, parameters);
                }
                catch (Exception e)
                {
                    ;
                }
            }

            // Load AppendToMessage

            XmlElement xAppendToMessage = (XmlElement)xroot.GetElementsByTagName("AppendToMessage").Item(0);
            AppendToMessage = xAppendToMessage.InnerText;

            // Load SendOnlyWhenConnected

            XmlElement xSendOnlyWhenConnected = (XmlElement)xroot.GetElementsByTagName("SendOnlyWhenConnected").Item(0);
            SendOnlyWhenConnected = Boolean.Parse(xSendOnlyWhenConnected.Attributes["value"].Value);
        }

        private static T LoadObject<T>(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new Exception("Empty type name in configuration file.");
            }
            Type t = Type.GetType(name);
            if (t == null)
                throw new Exception("Could not load type name " + name);
            Type[] types = new Type[0];
            return (T)t.GetConstructor(types).Invoke(null);
        }

        public static Boolean IsConnected()
        {
            Boolean ret;
            try
            {
                String hostName = Dns.GetHostName();
                IPHostEntry thisHost = Dns.GetHostByName(hostName);
                String thisIpAddr = thisHost.AddressList[0].ToString();
                ret = thisIpAddr.CompareTo(System.Net.IPAddress.Parse("127.0.0.1").ToString()) != 0;
            }
            catch (Exception e)
            {
                return false;
            }
            return ret;
        }

    }
}
