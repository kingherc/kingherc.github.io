﻿/*
Copyright 2010 Iraklis Psaroudakis

This file is part of SendInternetSms.

SendInternetSms is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SendInternetSms is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SendInternetSms.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SendSmsLib;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.IsAuthenticated)
        {
            AuthenticatedMessagePanel.Visible = true;
            AnonymousMessagePanel.Visible = false;
        }
        else
        {
            Response.Redirect("~/Login.aspx");
        }
    }
    protected void ButtonSend_Click(object sender, EventArgs e)
    {
        if (TextBoxReceiver.Text == "")
        {
            lblStatus.ForeColor = System.Drawing.Color.Red;
            lblStatus.Text = "Please give the receiver.";
        }
        else
        {
            ISmsService service = SmsServicesContainer.Instance.SendSmsMessage(TextBoxReceiver.Text, TextBoxMessage.Text);
            if (service == null)
            {
                lblStatus.ForeColor = System.Drawing.Color.Red;
                lblStatus.Text = "The message failed to be sent.";
            }
            else
            {
                lblStatus.ForeColor = System.Drawing.Color.Green;
                lblStatus.Text = "Sent successfully with:<br />" + service.Name;
            }
        }
        lblStatus.Visible = true;
        TextBoxReceiver.Text = "";
        TextBoxMessage.Text = "";
    }
}
