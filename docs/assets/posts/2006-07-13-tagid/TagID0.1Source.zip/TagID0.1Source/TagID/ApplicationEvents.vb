#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Imports Microsoft.Win32

Namespace My

    ' The following events are availble for MyApplication:
    ' 
    ' Startup: Raised when the application starts, before the startup form is created.
    ' Shutdown: Raised after all application forms are closed.  This event is not raised if the application terminates abnormally.
    ' UnhandledException: Raised if the application encounters an unhandled exception.
    ' StartupNextInstance: Raised when launching a single-instance application and the application is already active. 
    ' NetworkAvailabilityChanged: Raised when the network connection is connected or disconnected.
    Partial Friend Class MyApplication

        Private Sub MyApplication_Startup(ByVal sender As Object, ByVal e As Microsoft.VisualBasic.ApplicationServices.StartupEventArgs) Handles Me.Startup
            'Check and update the registry
            'Dim rC As RegistryKey = My.Computer.Registry.ClassesRoot
            'If Array.IndexOf(rC.GetSubKeyNames, "TagID.id3") = -1 Then
            '    rC.Close()
            '    CreateRegistryKeys()
            'End If

            UltraID3LibExtender.Helper.InitializeLibrary()

            Dim nrender As New ProfessionalColorTable
            nrender.UseSystemColors = True
            ToolStripManager.Renderer = New ToolStripProfessionalRenderer(nrender)
        End Sub

        'Private Sub CreateRegistryKeys()
        '    Dim appath As String = My.Application.Info.DirectoryPath & "\TagID.exe"
        '    Dim rC As RegistryKey = My.Computer.Registry.ClassesRoot

        '    'Create the HKEY_CLASSES_ROOT\TagID.id3 key
        '    Dim tC As RegistryKey = rC.CreateSubKey("TagID.id3")
        '    tC.SetValue("", "MPEG Layer 3 Audio")
        '    Dim defaulticonC As RegistryKey = tC.CreateSubKey("DefaultIcon")
        '    defaulticonC.SetValue("", appath & ",0")
        '    Dim shellC As RegistryKey = tC.CreateSubKey("Shell")
        '    shellC.SetValue("", "open")
        '    Dim openC As RegistryKey = shellC.CreateSubKey("open")
        '    Dim commandC As RegistryKey = openC.CreateSubKey("command")
        '    commandC.SetValue("", """" & appath & """ ""%1""")

        '    defaulticonC.Close()
        '    commandC.Close()
        '    openC.Close()
        '    shellC.Close()
        '    tC.Close()

        '    'Associate TagID.id3 key with the .mp3 class
        '    Dim mp3C As RegistryKey = rC.CreateSubKey(".mp3")
        '    Dim openwithC As RegistryKey = mp3C.CreateSubKey("OpenWithProgIds")
        '    openwithC.SetValue("TagID.id3", New Byte() {}, RegistryValueKind.Binary)

        '    openwithC.Close()
        '    mp3C.Close()

        '    rC.Close()

        '    SHChangeNotify(&H8000000, &H0, Nothing, Nothing)
        'End Sub

        'Declare Sub SHChangeNotify Lib "shell32.dll" (ByVal wEventsID As Integer, ByVal uFlags As Integer, ByVal dwItem1 As Integer, ByVal dwItem2 As Integer)

    End Class

End Namespace

