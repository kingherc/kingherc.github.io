TagID 0.1
by Kingherc
===========

The real ReadMe file for this program is the file ID3TagEditorHelp.htm in the folder TagIDEditor\Resources which can be viewed with any browser off-line.

The license for this program can be found in the text file License.txt in the folder TagIDEditor\Resources.

The Gnu General Public License can be found in the text file GPL.txt in the folder TagIDEditor\Resources.

TagID was developped using Microsoft Visual Studio 2005.

More information or contact at http://www34.brinkster.com/kingherc/.

31/1/07: The website's address changed from http://www34.brinkster.com/kingherc/ to http://kherc.brinkster.net/.