#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Namespace UltraID3LibExtender.TypeEditors
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class FrameFlagsControl
        Inherits System.Windows.Forms.UserControl

        'UserControl overrides dispose to clean up the component list.
        <System.Diagnostics.DebuggerNonUserCode()> _
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrameFlagsControl))
            Me.chkCompressed = New System.Windows.Forms.CheckBox
            Me.chkEncrypted = New System.Windows.Forms.CheckBox
            Me.chkFileAlterPreservation = New System.Windows.Forms.CheckBox
            Me.chkGroupingIdentity = New System.Windows.Forms.CheckBox
            Me.chkReadOnly = New System.Windows.Forms.CheckBox
            Me.chkTagAlterPreservation = New System.Windows.Forms.CheckBox
            Me.tip = New System.Windows.Forms.ToolTip(Me.components)
            Me.lblClose = New System.Windows.Forms.LinkLabel
            Me.SuspendLayout()
            '
            'chkCompressed
            '
            Me.chkCompressed.AutoSize = True
            Me.chkCompressed.Location = New System.Drawing.Point(3, 3)
            Me.chkCompressed.Name = "chkCompressed"
            Me.chkCompressed.Size = New System.Drawing.Size(109, 21)
            Me.chkCompressed.TabIndex = 0
            Me.chkCompressed.Text = "Compressed"
            Me.tip.SetToolTip(Me.chkCompressed, "This flag indicates whether or not the frame is compressed.")
            Me.chkCompressed.UseVisualStyleBackColor = True
            '
            'chkEncrypted
            '
            Me.chkEncrypted.AutoSize = True
            Me.chkEncrypted.Location = New System.Drawing.Point(3, 24)
            Me.chkEncrypted.Name = "chkEncrypted"
            Me.chkEncrypted.Size = New System.Drawing.Size(94, 21)
            Me.chkEncrypted.TabIndex = 1
            Me.chkEncrypted.Text = "Encrypted"
            Me.tip.SetToolTip(Me.chkEncrypted, resources.GetString("chkEncrypted.ToolTip"))
            Me.chkEncrypted.UseVisualStyleBackColor = True
            '
            'chkFileAlterPreservation
            '
            Me.chkFileAlterPreservation.AutoSize = True
            Me.chkFileAlterPreservation.Location = New System.Drawing.Point(3, 45)
            Me.chkFileAlterPreservation.Name = "chkFileAlterPreservation"
            Me.chkFileAlterPreservation.Size = New System.Drawing.Size(169, 21)
            Me.chkFileAlterPreservation.TabIndex = 2
            Me.chkFileAlterPreservation.Text = "File Alter Preservation"
            Me.tip.SetToolTip(Me.chkFileAlterPreservation, "This flag tells the software what to do with this frame if it is unknown" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and the" & _
                    " file, excluding the tag, is altered. This does not apply when" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "the audio is com" & _
                    "pletely replaced with other audio data.")
            Me.chkFileAlterPreservation.UseVisualStyleBackColor = True
            '
            'chkGroupingIdentity
            '
            Me.chkGroupingIdentity.AutoSize = True
            Me.chkGroupingIdentity.Location = New System.Drawing.Point(3, 66)
            Me.chkGroupingIdentity.Name = "chkGroupingIdentity"
            Me.chkGroupingIdentity.Size = New System.Drawing.Size(138, 21)
            Me.chkGroupingIdentity.TabIndex = 3
            Me.chkGroupingIdentity.Text = "Grouping Identity"
            Me.tip.SetToolTip(Me.chkGroupingIdentity, resources.GetString("chkGroupingIdentity.ToolTip"))
            Me.chkGroupingIdentity.UseVisualStyleBackColor = True
            '
            'chkReadOnly
            '
            Me.chkReadOnly.AutoSize = True
            Me.chkReadOnly.Location = New System.Drawing.Point(3, 87)
            Me.chkReadOnly.Name = "chkReadOnly"
            Me.chkReadOnly.Size = New System.Drawing.Size(98, 21)
            Me.chkReadOnly.TabIndex = 4
            Me.chkReadOnly.Text = "Read-Only"
            Me.tip.SetToolTip(Me.chkReadOnly, resources.GetString("chkReadOnly.ToolTip"))
            Me.chkReadOnly.UseVisualStyleBackColor = True
            '
            'chkTagAlterPreservation
            '
            Me.chkTagAlterPreservation.AutoSize = True
            Me.chkTagAlterPreservation.Location = New System.Drawing.Point(3, 108)
            Me.chkTagAlterPreservation.Name = "chkTagAlterPreservation"
            Me.chkTagAlterPreservation.Size = New System.Drawing.Size(172, 21)
            Me.chkTagAlterPreservation.TabIndex = 5
            Me.chkTagAlterPreservation.Text = "Tag Alter Preservation"
            Me.tip.SetToolTip(Me.chkTagAlterPreservation, resources.GetString("chkTagAlterPreservation.ToolTip"))
            Me.chkTagAlterPreservation.UseVisualStyleBackColor = True
            '
            'lblClose
            '
            Me.lblClose.AutoSize = True
            Me.lblClose.Location = New System.Drawing.Point(3, 132)
            Me.lblClose.Name = "lblClose"
            Me.lblClose.Size = New System.Drawing.Size(43, 17)
            Me.lblClose.TabIndex = 6
            Me.lblClose.TabStop = True
            Me.lblClose.Text = "Close"
            '
            'FrameFlagsControl
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.Controls.Add(Me.lblClose)
            Me.Controls.Add(Me.chkTagAlterPreservation)
            Me.Controls.Add(Me.chkReadOnly)
            Me.Controls.Add(Me.chkGroupingIdentity)
            Me.Controls.Add(Me.chkFileAlterPreservation)
            Me.Controls.Add(Me.chkEncrypted)
            Me.Controls.Add(Me.chkCompressed)
            Me.Name = "FrameFlagsControl"
            Me.Size = New System.Drawing.Size(190, 156)
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub
        Friend WithEvents chkCompressed As System.Windows.Forms.CheckBox
        Friend WithEvents chkEncrypted As System.Windows.Forms.CheckBox
        Friend WithEvents chkFileAlterPreservation As System.Windows.Forms.CheckBox
        Friend WithEvents chkGroupingIdentity As System.Windows.Forms.CheckBox
        Friend WithEvents chkReadOnly As System.Windows.Forms.CheckBox
        Friend WithEvents chkTagAlterPreservation As System.Windows.Forms.CheckBox
        Friend WithEvents tip As System.Windows.Forms.ToolTip
        Friend WithEvents lblClose As System.Windows.Forms.LinkLabel

    End Class

End Namespace
