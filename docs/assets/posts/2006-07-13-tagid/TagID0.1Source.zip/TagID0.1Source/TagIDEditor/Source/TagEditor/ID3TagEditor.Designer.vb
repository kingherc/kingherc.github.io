#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class ID3TagEditor
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ID3TagEditor))
        Me.pGrid = New System.Windows.Forms.PropertyGrid
        Me.ts = New System.Windows.Forms.ToolStrip
        Me.tsOpenFile = New System.Windows.Forms.ToolStripButton
        Me.tsSaveFile = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator
        Me.tsAutoSave = New System.Windows.Forms.ToolStripButton
        Me.tsAutoSaveSeperator = New System.Windows.Forms.ToolStripSeparator
        Me.tsNew = New System.Windows.Forms.ToolStripDropDownButton
        Me.tsNewFrame = New System.Windows.Forms.ToolStripMenuItem
        Me.tsAddAnotherFrame = New System.Windows.Forms.ToolStripMenuItem
        Me.tsNewFramesFromCategory = New System.Windows.Forms.ToolStripMenuItem
        Me.tsDelete = New System.Windows.Forms.ToolStripButton
        Me.tsHelp = New System.Windows.Forms.ToolStripDropDownButton
        Me.tsShowHelp = New System.Windows.Forms.ToolStripMenuItem
        Me.tsFrameBrowser = New System.Windows.Forms.ToolStripMenuItem
        Me.tsLoadDefaultOptions = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.tsAbout = New System.Windows.Forms.ToolStripMenuItem
        Me.tsMoveSeperator = New System.Windows.Forms.ToolStripSeparator
        Me.tsMoveUp = New System.Windows.Forms.ToolStripButton
        Me.tsMoveDown = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.tsMultipleActions = New System.Windows.Forms.ToolStripDropDownButton
        Me.tsDeleteAll = New System.Windows.Forms.ToolStripMenuItem
        Me.tsNormalize = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator
        Me.mnExpandAll = New System.Windows.Forms.ToolStripMenuItem
        Me.mnCollapseAll = New System.Windows.Forms.ToolStripMenuItem
        Me.tsViewMode = New System.Windows.Forms.ToolStripDropDownButton
        Me.tsID3v1 = New System.Windows.Forms.ToolStripMenuItem
        Me.tsID3v2 = New System.Windows.Forms.ToolStripMenuItem
        Me.tsFileInfo = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator
        Me.tsSynchronizeTags = New System.Windows.Forms.ToolStripMenuItem
        Me.tsStartSync = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator
        Me.tsSync2from1 = New System.Windows.Forms.ToolStripMenuItem
        Me.tsSync1from2 = New System.Windows.Forms.ToolStripMenuItem
        Me.tsSyncBoth1and2 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator
        Me.tsSyncBlankFields = New System.Windows.Forms.ToolStripMenuItem
        Me.tsSyncAllFields = New System.Windows.Forms.ToolStripMenuItem
        Me.tsID3v2Configure = New System.Windows.Forms.ToolStripDropDownButton
        Me.tsViewOptions = New System.Windows.Forms.ToolStripMenuItem
        Me.tsDisplayFlags = New System.Windows.Forms.ToolStripMenuItem
        Me.tsDisplayTextEncoding = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.tsCategorized = New System.Windows.Forms.ToolStripMenuItem
        Me.tsAlphabetical = New System.Windows.Forms.ToolStripMenuItem
        Me.tsNoOrder = New System.Windows.Forms.ToolStripMenuItem
        Me.tsModifyCategories = New System.Windows.Forms.ToolStripMenuItem
        Me.tsPromptWhenAddingConflictingFrames = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.tsAdvanced = New System.Windows.Forms.ToolStripMenuItem
        Me.tsDisplayOneLineEdit = New System.Windows.Forms.ToolStripMenuItem
        Me.tsForceOneLineEdit = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.tsSelectDefaultFlagsEncoding = New System.Windows.Forms.ToolStripMenuItem
        Me.tsAutoNormalizeOnLoad = New System.Windows.Forms.ToolStripMenuItem
        Me.mnReturnToTagContextMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnReturnToTag = New System.Windows.Forms.ToolStripMenuItem
        Me.OpenFile = New System.Windows.Forms.OpenFileDialog
        Me.ts.SuspendLayout()
        Me.mnReturnToTagContextMenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'pGrid
        '
        Me.pGrid.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pGrid.CommandsBackColor = System.Drawing.SystemColors.Control
        Me.pGrid.CommandsDisabledLinkColor = System.Drawing.Color.FromArgb(CType(CType(143, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(127, Byte), Integer))
        Me.pGrid.CommandsForeColor = System.Drawing.SystemColors.ControlText
        Me.pGrid.Location = New System.Drawing.Point(0, 25)
        Me.pGrid.Name = "pGrid"
        Me.pGrid.Size = New System.Drawing.Size(456, 527)
        Me.pGrid.TabIndex = 0
        Me.pGrid.ToolbarVisible = False
        '
        'ts
        '
        Me.ts.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ts.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsOpenFile, Me.tsSaveFile, Me.ToolStripSeparator11, Me.tsAutoSave, Me.tsAutoSaveSeperator, Me.tsNew, Me.tsDelete, Me.tsHelp, Me.tsMoveSeperator, Me.tsMoveUp, Me.tsMoveDown, Me.ToolStripSeparator1, Me.tsMultipleActions, Me.tsViewMode, Me.tsID3v2Configure})
        Me.ts.Location = New System.Drawing.Point(0, 0)
        Me.ts.Name = "ts"
        Me.ts.Size = New System.Drawing.Size(456, 25)
        Me.ts.TabIndex = 1
        Me.ts.Text = "ToolStrip1"
        '
        'tsOpenFile
        '
        Me.tsOpenFile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsOpenFile.Image = Global.TagID.Editor.My.Resources.Resources.imgFolderOpen
        Me.tsOpenFile.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsOpenFile.Name = "tsOpenFile"
        Me.tsOpenFile.Size = New System.Drawing.Size(23, 22)
        Me.tsOpenFile.Text = "Open File..."
        Me.tsOpenFile.ToolTipText = "Open a file to view or create ID3 tags."
        Me.tsOpenFile.Visible = False
        '
        'tsSaveFile
        '
        Me.tsSaveFile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsSaveFile.Image = Global.TagID.Editor.My.Resources.Resources.imgSave
        Me.tsSaveFile.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsSaveFile.Name = "tsSaveFile"
        Me.tsSaveFile.Size = New System.Drawing.Size(23, 22)
        Me.tsSaveFile.Text = "Save File"
        Me.tsSaveFile.ToolTipText = "Saves the current ID3 tags to the selected file."
        Me.tsSaveFile.Visible = False
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(6, 25)
        Me.ToolStripSeparator11.Visible = False
        '
        'tsAutoSave
        '
        Me.tsAutoSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsAutoSave.Image = Global.TagID.Editor.My.Resources.Resources.imgFileExport
        Me.tsAutoSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsAutoSave.Name = "tsAutoSave"
        Me.tsAutoSave.Size = New System.Drawing.Size(23, 22)
        Me.tsAutoSave.Text = "Auto-Save"
        Me.tsAutoSave.ToolTipText = resources.GetString("tsAutoSave.ToolTipText")
        Me.tsAutoSave.Visible = False
        '
        'tsAutoSaveSeperator
        '
        Me.tsAutoSaveSeperator.Name = "tsAutoSaveSeperator"
        Me.tsAutoSaveSeperator.Size = New System.Drawing.Size(6, 25)
        Me.tsAutoSaveSeperator.Visible = False
        '
        'tsNew
        '
        Me.tsNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsNew.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsNewFrame, Me.tsAddAnotherFrame, Me.tsNewFramesFromCategory})
        Me.tsNew.Image = Global.TagID.Editor.My.Resources.Resources.imgNewOne
        Me.tsNew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsNew.Name = "tsNew"
        Me.tsNew.Size = New System.Drawing.Size(29, 22)
        Me.tsNew.Text = "&New"
        Me.tsNew.ToolTipText = "New frame(s)"
        '
        'tsNewFrame
        '
        Me.tsNewFrame.Name = "tsNewFrame"
        Me.tsNewFrame.Size = New System.Drawing.Size(281, 22)
        Me.tsNewFrame.Text = "Add a new frame..."
        '
        'tsAddAnotherFrame
        '
        Me.tsAddAnotherFrame.Name = "tsAddAnotherFrame"
        Me.tsAddAnotherFrame.Size = New System.Drawing.Size(281, 22)
        Me.tsAddAnotherFrame.Text = "Add another such new frame"
        Me.tsAddAnotherFrame.ToolTipText = "Adds a new frame like the one selected."
        '
        'tsNewFramesFromCategory
        '
        Me.tsNewFramesFromCategory.Name = "tsNewFramesFromCategory"
        Me.tsNewFramesFromCategory.Size = New System.Drawing.Size(281, 22)
        Me.tsNewFramesFromCategory.Text = "Add new frames of category"
        '
        'tsDelete
        '
        Me.tsDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsDelete.Image = Global.TagID.Editor.My.Resources.Resources.imgDelete
        Me.tsDelete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsDelete.Name = "tsDelete"
        Me.tsDelete.Size = New System.Drawing.Size(23, 22)
        Me.tsDelete.Text = "&Delete"
        Me.tsDelete.ToolTipText = "Delete the selected frame." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "No confirmation needed."
        '
        'tsHelp
        '
        Me.tsHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.tsHelp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsShowHelp, Me.tsFrameBrowser, Me.tsLoadDefaultOptions, Me.ToolStripSeparator5, Me.tsAbout})
        Me.tsHelp.Image = CType(resources.GetObject("tsHelp.Image"), System.Drawing.Image)
        Me.tsHelp.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsHelp.Name = "tsHelp"
        Me.tsHelp.Size = New System.Drawing.Size(29, 22)
        Me.tsHelp.Text = "Tag Browser"
        Me.tsHelp.ToolTipText = "Open the tag browser to find help for the selected frame."
        '
        'tsShowHelp
        '
        Me.tsShowHelp.Image = Global.TagID.Editor.My.Resources.Resources.imgHelp
        Me.tsShowHelp.Name = "tsShowHelp"
        Me.tsShowHelp.Size = New System.Drawing.Size(250, 22)
        Me.tsShowHelp.Text = "Help..."
        '
        'tsFrameBrowser
        '
        Me.tsFrameBrowser.Image = Global.TagID.Editor.My.Resources.Resources.imgBook
        Me.tsFrameBrowser.Name = "tsFrameBrowser"
        Me.tsFrameBrowser.Size = New System.Drawing.Size(250, 22)
        Me.tsFrameBrowser.Text = "ID3v2 Frame Browser..."
        Me.tsFrameBrowser.ToolTipText = "Shows the frame browser which contains information for" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "each recognizable frame t" & _
            "hat an ID3v2 tag can contain."
        '
        'tsLoadDefaultOptions
        '
        Me.tsLoadDefaultOptions.Name = "tsLoadDefaultOptions"
        Me.tsLoadDefaultOptions.Size = New System.Drawing.Size(250, 22)
        Me.tsLoadDefaultOptions.Text = "Load Default Options"
        Me.tsLoadDefaultOptions.ToolTipText = "Loads default options for the ID3TagEditor" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "control. These options guarantee a si" & _
            "mple" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and safe tag-editing."
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(247, 6)
        '
        'tsAbout
        '
        Me.tsAbout.Name = "tsAbout"
        Me.tsAbout.Size = New System.Drawing.Size(250, 22)
        Me.tsAbout.Text = "About..."
        '
        'tsMoveSeperator
        '
        Me.tsMoveSeperator.Name = "tsMoveSeperator"
        Me.tsMoveSeperator.Size = New System.Drawing.Size(6, 25)
        Me.tsMoveSeperator.Visible = False
        '
        'tsMoveUp
        '
        Me.tsMoveUp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsMoveUp.Image = Global.TagID.Editor.My.Resources.Resources.imgArrowUp
        Me.tsMoveUp.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsMoveUp.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsMoveUp.Name = "tsMoveUp"
        Me.tsMoveUp.Size = New System.Drawing.Size(23, 22)
        Me.tsMoveUp.Text = "Move Up"
        Me.tsMoveUp.ToolTipText = "Move the selected frame up." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(Moving frames in a tag just changes the order the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & _
            "frames are written in a tag and doesn't really influence" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "how the frames are rea" & _
            "d by a program)"
        Me.tsMoveUp.Visible = False
        '
        'tsMoveDown
        '
        Me.tsMoveDown.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsMoveDown.Image = Global.TagID.Editor.My.Resources.Resources.imgArrowDown
        Me.tsMoveDown.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsMoveDown.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsMoveDown.Name = "tsMoveDown"
        Me.tsMoveDown.Size = New System.Drawing.Size(23, 22)
        Me.tsMoveDown.Text = "Move Down"
        Me.tsMoveDown.ToolTipText = "Move the selected frame down." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(Moving frames in a tag just changes the order the" & _
            "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "frames are written in a tag and doesn't really influence" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "how the frames are r" & _
            "ead by a program)"
        Me.tsMoveDown.Visible = False
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'tsMultipleActions
        '
        Me.tsMultipleActions.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsMultipleActions.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsDeleteAll, Me.tsNormalize, Me.ToolStripSeparator10, Me.mnExpandAll, Me.mnCollapseAll})
        Me.tsMultipleActions.Image = Global.TagID.Editor.My.Resources.Resources.imgGear
        Me.tsMultipleActions.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsMultipleActions.Name = "tsMultipleActions"
        Me.tsMultipleActions.Size = New System.Drawing.Size(29, 22)
        Me.tsMultipleActions.Text = "Multiple Actions"
        Me.tsMultipleActions.ToolTipText = "Actions to be applied to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "multiple frames of the tag."
        '
        'tsDeleteAll
        '
        Me.tsDeleteAll.Image = Global.TagID.Editor.My.Resources.Resources.imgClean
        Me.tsDeleteAll.Name = "tsDeleteAll"
        Me.tsDeleteAll.Size = New System.Drawing.Size(205, 22)
        Me.tsDeleteAll.Text = "Delete all frames"
        '
        'tsNormalize
        '
        Me.tsNormalize.Name = "tsNormalize"
        Me.tsNormalize.Size = New System.Drawing.Size(205, 22)
        Me.tsNormalize.Text = "Normalize frames"
        Me.tsNormalize.ToolTipText = "Applies the default Encoding and Flags to all frames." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "You can change the default" & _
            " values through the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Configure > Advanced menu."
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(202, 6)
        '
        'mnExpandAll
        '
        Me.mnExpandAll.Image = Global.TagID.Editor.My.Resources.Resources.imgPlusSign
        Me.mnExpandAll.Name = "mnExpandAll"
        Me.mnExpandAll.Size = New System.Drawing.Size(205, 22)
        Me.mnExpandAll.Text = "Expand All"
        '
        'mnCollapseAll
        '
        Me.mnCollapseAll.Image = Global.TagID.Editor.My.Resources.Resources.imgMinusSign
        Me.mnCollapseAll.Name = "mnCollapseAll"
        Me.mnCollapseAll.Size = New System.Drawing.Size(205, 22)
        Me.mnCollapseAll.Text = "Collapse All"
        '
        'tsViewMode
        '
        Me.tsViewMode.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.tsViewMode.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsViewMode.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsID3v1, Me.tsID3v2, Me.tsFileInfo, Me.ToolStripSeparator7, Me.tsSynchronizeTags})
        Me.tsViewMode.Image = CType(resources.GetObject("tsViewMode.Image"), System.Drawing.Image)
        Me.tsViewMode.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsViewMode.Name = "tsViewMode"
        Me.tsViewMode.Size = New System.Drawing.Size(29, 22)
        Me.tsViewMode.Text = "View Mode"
        '
        'tsID3v1
        '
        Me.tsID3v1.Image = Global.TagID.Editor.My.Resources.Resources.imgID3v1Logo
        Me.tsID3v1.Name = "tsID3v1"
        Me.tsID3v1.Size = New System.Drawing.Size(218, 22)
        Me.tsID3v1.Text = "ID3 version 1.1 tag"
        '
        'tsID3v2
        '
        Me.tsID3v2.Image = Global.TagID.Editor.My.Resources.Resources.imgID3v2Logo
        Me.tsID3v2.Name = "tsID3v2"
        Me.tsID3v2.Size = New System.Drawing.Size(218, 22)
        Me.tsID3v2.Text = "ID3 version 2.3 tag"
        '
        'tsFileInfo
        '
        Me.tsFileInfo.Image = Global.TagID.Editor.My.Resources.Resources.imgFile
        Me.tsFileInfo.Name = "tsFileInfo"
        Me.tsFileInfo.Size = New System.Drawing.Size(218, 22)
        Me.tsFileInfo.Text = "File Info"
        Me.tsFileInfo.ToolTipText = resources.GetString("tsFileInfo.ToolTipText")
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(215, 6)
        '
        'tsSynchronizeTags
        '
        Me.tsSynchronizeTags.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsStartSync, Me.ToolStripSeparator8, Me.tsSync2from1, Me.tsSync1from2, Me.tsSyncBoth1and2, Me.ToolStripSeparator9, Me.tsSyncBlankFields, Me.tsSyncAllFields})
        Me.tsSynchronizeTags.Image = Global.TagID.Editor.My.Resources.Resources.imgSynchronize
        Me.tsSynchronizeTags.Name = "tsSynchronizeTags"
        Me.tsSynchronizeTags.Size = New System.Drawing.Size(218, 22)
        Me.tsSynchronizeTags.Text = "Synchronize Tags"
        '
        'tsStartSync
        '
        Me.tsStartSync.Name = "tsStartSync"
        Me.tsStartSync.Size = New System.Drawing.Size(275, 22)
        Me.tsStartSync.Text = "Synchronize!"
        Me.tsStartSync.ToolTipText = "Synchronizes the tags according to the options" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "selected. More info about how the" & _
            " synchronization" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "process works can be found at Help."
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(272, 6)
        '
        'tsSync2from1
        '
        Me.tsSync2from1.Name = "tsSync2from1"
        Me.tsSync2from1.Size = New System.Drawing.Size(275, 22)
        Me.tsSync2from1.Text = "Sync ID3v2 from ID3v1"
        Me.tsSync2from1.ToolTipText = resources.GetString("tsSync2from1.ToolTipText")
        '
        'tsSync1from2
        '
        Me.tsSync1from2.Name = "tsSync1from2"
        Me.tsSync1from2.Size = New System.Drawing.Size(275, 22)
        Me.tsSync1from2.Text = "Sync ID3v1 from ID3v2"
        Me.tsSync1from2.ToolTipText = resources.GetString("tsSync1from2.ToolTipText")
        '
        'tsSyncBoth1and2
        '
        Me.tsSyncBoth1and2.Name = "tsSyncBoth1and2"
        Me.tsSyncBoth1and2.Size = New System.Drawing.Size(275, 22)
        Me.tsSyncBoth1and2.Text = "Sync both ID3v1 and ID3v2"
        Me.tsSyncBoth1and2.ToolTipText = "Copies info found in ID3v1 and ID3v2 tags to each other." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Only copies info when t" & _
            "he appropriate fields of the other" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "tag is empty (the 'Sync only blank fields' i" & _
            "s automatically" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "checked)."
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(272, 6)
        '
        'tsSyncBlankFields
        '
        Me.tsSyncBlankFields.Name = "tsSyncBlankFields"
        Me.tsSyncBlankFields.Size = New System.Drawing.Size(275, 22)
        Me.tsSyncBlankFields.Text = "Sync only blank fields"
        Me.tsSyncBlankFields.ToolTipText = "When synchronizing, only fields/frames that are empty" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "will be changed. If a fram" & _
            "e in ID3v2 hasn't been inserted," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "it will be automatically inserted."
        '
        'tsSyncAllFields
        '
        Me.tsSyncAllFields.Name = "tsSyncAllFields"
        Me.tsSyncAllFields.Size = New System.Drawing.Size(275, 22)
        Me.tsSyncAllFields.Text = "Sync all fields"
        Me.tsSyncAllFields.ToolTipText = "When synchronizing, all fields/frames of the ID3 tag to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "be synced are overwritte" & _
            "n even if the source or target" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "fields/frames are empty."
        '
        'tsID3v2Configure
        '
        Me.tsID3v2Configure.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.tsID3v2Configure.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsID3v2Configure.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsViewOptions, Me.tsModifyCategories, Me.tsPromptWhenAddingConflictingFrames, Me.ToolStripSeparator3, Me.tsAdvanced})
        Me.tsID3v2Configure.Image = Global.TagID.Editor.My.Resources.Resources.imgConfigure
        Me.tsID3v2Configure.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsID3v2Configure.Name = "tsID3v2Configure"
        Me.tsID3v2Configure.Size = New System.Drawing.Size(29, 22)
        Me.tsID3v2Configure.Text = "Con&figure"
        Me.tsID3v2Configure.ToolTipText = "Configure options concerning ID3v2 tags."
        '
        'tsViewOptions
        '
        Me.tsViewOptions.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsDisplayFlags, Me.tsDisplayTextEncoding, Me.ToolStripSeparator2, Me.tsCategorized, Me.tsAlphabetical, Me.tsNoOrder})
        Me.tsViewOptions.Image = Global.TagID.Editor.My.Resources.Resources.imgSideTree
        Me.tsViewOptions.Name = "tsViewOptions"
        Me.tsViewOptions.Size = New System.Drawing.Size(277, 22)
        Me.tsViewOptions.Text = "View Options"
        '
        'tsDisplayFlags
        '
        Me.tsDisplayFlags.Name = "tsDisplayFlags"
        Me.tsDisplayFlags.Size = New System.Drawing.Size(240, 22)
        Me.tsDisplayFlags.Text = "Display (Flags) field"
        '
        'tsDisplayTextEncoding
        '
        Me.tsDisplayTextEncoding.Name = "tsDisplayTextEncoding"
        Me.tsDisplayTextEncoding.Size = New System.Drawing.Size(240, 22)
        Me.tsDisplayTextEncoding.Text = "Display (Encoding) field"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(237, 6)
        '
        'tsCategorized
        '
        Me.tsCategorized.Image = Global.TagID.Editor.My.Resources.Resources.imgChoose
        Me.tsCategorized.Name = "tsCategorized"
        Me.tsCategorized.Size = New System.Drawing.Size(240, 22)
        Me.tsCategorized.Text = "Categorized"
        '
        'tsAlphabetical
        '
        Me.tsAlphabetical.Image = Global.TagID.Editor.My.Resources.Resources.imgTextBold
        Me.tsAlphabetical.Name = "tsAlphabetical"
        Me.tsAlphabetical.Size = New System.Drawing.Size(240, 22)
        Me.tsAlphabetical.Text = "Alphabetical"
        '
        'tsNoOrder
        '
        Me.tsNoOrder.Name = "tsNoOrder"
        Me.tsNoOrder.Size = New System.Drawing.Size(240, 22)
        Me.tsNoOrder.Text = "None"
        Me.tsNoOrder.ToolTipText = "The frames will be ordered as found or written" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "in the tag. Also this view gives " & _
            "you the chance" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to change the order of the frames."
        '
        'tsModifyCategories
        '
        Me.tsModifyCategories.Image = Global.TagID.Editor.My.Resources.Resources.imgChoose
        Me.tsModifyCategories.Name = "tsModifyCategories"
        Me.tsModifyCategories.Size = New System.Drawing.Size(277, 22)
        Me.tsModifyCategories.Text = "Modify frame categories..."
        Me.tsModifyCategories.ToolTipText = "Each ID3v2 frame is in a category (for organizing a tag" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "better). You can modify " & _
            "these categories through this" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "button. More info about categories can be found b" & _
            "y" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "clicking the Help button."
        '
        'tsPromptWhenAddingConflictingFrames
        '
        Me.tsPromptWhenAddingConflictingFrames.Name = "tsPromptWhenAddingConflictingFrames"
        Me.tsPromptWhenAddingConflictingFrames.Size = New System.Drawing.Size(277, 22)
        Me.tsPromptWhenAddingConflictingFrames.Text = "Prompt on conflicting frames"
        Me.tsPromptWhenAddingConflictingFrames.ToolTipText = resources.GetString("tsPromptWhenAddingConflictingFrames.ToolTipText")
        Me.tsPromptWhenAddingConflictingFrames.Visible = False
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(274, 6)
        '
        'tsAdvanced
        '
        Me.tsAdvanced.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsDisplayOneLineEdit, Me.tsForceOneLineEdit, Me.ToolStripSeparator4, Me.tsSelectDefaultFlagsEncoding, Me.tsAutoNormalizeOnLoad})
        Me.tsAdvanced.Name = "tsAdvanced"
        Me.tsAdvanced.Size = New System.Drawing.Size(277, 22)
        Me.tsAdvanced.Text = "Advanced"
        '
        'tsDisplayOneLineEdit
        '
        Me.tsDisplayOneLineEdit.Name = "tsDisplayOneLineEdit"
        Me.tsDisplayOneLineEdit.Size = New System.Drawing.Size(301, 22)
        Me.tsDisplayOneLineEdit.Text = "Display one-line frame summary"
        Me.tsDisplayOneLineEdit.ToolTipText = resources.GetString("tsDisplayOneLineEdit.ToolTipText")
        '
        'tsForceOneLineEdit
        '
        Me.tsForceOneLineEdit.Name = "tsForceOneLineEdit"
        Me.tsForceOneLineEdit.Size = New System.Drawing.Size(301, 22)
        Me.tsForceOneLineEdit.Text = "Force one-line frame summary"
        Me.tsForceOneLineEdit.ToolTipText = resources.GetString("tsForceOneLineEdit.ToolTipText")
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(298, 6)
        '
        'tsSelectDefaultFlagsEncoding
        '
        Me.tsSelectDefaultFlagsEncoding.Name = "tsSelectDefaultFlagsEncoding"
        Me.tsSelectDefaultFlagsEncoding.Size = New System.Drawing.Size(301, 22)
        Me.tsSelectDefaultFlagsEncoding.Text = "Select Default Flags && Encoding"
        Me.tsSelectDefaultFlagsEncoding.ToolTipText = resources.GetString("tsSelectDefaultFlagsEncoding.ToolTipText")
        '
        'tsAutoNormalizeOnLoad
        '
        Me.tsAutoNormalizeOnLoad.Name = "tsAutoNormalizeOnLoad"
        Me.tsAutoNormalizeOnLoad.Size = New System.Drawing.Size(301, 22)
        Me.tsAutoNormalizeOnLoad.Text = "Auto-Normalize on Load"
        Me.tsAutoNormalizeOnLoad.ToolTipText = resources.GetString("tsAutoNormalizeOnLoad.ToolTipText")
        '
        'mnReturnToTagContextMenu
        '
        Me.mnReturnToTagContextMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnReturnToTag})
        Me.mnReturnToTagContextMenu.Name = "mnReturnToTagContextMenu"
        Me.mnReturnToTagContextMenu.Size = New System.Drawing.Size(184, 26)
        '
        'mnReturnToTag
        '
        Me.mnReturnToTag.Image = Global.TagID.Editor.My.Resources.Resources.imgLeftArrow
        Me.mnReturnToTag.Name = "mnReturnToTag"
        Me.mnReturnToTag.Size = New System.Drawing.Size(183, 22)
        Me.mnReturnToTag.Text = "Return to Tag"
        '
        'OpenFile
        '
        Me.OpenFile.FileName = "File"
        Me.OpenFile.Title = "Select a file to open"
        '
        'ID3TagEditor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.ts)
        Me.Controls.Add(Me.pGrid)
        Me.Name = "ID3TagEditor"
        Me.Size = New System.Drawing.Size(456, 552)
        Me.ts.ResumeLayout(False)
        Me.ts.PerformLayout()
        Me.mnReturnToTagContextMenu.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pGrid As System.Windows.Forms.PropertyGrid
    Friend WithEvents ts As System.Windows.Forms.ToolStrip
    Friend WithEvents tsDelete As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsID3v2Configure As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents tsViewOptions As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsCategorized As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsAlphabetical As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsNoOrder As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsNew As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents tsNewFrame As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsNewFramesFromCategory As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsPromptWhenAddingConflictingFrames As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsMoveUp As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsMoveDown As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsMoveSeperator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsMultipleActions As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents tsDeleteAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsAddAnotherFrame As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsDisplayFlags As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsDisplayTextEncoding As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsAdvanced As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsDisplayOneLineEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsForceOneLineEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsSelectDefaultFlagsEncoding As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsHelp As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents tsFrameBrowser As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsShowHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsAbout As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsModifyCategories As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsNormalize As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsAutoNormalizeOnLoad As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnReturnToTagContextMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnReturnToTag As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsViewMode As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents tsID3v1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsID3v2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsSynchronizeTags As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsStartSync As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsSync2from1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsSync1from2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsSyncBoth1and2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsSyncBlankFields As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsSyncAllFields As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnExpandAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnCollapseAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsFileInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsOpenFile As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsSaveFile As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsAutoSave As System.Windows.Forms.ToolStripButton
    Friend WithEvents OpenFile As System.Windows.Forms.OpenFileDialog
    Friend WithEvents tsLoadDefaultOptions As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsAutoSaveSeperator As System.Windows.Forms.ToolStripSeparator

End Class
