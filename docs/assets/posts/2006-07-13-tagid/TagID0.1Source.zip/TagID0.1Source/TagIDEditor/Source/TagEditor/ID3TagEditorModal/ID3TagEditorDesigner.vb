#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

''' <summary>
''' Alters the ID3TagEditor control's behaviour at design-time.
''' </summary>
Public Class ID3TagEditorDesigner
    Inherits System.Windows.Forms.Design.ControlDesigner

    ''' <summary>
    ''' This property shadows the FileCanSave property of the control so that it's set to False at design-time in order to avoid accidental save operations and also avoid the save question.
    ''' </summary>
    Public Property FileCanSave() As Boolean
        Get
            Return CBool(Me.ShadowProperties("FileCanSave"))
        End Get
        Set(ByVal Value As Boolean)
            Me.ShadowProperties("FileCanSave") = Value
            CType(Me.Control, ID3TagEditor).FileCanSave = False
        End Set
    End Property

    ''' <summary>
    ''' This property shadows the FilePath property of the control so that in design-time to avoid file operations (the Form Designer generates unwanted code).
    ''' </summary>
    Public Property FilePath() As String
        Get
            Return CStr(Me.ShadowProperties("FilePath"))
        End Get
        Set(ByVal value As String)
            Me.ShadowProperties("FilePath") = value
        End Set
    End Property

    Protected Overrides Sub PreFilterProperties(ByVal properties As IDictionary)
        MyBase.PreFilterProperties(properties)

        properties("FileCanSave") = TypeDescriptor.CreateProperty(GetType(ID3TagEditorDesigner), CType(properties("FileCanSave"), PropertyDescriptor), New Attribute(-1) {})
        properties("FilePath") = TypeDescriptor.CreateProperty(GetType(ID3TagEditorDesigner), CType(properties("FilePath"), PropertyDescriptor), New Attribute(-1) {})
    End Sub

End Class