#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Namespace UltraID3LibExtender.FrameSpecific

#Region "FrameString Class - Used to express a frame as a string"

    Public Class FrameString

        Private _isdefault As Boolean = False
        ''' <summary>
        ''' Determines if the Flags and TextEncoding are the default ones.
        ''' </summary>
        ''' <remarks>The default FrameFlags and TextEncoding are the ones defined in Helper.</remarks>
        Public ReadOnly Property IsDefault() As Boolean
            Get
                ToString()
                Return _isdefault
            End Get
        End Property

        Private _flags As FrameFlags
        ''' <summary>
        ''' Gets or sets the FrameFlags associated with this FrameString.
        ''' </summary>
        Public Property Flags() As FrameFlags
            Get
                Return _flags
            End Get
            Set(ByVal value As FrameFlags)
                _flags = value
            End Set
        End Property

        Private _textencoding As TextEncodingTypes
        ''' <summary>
        ''' Gets or sets the TextEncoding associated with this FrameString.
        ''' </summary>
        Public Property TextEncoding() As TextEncodingTypes
            Get
                Return _textencoding
            End Get
            Set(ByVal value As TextEncodingTypes)
                _textencoding = value
            End Set
        End Property

        Private _text As String
        ''' <summary>
        ''' The data string stored in the FrameString.
        ''' </summary>
        Public Property Text() As String
            Get
                Return _text
            End Get
            Set(ByVal value As String)
                _text = value
            End Set
        End Property

        ''' <summary>
        ''' Gets a new FrameString with no data.
        ''' </summary>
        ''' <remarks>The Flags and TextEncoding properties are set to the default values found in Helper.</remarks>
        Public Sub New()
            Me.Flags = Helper.DefaultFlags
            Me.TextEncoding = Helper.DefaultTextEncoding
        End Sub

        ''' <summary>
        ''' Gets a new FrameString from a string. Automatically searches if there is a parameter string in the given string.
        ''' </summary>
        ''' <remarks>This constructor first of all searches if there is a parameter string in the given string by calling the GetParameters method. If there is, then it decodes it and sets the Flags and the TextEncoding properties. The rest of the string is set to the Text property. If the parameter string doesn't exist, then all the string is set to the Text property and the Flags and TextEncoding properties are set to the default ones specified in Helper.</remarks>
        ''' <param name="txt">The data string to store in the FrameString.</param>
        Public Sub New(ByVal txt As String)
            Me.New()
            Dim params As String = GetParameters(txt)
            If params Is Nothing Then
                Me.Text = txt
            Else
                Dim flags As FrameFlags = Helper.CreateFrameFlags
                flags.Compressed = params.Contains("C")
                flags.Encrypted = params.Contains("E")
                flags.FileAlterPreservation = params.Contains("F")
                flags.GroupingIdentity = params.Contains("G")
                flags.ReadOnly = params.Contains("R")
                flags.TagAlterPreservation = params.Contains("T")
                Me.Flags = flags
                If params.Contains("1") Then
                    Me.TextEncoding = TextEncodingTypes.ISO88591
                ElseIf params.Contains("2") Then
                    Me.TextEncoding = TextEncodingTypes.Unicode
                End If
                Me.Text = txt.Replace("{" & params & "}", "").Trim(New Char() {" "})
            End If
        End Sub

        ''' <summary>
        ''' Gets a new FrameString with the appropriate Text, Flags and TextEncoding values.
        ''' </summary>
        ''' <param name="txt">The data string to store in the FrameString.</param>
        ''' <param name="flags">The flags of the frame the FrameString represents.</param>
        ''' <param name="TextEncoding">The text encoding of the frame the FrameString represents.</param>
        Public Sub New(ByVal txt As String, ByVal flags As FrameFlags, ByVal TextEncoding As TextEncodingTypes)
            Me.New(txt)
            Me.Flags = flags
            Me.TextEncoding = TextEncoding
        End Sub

        ''' <summary>
        ''' Returns the parameters string, if one is present in the supplied string.
        ''' </summary>
        ''' <remarks>
        ''' This function receives a string that may or not contain a valid parameter string (as one returned by GetParameterString). It searches the beginning of the string to see if a parameter string is enclosed in { }. If it finds one and determines that it is valid, it returns that string, else it returns Nothing.
        ''' When a FrameString is created from a string, it first searches if a parameter string exists in the string. If one exists, then it gets the parameters and sets the Flags and TextEncoding. Then the rest of the string is set to the Text property. If a parameter string is not found, the whole string is set to the Text property and the Flags and TextEncoding properties are set to the default ones found in Helper.
        ''' </remarks>
        Private Function GetParameters(ByVal s As String) As String
            Dim str As String = ""
            Try
                If s.Contains("{") And s.Contains("}") Then
                    If s.IndexOf("}") > s.IndexOf("{") Then
                        If s.IndexOf("{") = 0 Then
                            s = s.Substring(s.IndexOf("{") + 1, s.IndexOf("}") - s.IndexOf("{") - 1)
                            Dim charactersallowedinparameters As String = "CEFGRT12", c As Char, ss As String = s
                            For Each c In charactersallowedinparameters
                                ss = ss.Replace(c, "")
                            Next
                            If ss = "" Then
                                str = s
                            End If
                        End If
                    End If
                End If
            Catch ex As Exception
                str = Nothing
            End Try
            Return str
        End Function

        ''' <summary>
        ''' Gets a string representing the FrameString.
        ''' </summary>
        ''' <remarks>The string returned is made up from the parameter string (as returned by the GetParameter string), enclosed in { } and followed by the Text property. If the parameters are the default ones found in Helper, then no parameter string is prepended - only the Text property is returned.</remarks>
        Public Shadows Function ToString() As String
            Dim params As String = GetParameterString()
            If params = New FrameString("", Helper.DefaultFlags, Helper.DefaultTextEncoding).GetParameterString Then
                _isdefault = True
                Return Me.Text
            Else
                _isdefault = False
                Return "{" & params & "} " & Me.Text
            End If
        End Function

        ''' <summary>
        ''' Returns a string containing FrameFlags and TextEncoding in an encoded format.
        ''' </summary>
        ''' <remarks>
        ''' This method encodes FrameFlags and TextEncoding to a string. This string is comprised of characters and a number. If a C is in the string, it means that the Compressed flag is true. If an E is in the string, it means that the Encrypted flag is true. If a F is in the string, it means that the FileAlterPreservation flag is true. If a G is in the string, it means that the GroupingIdentity flag is true. If a R is in the string, it means that the Read-Only flag is true. If a T is in the string, it means that the TagAlterPreservation flag is true. If a 1 is in the string, it means that the TextEncoding is ISO88591. If a 2 is in the string, it means that the TextEncoding is Unicode.
        ''' When the ToString method of a FrameString is called, the FrameString calls this method passing its Flags and TextEncoding properties. It then takes this parameter string, encloses it in { } and prepends it to the Text property. But if the parameters are the default ones defined in Helper, then the parameters string is not prepended at all.
        ''' </remarks>
        Public Function GetParameterString() As String
            Dim str As String = ""
            If flags.Compressed Then
                str &= "C"
            End If
            If flags.Encrypted Then
                str &= "E"
            End If
            If flags.FileAlterPreservation Then
                str &= "F"
            End If
            If flags.GroupingIdentity Then
                str &= "G"
            End If
            If flags.ReadOnly Then
                str &= "R"
            End If
            If flags.TagAlterPreservation Then
                str &= "T"
            End If
            Try
                If TextEncoding = TextEncodingTypes.ISO88591 Then
                    str &= "1"
                End If
                If TextEncoding = TextEncodingTypes.Unicode Then
                    str &= "2"
                End If
            Catch ex As Exception

            End Try
            Return str
        End Function

    End Class

#End Region

#Region "FrameStringExpandableConverter - For converting frames to FrameString"

    Friend MustInherit Class FrameStringExpandableConverter
        Inherits FrameExpandableConverter

        ''' <summary>
        ''' Converts the ID3Frame to a FrameString.
        ''' </summary>
        ''' <remarks>Each class that inherits from this converted must override this method. It should return a FrameString from the supplied ID3Frame.</remarks>
        Public MustOverride Function GetFrameString(ByVal frame As ID3Frame) As FrameString
        ''' <summary>
        ''' Converts the FrameString to an ID3Frame.
        ''' </summary>
        ''' <remarks>Each class that inherits from this converted must override this method. It should return an ID3Frame from the supplied FrameString.</remarks>
        Public MustOverride Function GetFrameFromFrameString(ByVal fs As FrameString) As ID3Frame

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext, ByVal t As Type) As Boolean
            If t Is GetType(String) Then
                Return True
            End If
            Return MyBase.CanConvertTo(context, t)
        End Function

        Public Overloads Overrides Function ConvertTo(ByVal context As ITypeDescriptorContext, ByVal culture As Globalization.CultureInfo, ByVal value As Object, ByVal destinationType As Type) As Object
            If destinationType Is GetType(String) Then
                If Helper.DisplayOneLineEdit Then
                    Return GetFrameString(value).ToString
                Else
                    Return ""
                End If
            End If
            Return MyBase.ConvertTo(context, culture, value, destinationType)
        End Function

        Public Overloads Overrides Function CanConvertFrom(ByVal context As ITypeDescriptorContext, ByVal sourceType As Type) As Boolean
            If sourceType Is GetType(String) Then
                If Helper.DisplayOneLineEdit Then
                    Return True
                Else
                    Return False
                End If
            End If
            Return MyBase.CanConvertFrom(context, sourceType)
        End Function

        Public Overloads Overrides Function ConvertFrom(ByVal context As ITypeDescriptorContext, ByVal culture As Globalization.CultureInfo, ByVal value As Object) As Object
            If TypeOf value Is String Then
                Return GetFrameFromFrameString(New FrameString(CStr(value)))
            End If
            Return MyBase.ConvertFrom(context, culture, value)
        End Function

        Public Overrides Function GetPropertiesSupported(ByVal context As System.ComponentModel.ITypeDescriptorContext) As Boolean
            'This function hides properties if according to Helper.oForceOneLineEdit.
            If Helper.ForceOneLineEdit = ForceOneLineEditModes.Nowhere Then
                Return True
            ElseIf Helper.ForceOneLineEdit = ForceOneLineEditModes.WhereverPossible Then
                Return False
            End If
            Return MyBase.GetPropertiesSupported(context)
        End Function

    End Class

#End Region

#Region "FrameExpandableConverter - For all frames to be expanded."

    Friend MustInherit Class FrameExpandableConverter
        Inherits ExpandableObjectConverter

        ''' <summary>
        ''' A simple string showing info about the frame's data.
        ''' </summary>
        ''' <remarks>The string simply describes the data of the frame. The default is Nothing.</remarks>
        Public Overridable Function FrameToString(ByVal frame As ID3Frame) As String
            Return ""
        End Function

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext, ByVal t As Type) As Boolean
            If t Is GetType(String) Then
                Return True
            End If
            Return MyBase.CanConvertTo(context, t)
        End Function

        Public Overloads Overrides Function ConvertTo(ByVal context As ITypeDescriptorContext, ByVal culture As Globalization.CultureInfo, ByVal value As Object, ByVal destinationType As Type) As Object
            If destinationType Is GetType(String) Then
                If Helper.DisplayOneLineEdit Then
                    Return FrameToString(value)
                Else
                    Return ""
                End If
            End If
            Return MyBase.ConvertTo(context, culture, value, destinationType)
        End Function

        Public Overrides Function GetPropertiesSupported(ByVal context As System.ComponentModel.ITypeDescriptorContext) As Boolean
            Return True
            Return MyBase.GetPropertiesSupported(context)
        End Function

    End Class

#End Region

End Namespace