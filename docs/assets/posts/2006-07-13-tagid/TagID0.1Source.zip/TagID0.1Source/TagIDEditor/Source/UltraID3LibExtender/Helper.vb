#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Namespace UltraID3LibExtender

    ''' <summary>
    ''' The main class of the namespace. This class should be used only.
    ''' </summary>
    ''' <remarks>UltraID3LibExtender is a namespace that helps extends UltraID3Lib. It's main purpose is to render UltraID3Lib's classes 'browsable' and editable for property grids and also ameliorates it generally. It all happens automatically. You simply call InitializeLibrary method of the Helper class.</remarks>
    Public Class Helper

#Region "Properties & Options & Events"

        ''' <summary>
        ''' The filename of the xml file containing the categories for each frame ID.
        ''' </summary>
        ''' <remarks>The Xml file must be found at the Directory.GetWorkingDirectory. If it's not found, the library tries to create it (with the default categories).</remarks>
        Public Const FrameCategoriesFileName = "FrameCategories.xml"
        ''' <summary>
        ''' The name of the UltraID3Lib assembly.
        ''' </summary>
        ''' <remarks>If the UltraID3Lib assembly is needed, the Assembly.Load is called with this string as a parameter.</remarks>
        Public Const UltraID3LibAssemblyName As String = "UltraID3Lib"
        ''' <summary>
        ''' A collection of FrameDescription structures for each recognised frame.
        ''' </summary>
        ''' <remarks>Recognised frames are the ones available in the UltraID3Lib assembly.</remarks>
        Public Shared FrameDescriptions As FrameDescriptionList

        Private Shared oDisplayTextEncoding As Boolean = True
        ''' <summary>
        ''' Whether to display the TextEncoding property or not.
        ''' </summary>
        ''' <remarks>Whether to apply the BrowsableAttribute to TextEncoding property of ID3Frames or not. If True, the text encoding field is shown for every ID3Frame in a property grid.</remarks>
        Public Shared Property DisplayTextEncoding() As Boolean
            Get
                Return oDisplayTextEncoding
            End Get
            Set(ByVal value As Boolean)
                oDisplayTextEncoding = value
                OnOptionsChanged()
            End Set
        End Property

        Private Shared oDefaultTextEncoding As TextEncodingTypes = TextEncodingTypes.Unicode
        ''' <summary>
        ''' Gets or sets the default text encoding for frames.
        ''' </summary>
        ''' <remarks>
        ''' The DefaultTextEncoding are used mainly when a Frame's text encoding is not somehow known.
        ''' It is also used in a FrameString. A FrameString will not show the frameflags and textencoding parameters in a frame's string only if these are the default ones.
        ''' </remarks>
        Public Shared Property DefaultTextEncoding() As TextEncodingTypes
            Get
                Return oDefaultTextEncoding
            End Get
            Set(ByVal value As TextEncodingTypes)
                oDefaultTextEncoding = value
                OnOptionsChanged()
            End Set
        End Property

        Private Shared oDisplayFlags As Boolean = True
        ''' <summary>
        ''' Whether to display the FrameFlags property or not.
        ''' </summary>
        ''' <remarks>Whether to apply the BrowsableAttribute to FrameFlags property of ID3Frames or not. If True, the frame flags field is shown for every ID3Frame in a property grid.</remarks>
        Public Shared Property DisplayFlags() As Boolean
            Get
                Return oDisplayFlags
            End Get
            Set(ByVal value As Boolean)
                oDisplayFlags = value
                OnOptionsChanged()
            End Set
        End Property

        Private Shared oDefaultFlags As FrameFlags = CreateFrameFlags()
        ''' <summary>
        ''' Gets or sets the default flags for frames.
        ''' </summary>
        ''' <remarks>
        ''' The DefaultFlags are used mainly when a Frame's flags are not somehow known.
        ''' They are also used in a FrameString. A FrameString will not show the frameflags and textencoding parameters in a frame's string only if these are the default ones.
        ''' </remarks>
        Public Shared Property DefaultFlags() As FrameFlags
            Get
                Return oDefaultFlags
            End Get
            Set(ByVal value As FrameFlags)
                'oDefaultFlags = value
                CloneFrameFlags(value, oDefaultFlags)
                OnOptionsChanged()
            End Set
        End Property

        Private Shared oDisplayOneLineEdit As Boolean = True
        ''' <summary>
        ''' Whether to display one-line descriptions or not.
        ''' </summary>
        ''' <remarks>
        ''' Some ID3Frames are simple enough to be expressed in a FrameString. This value determines whether the user will be able to edit these ID3Frames through editing a FrameString (this is achieved through a converter. More info can be found in the FrameSpecific namespace).
        ''' For example, if true, the user will be able to edit the frame in a property grid directly without having to expand the frame's properties.
        ''' Apart from the ID3Frames that can be converted to/from a framestring, there are some other ID3Frames that provide a small description of their contents in their first line in the property grid. The value of this option determines if this small description is shown or not.
        ''' If ForceOneLineEdit is set to WhereverPossible, then DisplayOneLineEdit will remain true.
        ''' </remarks>
        Public Shared Property DisplayOneLineEdit() As Boolean
            Get
                Return oDisplayOneLineEdit
            End Get
            Set(ByVal value As Boolean)
                oDisplayOneLineEdit = value
                If ForceOneLineEdit = ForceOneLineEditModes.WhereverPossible Then
                    oDisplayOneLineEdit = True
                End If
                OnOptionsChanged()
            End Set
        End Property

        Private Shared oForceOneLineEdit As ForceOneLineEditModes = ForceOneLineEditModes.Nowhere
        ''' <summary>
        ''' Whether to force one-line edit mode (wherever possible) or not.
        ''' </summary>
        ''' <remarks>
        ''' Some ID3Frames are simple enough to be expressed in a FrameString. The user can edit these ID3Frames through editing a FrameString (this is achieved through a converter. More info can be found in the FrameSpecific namespace) without having to expand the frame in a property grid.
        ''' This value determines whether these ID3Frames should be displayed as expandable. If True, the DisplayOneLineEdit is set to True.
        ''' </remarks>
        Public Shared Property ForceOneLineEdit() As ForceOneLineEditModes
            Get
                Return oForceOneLineEdit
            End Get
            Set(ByVal value As ForceOneLineEditModes)
                oForceOneLineEdit = value
                If value = ForceOneLineEditModes.WhereverPossible Then
                    oDisplayOneLineEdit = True
                End If
                OnOptionsChanged()
            End Set
        End Property

        Public Enum ForceOneLineEditModes As Integer
            ''' <summary>
            ''' Force one-line edit mode wherever an ID3Frame supports it.
            ''' </summary>
            ''' <remarks>Basically, this means that frames that support one-line edit will not be rendered expandable in a property grid. It may be simpler for some users.</remarks>
            WhereverPossible = 1
            ''' <summary>
            ''' Do not force one-line edit mode.
            ''' </summary>
            ''' <remarks>Basically, this means that frames that support one-line edit will remain expandable in a property grid.</remarks>
            Nowhere = 3
        End Enum

        ''' <summary>
        ''' Trigerred when one of the options is changed.
        ''' </summary>
        Public Shared Event OptionsChanged()
        Protected Shared Sub OnOptionsChanged()
            RaiseEvent OptionsChanged()
        End Sub

#End Region

#Region "InitializeLibrary"

        ''' <summary>
        ''' Should be called by the startup application event to initialize the library before it is used.
        ''' </summary>
        ''' <remarks>This is the main method of the library. It should be called to activate the library. It mainly does the following: It distributes the ID3v2FrameProvider to all ID3Frames, creates the FrameDescriptions list and distribute some TypeEditors to some types (for example it distributes FrameFlagsEditor to the FrameFlags type). The ID3v2FrameProvider automatically takes action each time an ID3Frame is requested for its properties and attributes.</remarks>
        Public Shared Sub InitializeLibrary()
            FrameDescriptions = New FrameDescriptionList

            TypeDescriptor.AddProvider(New TypeEditors.InvolvedPersonProvider(GetType(InvolvedPerson)), GetType(InvolvedPerson))
            TypeDescriptor.AddAttributes(GetType(FrameFlags), New Attribute() {New EditorAttribute(GetType(TypeEditors.FrameFlagsEditor), GetType(UITypeEditor)), New TypeConverterAttribute(GetType(TypeEditors.FrameFlagsConverter))})
            TypeDescriptor.AddProvider(New ID3v2FrameProvider(GetType(ID3Frame)), GetType(ID3Frame))
            TypeDescriptor.AddProvider(New ID3v2Tag.ID3v2TagProvider(GetType(Editor.ID3v2Tag)), GetType(Editor.ID3v2Tag))
            TypeDescriptor.AddProvider(New MPEGInfo.MPEGInfoProvider(GetType(MPEGInfo)), GetType(MPEGInfo))

            If ID3TagEditor.Ops Is Nothing Then
                ID3TagEditor.Ops = New ID3TagEditor.Options
                ID3TagEditor.Ops.LoadOptions()
            End If
        End Sub

        Public Sub New()
            InitializeLibrary()
        End Sub

#End Region

#Region "CreateFrameFromType"

        ''' <summary>
        ''' Creates an ID3Frame object from the supplied type.
        ''' </summary>
        ''' <remarks>
        ''' In the UltraID3Lib library, each Frame has its Type. E.g. The ID3ArtistsFrame is used to manipulate Artist frames.
        ''' As each type has its own constructor, this method tries to create an instance of a frame by its corresponding type. It uses Helper's default values.
        ''' </remarks>
        ''' <param name="t">The Type that corresponds to the ID3Frame you wish to retrieve.</param>
        ''' <returns>An ID3Frame object corresponding to the supplied type.</returns>
        Public Shared Function CreateFrameFromType(ByVal t As Type) As ID3Frame
            If IsFrame(t) Then
                Dim constructors() As Reflection.ConstructorInfo = t.GetConstructors, o As Object = Nothing, i As Integer = 0
                While (o Is Nothing) And (i < constructors.Length)
                    If (Not o Is Nothing) Or (i > constructors.Length) Then Exit While
                    Dim c As Reflection.ConstructorInfo = constructors(i), params() As Reflection.ParameterInfo = c.GetParameters, paramobjs(params.Length - 1) As Object
                    If paramobjs.Length <= 0 Then
                        Try
                            o = c.Invoke(Nothing)
                        Catch ex As Exception
                            o = Nothing
                        End Try
                    Else
                        Try
                            Dim ii As Integer = 0
                            For ii = 0 To params.Length - 1
                                Dim p As Reflection.ParameterInfo = params(ii)
                                Dim oo As Object
                                'Parameters types and default values
                                If p.ParameterType Is GetType(TextEncodingTypes) Then
                                    oo = Helper.DefaultTextEncoding
                                Else
                                    oo = Nothing
                                End If
                                paramobjs.SetValue(oo, ii)
                            Next
                            o = c.Invoke(paramobjs)
                        Catch ex As Exception
                            o = Nothing
                        End Try
                    End If
                    i += 1
                End While
                If Not o Is Nothing Then
                    CloneFrameFlags(Helper.DefaultFlags, CType(o, ID3Frame).FrameFlags)
                    'CType(o, ID3Frame).FrameFlags = Helper.DefaultFlags
                    Dim p As PropertyDescriptor = TypeDescriptor.GetProperties(o, False).Find("TextEncodingType", True)
                    If Not p Is Nothing Then
                        p.SetValue(o, Helper.DefaultTextEncoding)
                    End If
                End If
                Return o
            Else
                Throw New Exception("Type was not of a frame.")
            End If
        End Function

#End Region

#Region "CloneFrame"

        ''' <summary>
        ''' Clones an ID3Frame object.
        ''' </summary>
        ''' <remarks>
        ''' In the UltraID3Lib, there is not a Clone function. So, frames are passed by reference. If you want to 'copy' a frame, then use this function to clone an ID3Frame object.
        ''' </remarks>
        ''' <param name="f">The ID3Frame to clone.</param>
        ''' <returns>An ID3Frame object cloned from the supplied frame. Returns Nothing if an error occurs.</returns>
        Public Shared Function CloneFrame(ByVal f As ID3Frame) As ID3Frame
            Dim nf As ID3Frame = CreateFrameFromType(f.GetType)
            If Not nf Is Nothing Then
                Try
                    Dim ps As PropertyDescriptorCollection = TypeDescriptor.GetProperties(f)
                    Dim p As PropertyDescriptor
                    For Each p In ps
                        If Not p.IsReadOnly Then
                            If Not p.PropertyType Is GetType(FrameFlags) Then
                                Dim o As Object = p.GetValue(f)
                                If Not o Is Nothing Then
                                    p.SetValue(nf, p.GetValue(f))
                                End If
                            Else
                                Dim newff As FrameFlags = CreateFrameFlags()
                                CloneFrameFlags(p.GetValue(f), newff)
                                p.SetValue(nf, newff)
                            End If
                        End If
                    Next
                Catch ex As Exception
                    nf = Nothing
                End Try
            End If
            Return nf
        End Function

#End Region

#Region "IsFrame"

        ''' <summary>
        ''' Determines if a Type derives from ID3Frame.
        ''' </summary>
        ''' <remarks></remarks>
        ''' <returns>True if the Type is derived from ID3Frame. Else, False.</returns>
        Public Shared Function IsFrame(ByVal t As Type) As Boolean
            Dim b As Boolean = False
            While (Not t Is Nothing) And (Not b)
                If t Is GetType(ID3Frame) Then
                    b = True
                Else
                    t = t.BaseType
                End If
            End While
            Return b
        End Function

#End Region

#Region "CreateFrameFlags & CloneFrameFlags"

        ''' <summary>
        ''' Creates a new FrameFlags object.
        ''' </summary>
        ''' <remarks>Because the FrameFlags.New constructor doesn't work, use this method to create a FrameFlags object.</remarks>
        ''' <returns>A new FrameFlags object.</returns>
        Public Shared Function CreateFrameFlags() As FrameFlags
            Dim tmpframe As ID3TitleFrame = New ID3TitleFrame(oDefaultTextEncoding)
            tmpframe.FrameFlags.Compressed = False
            tmpframe.FrameFlags.Encrypted = False
            tmpframe.FrameFlags.FileAlterPreservation = False
            tmpframe.FrameFlags.GroupingIdentity = False
            tmpframe.FrameFlags.ReadOnly = False
            tmpframe.FrameFlags.TagAlterPreservation = False
            Return tmpframe.FrameFlags
        End Function

        ''' <summary>
        ''' Clones FrameFlags object.
        ''' </summary>
        ''' <remarks>Because when assigning a value to a FrameFlags object, it passes by reference, you should use this method to copy the frame flags fields of the first object to the second object.</remarks>
        Public Shared Sub CloneFrameFlags(ByVal originalFlags As FrameFlags, ByRef flagsToModify As FrameFlags)
            flagsToModify.Compressed = originalFlags.Compressed
            flagsToModify.Encrypted = originalFlags.Encrypted
            flagsToModify.FileAlterPreservation = originalFlags.FileAlterPreservation
            flagsToModify.GroupingIdentity = originalFlags.GroupingIdentity
            flagsToModify.ReadOnly = originalFlags.ReadOnly
            flagsToModify.TagAlterPreservation = originalFlags.TagAlterPreservation
        End Sub

#End Region

#Region "PropertyComparer"

        ''' <summary>
        ''' A comparer used to sort the ProperyDescriptorCollection returned by ID3v2FrameProvider.
        ''' </summary>
        ''' <remarks>The main intention of this comparer is to sort properties by their DisplayNames, and putting (Flags) and (Encoding) first.</remarks>
        <EditorBrowsable(EditorBrowsableState.Never)> _
        Friend Class PropertyComparer
            Inherits Comparer(Of PropertyDescriptor)

            Public Overrides Function Compare(ByVal x As System.ComponentModel.PropertyDescriptor, ByVal y As System.ComponentModel.PropertyDescriptor) As Integer
                Return Comparer.Default.Compare(x.DisplayName, y.DisplayName)
            End Function

        End Class

#End Region

#Region "UsefulMethods"

        Public Class UsefulMethods

#Region "MinimumDigits"

            ''' <summary>
            ''' Returns a string containing at least the specified digits and the number.
            ''' </summary>
            Public Shared Function MinimumDigits(ByVal num As Integer, ByVal digits As Integer) As String
                If num.ToString.Length < digits Then
                    Dim i As Integer, str As String = ""
                    For i = 1 To (digits - num.ToString.Length)
                        str &= "0"
                    Next
                    str &= num.ToString
                    Return str
                Else
                    'TODO: Really substring?
                    Return CStr(num).Substring(0, digits)
                End If
            End Function

#End Region

#Region "cTimeSpanToString"

            ''' <summary>
            ''' Formats the Timespan to a human-readable string. eg. "1h 23m 40s 179ms"
            ''' </summary>
            Public Shared Function cTimeSpanToString(ByVal ts As TimeSpan) As String
                Dim str As String = ""
                If Not ts.Days = 0 Then
                    str &= ts.Days & " days "
                End If
                If Not ts.Hours = 0 Then
                    str &= ts.Hours & "h "
                End If
                If Not ts.Minutes = 0 Then
                    str &= ts.Minutes & "m "
                End If
                If Not ts.Seconds = 0 Then
                    str &= ts.Seconds & "s "
                End If
                If Not ts.Milliseconds = 0 Then
                    str &= ts.Milliseconds & "ms"
                End If
                Return str
            End Function

#End Region

#Region "cBytesLengthDescription"

            ''' <summary>
            ''' Formats the Bytes' length to a human-reable form. eg. 378965 returns "378.965 bytes".
            ''' </summary>
            Public Shared Function cBytesLengthDescription(ByVal length As Long) As String
                Dim str As String = ""
                If length = 0 Then
                    str = "0 bytes"
                Else
                    Do While Not length \ 1000 = 0
                        Dim f As Double = length / 1000
                        Dim demicals As Integer = (f - Math.Truncate(f)) * 1000
                        str = MinimumDigits(demicals, 3) & "." & str
                        length = Math.Truncate(f)
                    Loop
                    If Not length = 0 Then
                        str = CStr(length) & "." & str
                    End If
                    str = str.Substring(0, str.Length - 1)
                    str = str & " bytes"
                End If
                Return str
            End Function

#End Region

        End Class

#End Region

    End Class
End Namespace
