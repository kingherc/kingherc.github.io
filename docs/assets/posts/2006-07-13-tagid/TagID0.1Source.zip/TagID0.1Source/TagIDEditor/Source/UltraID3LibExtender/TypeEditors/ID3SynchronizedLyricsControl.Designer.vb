#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Namespace UltraID3LibExtender.TypeEditors
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class ID3SynchronizedLyricsControl
        Inherits System.Windows.Forms.Form

        'Form overrides dispose to clean up the component list.
        <System.Diagnostics.DebuggerNonUserCode()> _
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ID3SynchronizedLyricsControl))
            Me.OK_Button = New System.Windows.Forms.Button
            Me.Cancel_Button = New System.Windows.Forms.Button
            Me.LyricsList = New System.Windows.Forms.ListBox
            Me.mnLyrics = New System.Windows.Forms.ContextMenuStrip(Me.components)
            Me.mnNewLyric = New System.Windows.Forms.ToolStripMenuItem
            Me.mnDeleteLyric = New System.Windows.Forms.ToolStripMenuItem
            Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
            Me.mnImportSrt = New System.Windows.Forms.ToolStripMenuItem
            Me.mnExport = New System.Windows.Forms.ToolStripMenuItem
            Me.txtLyric = New System.Windows.Forms.TextBox
            Me.wmp = New AxMediaPlayer.AxMediaPlayer
            Me.tmr = New System.Windows.Forms.Timer(Me.components)
            Me.btnOpen = New System.Windows.Forms.Button
            Me.OpenFile = New System.Windows.Forms.OpenFileDialog
            Me.lblFile = New System.Windows.Forms.Label
            Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
            Me.chkFollowFile = New System.Windows.Forms.CheckBox
            Me.txtTime = New System.Windows.Forms.TextBox
            Me.PictureBox1 = New System.Windows.Forms.PictureBox
            Me.PictureBox2 = New System.Windows.Forms.PictureBox
            Me.lblTimer = New System.Windows.Forms.Label
            Me.btnHelp = New System.Windows.Forms.Button
            Me.Panel1 = New System.Windows.Forms.Panel
            Me.SaveFile = New System.Windows.Forms.SaveFileDialog
            Me.tt = New System.Windows.Forms.ToolTip(Me.components)
            Me.mnLyrics.SuspendLayout()
            CType(Me.wmp, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SplitContainer1.Panel1.SuspendLayout()
            Me.SplitContainer1.Panel2.SuspendLayout()
            Me.SplitContainer1.SuspendLayout()
            CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.Panel1.SuspendLayout()
            Me.SuspendLayout()
            '
            'OK_Button
            '
            Me.OK_Button.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.OK_Button.Location = New System.Drawing.Point(155, 386)
            Me.OK_Button.Margin = New System.Windows.Forms.Padding(4)
            Me.OK_Button.Name = "OK_Button"
            Me.OK_Button.Size = New System.Drawing.Size(67, 28)
            Me.OK_Button.TabIndex = 0
            Me.OK_Button.Text = "OK"
            '
            'Cancel_Button
            '
            Me.Cancel_Button.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
            Me.Cancel_Button.Location = New System.Drawing.Point(230, 386)
            Me.Cancel_Button.Margin = New System.Windows.Forms.Padding(4)
            Me.Cancel_Button.Name = "Cancel_Button"
            Me.Cancel_Button.Size = New System.Drawing.Size(67, 28)
            Me.Cancel_Button.TabIndex = 1
            Me.Cancel_Button.Text = "Cancel"
            '
            'LyricsList
            '
            Me.LyricsList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                        Or System.Windows.Forms.AnchorStyles.Left) _
                        Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.LyricsList.ContextMenuStrip = Me.mnLyrics
            Me.LyricsList.FormattingEnabled = True
            Me.LyricsList.ItemHeight = 16
            Me.LyricsList.Location = New System.Drawing.Point(12, 73)
            Me.LyricsList.Name = "LyricsList"
            Me.LyricsList.Size = New System.Drawing.Size(315, 244)
            Me.LyricsList.TabIndex = 1
            '
            'mnLyrics
            '
            Me.mnLyrics.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnNewLyric, Me.mnDeleteLyric, Me.ToolStripSeparator1, Me.mnImportSrt, Me.mnExport})
            Me.mnLyrics.Name = "mnLyrics"
            Me.mnLyrics.Size = New System.Drawing.Size(214, 98)
            '
            'mnNewLyric
            '
            Me.mnNewLyric.Image = Global.TagID.Editor.My.Resources.Resources.imgNewOne
            Me.mnNewLyric.Name = "mnNewLyric"
            Me.mnNewLyric.Size = New System.Drawing.Size(213, 22)
            Me.mnNewLyric.Text = "New Lyric (Ins)"
            '
            'mnDeleteLyric
            '
            Me.mnDeleteLyric.Image = Global.TagID.Editor.My.Resources.Resources.imgDelete
            Me.mnDeleteLyric.Name = "mnDeleteLyric"
            Me.mnDeleteLyric.Size = New System.Drawing.Size(213, 22)
            Me.mnDeleteLyric.Text = "Delete Lyric (Del)"
            '
            'ToolStripSeparator1
            '
            Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
            Me.ToolStripSeparator1.Size = New System.Drawing.Size(210, 6)
            '
            'mnImportSrt
            '
            Me.mnImportSrt.Image = Global.TagID.Editor.My.Resources.Resources.imgLeftArrow
            Me.mnImportSrt.Name = "mnImportSrt"
            Me.mnImportSrt.Size = New System.Drawing.Size(213, 22)
            Me.mnImportSrt.Text = "Import a .srt file"
            Me.mnImportSrt.ToolTipText = resources.GetString("mnImportSrt.ToolTipText")
            '
            'mnExport
            '
            Me.mnExport.Image = Global.TagID.Editor.My.Resources.Resources.imgRightArrow
            Me.mnExport.Name = "mnExport"
            Me.mnExport.Size = New System.Drawing.Size(213, 22)
            Me.mnExport.Text = "Export to a .srt file"
            Me.mnExport.ToolTipText = resources.GetString("mnExport.ToolTipText")
            '
            'txtLyric
            '
            Me.txtLyric.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                        Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.txtLyric.Location = New System.Drawing.Point(12, 351)
            Me.txtLyric.Multiline = True
            Me.txtLyric.Name = "txtLyric"
            Me.txtLyric.ScrollBars = System.Windows.Forms.ScrollBars.Both
            Me.txtLyric.Size = New System.Drawing.Size(315, 63)
            Me.txtLyric.TabIndex = 2
            Me.txtLyric.Text = "Lyric"
            Me.txtLyric.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            '
            'wmp
            '
            Me.wmp.Dock = System.Windows.Forms.DockStyle.Fill
            Me.wmp.Location = New System.Drawing.Point(0, 0)
            Me.wmp.Name = "wmp"
            Me.wmp.OcxState = CType(resources.GetObject("wmp.OcxState"), System.Windows.Forms.AxHost.State)
            Me.wmp.Size = New System.Drawing.Size(292, 378)
            Me.wmp.TabIndex = 3
            '
            'tmr
            '
            '
            'btnOpen
            '
            Me.btnOpen.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.btnOpen.Image = Global.TagID.Editor.My.Resources.Resources.imgRightArrow
            Me.btnOpen.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
            Me.btnOpen.Location = New System.Drawing.Point(43, 386)
            Me.btnOpen.Name = "btnOpen"
            Me.btnOpen.Size = New System.Drawing.Size(105, 28)
            Me.btnOpen.TabIndex = 5
            Me.btnOpen.Text = "Play File..."
            Me.btnOpen.TextAlign = System.Drawing.ContentAlignment.MiddleRight
            Me.btnOpen.UseVisualStyleBackColor = True
            '
            'OpenFile
            '
            Me.OpenFile.Title = "Select a file to open"
            '
            'lblFile
            '
            Me.lblFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                        Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.lblFile.AutoEllipsis = True
            Me.lblFile.Location = New System.Drawing.Point(33, 30)
            Me.lblFile.Name = "lblFile"
            Me.lblFile.Size = New System.Drawing.Size(294, 19)
            Me.lblFile.TabIndex = 6
            Me.lblFile.Text = "Filename of the currently played file"
            '
            'SplitContainer1
            '
            Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
            Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
            Me.SplitContainer1.Name = "SplitContainer1"
            '
            'SplitContainer1.Panel1
            '
            Me.SplitContainer1.Panel1.Controls.Add(Me.chkFollowFile)
            Me.SplitContainer1.Panel1.Controls.Add(Me.txtTime)
            Me.SplitContainer1.Panel1.Controls.Add(Me.PictureBox1)
            Me.SplitContainer1.Panel1.Controls.Add(Me.PictureBox2)
            Me.SplitContainer1.Panel1.Controls.Add(Me.lblTimer)
            Me.SplitContainer1.Panel1.Controls.Add(Me.LyricsList)
            Me.SplitContainer1.Panel1.Controls.Add(Me.lblFile)
            Me.SplitContainer1.Panel1.Controls.Add(Me.txtLyric)
            '
            'SplitContainer1.Panel2
            '
            Me.SplitContainer1.Panel2.Controls.Add(Me.btnHelp)
            Me.SplitContainer1.Panel2.Controls.Add(Me.Panel1)
            Me.SplitContainer1.Panel2.Controls.Add(Me.Cancel_Button)
            Me.SplitContainer1.Panel2.Controls.Add(Me.btnOpen)
            Me.SplitContainer1.Panel2.Controls.Add(Me.OK_Button)
            Me.SplitContainer1.Size = New System.Drawing.Size(639, 418)
            Me.SplitContainer1.SplitterDistance = 335
            Me.SplitContainer1.TabIndex = 7
            '
            'chkFollowFile
            '
            Me.chkFollowFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                        Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.chkFollowFile.Location = New System.Drawing.Point(13, 50)
            Me.chkFollowFile.Name = "chkFollowFile"
            Me.chkFollowFile.Size = New System.Drawing.Size(315, 21)
            Me.chkFollowFile.TabIndex = 23
            Me.chkFollowFile.Text = "Follow file being played"
            Me.chkFollowFile.TextAlign = System.Drawing.ContentAlignment.TopLeft
            Me.tt.SetToolTip(Me.chkFollowFile, "When checked, the lyrics are auto-selected according" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to the current position of " & _
                    "the file being played. When" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "checked, the lyric controls are disabled.")
            Me.chkFollowFile.UseVisualStyleBackColor = True
            '
            'txtTime
            '
            Me.txtTime.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                        Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.txtTime.Location = New System.Drawing.Point(12, 323)
            Me.txtTime.Name = "txtTime"
            Me.txtTime.Size = New System.Drawing.Size(315, 22)
            Me.txtTime.TabIndex = 22
            Me.txtTime.Text = "Time"
            '
            'PictureBox1
            '
            Me.PictureBox1.Image = Global.TagID.Editor.My.Resources.Resources.imgMusicFile
            Me.PictureBox1.Location = New System.Drawing.Point(12, 31)
            Me.PictureBox1.Name = "PictureBox1"
            Me.PictureBox1.Size = New System.Drawing.Size(16, 16)
            Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
            Me.PictureBox1.TabIndex = 10
            Me.PictureBox1.TabStop = False
            '
            'PictureBox2
            '
            Me.PictureBox2.Image = Global.TagID.Editor.My.Resources.Resources.imgTime
            Me.PictureBox2.Location = New System.Drawing.Point(12, 9)
            Me.PictureBox2.Name = "PictureBox2"
            Me.PictureBox2.Size = New System.Drawing.Size(16, 16)
            Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
            Me.PictureBox2.TabIndex = 9
            Me.PictureBox2.TabStop = False
            '
            'lblTimer
            '
            Me.lblTimer.Location = New System.Drawing.Point(33, 9)
            Me.lblTimer.Name = "lblTimer"
            Me.lblTimer.Size = New System.Drawing.Size(294, 19)
            Me.lblTimer.TabIndex = 7
            Me.lblTimer.Text = "Current position of file being played"
            '
            'btnHelp
            '
            Me.btnHelp.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.btnHelp.Location = New System.Drawing.Point(5, 386)
            Me.btnHelp.Name = "btnHelp"
            Me.btnHelp.Size = New System.Drawing.Size(32, 28)
            Me.btnHelp.TabIndex = 7
            Me.btnHelp.Text = "?"
            Me.btnHelp.UseVisualStyleBackColor = True
            '
            'Panel1
            '
            Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                        Or System.Windows.Forms.AnchorStyles.Left) _
                        Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.Panel1.Controls.Add(Me.wmp)
            Me.Panel1.Location = New System.Drawing.Point(5, 3)
            Me.Panel1.Name = "Panel1"
            Me.Panel1.Size = New System.Drawing.Size(292, 378)
            Me.Panel1.TabIndex = 6
            '
            'SaveFile
            '
            Me.SaveFile.Title = "Select a file to save to"
            '
            'ID3SynchronizedLyricsControl
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(639, 418)
            Me.Controls.Add(Me.SplitContainer1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
            Me.Margin = New System.Windows.Forms.Padding(4)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "ID3SynchronizedLyricsControl"
            Me.ShowInTaskbar = False
            Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
            Me.Text = "Edit Synchronized Lyrics"
            Me.mnLyrics.ResumeLayout(False)
            CType(Me.wmp, System.ComponentModel.ISupportInitialize).EndInit()
            Me.SplitContainer1.Panel1.ResumeLayout(False)
            Me.SplitContainer1.Panel1.PerformLayout()
            Me.SplitContainer1.Panel2.ResumeLayout(False)
            Me.SplitContainer1.ResumeLayout(False)
            CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
            Me.Panel1.ResumeLayout(False)
            Me.ResumeLayout(False)

        End Sub
        Friend WithEvents OK_Button As System.Windows.Forms.Button
        Friend WithEvents Cancel_Button As System.Windows.Forms.Button
        Friend WithEvents LyricsList As System.Windows.Forms.ListBox
        Friend WithEvents txtLyric As System.Windows.Forms.TextBox
        Friend WithEvents wmp As AxMediaPlayer.AxMediaPlayer
        Friend WithEvents tmr As System.Windows.Forms.Timer
        Friend WithEvents btnOpen As System.Windows.Forms.Button
        Friend WithEvents OpenFile As System.Windows.Forms.OpenFileDialog
        Friend WithEvents lblFile As System.Windows.Forms.Label
        Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
        Friend WithEvents lblTimer As System.Windows.Forms.Label
        Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
        Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
        Friend WithEvents Panel1 As System.Windows.Forms.Panel
        Friend WithEvents mnLyrics As System.Windows.Forms.ContextMenuStrip
        Friend WithEvents mnImportSrt As System.Windows.Forms.ToolStripMenuItem
        Friend WithEvents mnExport As System.Windows.Forms.ToolStripMenuItem
        Friend WithEvents SaveFile As System.Windows.Forms.SaveFileDialog
        Friend WithEvents tt As System.Windows.Forms.ToolTip
        Friend WithEvents txtTime As System.Windows.Forms.TextBox
        Friend WithEvents mnDeleteLyric As System.Windows.Forms.ToolStripMenuItem
        Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
        Friend WithEvents mnNewLyric As System.Windows.Forms.ToolStripMenuItem
        Friend WithEvents chkFollowFile As System.Windows.Forms.CheckBox
        Friend WithEvents btnHelp As System.Windows.Forms.Button

    End Class

End Namespace
