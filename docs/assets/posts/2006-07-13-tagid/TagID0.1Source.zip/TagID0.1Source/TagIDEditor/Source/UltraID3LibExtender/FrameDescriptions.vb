#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Namespace UltraID3LibExtender

#Region "FrameDescription Structure"

    Public Structure FrameDescription
        ''' <summary>
        ''' The 4-character FrameID of the frame.
        ''' </summary>
        Dim FrameID As String
        ''' <summary>
        ''' The (UltraID3Lib's) FrameType of the frame.
        ''' </summary>
        Dim FrameType As FrameTypes
        ''' <summary>
        ''' The AssemblyQualifiedName of the UltraID3Lib's Type associated with the frame.
        ''' </summary>
        Dim FullTypeName As String 'Fully qualified type name.
        ''' <summary>
        ''' The name of the frame.
        ''' </summary>
        Dim Name As String
        ''' <summary>
        ''' The summary of the frame.
        ''' </summary>
        Dim Summary As String
        ''' <summary>
        ''' The full description of the frame.
        ''' </summary>
        ''' <remarks>The Full Description is found in the FrameExplanations Xml file of the project's resources.</remarks>
        Dim FullDescription As String
        ''' <summary>
        ''' The category of the frame in a property grid.
        ''' </summary>
        ''' <remarks>The category is found in a Xml file containing the categories of each frame. This file should be named as Helper.FrameCategoriesFileName and should be found at Directory.WorkingDirectory. If it's not found, it's created and a default category for the frame is assigned.</remarks>
        Dim Category As String

        ''' <summary>
        ''' Gets a description of a property of the frame's associated class.
        ''' </summary>
        ''' <remarks>Basically called by ID3v2FrameDescription when the DescriptionAttribute is added to properties of ID3Frames. The description of the property is found in the FrameExplanations Xml file of the project's resources.</remarks>
        ''' <param name="propName">The name of the Property for which the description is searched.</param>
        Public Function GetPropertyDescription(ByVal propName) As String
            Dim str As String = ""
            If Not FrameID Is Nothing Then
                Dim x As XmlElement = Nothing
                Dim xdoc As New XmlDocument
                xdoc.LoadXml(My.Resources.xmlFrameExplanations)
                Dim xEl As XmlElement = xdoc.Item("FrameExplanations")
                If Not xEl Is Nothing Then
                    x = xEl.Item(FrameID)
                End If

                If Not x Is Nothing Then
                    Dim xProp As XmlElement = x.Item(propName)
                    If Not xProp Is Nothing Then
                        str = xProp.InnerText.Trim
                    End If
                End If
            End If
            Return str
        End Function

        ''' <summary>
        ''' Whether the frame can have multiple instances in a tag.
        ''' </summary>
        ''' <remarks>It basically searches if the FrameType is contained in UltraID3Lib's MultipleInstanceFrameTypes enumeration.</remarks>
        Public Function AllowedMultiple() As Boolean
            Dim b As Boolean = False
            If [Enum].IsDefined(GetType(MultipleInstanceFrameTypes), CType(FrameType, MultipleInstanceFrameTypes)) Then
                b = True
            End If
            Return b
        End Function

        ''' <summary>
        ''' Whether the frame cannot have multiple instances in a tag.
        ''' </summary>
        ''' <remarks>It basically searches if the FrameType is contained in UltraID3Lib's SingleInstanceFrameTypes enumeration.</remarks>
        Public Function AllowedSingle() As Boolean
            Dim b As Boolean = False
            If [Enum].IsDefined(GetType(SingleInstanceFrameTypes), CType(FrameType, SingleInstanceFrameTypes)) Then
                b = True
            End If
            Return b
        End Function

        ''' <summary>
        ''' Whether it's frame not yet supported by UltraID3Lib.
        ''' </summary>
        ''' <remarks></remarks>
        ''' <returns>True when the type derives from ID3UnableToDecodeYetFrame. Else, False.</returns>
        Public Function NotSupportedType() As Boolean
            Dim t As Type = Type.GetType(FullTypeName)
            Dim isnotsupported As Boolean = False
            Do While (Not t Is Nothing) And (Not isnotsupported)
                If t Is GetType(ID3UnableToDecodeYetFrame) Then
                    isnotsupported = True
                End If
                t = t.BaseType
            Loop
            Return isnotsupported
        End Function

        ''' <summary>
        ''' An empty FrameDescription structure.
        ''' </summary>
        ''' <remarks></remarks>
        ''' <returns>This should be returned for unknown and undefined FrameDescriptions.</returns>
        Public Shared ReadOnly Property Empty() As FrameDescription
            Get
                Dim fd As New FrameDescription
                fd.Category = ""
                fd.FrameID = ""
                fd.FrameType = FrameTypes.Unknown
                fd.FullDescription = ""
                fd.FullTypeName = ""
                fd.Name = ""
                fd.Summary = ""
                Return fd
            End Get
        End Property

        ''' <summary>
        ''' If this is an empty FrameDescription structure.
        ''' </summary>
        ''' <remarks></remarks>
        ''' <returns>True if this FrameDescription equals the Empty one.</returns>
        Public ReadOnly Property IsEmpty() As Boolean
            Get
                If Me.Category = "" And Me.FrameID = "" And Me.FrameType = FrameTypes.Unknown And Me.FullDescription = "" And Me.FullTypeName = "" And Me.Name = "" And Me.Summary = "" Then
                    Return True
                Else
                    Return False
                End If
            End Get
        End Property

    End Structure

#End Region

#Region "FrameDescriptionList"

    ''' <summary>
    ''' Contains info for all recognisable ID3 frames.
    ''' </summary>
    ''' <remarks>The FrameDescription structure contains info for a frame. All recognisable frames are contained in Helper.FrameDescriptions which is a FrameDescriptionsList.</remarks>
    Public Class FrameDescriptionList
        Inherits List(Of FrameDescription)

        ''' <summary>
        ''' Creates a new FrameDescriptionList.
        ''' </summary>
        ''' <remarks>As far as frame categories are concerned, the frame categories xml file is firstly searched in the application's running directory. If not found, the default frame categories xml file (it is found in the project's resources) is copied to the directory (so that the user may change it) and loaded.</remarks>
        Public Sub New()
            MyBase.New()

            'Starting to find the frame categories file.
            Dim xCatDoc As New XmlDocument, xCatPath As String = Directory.GetCurrentDirectory & "\" & Helper.FrameCategoriesFileName
            Try 'If the categories file is not found, try to create one with the default categories.
                If Not File.Exists(xCatPath) Then
                    Dim s As StreamWriter = File.CreateText(xCatPath)
                    s.Write(My.Resources.xmlFrameDefaultCategories)
                    s.Close()
                    s.Dispose()
                End If
            Catch ex As Exception

            End Try
            If File.Exists(xCatPath) Then
                xCatDoc.Load(xCatPath) 'If the frame categories file is found, load it.
            Else
                xCatDoc.LoadXml(My.Resources.xmlFrameDefaultCategories) 'If the frame categories file was not found (or was not created), load up the default categories.
            End If

            LoadFrameDescriptions(xCatDoc)
        End Sub

        ''' <summary>
        ''' Creates a new FrameDescriptionList with the frame categories defined by the supplied xml file (which should be similar to the default found in the project's resources).
        ''' </summary>
        Public Sub New(ByVal categoriesxml As XmlDocument)
            MyBase.New()
            LoadFrameDescriptions(categoriesxml)
        End Sub

#Region "LoadFrameDescriptions"

        ''' <summary>
        ''' Loads FrameDescription structures for each recognisable frame.
        ''' </summary>
        Private Sub LoadFrameDescriptions(ByVal categoriesxml As XmlDocument)
            '1. Starting to create the FrameDescriptions.
            Me.Clear()
            Dim xCats As XmlElement = categoriesxml.Item("FramesDefaultCategories")

            '1.1. Load the FrameExplanations xml.
            Dim xExplanationsDoc As New XmlDocument
            xExplanationsDoc.LoadXml(My.Resources.xmlFrameExplanations)
            Dim xExplanations As XmlElement = xExplanationsDoc.Item("FrameExplanations")

            '1.2. Load available frame types from UltraID3Lib Assembly to create FrameDescriptions.
            Dim a As Assembly
            Try
                a = Assembly.Load(Helper.UltraID3LibAssemblyName)
            Catch ex As Exception
                Throw New Exception(Helper.UltraID3LibAssemblyName & " assembly was not found.")
            End Try
            Dim ts() As Type = a.GetTypes, t As Type
            For Each t In ts
                If IsFrame(t) Then
                    Dim fd As New FrameDescription 'The new framedescription to add.
                    fd.FullTypeName = t.AssemblyQualifiedName

                    Dim o As ID3Frame = CreateFrameFromType(t)
                    If Not o Is Nothing Then
                        'If an instance is created then all info (except Full Description which is got from FrameExplanations xml) is got from the object.
                        fd.FrameID = o.FrameID
                        fd.FrameType = o.FrameType
                        fd.Name = o.FrameName
                        fd.Summary = o.FrameDescription.Trim

                        Dim x As XmlElement = xExplanations.Item(fd.FrameID)
                        If Not x Is Nothing Then
                            fd.FullDescription = x.Item("Full_Description").InnerText.Trim
                        End If
                    Else
                        'If an instance is not created then try to find the info from FrameExplanations.
                        'Try to find the XmlElement in FrameExplanations that has the type's class name.
                        Dim x As XmlElement = Nothing, xx As XmlNode
                        For Each xx In xExplanations.ChildNodes
                            If xx.NodeType = XmlNodeType.Element Then
                                If CType(xx, XmlElement).GetAttribute("Class") = t.Name Then
                                    x = xx
                                    Exit For
                                End If
                            End If
                        Next
                        If Not x Is Nothing Then
                            fd.FrameID = x.Name
                            fd.Name = x.GetAttribute("Name")
                            'Try to find the FrameType
                            Dim nameindex As Integer = Array.IndexOf([Enum].GetNames(GetType(FrameTypes)), t.Name.Replace("ID3", "").Replace("Frame", ""))
                            If Not nameindex = -1 Then
                                fd.FrameType = [Enum].Parse(GetType(FrameTypes), [Enum].GetNames(GetType(FrameTypes))(nameindex))
                            End If
                            fd.Summary = x.Item("Summary_Description").InnerText.Trim
                            fd.FullDescription = x.Item("Full_Description").InnerText.Trim
                        End If
                    End If

                    'Try to find it's category.
                    If Not xCats Is Nothing Then
                        Dim cat As String = Nothing
                        Dim x As XmlElement = xCats.Item(fd.FrameID)
                        If Not x Is Nothing Then
                            cat = x.GetAttribute("Category")
                        End If
                        If cat Is Nothing Then
                            cat = "Undefined Category"
                        End If
                        fd.Category = cat
                    End If

                    If Not (fd.FrameID Is Nothing Or fd.Name Is Nothing) Then 'If FrameDescription has at least the FrameID and Name, then add it.
                        Me.Add(fd)
                    End If
                End If
            Next
        End Sub

#End Region

#Region "Get from: FrameID, FrameName, Type, FullTypeName"

        ''' <summary>
        ''' Gets the FrameDescription that has this FrameID.
        ''' </summary>
        ''' <returns>If not found, returns Nothing.</returns>
        Public Function GetFromID(ByVal FrameID As String) As FrameDescription
            Dim fd As FrameDescription = FrameDescription.Empty, i As Integer
            For i = 0 To Count - 1
                fd = Item(i)
                If fd.FrameID = FrameID Then
                    Exit For
                ElseIf i = Count - 1 Then
                    fd = Nothing
                End If
            Next
            Return fd
        End Function

        ''' <summary>
        ''' Gets the FrameDescription that has this FrameType.
        ''' </summary>
        ''' <returns>If not found, returns Nothing.</returns>
        Public Function GetFromFrameType(ByVal FrameType As FrameTypes) As FrameDescription
            Dim fd As FrameDescription = FrameDescription.Empty, i As Integer
            For i = 0 To Count - 1
                fd = Item(i)
                If fd.FrameType = FrameType Then
                    Exit For
                ElseIf i = Count - 1 Then
                    fd = Nothing
                End If
            Next
            Return fd
        End Function

        ''' <summary>
        ''' Get the FrameDescription that has this Type's FullTypeName.
        ''' </summary>
        ''' <returns>If not found, returns Nothing.</returns>
        Public Function GetFromType(ByVal t As Type) As FrameDescription
            Dim fd As FrameDescription = FrameDescription.Empty, i As Integer
            For i = 0 To Count - 1
                fd = Item(i)
                If fd.FullTypeName = t.AssemblyQualifiedName Then
                    Exit For
                ElseIf i = Count - 1 Then
                    fd = Nothing
                End If
            Next
            Return fd
        End Function

        ''' <summary>
        ''' Gets the FrameDescription that has this Name.
        ''' </summary>
        ''' <returns>If not found, returns Nothing.</returns>
        Public Function GetFromName(ByVal Name As String) As FrameDescription
            Dim fd As FrameDescription = FrameDescription.Empty, i As Integer
            For i = 0 To Count - 1
                fd = Item(i)
                If fd.Name = Name Then
                    Exit For
                ElseIf i = Count - 1 Then
                    fd = Nothing
                End If
            Next
            Return fd
        End Function

#End Region

    End Class


#End Region

End Namespace