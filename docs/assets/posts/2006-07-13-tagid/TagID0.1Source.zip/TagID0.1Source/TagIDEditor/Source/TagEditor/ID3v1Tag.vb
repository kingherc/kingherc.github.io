#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

''' <summary>
''' The ID3v1Tag encapsulates the fields of an ID3v1 tag. Its main purpose is to be editable in a property grid.
''' </summary>
Public Class ID3v1Tag

#Region "Properties"

    Private _album As String
    ''' <summary>
    ''' The name of the album on which the Track appears. Max 30 characters.
    ''' </summary>
    <Description("The name of the album on which the Track appears. Max 30 characters.")> _
    Public Property Album() As String
        Get
            Return _album
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing Then
                If value.Length > 30 Then
                    value = value.Substring(0, 30)
                End If
            End If
            _album = value
        End Set
    End Property

    Private _artist As String
    ''' <summary>
    ''' The artist who performed the Track. Max 30 characters.
    ''' </summary>
    <Description("The artist who performed the Track. Max 30 characters.")> _
    Public Property Artist() As String
        Get
            Return _artist
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing Then
                If value.Length > 30 Then
                    value = value.Substring(0, 30)
                End If
            End If
            _artist = value
        End Set
    End Property

    Private _comments As String
    ''' <summary>
    ''' Any comments associated with this Track. Max 28 characters.
    ''' </summary>
    <Description("Any comments associated with this Track. Max 28 characters.")> _
    Public Property Comments() As String
        Get
            Return _comments
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing Then
                If value.Length > 28 Then
                    value = value.Substring(0, 28)
                End If
            End If
            _comments = value
        End Set
    End Property

    Private _genre As Byte = 255
    ''' <summary>
    ''' The genre byte (from the ID3v1 standard genre list) of the track.
    ''' </summary>
    <Description("The genre of the Track. Allowed values: 0-255.")> _
    <Editor(GetType(ID3GenreByteEditor), GetType(UITypeEditor))> _
    Public Property Genre() As Byte
        Get
            Return _genre
        End Get
        Set(ByVal value As Byte)
            _genre = value
        End Set
    End Property

    Private _title As String
    ''' <summary>
    ''' The title of the Track. Max 30 characters.
    ''' </summary>
    <Description("The title of the Track. Max 30 characters.")> _
    Public Property Title() As String
        Get
            Return _title
        End Get
        Set(ByVal value As String)
            If Not value Is Nothing Then
                If value.Length > 30 Then
                    value = value.Substring(0, 30)
                End If
            End If
            _title = value
        End Set
    End Property

    Private _tracknum As System.Nullable(Of Byte) = Nothing
    ''' <summary>
    ''' The number of the Track on the album.
    ''' </summary>
    <Description("The number of the Track on the album. Allowed values: 0-255.")> _
    <DisplayName("Track Number")> _
    Public Property TrackNum() As System.Nullable(Of Byte)
        Get
            Return _tracknum
        End Get
        Set(ByVal value As System.Nullable(Of Byte))
            _tracknum = value
        End Set
    End Property

    Private _year As System.Nullable(Of Short)
    ''' <summary>
    ''' The year of the recording. Must be a 4-digit number.
    ''' </summary>
    <Description("The year of the recording. Must be a 4-digit number.")> _
    Public Property Year() As System.Nullable(Of Short)
        Get
            Return _year
        End Get
        Set(ByVal value As System.Nullable(Of Short))
            If value.HasValue Then
                If Not value.Value = 0 Then
                    If value.ToString.Length < 4 Then
                        Do
                            value = value.Value * 10
                        Loop While Not value.ToString.Length = 4
                    ElseIf value.ToString.Length > 4 Then
                        Do
                            value = Math.Truncate(value.Value / 10)
                        Loop While Not value.ToString.Length = 4
                    End If
                End If
            Else
                value = Nothing
            End If
            _year = value
        End Set
    End Property

#End Region

#Region "Constructor and CopyToUltraV1Tag"

    ''' <summary>
    ''' A new ID3v1Tag with empty fields and the genre set to 255.
    ''' </summary>
    Public Sub New()
        _genre = 255
    End Sub

    ''' <summary>
    ''' A new ID3v1Tag with fields copied from the UltraID3Lib's ID3v1Tag.
    ''' </summary>
    ''' <param name="id1">The UltraID3Lib's ID3v1Tag from which to copy fields.</param>
    Public Sub New(ByVal id1 As HundredMilesSoftware.UltraID3Lib.ID3v1Tag)
        Me.New()
        Me.Album = id1.Album
        Me.Artist = id1.Artist
        Me.Comments = id1.Comments
        Me.Genre = id1.Genre
        Me.Title = id1.Title
        Me.TrackNum = id1.TrackNum
        Me.Year = id1.Year
    End Sub

    ''' <summary>
    ''' Tries to copy the fields of the class to the UltraID3Lib's namesake class.
    ''' </summary>
    ''' <param name="v1">The UltraID3Lib's ID3v1Tag to which to copy fields.</param>
    Public Sub CopyToUltraV1Tag(ByRef v1 As HundredMilesSoftware.UltraID3Lib.ID3v1Tag)
        Try
            v1.Album = Me.Album
            v1.Artist = Me.Artist
            v1.Comments = Me.Comments
            v1.Genre = Me.Genre
            v1.Title = Me.Title
            v1.TrackNum = Me.TrackNum
            v1.Year = Me.Year
        Catch ex As Exception

        End Try
    End Sub

#End Region

#Region "ID3GenreByteEditor"

    <EditorBrowsable(EditorBrowsableState.Never)> _
    Private Class ID3GenreByteEditor
        Inherits UITypeEditor

        Public Overrides Function GetEditStyle(ByVal context As System.ComponentModel.ITypeDescriptorContext) As UITypeEditorEditStyle
            Return UITypeEditorEditStyle.DropDown
        End Function

        Public Overrides Function EditValue(ByVal context As ITypeDescriptorContext, ByVal provider As IServiceProvider, ByVal value As Object) As Object
            Dim editorService As Windows.Forms.Design.IWindowsFormsEditorService = Nothing

            If Not (provider Is Nothing) Then
                editorService = CType(provider.GetService(GetType(Windows.Forms.Design.IWindowsFormsEditorService)), Windows.Forms.Design.IWindowsFormsEditorService)
            End If

            If Not (editorService Is Nothing) Then
                Dim ob As System.Nullable(Of Byte) = value, ostr As String = ""
                If ob.HasValue Then
                    ostr = CStr(ob)
                End If
                Dim selectionControl As New TypeEditors.ID3GenreControl(ostr, editorService, True)
                editorService.DropDownControl(selectionControl)
                Dim b As System.Nullable(Of Byte) = selectionControl.GenreByte
                If b.HasValue Then
                    value = b
                End If
            End If

            Return value
        End Function

    End Class

#End Region

End Class