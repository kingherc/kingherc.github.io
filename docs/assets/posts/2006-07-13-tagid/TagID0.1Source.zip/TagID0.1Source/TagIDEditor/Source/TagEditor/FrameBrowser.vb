#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

''' <summary>
''' This is used to show information for each recognisable frame. It's also used by the ID3TagEditor to select a new frame to insert into an ID3v2Tag.
''' </summary>
Public Class FrameBrowser

    Private previousID As String
    Private previousName As String

    Public Enum SortMethods
        ''' <summary>
        ''' Sort and show frames by their frame IDs.
        ''' </summary>
        ByFrameID = 1
        ''' <summary>
        ''' Sort and show frames by their frame names.
        ''' </summary>
        ByFrameName = 2
    End Enum

    Private _sortMethod As SortMethods
    ''' <summary>
    ''' The SortMethod (by FrameName or by FrameID) used to present the frames.
    ''' </summary>
    Public Property SortMethod() As SortMethods
        Get
            Return _sortMethod
        End Get
        Set(ByVal value As SortMethods)
            _sortMethod = value
            If value = SortMethods.ByFrameID Then
                lblSort.Text = "Sort by Frame Names"
            ElseIf value = SortMethods.ByFrameName Then
                lblSort.Text = "Sort by Frame IDs"
            End If
            RePopulate()
        End Set
    End Property

    ''' <summary>
    ''' Gets the selected item string.
    ''' </summary>
    ''' <remarks>When SortMethod is by FrameName, this string is a frame name. When SortMethod is by FrameID, this string is a frame id.</remarks>
    Public ReadOnly Property SelectedItem() As String
        Get
            Return lbFrames.SelectedItem
        End Get
    End Property

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Me.DialogResult = Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub RePopulate()
        lbFrames.Items.Clear()
        Dim fd As FrameDescription
        For Each fd In Helper.FrameDescriptions
            If SortMethod = SortMethods.ByFrameID Then
                lbFrames.Items.Add(fd.FrameID)
                If fd.FrameID = previousID Or fd.Name = previousName Then
                    lbFrames.SelectedItem = fd.FrameID
                End If
            ElseIf SortMethod = SortMethods.ByFrameName Then
                lbFrames.Items.Add(fd.Name)
                If fd.FrameID = previousID Or fd.Name = previousName Then
                    lbFrames.SelectedItem = fd.Name
                End If
            End If
        Next
    End Sub

    Private Sub lblSort_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lblSort.LinkClicked
        If SortMethod = SortMethods.ByFrameID Then
            SortMethod = SortMethods.ByFrameName
        ElseIf SortMethod = SortMethods.ByFrameName Then
            SortMethod = SortMethods.ByFrameID
        End If
    End Sub

    Private Sub lbFrames_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbFrames.SelectedIndexChanged
        If SortMethod = SortMethods.ByFrameID Then
            previousID = lbFrames.SelectedItem
            previousName = Nothing
        ElseIf SortMethod = SortMethods.ByFrameName Then
            previousName = lbFrames.SelectedItem
            previousID = Nothing
        End If
        RefreshFrame()
    End Sub

    Private Sub FrameBrowser_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If lbFrames.SelectedItem = Nothing And Not lbFrames.Items.Count = 0 Then
            lbFrames.SelectedItem = lbFrames.Items(0)
        End If
        txtDescription.Font = New Font(FontFamily.GenericMonospace, 8, FontStyle.Regular, GraphicsUnit.Point)
    End Sub

    Private Sub RefreshFrame()
        Dim fd As FrameDescription = Nothing
        If SortMethod = SortMethods.ByFrameID Then
            fd = FrameDescriptions.GetFromID(lbFrames.SelectedItem)
        ElseIf SortMethod = SortMethods.ByFrameName Then
            fd = FrameDescriptions.GetFromName(lbFrames.SelectedItem)
        End If
        If Not fd.Equals(Nothing) Then
            lblName.Visible = True
            lblID.Visible = True
            lblCategory.Visible = True
            lblInstances.Visible = True
            lblNotSupported.Visible = False
            txtDescription.Visible = True

            lblName.Text = fd.Name
            lblID.Text = "Frame ID: " & fd.FrameID
            lblCategory.Text = "Category chosen: " & fd.Category
            If fd.AllowedMultiple Then
                lblInstances.Text = "Instances allowed in a tag: Multiple"
            ElseIf fd.AllowedSingle Then
                lblInstances.Text = "Instances allowed in a tag: Single"
            Else
                lblInstances.Visible = False
            End If
            Dim desc As String = fd.FullDescription
            If desc Is Nothing Then
                desc = fd.Summary
            End If
            If desc Is Nothing Then
                desc = "The description of the frame was not found."
            End If
            txtDescription.Text = desc

            Dim isnotsupported As Boolean = fd.NotSupportedType
            lblNotSupported.Visible = isnotsupported
        Else
            lblName.Visible = True
            lblName.Text = "No Frame"
            lblID.Visible = False
            lblCategory.Visible = False
            lblInstances.Visible = False
            lblNotSupported.Visible = False
            txtDescription.Visible = True
            txtDescription.Text = "Couldn't load a frame type."
        End If
    End Sub

    ''' <summary>
    ''' Selects the frame that has this Frame name.
    ''' </summary>
    Public Sub ChangeToFrameName(ByVal name As String)
        Dim prevSort As SortMethods = SortMethod
        SortMethod = SortMethods.ByFrameName
        If lbFrames.Items.Contains(name) Then
            lbFrames.SelectedItem = name
        End If
        SortMethod = prevSort
    End Sub

    ''' <summary>
    ''' Selects the frame that has this FrameID.
    ''' </summary>
    Public Sub ChangeToFrameID(ByVal id As String)
        Dim prevSort As SortMethods = SortMethod
        SortMethod = SortMethods.ByFrameID
        If lbFrames.Items.Contains(id) Then
            lbFrames.SelectedItem = id
        End If
        SortMethod = prevSort
    End Sub

End Class