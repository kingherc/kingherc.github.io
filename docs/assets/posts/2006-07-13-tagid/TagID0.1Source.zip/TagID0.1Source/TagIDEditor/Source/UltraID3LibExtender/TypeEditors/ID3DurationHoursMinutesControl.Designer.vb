#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Namespace UltraID3LibExtender.TypeEditors
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class ID3DurationHoursMinutesControl
        Inherits System.Windows.Forms.UserControl

        'UserControl overrides dispose to clean up the component list.
        <System.Diagnostics.DebuggerNonUserCode()> _
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container
            Me.tt = New System.Windows.Forms.ToolTip(Me.components)
            Me.numericHours = New System.Windows.Forms.NumericUpDown
            Me.numericMinutes = New System.Windows.Forms.NumericUpDown
            Me.lblHours = New System.Windows.Forms.Label
            Me.lblMinutes = New System.Windows.Forms.Label
            CType(Me.numericHours, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.numericMinutes, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            '
            'tt
            '
            Me.tt.AutoPopDelay = 20000
            Me.tt.InitialDelay = 500
            Me.tt.ReshowDelay = 100
            '
            'numericHours
            '
            Me.numericHours.Location = New System.Drawing.Point(16, 27)
            Me.numericHours.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
            Me.numericHours.Name = "numericHours"
            Me.numericHours.Size = New System.Drawing.Size(53, 22)
            Me.numericHours.TabIndex = 0
            '
            'numericMinutes
            '
            Me.numericMinutes.Location = New System.Drawing.Point(86, 27)
            Me.numericMinutes.Maximum = New Decimal(New Integer() {59, 0, 0, 0})
            Me.numericMinutes.Name = "numericMinutes"
            Me.numericMinutes.Size = New System.Drawing.Size(55, 22)
            Me.numericMinutes.TabIndex = 1
            '
            'lblHours
            '
            Me.lblHours.AutoSize = True
            Me.lblHours.Location = New System.Drawing.Point(13, 7)
            Me.lblHours.Name = "lblHours"
            Me.lblHours.Size = New System.Drawing.Size(46, 17)
            Me.lblHours.TabIndex = 2
            Me.lblHours.Text = "Hours"
            '
            'lblMinutes
            '
            Me.lblMinutes.AutoSize = True
            Me.lblMinutes.Location = New System.Drawing.Point(83, 7)
            Me.lblMinutes.Name = "lblMinutes"
            Me.lblMinutes.Size = New System.Drawing.Size(57, 17)
            Me.lblMinutes.TabIndex = 3
            Me.lblMinutes.Text = "Minutes"
            '
            'ID3DurationHoursMinutesControl
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.Controls.Add(Me.lblMinutes)
            Me.Controls.Add(Me.lblHours)
            Me.Controls.Add(Me.numericMinutes)
            Me.Controls.Add(Me.numericHours)
            Me.Name = "ID3DurationHoursMinutesControl"
            Me.Size = New System.Drawing.Size(159, 62)
            CType(Me.numericHours, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.numericMinutes, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub
        Friend WithEvents tt As System.Windows.Forms.ToolTip
        Friend WithEvents numericHours As System.Windows.Forms.NumericUpDown
        Friend WithEvents numericMinutes As System.Windows.Forms.NumericUpDown
        Friend WithEvents lblHours As System.Windows.Forms.Label
        Friend WithEvents lblMinutes As System.Windows.Forms.Label

    End Class

End Namespace
