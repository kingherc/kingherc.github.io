#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Namespace UltraID3LibExtender.TypeEditors

    <ToolboxItem(False)> _
    Public Class FrameFlagsControl

        Private editorService As IWindowsFormsEditorService
        Private disableRefresh As Boolean = False

        Public Sub New(ByVal fg As FrameFlags, ByVal editorService As Windows.Forms.Design.IWindowsFormsEditorService)
            InitializeComponent()
            Me.Flags = fg
            Me.editorService = editorService
        End Sub

        Private f As FrameFlags
        ''' <summary>
        ''' Gets or sets the Flags selected.
        ''' </summary>
        Public Property Flags() As FrameFlags
            Get
                Return f
            End Get
            Set(ByVal value As FrameFlags)
                'CloneFrameFlags(value, f)
                f = value
            End Set
        End Property

        Private Sub FrameFlagsSelectionControl_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim c As Control, maxwidth As Integer = 200
            For Each c In Me.Controls
                If c.Width > maxwidth Then
                    maxwidth = c.Width
                End If
            Next
            Me.Width = maxwidth

            disableRefresh = True
            chkCompressed.Checked = f.Compressed
            chkEncrypted.Checked = f.Encrypted
            chkFileAlterPreservation.Checked = f.FileAlterPreservation
            chkGroupingIdentity.Checked = f.GroupingIdentity
            chkReadOnly.Checked = f.ReadOnly
            chkTagAlterPreservation.Checked = f.TagAlterPreservation
            disableRefresh = False
        End Sub

        Private Sub RequiredRefresh(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkCompressed.CheckedChanged, chkEncrypted.CheckedChanged, chkFileAlterPreservation.CheckedChanged, chkGroupingIdentity.CheckedChanged, chkReadOnly.CheckedChanged, chkTagAlterPreservation.CheckedChanged
            If Not disableRefresh Then
                f.Compressed = chkCompressed.Checked
                f.Encrypted = chkEncrypted.Checked()
                f.FileAlterPreservation = chkFileAlterPreservation.Checked()
                f.GroupingIdentity = chkGroupingIdentity.Checked()
                f.ReadOnly = chkReadOnly.Checked()
                f.TagAlterPreservation = chkTagAlterPreservation.Checked()
            End If
        End Sub

        Private Sub lblClose_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lblClose.LinkClicked
            Me.editorService.CloseDropDown()
        End Sub

    End Class
End Namespace