#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Namespace UltraID3LibExtender.TypeEditors
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class ID3GenreControl
        Inherits System.Windows.Forms.UserControl

        'UserControl overrides dispose to clean up the component list.
        <System.Diagnostics.DebuggerNonUserCode()> _
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container
            Me.tip = New System.Windows.Forms.ToolTip(Me.components)
            Me.lblID3v2Description = New System.Windows.Forms.Label
            Me.GenreList = New System.Windows.Forms.ComboBox
            Me.lblID3v1Description = New System.Windows.Forms.Label
            Me.SuspendLayout()
            '
            'lblID3v2Description
            '
            Me.lblID3v2Description.AutoSize = True
            Me.lblID3v2Description.Location = New System.Drawing.Point(5, 3)
            Me.lblID3v2Description.Name = "lblID3v2Description"
            Me.lblID3v2Description.Size = New System.Drawing.Size(187, 68)
            Me.lblID3v2Description.TabIndex = 0
            Me.lblID3v2Description.Text = "In ID3v2 tags you can define" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "your own genre. Meanwhile," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "you can also use ID3v1'" & _
                "s" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "standard genre list:"
            '
            'GenreList
            '
            Me.GenreList.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                        Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.GenreList.FormattingEnabled = True
            Me.GenreList.Location = New System.Drawing.Point(8, 77)
            Me.GenreList.Name = "GenreList"
            Me.GenreList.Size = New System.Drawing.Size(184, 24)
            Me.GenreList.TabIndex = 1
            '
            'lblID3v1Description
            '
            Me.lblID3v1Description.AutoSize = True
            Me.lblID3v1Description.Location = New System.Drawing.Point(5, 6)
            Me.lblID3v1Description.Name = "lblID3v1Description"
            Me.lblID3v1Description.Size = New System.Drawing.Size(186, 68)
            Me.lblID3v1Description.TabIndex = 2
            Me.lblID3v1Description.Text = "In ID3v1, you cannot define" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "your own genre. Select a" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "genre code from the ID3v1'" & _
                "s" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "standard genre list."
            Me.lblID3v1Description.Visible = False
            '
            'ID3GenreControl
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.Controls.Add(Me.lblID3v1Description)
            Me.Controls.Add(Me.GenreList)
            Me.Controls.Add(Me.lblID3v2Description)
            Me.Name = "ID3GenreControl"
            Me.Size = New System.Drawing.Size(199, 110)
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub
        Friend WithEvents tip As System.Windows.Forms.ToolTip
        Friend WithEvents lblID3v2Description As System.Windows.Forms.Label
        Friend WithEvents GenreList As System.Windows.Forms.ComboBox
        Friend WithEvents lblID3v1Description As System.Windows.Forms.Label

    End Class

End Namespace
