#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Namespace UltraID3LibExtender.TypeEditors

    <ToolboxItem(False)> _
    Public Class ID3GenreControl

        Private editorService As IWindowsFormsEditorService
        Private disableRefresh As Boolean = False

        ''' <summary>
        ''' Initializes a new ID3GenreControl. Can be used to select an ID3v1 or ID3v2 genre.
        ''' </summary>
        ''' <param name="genre">The pre-selected value (if the user has already chosen a genre).</param>
        ''' <param name="isID3v1">If the control should use only the ID3v1 standard genre list.</param>
        ''' <remarks></remarks>
        Public Sub New(ByVal genre As String, ByVal editorService As Windows.Forms.Design.IWindowsFormsEditorService, Optional ByVal isID3v1 As Boolean = False)
            InitializeComponent()
            Me.Genre = genre
            Me.editorService = editorService
            Me.isID3v1 = isID3v1
        End Sub

        Private isID3v1 As Boolean

        Private _genre As String
        ''' <summary>
        ''' Returns the selected string. If you want the genre byte, use the GenreByte property.
        ''' </summary>
        Public Property Genre() As String
            Get
                Return _genre
            End Get
            Set(ByVal value As String)
                _genre = value
            End Set
        End Property

        ''' <summary>
        ''' Tries to find the ID3v1 genre byte from the selected string.
        ''' </summary>
        Public ReadOnly Property GenreByte() As System.Nullable(Of Byte)
            Get
                Try
                    If Not Genre Is Nothing Then
                        Dim str As String = Genre.Substring(Genre.IndexOf("(") + 1, Genre.IndexOf(")") - Genre.IndexOf("(") - 1)
                        If str = "" Then
                            Return Nothing
                        Else
                            Return str
                        End If
                    Else
                        Return Nothing
                    End If
                Catch ex As Exception
                    Return Nothing
                End Try
            End Get
        End Property

        Private Sub ID3GenreControl_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim gb As System.Nullable(Of Byte) = GenreByte
            Dim gs As New GenreInfoCollection
            Dim g As GenreInfo
            For Each g In gs
                Dim str As String = "(" & g.Number & ")" & g.Name
                GenreList.Items.Add(str)
                If str = Genre Or g.Name = Genre Or CStr(g.Number) = Genre Then
                    GenreList.SelectedItem = str
                End If
                If gb.HasValue Then
                    If g.Number = CInt(gb) Then
                        GenreList.SelectedItem = str
                    End If
                End If
            Next
            If GenreList.SelectedIndex = -1 Then
                If Not isID3v1 Then
                    GenreList.Items.Add(Genre)
                    GenreList.SelectedItem = Genre
                End If
            End If

            lblID3v1Description.Visible = isID3v1
            lblID3v2Description.Visible = Not isID3v1
        End Sub

        Private Sub GenreList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GenreList.SelectedIndexChanged
            Me.Genre = GenreList.SelectedItem
        End Sub

    End Class
End Namespace