#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class ID3TagEditorAbout
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pbAppIcon = New System.Windows.Forms.PictureBox
        Me.lblAppName = New System.Windows.Forms.Label
        Me.lblAppVersion = New System.Windows.Forms.Label
        Me.lblWebsite = New System.Windows.Forms.Label
        Me.pnlSeperator = New System.Windows.Forms.Panel
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.lblContact = New System.Windows.Forms.Label
        Me.txtlicense = New System.Windows.Forms.TextBox
        Me.btnOK = New System.Windows.Forms.Button
        Me.txtAcknowledgements = New System.Windows.Forms.TextBox
        Me.btnGNUGPL = New System.Windows.Forms.Button
        CType(Me.pbAppIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pbAppIcon
        '
        Me.pbAppIcon.Location = New System.Drawing.Point(12, 12)
        Me.pbAppIcon.Name = "pbAppIcon"
        Me.pbAppIcon.Size = New System.Drawing.Size(48, 48)
        Me.pbAppIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.pbAppIcon.TabIndex = 0
        Me.pbAppIcon.TabStop = False
        '
        'lblAppName
        '
        Me.lblAppName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblAppName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.lblAppName.Location = New System.Drawing.Point(65, 12)
        Me.lblAppName.Name = "lblAppName"
        Me.lblAppName.Size = New System.Drawing.Size(417, 33)
        Me.lblAppName.TabIndex = 1
        Me.lblAppName.Text = "TagID"
        Me.lblAppName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAppVersion
        '
        Me.lblAppVersion.AutoSize = True
        Me.lblAppVersion.Location = New System.Drawing.Point(67, 45)
        Me.lblAppVersion.Name = "lblAppVersion"
        Me.lblAppVersion.Size = New System.Drawing.Size(84, 17)
        Me.lblAppVersion.TabIndex = 2
        Me.lblAppVersion.Text = "Version: 0.1"
        '
        'lblWebsite
        '
        Me.lblWebsite.AutoSize = True
        Me.lblWebsite.Location = New System.Drawing.Point(67, 64)
        Me.lblWebsite.Name = "lblWebsite"
        Me.lblWebsite.Size = New System.Drawing.Size(297, 17)
        Me.lblWebsite.TabIndex = 3
        Me.lblWebsite.Text = "Website: http://www34.brinkster.com/kingherc/"
        '
        'pnlSeperator
        '
        Me.pnlSeperator.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlSeperator.BackColor = System.Drawing.Color.Black
        Me.pnlSeperator.Location = New System.Drawing.Point(71, 105)
        Me.pnlSeperator.Name = "pnlSeperator"
        Me.pnlSeperator.Size = New System.Drawing.Size(411, 1)
        Me.pnlSeperator.TabIndex = 5
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.Black
        Me.Panel1.Location = New System.Drawing.Point(71, 177)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(411, 1)
        Me.Panel1.TabIndex = 6
        '
        'lblContact
        '
        Me.lblContact.AutoSize = True
        Me.lblContact.Location = New System.Drawing.Point(68, 83)
        Me.lblContact.Name = "lblContact"
        Me.lblContact.Size = New System.Drawing.Size(279, 17)
        Me.lblContact.TabIndex = 7
        Me.lblContact.Text = "Contact: Kingherc (king_herc@yahoo.com)"
        '
        'txtlicense
        '
        Me.txtlicense.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtlicense.BackColor = System.Drawing.SystemColors.Control
        Me.txtlicense.Location = New System.Drawing.Point(71, 184)
        Me.txtlicense.Multiline = True
        Me.txtlicense.Name = "txtlicense"
        Me.txtlicense.ReadOnly = True
        Me.txtlicense.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtlicense.Size = New System.Drawing.Size(411, 101)
        Me.txtlicense.TabIndex = 8
        '
        'btnOK
        '
        Me.btnOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOK.Location = New System.Drawing.Point(389, 293)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(94, 30)
        Me.btnOK.TabIndex = 9
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'txtAcknowledgements
        '
        Me.txtAcknowledgements.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtAcknowledgements.BackColor = System.Drawing.SystemColors.Control
        Me.txtAcknowledgements.Location = New System.Drawing.Point(71, 112)
        Me.txtAcknowledgements.Multiline = True
        Me.txtAcknowledgements.Name = "txtAcknowledgements"
        Me.txtAcknowledgements.ReadOnly = True
        Me.txtAcknowledgements.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtAcknowledgements.Size = New System.Drawing.Size(411, 59)
        Me.txtAcknowledgements.TabIndex = 10
        '
        'btnGNUGPL
        '
        Me.btnGNUGPL.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnGNUGPL.Location = New System.Drawing.Point(70, 293)
        Me.btnGNUGPL.Name = "btnGNUGPL"
        Me.btnGNUGPL.Size = New System.Drawing.Size(122, 30)
        Me.btnGNUGPL.TabIndex = 11
        Me.btnGNUGPL.Text = "GNU GPL..."
        Me.btnGNUGPL.UseVisualStyleBackColor = True
        '
        'ID3TagEditorAbout
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(495, 335)
        Me.Controls.Add(Me.btnGNUGPL)
        Me.Controls.Add(Me.txtAcknowledgements)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.txtlicense)
        Me.Controls.Add(Me.lblContact)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.pnlSeperator)
        Me.Controls.Add(Me.lblWebsite)
        Me.Controls.Add(Me.lblAppVersion)
        Me.Controls.Add(Me.lblAppName)
        Me.Controls.Add(Me.pbAppIcon)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ID3TagEditorAbout"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.Text = "About..."
        CType(Me.pbAppIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pbAppIcon As System.Windows.Forms.PictureBox
    Friend WithEvents lblAppName As System.Windows.Forms.Label
    Friend WithEvents lblAppVersion As System.Windows.Forms.Label
    Friend WithEvents lblWebsite As System.Windows.Forms.Label
    Friend WithEvents pnlSeperator As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblContact As System.Windows.Forms.Label
    Friend WithEvents txtlicense As System.Windows.Forms.TextBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents txtAcknowledgements As System.Windows.Forms.TextBox
    Friend WithEvents btnGNUGPL As System.Windows.Forms.Button
End Class