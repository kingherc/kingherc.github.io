#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Imports System.Windows.Forms

    ''' <summary>
    ''' With this form, the user can edit the frame categories of the Helper.FrameDescriptions.
    ''' </summary>
    Public Class ID3TagEditorCategories

#Region "Form Load"

        Private Sub EditCategoriesDialog_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Me.imgs.Images.Add(My.Resources.imgTextFileLow)
            Me.imgs.Images.Add(My.Resources.imgFolderLow)

            LoadCategories(FrameDescriptions)
        End Sub

#End Region

#Region "Drag operation"

        Private Sub tv_ItemDrag(ByVal sender As Object, ByVal e As System.Windows.Forms.ItemDragEventArgs) Handles tv.ItemDrag
            DoDragDrop(e.Item, DragDropEffects.Move)
        End Sub

        Private Sub tv_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles tv.DragEnter
            e.Effect = e.AllowedEffect
        End Sub

        Private Sub tv_DragOver(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles tv.DragOver
            Dim targetPoint As Point = tv.PointToClient(New Point(e.X, e.Y))
            tv.SelectedNode = tv.GetNodeAt(targetPoint)
        End Sub

        Private Sub tv_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles tv.DragDrop
            Dim targetPoint As Point = tv.PointToClient(New Point(e.X, e.Y))
            Dim targetNode As TreeNode = tv.GetNodeAt(targetPoint)
            Dim draggedNode As TreeNode = CType(e.Data.GetData(GetType(TreeNode)), TreeNode)
            If targetNode.Tag.ToString.Substring(0, 1) = "c" And draggedNode.Tag.ToString.Substring(0, 1) = "f" Then
                If e.Effect = DragDropEffects.Move Then
                    draggedNode.Parent.Nodes.Remove(draggedNode)
                    targetNode.Nodes.Add(draggedNode)
                End If
            End If
        End Sub

#End Region

#Region "LoadCategories"

        Private Sub LoadCategories(ByVal fds As FrameDescriptionList)
            'Load FrameDescriptions
            tv.Nodes.Clear()
            Dim fd As FrameDescription
            For Each fd In fds
                Dim catN As TreeNode = Nothing
                Dim i As Integer
                For i = 0 To tv.Nodes.Count - 1
                    If tv.Nodes(i).Tag = "c" & fd.Category Then
                        catN = tv.Nodes(i)
                        Exit For
                    End If
                Next
                If catN Is Nothing Then
                    catN = New TreeNode(fd.Category, 1, 1)
                    catN.Tag = "c" & fd.Category
                    tv.Nodes.Add(catN)
                End If
                Dim fN As New TreeNode(fd.FrameID & " " & fd.Name, 0, 0)
                fN.Tag = "f" & fd.FrameID
                catN.Nodes.Add(fN)
            Next
        End Sub

#End Region

#Region "Load Default"

        Private Sub btnLoadDefault_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadDefault.Click
            Dim xmldoc As New XmlDocument
            xmldoc.LoadXml(My.Resources.xmlFrameDefaultCategories)
            Dim fds As New FrameDescriptionList(xmldoc)
            LoadCategories(fds)
        End Sub

#End Region

#Region "Expand / Collapse"

        Private Sub mnExpandAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnExpandAll.Click
            tv.ExpandAll()
        End Sub

        Private Sub mnCollapseAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCollapseAll.Click
            tv.CollapseAll()
        End Sub

#End Region

#Region "New Category"

        Private Sub mnNewCategory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnNewCategory.Click
            Dim newcatname As String = "New Category"
            Dim i As Integer = 1
            Do While ContainsCategory(newcatname)
                i += 1
                newcatname = "New Category (" & i & ")"
            Loop
            Dim catN As New TreeNode(newcatname, 1, 1)
            catN.Tag = "c" & newcatname
            tv.Nodes.Add(catN)
        End Sub

        Private Function ContainsCategory(ByVal catname As String) As Boolean
            Dim i As Integer, b As Boolean = False
            For i = 0 To tv.Nodes.Count - 1
                If tv.Nodes.Item(i).Tag = "c" & catname Then
                    b = True
                    Exit For
                End If
            Next
            Return b
        End Function

#End Region

#Region "Renaming a category"

        Private Sub tv_BeforeLabelEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.NodeLabelEditEventArgs) Handles tv.BeforeLabelEdit
            If e.Node.Tag.ToString.Substring(0, 1) = "f" Then
                e.CancelEdit = True
            End If
        End Sub

        Private Sub tv_AfterLabelEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.NodeLabelEditEventArgs) Handles tv.AfterLabelEdit
            If e.Node.Tag.ToString.Substring(0, 1) = "c" Then
                Dim i As Integer
                For i = 0 To tv.Nodes.Count - 1
                    If tv.Nodes(i).Text = e.Label Then
                        e.CancelEdit = True
                        Exit Sub
                    End If
                Next
                e.Node.Text = e.Label
                e.Node.Tag = "c" & e.Label
            Else
                e.CancelEdit = True
            End If
        End Sub

        Private Sub mnRenameCategory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnRenameCategory.Click
            If tv.SelectedNode.Tag.ToString.Substring(0, 1) = "c" Then
                tv.SelectedNode.BeginEdit()
            End If
        End Sub

#End Region

#Region "OK Button"

        Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
            Dim catN As TreeNode
            For Each catN In tv.Nodes
                Dim fN As TreeNode
                For Each fN In catN.Nodes
                    Dim fd As FrameDescription = FrameDescriptions.GetFromID(fN.Tag.ToString.Substring(1))
                    FrameDescriptions.Remove(fd)
                    fd.Category = catN.Text
                    FrameDescriptions.Add(fd)
                Next
            Next
        End Sub

#End Region

    End Class