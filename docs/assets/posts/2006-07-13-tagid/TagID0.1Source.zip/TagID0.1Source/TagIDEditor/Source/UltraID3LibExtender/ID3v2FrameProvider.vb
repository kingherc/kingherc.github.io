#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Namespace UltraID3LibExtender

    Friend Class ID3v2FrameProvider
        Inherits TypeDescriptionProvider


        Private _baseProvider As TypeDescriptionProvider

        Public Sub New(ByVal t As Type)
            _baseProvider = TypeDescriptor.GetProvider(t)
        End Sub

        Public Overloads Overrides Function GetTypeDescriptor(ByVal objectType As Type, ByVal instance As Object) As ICustomTypeDescriptor
            Return New ID3v2FrameDescriptor(Me, _baseProvider.GetTypeDescriptor(objectType, instance), objectType)
        End Function

        ''' <summary>
        ''' Responsible for changing how the ID3Frames are shown in a property grid.
        ''' </summary>
        ''' <remarks>The ID3v2FrameDescriptor is the one responsible for changing how the ID3Frames are shown in a property grid. For each ID3Frame, the GetAttributes and GetProperties is called.</remarks>
        Private Class ID3v2FrameDescriptor
            Inherits CustomTypeDescriptor

            Private _objectType As Type
            Private _provider As ID3v2FrameProvider

            Public Sub New(ByVal provider As ID3v2FrameProvider, ByVal descriptor As ICustomTypeDescriptor, ByVal objectType As Type)
                MyBase.New(descriptor)
                If provider Is Nothing Or descriptor Is Nothing Or objectType Is Nothing Then
                    Throw New ArgumentNullException(Me.GetType.ToString & "'s initialization failed: Provider or Descriptor or objectType is Nothing.")
                End If
                _objectType = objectType
                _provider = provider
            End Sub

            'TODO: Be careful, when you change namespace names, to update this function.
            Private Function FindConverter(ByVal t As Type) As Type
                Return Type.GetType("TagID.Editor.UltraID3LibExtender.FrameSpecific." & t.Name & "Converter")
            End Function

#Region "Attributes"

            ''' <summary>
            ''' Gets Attributes for an ID3Frame.
            ''' </summary>
            ''' <remarks>The FrameDescription of the frame is retrieved. Then the frame is supplied with the appropriate DescriptionAttribute, DisplayNameAttribute, CategoryAttribute. It also searches if there is an available converter for this type (the name of the converter is the name of the type + "Converter" and is found under the FrameSpecific namespace). If it finds one, it also adds a TypeConverterAttribute.</remarks>
            Public Overloads Overrides Function GetAttributes() As AttributeCollection
                Dim atts As AttributeCollection = MyBase.GetAttributes

                Dim fd As FrameDescription = FrameDescriptions.GetFromType(_objectType)
                If Not Object.Equals(fd, Nothing) Then
                    Dim desc As String = fd.Summary & vbCrLf & "FrameID: " & fd.FrameID
                    If fd.AllowedMultiple Then
                        desc &= " (Multiple instances allowed)"
                    ElseIf fd.AllowedSingle Then
                        desc &= " (Single instance allowed)"
                    End If
                    atts = AttributeCollection.FromExisting(atts, New Attribute() {New DescriptionAttribute(desc), New DisplayNameAttribute(fd.Name), New CategoryAttribute(fd.Category)})

                    'Try to find if there is a converter for this frame type.
                    Dim frameconverter As Type = FindConverter(_objectType)
                    If Not frameconverter Is Nothing Then
                        atts = AttributeCollection.FromExisting(atts, New Attribute() {New TypeConverterAttribute(frameconverter)})
                    End If
                End If

                Return atts
            End Function

#End Region

#Region "Properties"

            Public Overloads Overrides Function GetProperties() As PropertyDescriptorCollection
                Return GetProperties(Nothing)
            End Function

            ''' <summary>
            ''' Gets Properties for an ID3Frame.
            ''' </summary>
            ''' <remarks>This returns a PropertyDescriptors for each Property of the ID3Frame. It's quite handy when the ID3Frames are presented in a property grid. It basically renders some properties not browsable, changes some properties' attributes and such. For example, FrameID property is rendered not-browsable because you can see the FrameID in the descriptionattribute of the class in a property grid.</remarks>
            Public Overloads Overrides Function GetProperties(ByVal attributes As Attribute()) As PropertyDescriptorCollection
                Dim props As New PropertyDescriptorCollection(Nothing)
                Dim fd As FrameDescription = FrameDescriptions.GetFromType(_objectType)

                For Each prop As PropertyDescriptor In MyBase.GetProperties(attributes)
                    Dim newAtts As New AttributeCollection()

                    'General property changes that apply to all ID3Frames.
                    If prop.Name = "FrameFlags" Then newAtts = AttributeCollection.FromExisting(newAtts, New Attribute() {New DisplayNameAttribute("(Flags)"), New BrowsableAttribute(Helper.DisplayFlags), New DescriptionAttribute("Various flag attributes of the frame.")})

                    If prop.Name = "TextEncodingType" Then newAtts = AttributeCollection.FromExisting(newAtts, New Attribute() {New DisplayNameAttribute("(Encoding)"), New BrowsableAttribute(Helper.DisplayTextEncoding), New DescriptionAttribute("Describes how text inside of a Frame is encoded.")})
                    If prop.Name = "Exceptions" Or prop.Name = "FrameDescription" Or prop.Name = "FrameID" Or prop.Name = "FrameName" Or prop.Name = "FrameType" Or prop.Name = "IsSet" Then
                        newAtts = AttributeCollection.FromExisting(newAtts, New Attribute() {New BrowsableAttribute(False)})
                    End If

                    'Frame-specific descriptions of properties (only for description attribute found in FrameExplanation xml resource file)
                    If Not Object.Equals(fd, Nothing) Then
                        Dim propDescription As String = fd.GetPropertyDescription(prop.Name)
                        If Not propDescription Is Nothing Then
                            newAtts = AttributeCollection.FromExisting(newAtts, New Attribute() {New DescriptionAttribute(propDescription)})
                        End If
                    End If

                    Dim newAtt(newAtts.Count - 1) As Attribute
                    newAtts.CopyTo(newAtt, 0)
                    prop = TypeDescriptor.CreateProperty(prop.ComponentType, prop.Name, prop.PropertyType, newAtt)
                    props.Add(prop)
                Next

                'General property additions that apply to all ID3Frames.


                Return props.Sort(New PropertyComparer)
            End Function

#End Region

        End Class

    End Class
End Namespace
