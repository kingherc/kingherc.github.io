#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Imports Microsoft.Win32

''' <summary>
''' Provides a ready and customizable user interface for editing ID3v1 and ID3v2 tags, a file's tags and also view a file's mpeg info.
''' </summary>
<Designer(GetType(ID3TagEditorDesigner))> _
Public Class ID3TagEditor

#Region "Variables, properties, events"

    ''' <summary>
    ''' Will be marked true when the ID3TagControl is completely loaded.
    ''' </summary>
    Private _initialized As Boolean = False

    ''' <summary>
    ''' The Options class used by the ID3TagEditor controls. The value is initialized by Helper.InitializeLibrary method.
    ''' </summary>
    Public Shared Ops As Options
    ''' <summary>
    ''' This property refers to the shared Ops of the class. Options are automatically loaded from the registry and saved to it. The property is readonly, but you can always change the Ops field.
    ''' </summary>
    <Description("This property refers to the shared Ops of the class. Options are automatically loaded from the registry and saved to it. The property is readonly, but you can always change the Ops field.")> _
    Public ReadOnly Property OptionsUsed() As Options
        Get
            Return Ops
        End Get
    End Property

    Private _tagstoshow As TagsToShowEnum
    Public Enum TagsToShowEnum
        ''' <summary>
        ''' The TagIDEditor is to be used for editing only ID3v1 tag.
        ''' </summary>
        ID3v1 = 1
        ''' <summary>
        ''' The TagIDEditor is to be used for editing only ID3v2 tag.
        ''' </summary>
        ID3v2 = 2
        ''' <summary>
        ''' The TagIDEditor is to be used for editing both ID3v1 and ID3v2 tags. This also enables the user to synchronize tags.
        ''' </summary>
        All = 3
    End Enum
    ''' <summary>
    ''' Specifies which ID3 versions will be editable.
    ''' </summary>
    <Description("Specifies which ID3 versions will be editable.")> _
    Public Property TagsToShow() As TagsToShowEnum
        Get
            Return _tagstoshow
        End Get
        Set(ByVal value As TagsToShowEnum)
            _tagstoshow = value
            RefreshControl()
        End Set
    End Property

    ''' <summary>
    ''' Which view mode to show in the ID3TagEditor.
    ''' </summary>
    Public Enum ViewModes
        ''' <summary>
        ''' Signifies that the ID3v1 editing mode is being shown.
        ''' </summary>
        ID3v1 = 1
        ''' <summary>
        ''' Signifies that the ID3v2 editing mode is being shown.
        ''' </summary>
        ID3v2 = 2
        ''' <summary>
        ''' Signifies that the file info view mode is being shown.
        ''' </summary>
        FileInfo = 3
        ''' <summary>
        ''' Signifies that the ID3v2's view mode (for selecting default textencoding and frameflags) is being shown.
        ''' </summary>
        DefaultEncodingAndFlags = 4
    End Enum

    Private _viewmode As ViewModes = ViewModes.ID3v2
    ''' <summary>
    ''' Which view mode is currently being shown. Complies with TagsToShow and FileAware properties.
    ''' </summary>
    <Description("Which view mode is currently being shown. Complies with TagsToShow and FileAware properties.")> _
    Public Property ViewMode() As ViewModes
        Get
            Return _viewmode
        End Get
        Set(ByVal value As ViewModes)
            _viewmode = value
            RefreshControl()
        End Set
    End Property

    Private _fileaware As Boolean
    ''' <summary>
    ''' Specifies if the ID3TagEditor can be used by the user to view file/mpeg info and their tags. If not, the ID3TagEditor is used only for editing the ID3v1Tag and the ID3v2Tag.
    ''' </summary>
    ''' <remarks>If true, the File Info button is displayed under the View Mode. Through this button, a user can see the file's info and mpeg info. Also, the user can change the selected file if FileCanOpen is true (the OpenFile button appears) and the user can save the selected file if the FileCanSave is true (the SaveFile button and AutoSave checkbutton appear).</remarks>
    <Description("If true, the File Info button is displayed under the View Mode. Also, the user can change the selected file if FileCanOpen is true and the user can save the selected file if the FileCanSave is true.")> _
    Public Property FileAware() As Boolean
        Get
            Return _fileaware
        End Get
        Set(ByVal value As Boolean)
            _fileaware = value
            RefreshControl()
        End Set
    End Property

    Private _filepath As String = ""
    ''' <summary>
    ''' Should be used when FileAware is true. Is the path of the file being edited/viewed.
    ''' </summary>
    <Description("Should be used when FileAware is true. Is the path of the file being edited/viewed.")> _
    <Editor(GetType(System.Windows.Forms.Design.FileNameEditor), GetType(UITypeEditor))> _
    Public Property FilePath() As String
        Get
            Return _filepath
        End Get
        Set(ByVal value As String)
            DoSaveQuestion()
            If File.Exists(value) Then
                _filepath = value
                _u = New UltraID3
                _u.Read(value)
                Dim id2 As New Editor.ID3v2Tag(_u.ID3v23Tag.Frames)
                Dim id1 As New Editor.ID3v1Tag(_u.ID3v1Tag)
                Me.v2Tag = id2
                Me.v1Tag = id1
            Else
                _filepath = ""
                _u = Nothing
                Me.v2Tag = New ID3v2Tag()
                Me.v1Tag = New ID3v1Tag()
            End If
            RefreshControl()
        End Set
    End Property

    Private _u As UltraID3 = Nothing
    ''' <summary>
    ''' This is used when changing the FilePath property or saving the file.
    ''' </summary>
    Private ReadOnly Property FileUltraID3() As UltraID3
        Get
            Return _u
        End Get
    End Property

    Private _filecanopen As Boolean = False
    ''' <summary>
    ''' Used when FileAware is true. If true, the OpenFile button appears when the user views the file's info.
    ''' </summary>
    <Description("Used be true when FileAware is true. If true, the OpenFile button appears when the user views the file's info.")> _
    Public Property FileCanOpen() As Boolean
        Get
            Return _filecanopen
        End Get
        Set(ByVal value As Boolean)
            _filecanopen = value
            RefreshControl()
        End Set
    End Property

    Private _filecansave As Boolean = False
    ''' <summary>
    ''' Used when FileAware is true. If true, the SaveFile button appears when the user views the file's info.
    ''' </summary>
    <Description("Used be true when FileAware is true. If true, the SaveFile and AutoSave button appears when the user views the file's info.")> _
    Public Property FileCanSave() As Boolean
        Get
            Return _filecansave
        End Get
        Set(ByVal value As Boolean)
            _filecansave = value
            RefreshControl()
        End Set
    End Property

    Private idv1 As ID3v1Tag
    ''' <summary>
    ''' Gets or sets the currently stored ID3v1Tag.
    ''' </summary>
    <Browsable(False)> _
    Public Property v1Tag() As ID3v1Tag
        Get
            Return idv1
        End Get
        Set(ByVal value As ID3v1Tag)
            idv1 = value
            OnIDTagChanged()
        End Set
    End Property

    Private idv2 As ID3v2Tag
    ''' <summary>
    ''' Gets or sets the currently stored ID3v2Tag.
    ''' </summary>
    <Browsable(False)> _
    Public Property v2Tag() As ID3v2Tag
        Get
            Return idv2
        End Get
        Set(ByVal value As ID3v2Tag)
            idv2 = value
            If OptionsUsed.AutoNormalizeOnLoad Then
                tsNormalize_Click(Me, EventArgs.Empty)
            End If
            OnIDTagChanged()
            If Not idv2 Is Nothing Then
                AddHandler idv2.FramesChanged, AddressOf OnIDTagChanged
            End If
        End Set
    End Property

    ''' <summary>
    ''' Triggerred when one of the ID3v1Tag and ID3v2Tag is changed.
    ''' </summary>
    ''' <remarks>Triggerred also when one of the fields of ID3v1Tag or frames of the ID3v2Tag are changed.</remarks>
    Public Event IDTagChanged()
    Protected Sub OnIDTagChanged()
        If ViewMode = ViewModes.ID3v1 Then
            pGrid.SelectedObject = v1Tag
        ElseIf ViewMode = ViewModes.ID3v2 Then
            pGrid.SelectedObject = v2Tag
        End If
        If tsAutoSave.Checked Then
            SaveFile()
        End If
        RaiseEvent IDTagChanged()
    End Sub

#End Region

#Region "ID3v2 related"


#Region "New frames menus"

    Private Sub tsNewFrame_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsNewFrame.Click
        Dim fb As New FrameBrowser()
        If fb.ShowDialog = DialogResult.OK Then
            Dim s As String = fb.SelectedItem
            Dim fd As FrameDescription = FrameDescription.Empty
            If fb.SortMethod = FrameBrowser.SortMethods.ByFrameID Then
                fd = FrameDescriptions.GetFromID(s)
            ElseIf fb.SortMethod = FrameBrowser.SortMethods.ByFrameName Then
                fd = FrameDescriptions.GetFromName(s)
            End If
            If Not fd.IsEmpty Then
                Dim f As ID3Frame = Helper.CreateFrameFromType(Type.GetType(fd.FullTypeName))
                If Not f Is Nothing Then
                    If ConfirmFrameAddition(f) Then
                        Me.v2Tag.Frames.Add(f)
                        OnIDTagChanged()
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub tsNewFramesFromCategoryClick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim s As ToolStripMenuItem = sender
        Dim cat As String = s.Tag
        If Not cat Is Nothing Then
            Dim fd As FrameDescription
            For Each fd In FrameDescriptions
                If fd.Category = cat Then
                    Dim f As ID3Frame = Helper.CreateFrameFromType(Type.GetType(fd.FullTypeName))
                    If Not f Is Nothing Then
                        If ConfirmFrameAddition(f) Then
                            Me.v2Tag.Frames.Add(f)
                        End If
                    End If
                End If
            Next
            OnIDTagChanged()
        End If
    End Sub

    Private Sub tsNewFramesFromAllCategoriesClick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim s As ToolStripMenuItem = sender
        Dim fd As FrameDescription
        For Each fd In FrameDescriptions
            Dim f As ID3Frame = Helper.CreateFrameFromType(Type.GetType(fd.FullTypeName))
            If Not f Is Nothing Then
                If ConfirmFrameAddition(f) Then
                    Me.v2Tag.Frames.Add(f)
                End If
            End If
        Next
        OnIDTagChanged()
    End Sub

    Private Sub tsAddAnotherFrame_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsAddAnotherFrame.Click
        Dim gi As GridItem = GetSelectedFrame()
        If Not gi Is Nothing Then
            Dim p As ID3v2Tag.ID3v2TagPropertyDescriptor = gi.PropertyDescriptor
            If Not p Is Nothing Then
                Dim f As ID3Frame = Helper.CreateFrameFromType(p.PropertyType)
                If Not f Is Nothing Then
                    If ConfirmFrameAddition(f) Then
                        Dim i As Integer = p.FrameIndex + 1
                        Me.v2Tag.InsertAt(f, i)
                        OnIDTagChanged()
                        SelectFrameIndex(i)
                    End If
                End If
            End If
        End If
    End Sub

#End Region

#Region "Delete frame menu"

    Private Sub tsDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsDelete.Click
        Dim gi As GridItem = GetSelectedFrame()
        If Not gi Is Nothing Then
            Dim p As ID3v2Tag.ID3v2TagPropertyDescriptor = gi.PropertyDescriptor
            If Not p Is Nothing Then
                Me.v2Tag.Frames.RemoveAt(p.FrameIndex)
                OnIDTagChanged()
            End If
        End If
    End Sub

#End Region

#Region "Move Up and Down menus"

    Private Sub tsMoveUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsMoveUp.Click
        Dim gi As GridItem = GetSelectedFrame()
        If Not gi Is Nothing Then
            Dim p As ID3v2Tag.ID3v2TagPropertyDescriptor = gi.PropertyDescriptor
            If Not p Is Nothing Then
                If Not p.FrameIndex = 0 Then
                    Dim f As ID3Frame = Me.v2Tag.Frames.Item(p.FrameIndex)
                    Me.v2Tag.Frames.RemoveAt(p.FrameIndex)
                    Me.idv2.InsertAt(f, p.FrameIndex - 1)
                    OnIDTagChanged()
                    SelectFrameIndex(p.FrameIndex - 1)
                End If
            End If
        End If
    End Sub

    Private Sub tsMoveDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsMoveDown.Click
        Dim gi As GridItem = GetSelectedFrame()
        If Not gi Is Nothing Then
            Dim p As ID3v2Tag.ID3v2TagPropertyDescriptor = gi.PropertyDescriptor
            If Not p Is Nothing Then
                If Not p.FrameIndex = Me.v2Tag.Frames.Count - 1 Then
                    Dim f As ID3Frame = Me.v2Tag.Frames.Item(p.FrameIndex)
                    Me.v2Tag.Frames.RemoveAt(p.FrameIndex)
                    Me.idv2.InsertAt(f, p.FrameIndex + 1)
                    OnIDTagChanged()
                    SelectFrameIndex(p.FrameIndex + 1)
                End If
            End If
        End If
    End Sub

#End Region

#Region "Multiple Actions menus"

    Private Sub tsDeleteAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsDeleteAll.Click
        If MessageBox.Show("Are you sure you want to delete all the frames of the tag?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1) = DialogResult.Yes Then
            Me.v2Tag.Frames.Clear()
            OnIDTagChanged()
        End If
    End Sub

    Private Sub tsNormalize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsNormalize.Click
        Dim i As Integer
        For i = 0 To Me.v2Tag.Frames.Count - 1
            Dim f As ID3Frame = Me.v2Tag.Frames.Item(i)
            CloneFrameFlags(Helper.DefaultFlags, f.FrameFlags)
            Dim p As PropertyDescriptor = TypeDescriptor.GetProperties(f, False).Find("TextEncodingType", True)
            If Not p Is Nothing Then
                p.SetValue(f, Helper.DefaultTextEncoding)
            End If
        Next
        OnIDTagChanged()
    End Sub

    Private Sub mnExpandAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnExpandAll.Click
        pGrid.ExpandAllGridItems()
    End Sub

    Private Sub mnCollapseAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCollapseAll.Click
        pGrid.CollapseAllGridItems()
    End Sub

#End Region

#Region "Configuration menus"

#Region "View Options"

    Private Sub tsCategorized_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsCategorized.Click
        OptionsUsed.FramesOrder = Options.FramesOrderEnum.Categorized
        RefreshControl()
    End Sub

    Private Sub tsAlphabetical_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsAlphabetical.Click
        OptionsUsed.FramesOrder = Options.FramesOrderEnum.Alphabetical
        RefreshControl()
    End Sub

    Private Sub tsNoOrder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsNoOrder.Click
        OptionsUsed.FramesOrder = Options.FramesOrderEnum.None
        RefreshControl()
    End Sub

    Private Sub tsDisplayFlags_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsDisplayFlags.Click
        OptionsUsed.DisplayFlags = Not OptionsUsed.DisplayFlags
        RefreshControl()
    End Sub

    Private Sub tsDisplayTextEncoding_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsDisplayTextEncoding.Click
        OptionsUsed.DisplayTextEncoding = Not OptionsUsed.DisplayTextEncoding
        RefreshControl()
    End Sub

#End Region

#Region "Advanced"

    Private Sub tsDisplayOneLineEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsDisplayOneLineEdit.Click
        OptionsUsed.DisplayOneLineEdit = Not OptionsUsed.DisplayOneLineEdit
    End Sub

    Private Sub tsForceOneLineEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsForceOneLineEdit.Click
        If OptionsUsed.ForceOneLineEdit = ForceOneLineEditModes.Nowhere Then
            OptionsUsed.ForceOneLineEdit = ForceOneLineEditModes.WhereverPossible
        Else
            OptionsUsed.ForceOneLineEdit = ForceOneLineEditModes.Nowhere
        End If
    End Sub

    Private Sub tsSelectDefaultFlagsEncoding_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsSelectDefaultFlagsEncoding.Click
        ViewMode = ViewModes.DefaultEncodingAndFlags
    End Sub

    Private Sub mnReturnToTag_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnReturnToTag.Click
        ViewMode = ViewModes.ID3v2
    End Sub

    Private Sub tsAutoNormalizeOnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsAutoNormalizeOnLoad.Click
        OptionsUsed.AutoNormalizeOnLoad = Not OptionsUsed.AutoNormalizeOnLoad
    End Sub

#End Region

    Private Sub tsPromptWhenAddingConflictingFrames_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsPromptWhenAddingConflictingFrames.Click
        OptionsUsed.PromptOnConflictingFrames = True
    End Sub

    Private Sub tsModifyCategories_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsModifyCategories.Click
        Dim edc As New ID3TagEditorCategories
        If edc.ShowDialog() = DialogResult.OK Then
            RefreshControl()
        End If
    End Sub

#End Region



#Region "LoadNewFramesFromCategory"

    Private Sub LoadNewFramesFromCategory()
        Try
            tsNewFramesFromCategory.DropDownItems.Clear()
            Dim cats As New ArrayList()
            Dim fd As FrameDescription
            For Each fd In FrameDescriptions
                If Not cats.Contains(fd.Category) Then
                    cats.Add(fd.Category)
                End If
            Next
            Dim cat As String
            For Each cat In cats
                Dim tsmi As New ToolStripMenuItem("'" & cat & "'", Nothing, AddressOf tsNewFramesFromCategoryClick)
                tsmi.Tag = cat
                tsNewFramesFromCategory.DropDownItems.Add(tsmi)
            Next
            tsNewFramesFromCategory.DropDownItems.Add(New ToolStripSeparator())
            Dim tsmAll As New ToolStripMenuItem("All", Nothing, AddressOf tsNewFramesFromAllCategoriesClick)
            tsNewFramesFromCategory.DropDownItems.Add(tsmAll)
        Catch ex As Exception
            tsNewFramesFromCategory.Visible = False
        End Try
    End Sub

#End Region

#Region "GetSelectedFrame"

    Private Function GetSelectedFrame() As GridItem
        Dim gi As GridItem
        gi = pGrid.SelectedGridItem
        Dim isframe As Boolean = False, fd As FrameDescription = FrameDescription.Empty
        If Not gi Is Nothing Then
            Do While (Not isframe) And (Not gi.Parent Is Nothing)
                Try
                    fd = FrameDescriptions.GetFromType(gi.PropertyDescriptor.PropertyType)
                Catch ex As Exception
                    fd = FrameDescription.Empty
                End Try
                If Not fd.IsEmpty Then
                    isframe = True
                Else
                    isframe = False
                    gi = gi.Parent
                End If
            Loop
        End If
        Return gi
    End Function

#End Region

#Region "ConfirmFrameAddition"

    Private Function ConfirmFrameAddition(ByVal f As ID3Frame) As Boolean
        Dim b As Boolean = True
        If FrameDescriptions.GetFromID(f.FrameID).AllowedSingle Then
            Dim ff As ID3Frame
            For Each ff In Me.v2Tag.Frames
                If ff.FrameID = f.FrameID Then
                    If OptionsUsed.PromptOnConflictingFrames Then
                        Dim dr As DialogResult = MessageBox.Show("The '" & f.FrameName & "' frame is supposed to have a single instance in a tag. By adding another '" & f.FrameName & "' frame, you risk generating errors while running programs that read these frames." & vbCrLf & "Are you sure you want to add this frame?" & vbCrLf & vbCrLf & "* You can click cancel to be asked for ""Yes to All"" or ""No to All"".", "Single-instance frame conflict", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2)
                        If dr = DialogResult.No Then
                            b = False
                        ElseIf dr = DialogResult.Yes Then
                            b = True
                        ElseIf dr = DialogResult.Cancel Then
                            Dim dr2 As DialogResult = MessageBox.Show("Yes button: Yes to all (add frames that conflict with others)" & vbCrLf & "No Button: No to all (do not add frames that conflict with others)" & vbCrLf & "Cancel button: Add previous conflicting frame but prompt for the next ones.", "Confirmation", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1)
                            If dr2 = DialogResult.Yes Then
                                b = True
                                OptionsUsed.PromptOnConflictingFrames = False
                                OptionsUsed.AddConflictingFrames = True
                            ElseIf dr2 = DialogResult.No Then
                                b = False
                                OptionsUsed.PromptOnConflictingFrames = False
                                OptionsUsed.AddConflictingFrames = False
                            ElseIf dr2 = DialogResult.Cancel Then
                                OptionsUsed.PromptOnConflictingFrames = True
                                OptionsUsed.AddConflictingFrames = True
                                b = True
                            End If
                        End If
                    Else
                        If OptionsUsed.AddConflictingFrames Then
                            b = True
                        Else
                            b = False
                        End If
                    End If
                    Exit For
                End If
            Next
        End If
        Return b
    End Function

#End Region

#Region "SelectFrameIndex"

    Private Sub SelectFrameIndex(ByVal i As Integer)
        Dim gi As GridItem = pGrid.SelectedGridItem
        Do While Not gi.Parent Is Nothing
            gi = gi.Parent
        Loop
        Dim g As GridItem, sg As GridItem = Nothing
        For Each g In gi.GridItems
            Dim p As ID3v2Tag.ID3v2TagPropertyDescriptor = g.PropertyDescriptor
            If Not p Is Nothing Then
                If p.FrameIndex = i Then
                    sg = g
                End If
            End If
        Next
        If Not sg Is Nothing Then
            pGrid.SelectedGridItem = sg
        End If
    End Sub

#End Region


#End Region

#Region "File Info related"

    Private Sub tsAutoSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsAutoSave.Click
        OptionsUsed.AutoSave = Not OptionsUsed.AutoSave
        RefreshControl()
    End Sub

    Private Sub tsOpenFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsOpenFile.Click
        If OpenFile.ShowDialog = DialogResult.OK Then
            Me.FilePath = OpenFile.FileName
        End If
    End Sub

    Private Sub tsSaveFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsSaveFile.Click
        SaveFile()
    End Sub

    ''' <summary>
    ''' This method is called when the FilePath is changed, or when the control's handle is destroyed.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DoSaveQuestion()
        If Me.FileAware And Me.FileCanSave And _initialized And File.Exists(Me.FilePath) And Not tsAutoSave.Checked Then
            If MessageBox.Show("Any changes of the ID3 tags will be lost on the current file:" & vbCrLf & Me.FilePath & vbCrLf & "Do you want to save them before closing the current file?", "Save current file?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification) = DialogResult.Yes Then
                SaveFile()
            End If
        End If
    End Sub

    ''' <summary>
    ''' If options permit it, saves the tags of the current file.
    ''' </summary>
    ''' <returns>True if the file was saved. Else, false.</returns>
    Public Function SaveFile() As Boolean
        Dim b As Boolean = False
        If _initialized And (Not Me.FilePath = "") And (Not FileUltraID3 Is Nothing) Then
            Me.v1Tag.CopyToUltraV1Tag(FileUltraID3.ID3v1Tag)
            Try
                FileUltraID3.Write()
            Catch ex As Exception
                MessageBox.Show("An error occurred while trying to save the ID3 tags of the current file:" & vbCrLf & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
        Return b
    End Function

#End Region

#Region "Synchronizing tags"

#Region "SyncID3Tags shared sub"

    ''' <summary>
    ''' Synchronizes ID3v1Tag and ID3v2Tag with the specified options.
    ''' </summary>
    ''' <remarks>
    ''' When SyncMethod is Sync1from2, the info from ID3v2Tag is copied to ID3v1Tag. When SyncMethod is Sync2from1, the info from ID3v1Tag is copied to ID3v2Tag. When SyncMethod is SyncBoth1and2, both tags are synchronized (in reality it synchronizes first ID3v1Tag from ID3v2Tag and then ID3v2Tag from ID3v1Tag).
    ''' 
    ''' When SyncFields is SyncAllFields, then the synchronized fields/frames are overwritten and if not found are created. When the ID3v2Tag is synchronized, the first Comments frame is overwritten.
    ''' When SyncFields is SyncBlankFields, then the synchronized fields/frames are written only when they are empty or not found. When the ID3v2Tag is synchronized, the first Comments frame is overwritten.
    ''' 
    ''' The synchronization does the following automatically:
    ''' - When the ID3v1's comments field is synchronized, it's filled this way: When the ID3v2's comment frame has a description, it's filled 'Description: Comment'. If it doesn't have a description, only the comment is copied.
    ''' - When the ID3v1's genre field is synchronized, the genre byte is searched in the ID3v2's genre frame in this way: First, if it's in a format of '(No)Genre', or '(No)' or 'No' (where No is the genre byte). Else, it searches the ID3v1's standard genre list for the frame's custom genre. If found it copies the genre byte to the ID3v1's genre field. If not it sets the genre to 255.
    ''' - When the ID3v2's genre frame is synchronized, it's filled this way: '(No)Genre' where No is the genre byte and Genre is the genre's name as found in the ID3v1's standard genre list.
    ''' - When the ID3v1's track number is synchronized, if the ID3v2's track number frame is greater than 255, then the ID3v1's track number field is emptied.
    ''' - Note that when synchronizing ID3v1 from ID3v2 you may lose some info due to restrictions that the ID3v1 has but the ID3v2 hasn't.
    ''' </remarks>
    ''' <param name="syncmethod">Which SyncMethod to use when synchronizing.</param>
    ''' <param name="syncfields">Which SyncFields to synchronize.</param>
    Public Shared Sub SyncID3Tags(ByRef idv1 As ID3v1Tag, ByRef idv2 As ID3v2Tag, ByVal syncmethod As Options.SyncMethodEnum, ByVal syncfields As Options.SyncFieldsEnum)
        'Sync ID3v1 from ID3v2
        If syncmethod = Options.SyncMethodEnum.Sync1from2 Or syncmethod = Options.SyncMethodEnum.SyncBoth1and2 Then
            Dim falbum As ID3AlbumFrame = idv2.Frames.GetFrame(SingleInstanceFrameTypes.Album)
            Dim fartist As ID3ArtistFrame = idv2.Frames.GetFrame(SingleInstanceFrameTypes.Artist)
            Dim fcomments As ID3FrameCollection = idv2.Frames.GetFrames(MultipleInstanceFrameTypes.Comments)
            Dim fcomment As ID3CommentsFrame = Nothing
            If fcomments.Count > 0 Then
                'TODO: Write in help that the first comments frame is got in consideration.
                fcomment = fcomments.Item(0)
            End If
            Dim fgenre As ID3GenreFrame = idv2.Frames.GetFrame(SingleInstanceFrameTypes.Genre)
            Dim ftitle As ID3TitleFrame = idv2.Frames.GetFrame(SingleInstanceFrameTypes.Title)
            Dim ftracknum As ID3TrackNumFrame = idv2.Frames.GetFrame(SingleInstanceFrameTypes.TrackNum)
            Dim fyear As ID3YearFrame = idv2.Frames.GetFrame(SingleInstanceFrameTypes.Year)

            If (syncfields = Options.SyncFieldsEnum.SyncAllFields) Or (syncfields = Options.SyncFieldsEnum.SyncBlankFields And idv1.Album = "") Then
                If falbum Is Nothing Then
                    idv1.Album = ""
                Else
                    idv1.Album = falbum.Album
                End If
            End If
            If (syncfields = Options.SyncFieldsEnum.SyncAllFields) Or (syncfields = Options.SyncFieldsEnum.SyncBlankFields And idv1.Artist = "") Then
                If fartist Is Nothing Then
                    idv1.Artist = ""
                Else
                    idv1.Artist = fartist.Artist
                End If
            End If
            If (syncfields = Options.SyncFieldsEnum.SyncAllFields) Or (syncfields = Options.SyncFieldsEnum.SyncBlankFields And idv1.Comments = "") Then
                If fcomment Is Nothing Then
                    idv1.Comments = ""
                Else
                    Dim str As String = ""
                    'TODO: Write in help that the synced idv1 comment to be changed from the comment frame will be: description + ': ' + comment.
                    If Not fcomment.Description.Trim = "" Then
                        str &= fcomment.Description & ": "
                    End If
                    str &= fcomment.Comments
                    idv1.Comments = str
                End If
            End If
            If (syncfields = Options.SyncFieldsEnum.SyncAllFields) Or (syncfields = Options.SyncFieldsEnum.SyncBlankFields And idv1.Genre = 255) Then
                If fgenre Is Nothing Then
                    idv1.Genre = 255
                Else
                    'Find if there is a frame byte in the genre string of the genre frame
                    Dim b As String = ""
                    If Not fgenre.Genre Is Nothing Then
                        Dim str As String = ""
                        Try
                            str = fgenre.Genre.Substring(fgenre.Genre.IndexOf("(") + 1, fgenre.Genre.IndexOf(")") - fgenre.Genre.IndexOf("(") - 1)
                        Catch ex As Exception
                            str = ""
                        End Try
                        If str = "" Then
                            b = ""
                        Else
                            b = str
                        End If
                    Else
                        b = ""
                    End If
                    If b = "" Then
                        'Search if the genre string is of the ID3v1's standard genre list.
                        Dim gs As New GenreInfoCollection
                        Dim g As GenreInfo
                        For Each g In gs
                            If g.Name = fgenre.Genre Then
                                b = g.Number
                                Exit For
                            End If
                        Next
                    End If
                    If b = "" Then
                        b = "255"
                    End If
                    idv1.Genre = CInt(b)
                End If
            End If
            If (syncfields = Options.SyncFieldsEnum.SyncAllFields) Or (syncfields = Options.SyncFieldsEnum.SyncBlankFields And idv1.Title = "") Then
                If ftitle Is Nothing Then
                    idv1.Title = ""
                Else
                    idv1.Title = ftitle.Title
                End If
            End If
            If (syncfields = Options.SyncFieldsEnum.SyncAllFields) Or (syncfields = Options.SyncFieldsEnum.SyncBlankFields And (Not idv1.TrackNum.HasValue)) Then
                If ftracknum Is Nothing Then
                    idv1.TrackNum = Nothing
                Else
                    If ftracknum.TrackNum.HasValue Then
                        If CShort(ftracknum.TrackNum.Value) <= 255 Then
                            idv1.TrackNum = CShort(ftracknum.TrackNum.Value)
                        Else
                            idv1.TrackNum = Nothing
                        End If
                    Else
                        idv1.TrackNum = Nothing
                    End If
                End If
            End If
            If (syncfields = Options.SyncFieldsEnum.SyncAllFields) Or (syncfields = Options.SyncFieldsEnum.SyncBlankFields And (Not idv1.Year.HasValue)) Then
                If fyear Is Nothing Then
                    idv1.Year = Nothing
                Else
                    If fyear.Year.HasValue Then
                        idv1.Year = CShort(fyear.Year.Value)
                    Else
                        idv1.Year = Nothing
                    End If
                End If
            End If

        End If

        'Sync ID3v2 from ID3v1
        If syncmethod = Options.SyncMethodEnum.Sync2from1 Or syncmethod = Options.SyncMethodEnum.SyncBoth1and2 Then
            Dim falbum As ID3AlbumFrame = idv2.GetFirstOccurence(FrameTypes.Album)
            If falbum Is Nothing Then
                falbum = New ID3AlbumFrame(Helper.DefaultTextEncoding)
                falbum.Album = ""
            Else
                idv2.Frames.Remove(falbum)
            End If
            Dim fartist As ID3ArtistFrame = idv2.GetFirstOccurence(FrameTypes.Artist)
            If fartist Is Nothing Then
                fartist = New ID3ArtistFrame(Helper.DefaultTextEncoding)
                fartist.Artist = ""
            Else
                idv2.Frames.Remove(fartist)
            End If
            Dim fgenre As ID3GenreFrame = idv2.GetFirstOccurence(FrameTypes.Genre)
            If fgenre Is Nothing Then
                fgenre = New ID3GenreFrame(Helper.DefaultTextEncoding)
                fgenre.Genre = ""
            Else
                idv2.Frames.Remove(fgenre)
            End If
            Dim ftitle As ID3TitleFrame = idv2.GetFirstOccurence(FrameTypes.Title)
            If ftitle Is Nothing Then
                ftitle = New ID3TitleFrame(Helper.DefaultTextEncoding)
                ftitle.Title = ""
            Else
                idv2.Frames.Remove(ftitle)
            End If
            Dim ftracknum As ID3TrackNumFrame = idv2.GetFirstOccurence(FrameTypes.TrackNum)
            If ftracknum Is Nothing Then
                ftracknum = New ID3TrackNumFrame()
                ftracknum.TrackCount = Nothing
                ftracknum.TrackNum = Nothing
            Else
                idv2.Frames.Remove(ftracknum)
            End If
            Dim fyear As ID3YearFrame = idv2.GetFirstOccurence(FrameTypes.Year)
            If fyear Is Nothing Then
                fyear = New ID3YearFrame()
                fyear.Year = Nothing
            Else
                idv2.Frames.Remove(fyear)
            End If

            Dim fcomm As ID3CommentsFrame, fcommplace As Integer = -1
            fcomm = idv2.GetFirstOccurence(FrameTypes.Comments)
            If fcomm Is Nothing Then
                fcomm = New ID3CommentsFrame(Helper.DefaultTextEncoding)
                fcomm.Comments = ""
            Else
                fcommplace = idv2.IndexOf(fcomm)
                idv2.Frames.RemoveAt(fcommplace)
            End If
            If (syncfields = Options.SyncFieldsEnum.SyncAllFields) Or (syncfields = Options.SyncFieldsEnum.SyncBlankFields And fcomm.Comments = "") Then
                fcomm.Comments = idv1.Comments
                fcomm.Description = ""
                fcomm.Language = ""
            End If
            If fcommplace = -1 Then
                idv2.Frames.Add(fcomm)
            Else
                idv2.InsertAt(fcomm, fcommplace)
            End If

            If (syncfields = Options.SyncFieldsEnum.SyncAllFields) Or (syncfields = Options.SyncFieldsEnum.SyncBlankFields And falbum.Album = "") Then
                falbum.Album = idv1.Album
            End If
            idv2.Frames.Add(falbum)
            If (syncfields = Options.SyncFieldsEnum.SyncAllFields) Or (syncfields = Options.SyncFieldsEnum.SyncBlankFields And fartist.Artist = "") Then
                fartist.Artist = idv1.Artist
            End If
            idv2.Frames.Add(fartist)
            If (syncfields = Options.SyncFieldsEnum.SyncAllFields) Or (syncfields = Options.SyncFieldsEnum.SyncBlankFields And fgenre.Genre = "") Then
                Dim genrename As String = ""
                Dim gs As New GenreInfoCollection
                Dim g As GenreInfo
                For Each g In gs
                    If CInt(g.Number) = CInt(idv1.Genre) Then
                        genrename = "(" & g.Number & ")" & g.Name
                        Exit For
                    End If
                Next
                If genrename = "" Then
                    genrename = "(" & idv1.Genre & ")"
                End If
                If CInt(idv1.Genre) = 255 Then
                    genrename = ""
                End If
                fgenre.Genre = genrename
            End If
            idv2.Frames.Add(fgenre)
            If (syncfields = Options.SyncFieldsEnum.SyncAllFields) Or (syncfields = Options.SyncFieldsEnum.SyncBlankFields And ftitle.Title = "") Then
                ftitle.Title = idv1.Title
            End If
            idv2.Frames.Add(ftitle)
            If (syncfields = Options.SyncFieldsEnum.SyncAllFields) Or (syncfields = Options.SyncFieldsEnum.SyncBlankFields And (Not ftracknum.TrackNum.HasValue)) Then
                If idv1.TrackNum.HasValue Then
                    ftracknum.TrackNum = idv1.TrackNum.Value
                Else
                    ftracknum.TrackNum = Nothing
                End If
                ftracknum.TrackCount = Nothing
            End If
            idv2.Frames.Add(ftracknum)
            If (syncfields = Options.SyncFieldsEnum.SyncAllFields) Or (syncfields = Options.SyncFieldsEnum.SyncBlankFields And (Not fyear.Year.HasValue)) Then
                If idv1.Year.HasValue Then
                    fyear.Year = idv1.Year.Value
                Else
                    fyear.Year = Nothing
                End If
            End If
            idv2.Frames.Add(fyear)

        End If
    End Sub

#End Region

    Private Sub tsStartSync_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsStartSync.Click
        SyncID3Tags(Me.v1Tag, Me.v2Tag, OptionsUsed.SyncMethod, OptionsUsed.SyncFields)
    End Sub

    Private Sub tsSync2from1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsSync2from1.Click
        OptionsUsed.SyncMethod = Options.SyncMethodEnum.Sync2from1
    End Sub

    Private Sub tsSync1from2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsSync1from2.Click
        OptionsUsed.SyncMethod = Options.SyncMethodEnum.Sync1from2
    End Sub

    Private Sub tsSyncBoth1and2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsSyncBoth1and2.Click
        OptionsUsed.SyncMethod = Options.SyncMethodEnum.SyncBoth1and2
    End Sub

    Private Sub tsSyncBlankFields_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsSyncBlankFields.Click
        OptionsUsed.SyncFields = Options.SyncFieldsEnum.SyncBlankFields
    End Sub

    Private Sub tsSyncAllFields_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsSyncAllFields.Click
        OptionsUsed.SyncFields = Options.SyncFieldsEnum.SyncAllFields
    End Sub

#End Region

#Region "View mode buttons"

    Private Sub tsID3v1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsID3v1.Click
        ViewMode = ViewModes.ID3v1
        RefreshControl()
    End Sub

    Private Sub tsID3v2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsID3v2.Click
        ViewMode = ViewModes.ID3v2
        RefreshControl()
    End Sub

    Private Sub tsFileInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsFileInfo.Click
        ViewMode = ViewModes.FileInfo
        RefreshControl()
    End Sub

#End Region

#Region "Help menus"

    Private Sub tsFrameBrowser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsFrameBrowser.Click
        Dim gi As GridItem = GetSelectedFrame(), fd As FrameDescription = FrameDescription.Empty
        If Not gi Is Nothing Then
            Dim p As PropertyDescriptor = gi.PropertyDescriptor
            If Not p Is Nothing Then
                fd = FrameDescriptions.GetFromType(gi.PropertyDescriptor.PropertyType)
            End If
        End If

        Dim id As String = ""
        If Not fd.IsEmpty Then
            id = fd.FrameID
        End If
        Dim tg As New FrameBrowser(id, True)
        tg.Show()
    End Sub

    Private Sub tsAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsAbout.Click
        Dim a As New ID3TagEditorAbout
        a.ShowDialog()
    End Sub

    Private Sub tsShowHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsShowHelp.Click
        Dim helppath As String = Directory.GetCurrentDirectory & "\ID3TagEditorHelp.htm"
        Try
            My.Computer.FileSystem.WriteAllText(helppath, My.Resources.htmlID3TagEditorHelp, False)
            Process.Start(helppath)
        Catch ex As Exception
            If File.Exists(helppath) Then
                Process.Start(helppath)
            Else
                If MessageBox.Show("Could not create the help file at the default path: " & vbCrLf & helppath & vbCrLf & "Because of this, you won't be able to view the help file with your browser. Would you like instead to open a small browser to view the help file?", "Could not create help file", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = DialogResult.Yes Then
                    Dim hh As New ID3TagEditorHelp
                    hh.Show()
                End If
            End If
        End Try
    End Sub

    Private Sub tsLoadDefaultOptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsLoadDefaultOptions.Click
        If MessageBox.Show("Are you sure you want to load the default options?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = DialogResult.Yes Then
            If MessageBox.Show("Would you like to also load the default categories for frames?", "Load default categories?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = DialogResult.Yes Then
                Dim xmldoc As New XmlDocument
                xmldoc.LoadXml(My.Resources.xmlFrameDefaultCategories)
                FrameDescriptions = New FrameDescriptionList(xmldoc)
            End If
            OptionsUsed.LoadDefaults()
        End If
    End Sub

#End Region

#Region "Constructor and handling events"

    ''' <summary>
    ''' Initializes a new ID3TagEditor.
    ''' </summary>
    ''' <param name="tagstoshow">Specifies which ID3 versions will be made editable.</param>
    ''' <param name="filepath">Specifies the file being edited and viewed in the ID3TagEditor. The FileAware, FileCanOpen and FileCanSave properties are set to true.</param>
    Public Sub New(ByVal tagstoshow As TagsToShowEnum, ByVal filepath As String)
        Me.New(tagstoshow, True)
        Me.FilePath = filepath
    End Sub

    ''' <summary>
    ''' Initializes a new ID3TagEditor.
    ''' </summary>
    ''' <param name="tagstoshow">Specifies which ID3 versions will be made editable.</param>
    ''' <param name="fullfilemode">If true, the FileAware, FileCanOpen and FileCanSave properties are set to true.</param>
    Public Sub New(ByVal tagstoshow As TagsToShowEnum, ByVal fullfilemode As Boolean)
        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Helper.InitializeLibrary()
        AddHandler Ops.OptionsChanged, AddressOf RefreshControl

        Me.v2Tag = New ID3v2Tag()
        Me.v1Tag = New ID3v1Tag()
        Me.TagsToShow = tagstoshow
        Me.FileAware = fullfilemode
        Me.FileCanOpen = fullfilemode
        Me.FileCanSave = fullfilemode
    End Sub

    ''' <summary>
    ''' Initializes a new ID3TagEditor with all capabilities enabled.
    ''' </summary>
    Public Sub New()
        Me.New(TagsToShowEnum.All, True)
    End Sub

    Private Sub Helper_OptionsChanged()
        RefreshControl()
    End Sub

    Private Sub pGrid_PropertyValueChanged(ByVal s As Object, ByVal e As System.Windows.Forms.PropertyValueChangedEventArgs) Handles pGrid.PropertyValueChanged
        If ViewMode = ViewModes.ID3v1 Or ViewMode = ViewModes.ID3v2 Then
            OnIDTagChanged()
        End If
    End Sub

    Private Sub ID3TagEditor_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        _initialized = True
    End Sub

    Private Sub ID3TagEditor_HandleDestroyed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.HandleDestroyed
        DoSaveQuestion()
        OptionsUsed.SaveOptions()
    End Sub

#End Region

#Region "RefreshControl"

    ''' <summary>
    ''' Refreshes menus according to the properties and options selected.
    ''' </summary>
    Public Sub RefreshControl()
        If _initialized Then
            'Comply ViewMode with FileAware and TagsToShow properties.
            If Not FileAware Then
                If ViewMode = ViewModes.FileInfo Then
                    ViewMode = ViewModes.ID3v2
                End If
            End If
            If TagsToShow = TagsToShowEnum.ID3v1 Then
                If ViewMode = ViewModes.DefaultEncodingAndFlags Or ViewMode = ViewModes.ID3v2 Then
                    ViewMode = ViewModes.ID3v1
                End If
            End If
            If TagsToShow = TagsToShowEnum.ID3v2 Then
                If ViewMode = ViewModes.ID3v1 Then
                    ViewMode = ViewModes.ID3v2
                End If
            End If

            'Comply ViewMode menus with the TagsToShow property.
            If TagsToShow = TagsToShowEnum.ID3v1 Then
                tsID3v1.Visible = True
                tsID3v2.Visible = False
                tsSynchronizeTags.Visible = False
                ToolStripSeparator7.Visible = False
            ElseIf TagsToShow = TagsToShowEnum.ID3v2 Then
                tsID3v1.Visible = False
                tsID3v2.Visible = True
                tsSynchronizeTags.Visible = False
                ToolStripSeparator7.Visible = False
            ElseIf TagsToShow = TagsToShowEnum.All Then
                tsID3v1.Visible = True
                tsID3v2.Visible = True
                tsSynchronizeTags.Visible = True
                ToolStripSeparator7.Visible = True

                If OptionsUsed.SyncMethod = Options.SyncMethodEnum.Sync1from2 Then
                    tsSync1from2.Checked = True
                    tsSync2from1.Checked = False
                    tsSyncBoth1and2.Checked = False
                ElseIf OptionsUsed.SyncMethod = Options.SyncMethodEnum.Sync2from1 Then
                    tsSync1from2.Checked = False
                    tsSync2from1.Checked = True
                    tsSyncBoth1and2.Checked = False
                ElseIf OptionsUsed.SyncMethod = Options.SyncMethodEnum.SyncBoth1and2 Then
                    tsSync1from2.Checked = False
                    tsSync2from1.Checked = False
                    tsSyncBoth1and2.Checked = True
                End If
                If OptionsUsed.SyncFields = Options.SyncFieldsEnum.SyncAllFields Then
                    tsSyncAllFields.Checked = True
                    tsSyncBlankFields.Checked = False
                ElseIf OptionsUsed.SyncFields = Options.SyncFieldsEnum.SyncBlankFields Then
                    tsSyncAllFields.Checked = False
                    tsSyncBlankFields.Checked = True
                End If
            End If
            tsFileInfo.Visible = FileAware

            'Initializing
            pGrid.SelectedObject = Nothing
            pGrid.PropertySort = PropertySort.Alphabetical
            ts.Enabled = True
            tsID3v1.Checked = False
            tsID3v2.Checked = False
            tsFileInfo.Checked = False
            tsNew.Visible = False
            tsDelete.Visible = False
            tsMoveSeperator.Visible = False
            tsMoveUp.Visible = False
            tsMoveDown.Visible = False
            ToolStripSeparator1.Visible = False
            tsMultipleActions.Visible = False
            tsID3v2Configure.Visible = False
            tsFrameBrowser.Visible = False
            tsOpenFile.Visible = False
            tsSaveFile.Visible = False
            ToolStripSeparator11.Visible = False
            tsAutoSave.Visible = False
            tsAutoSaveSeperator.Visible = False

            'Comply ViewMode with menu items.
            If ViewMode = ViewModes.ID3v1 Then
                tsID3v1.Checked = True
                tsViewMode.Image = tsID3v1.Image

                pGrid.SelectedObject = Me.v1Tag
                pGrid.ContextMenuStrip = Nothing
            ElseIf ViewMode = ViewModes.ID3v2 Then
                tsID3v2.Checked = True
                tsViewMode.Image = tsID3v2.Image

                tsNew.Visible = True
                tsDelete.Visible = True
                tsMoveSeperator.Visible = (OptionsUsed.FramesOrder = Options.FramesOrderEnum.None)
                tsMoveUp.Visible = (OptionsUsed.FramesOrder = Options.FramesOrderEnum.None)
                tsMoveDown.Visible = (OptionsUsed.FramesOrder = Options.FramesOrderEnum.None)
                ToolStripSeparator1.Visible = True
                tsMultipleActions.Visible = True
                tsID3v2Configure.Visible = True
                tsFrameBrowser.Visible = True

                tsCategorized.Checked = False
                tsAlphabetical.Checked = False
                tsNoOrder.Checked = False
                If OptionsUsed.FramesOrder = Options.FramesOrderEnum.Alphabetical Then
                    tsAlphabetical.Checked = True
                    pGrid.PropertySort = PropertySort.Alphabetical
                ElseIf OptionsUsed.FramesOrder = Options.FramesOrderEnum.Categorized Then
                    tsCategorized.Checked = True
                    pGrid.PropertySort = PropertySort.CategorizedAlphabetical
                ElseIf OptionsUsed.FramesOrder = Options.FramesOrderEnum.None Then
                    tsNoOrder.Checked = True
                    pGrid.PropertySort = PropertySort.NoSort
                End If

                LoadNewFramesFromCategory()
                tsDisplayFlags.Checked = OptionsUsed.DisplayFlags
                tsDisplayTextEncoding.Checked = OptionsUsed.DisplayTextEncoding
                tsDisplayOneLineEdit.Checked = OptionsUsed.DisplayOneLineEdit
                If OptionsUsed.ForceOneLineEdit = ForceOneLineEditModes.Nowhere Then
                    tsForceOneLineEdit.Checked = False
                ElseIf OptionsUsed.ForceOneLineEdit = ForceOneLineEditModes.WhereverPossible Then
                    tsForceOneLineEdit.Checked = True
                End If
                tsPromptWhenAddingConflictingFrames.Visible = Not OptionsUsed.PromptOnConflictingFrames
                tsAutoNormalizeOnLoad.Checked = OptionsUsed.AutoNormalizeOnLoad

                pGrid.SelectedObject = Me.v2Tag
                pGrid.ContextMenuStrip = Nothing
            ElseIf ViewMode = ViewModes.FileInfo Then
                tsFileInfo.Checked = True
                tsViewMode.Image = tsFileInfo.Image

                tsOpenFile.Visible = Me.FileCanOpen
                tsSaveFile.Visible = Me.FileCanSave
                ToolStripSeparator11.Visible = Me.FileCanSave
                tsAutoSave.Visible = Me.FileCanSave

                pGrid.SelectedObject = New MPEGInfo(Me.FilePath, False)
                pGrid.PropertySort = PropertySort.CategorizedAlphabetical
                pGrid.ContextMenuStrip = Nothing
            ElseIf ViewMode = ViewModes.DefaultEncodingAndFlags Then
                ts.Enabled = False
                pGrid.SelectedObject = New ID3TagControlDefaultFlagsEncoding
                pGrid.ContextMenuStrip = mnReturnToTagContextMenu
            End If

            'Comply tsAutoSave with options.
            If Me.FileAware And Me.FileCanSave Then
                tsAutoSave.Checked = OptionsUsed.AutoSave
            End If

            'Display AutoSave when checked, to remind users it's checked.
            If tsAutoSave.Checked Then
                tsAutoSave.Visible = True
                If Not ViewMode = ViewModes.FileInfo Then
                    tsAutoSaveSeperator.Visible = True
                End If
            End If

            pGrid.Refresh()
        End If
    End Sub

#End Region



#Region "ID3TagControlDefaultFlagsEncoding modal class"

    ''' <summary>
    ''' This class is used as a modal class to edit Option's default textencoding and frameflags values (it is used in ViewMode DefaultEncodingAndFlags).
    ''' </summary>
    <EditorBrowsable(EditorBrowsableState.Never)> _
    Private Class ID3TagControlDefaultFlagsEncoding

        <DisplayName("Default Frame Flags")> _
        <Description("This will be used when a new frame is added, when normalizing a tag etc. Right-click to return to tag.")> _
        Public Property DefaultFlags() As FrameFlags
            Get
                Return Ops.DefaultFlags
            End Get
            Set(ByVal value As FrameFlags)
                Ops.DefaultFlags = value
            End Set
        End Property

        <DisplayName("Default Text Encoding")> _
        <Description("This will be used when a new frame is added, when normalizing a tag etc. Right-click to return to tag.")> _
        Public Property DefaultEncoding() As TextEncodingTypes
            Get
                Return Ops.DefaultTextEncoding
            End Get
            Set(ByVal value As TextEncodingTypes)
                Ops.DefaultTextEncoding = value
            End Set
        End Property

    End Class

#End Region

#Region "Options class"

    ''' <summary>
    ''' Provides a unified way to access shared options that are used by the ID3TagEditor controls.
    ''' </summary>
    ''' <remarks>The options included are shared throughout the library. Some options are specific to the ID3TagEditor control (whether, for example, it should auto-save a file when the user changes it tag) and other options are 'borrowed' from the Helper class of the UltraID3LibExtender namespace (eg. the default frameflags). Note that when changing an option borrowed from the Helper class, you automatically change the Helper's shared option. Because of this, you should not use many instances of the Options class, you should use a shared one just like ID3TagEditor controls do.
    ''' The options can be saved in the registry through the SaveOptions method. The SaveOptions method also saves the ID3v2 frame categories xml file (in the app's running directory). Also, the options can be loaded from the registry through the LoadOptions method (which also loads the categories xml file, if it exists).</remarks>
    <TypeConverter(GetType(ExpandableObjectConverter))> _
    Public Class Options

#Region "Constructor & events"

        ''' <summary>
        ''' Initializes a new Options class and LoadDefaults. Doesn't autoload options from the registry.
        ''' </summary>
        Public Sub New()
            AddHandler Helper.OptionsChanged, AddressOf Helper_OptionsChanged
            LoadDefaults()
        End Sub

        ''' <summary>
        ''' Triggerred when one of the options is changed. Doesn't autosave options to the registry.
        ''' </summary>
        ''' <remarks>Triggerred even if the UltraID3LibExtender's Helper's options is changed.</remarks>
        Public Event OptionsChanged()
        Protected Sub OnOptionsChanged()
            RaiseEvent OptionsChanged()
        End Sub

        Protected Sub Helper_OptionsChanged()
            OnOptionsChanged()
        End Sub

#End Region

#Region "Properties"

        Private _AddConflictingFrames As Boolean
        ''' <summary>
        ''' Used when PromptOnConflictingFrames is false.
        ''' </summary>
        ''' <remarks>When true, conflicting frames are automatically added. Else, there are automatically not added.</remarks>
        <Description("Used when PromptOnConflictingFrames is false.")> _
        Public Property AddConflictingFrames() As Boolean
            Get
                Return _AddConflictingFrames
            End Get
            Set(ByVal value As Boolean)
                _AddConflictingFrames = value
                OnOptionsChanged()
            End Set
        End Property

        Private _AutoNormalizeOnLoad As Boolean
        ''' <summary>
        ''' Normalizes an ID3v2Tag when loaded.
        ''' </summary>
        ''' <remarks>If true, when the ID3TagEditor's ID3v2Tag property is changed, the ID3v2Tag is normalized (the default flags and text encoding is applied to all frames) automatically.</remarks>
        <Description("Normalizes (the default flags and text encoding is applied to all frames) an ID3v2Tag when loaded.")> _
        Public Property AutoNormalizeOnLoad() As Boolean
            Get
                Return _AutoNormalizeOnLoad
            End Get
            Set(ByVal value As Boolean)
                _AutoNormalizeOnLoad = value
                OnOptionsChanged()
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the default flags for frames.
        ''' </summary>
        ''' <remarks>Used in occasions such as creating a new ID3v2 frame. It also affects how a frame's one-line appears. If the Flags and TextEncoding are the default, the one-line doesn't have a parameters string prepended (a string enclosed in {} ).</remarks>
        ''' 
        <TypeConverter(GetType(TypeEditors.FrameFlagsConverter))> _
        <Editor(GetType(TypeEditors.FrameFlagsEditor), GetType(UITypeEditor))> _
        <Description("Gets or sets the default flags for frames.")> _
        Public Property DefaultFlags() As FrameFlags
            Get
                Return Helper.DefaultFlags
            End Get
            Set(ByVal value As FrameFlags)
                Helper.DefaultFlags = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the default text encoding for frames.
        ''' </summary>
        ''' <remarks>Used in occasions such as creating a new ID3v2 frame. It also affects how a frame's one-line appears. If the Flags and TextEncoding are the default, the one-line doesn't have a parameters string prepended (a string enclosed in {} ).</remarks>
        <Description("Gets or sets the default text encoding for frames.")> _
        Public Property DefaultTextEncoding() As TextEncodingTypes
            Get
                Return Helper.DefaultTextEncoding
            End Get
            Set(ByVal value As TextEncodingTypes)
                Helper.DefaultTextEncoding = value
            End Set
        End Property

        ''' <summary>
        ''' Whether to display the (Flags) property or not.
        ''' </summary>
        <Description("Whether to display the (Flags) property or not.")> _
        Public Property DisplayFlags() As Boolean
            Get
                Return Helper.DisplayFlags
            End Get
            Set(ByVal value As Boolean)
                Helper.DisplayFlags = value
            End Set
        End Property

        ''' <summary>
        ''' Whether to display one-line descriptions or not.
        ''' </summary>
        ''' <remarks>
        ''' Some ID3Frames are simple enough to be expressed in an UltraID3LibExtender's FrameString. This value determines whether the user will be able to edit these ID3Frames through editing a FrameString.
        ''' For example, if true, the user will be able to edit the frame in a property grid directly without having to expand the frame's properties.
        ''' Apart from the ID3Frames that can be converted to/from a framestring, there are some other ID3Frames that provide a small description of their contents in their first line in the property grid. The value of this option determines if this small description is shown or not.
        ''' If ForceOneLineEdit is set to WhereverPossible, then DisplayOneLineEdit will remain true.
        ''' </remarks>
        <Description("Whether to display one-line descriptions or not.")> _
        Public Property DisplayOneLineEdit() As Boolean
            Get
                Return Helper.DisplayOneLineEdit
            End Get
            Set(ByVal value As Boolean)
                Helper.DisplayOneLineEdit = value
            End Set
        End Property

        ''' <summary>
        ''' Whether to display the (Encoding) property or not.
        ''' </summary>
        <Description("Whether to display the (Encoding) property or not.")> _
        Public Property DisplayTextEncoding() As Boolean
            Get
                Return Helper.DisplayTextEncoding
            End Get
            Set(ByVal value As Boolean)
                Helper.DisplayTextEncoding = value
            End Set
        End Property

        ''' <summary>
        ''' Whether to force one-line edit mode (wherever possible) or not.
        ''' </summary>
        ''' <remarks>
        ''' Some ID3Frames are simple enough to be expressed in an UltraID3LibExtender's FrameString. The user can edit these ID3Frames through editing a FrameString (this is achieved through a converter. More info can be found in the FrameSpecific namespace) without having to expand the frame in a property grid.
        ''' This value determines whether these ID3Frames should be displayed as expandable. If True, the DisplayOneLineEdit is set to True.
        ''' </remarks>
        <Description("Whether to force one-line edit mode (wherever possible) or not.")> _
        Public Property ForceOneLineEdit() As Helper.ForceOneLineEditModes
            Get
                Return Helper.ForceOneLineEdit
            End Get
            Set(ByVal value As Helper.ForceOneLineEditModes)
                Helper.ForceOneLineEdit = value
            End Set
        End Property

        Private _FramesOrder As FramesOrderEnum
        ''' <summary>
        ''' How frames should be ordered in the property grid.
        ''' </summary>
        <Description("How frames should be ordered in the property grid.")> _
        Public Property FramesOrder() As FramesOrderEnum
            Get
                Return _FramesOrder
            End Get
            Set(ByVal value As FramesOrderEnum)
                _FramesOrder = value
                OnOptionsChanged()
            End Set
        End Property

        Private _PromptOnConflictingFrames As Boolean
        ''' <summary>
        ''' When true, prompts the user to add a conflicting frame.
        ''' </summary>
        ''' <remarks>If false, AddConflictingFrames boolean value is used. Conflicting frames are ID3v2's ID3Frames that are supposed to have a single instance in an ID3v2 tag. If an instance of the frame is already in the tag, the second frame that is tried to be inserted is refered as 'conflicting'.</remarks>
        <Description("When true, prompts the user to add a conflicting frame.")> _
        Public Property PromptOnConflictingFrames() As Boolean
            Get
                Return _PromptOnConflictingFrames
            End Get
            Set(ByVal value As Boolean)
                _PromptOnConflictingFrames = value
                OnOptionsChanged()
            End Set
        End Property

        Private _SyncMethod As SyncMethodEnum
        ''' <summary>
        ''' Used when synchronizing two ID3v1Tag and ID3v2Tag.
        ''' </summary>
        ''' <remarks>More info about how the synchronization works can be found at the remarks of the ID3TagEditor's SyncID3Tags method.</remarks>
        <Description("Used when synchronizing two ID3v1Tag and ID3v2Tag.")> _
        Public Property SyncMethod() As SyncMethodEnum
            Get
                Return _SyncMethod
            End Get
            Set(ByVal value As SyncMethodEnum)
                _SyncMethod = value
                If value = SyncMethodEnum.SyncBoth1and2 Then
                    SyncFields = SyncFieldsEnum.SyncBlankFields
                End If
                OnOptionsChanged()
            End Set
        End Property

        Private _SyncFields As SyncFieldsEnum
        ''' <summary>
        ''' Used when synchronizing two ID3v1Tag and ID3v2Tag.
        ''' </summary>
        ''' <remarks>More info about how the synchronization works can be found at the remarks of the ID3TagEditor's SyncID3Tags method.</remarks>
        <Description("Used when synchronizing two ID3v1Tag and ID3v2Tag.")> _
        Public Property SyncFields() As SyncFieldsEnum
            Get
                Return _SyncFields
            End Get
            Set(ByVal value As SyncFieldsEnum)
                _SyncFields = value
                If SyncMethod = SyncMethodEnum.SyncBoth1and2 Then
                    _SyncFields = SyncFieldsEnum.SyncBlankFields
                End If
                OnOptionsChanged()
            End Set
        End Property

        Private _AutoSave As Boolean
        ''' <summary>
        ''' If ID3TagEditor's FileAware and FileCanSave are true, and this is true, then the AutoSave button is checked.
        ''' </summary>
        ''' <remarks>If ID3TagEditor's FileAware and FileCanSave are true, and this is true, then the AutoSave button is checked. When the AutoSave button is checked, the file's ID3 tags are auto-saved when they are changed by the ID3TagEditor.</remarks>
        <Description("If ID3TagEditor's FileAware and FileCanSave are true, and this is true, then the AutoSave button is checked.")> _
        Public Property AutoSave() As Boolean
            Get
                Return _AutoSave
            End Get
            Set(ByVal value As Boolean)
                _AutoSave = value
                OnOptionsChanged()
            End Set
        End Property

#End Region

#Region "LoadDefaults"

        ''' <summary>
        ''' Loads the default options.
        ''' </summary>
        Public Sub LoadDefaults()
            _AddConflictingFrames = False
            _AutoNormalizeOnLoad = False
            _FramesOrder = FramesOrderEnum.Alphabetical
            _PromptOnConflictingFrames = True
            Me.DefaultFlags = Helper.CreateFrameFlags
            Me.DefaultTextEncoding = TextEncodingTypes.Unicode
            Me.DisplayFlags = True
            Me.DisplayTextEncoding = True
            Me.ForceOneLineEdit = ForceOneLineEditModes.Nowhere
            Me.DisplayOneLineEdit = False
            Me.FramesOrder = FramesOrderEnum.Alphabetical
            _SyncMethod = SyncMethodEnum.SyncBoth1and2
            _SyncFields = SyncFieldsEnum.SyncBlankFields
            _AutoSave = False
            OnOptionsChanged()
        End Sub

#End Region

#Region "SaveOptions"

        ''' <summary>
        ''' Saves the options to the registry and the frame categories to a xml file.
        ''' </summary>
        ''' <remarks>The registry options are saved at HKEY_CURRENT_USER\Software\TagID. The chosen frame categories are saved in an xml file in the running directory of the program.</remarks>
        Public Sub SaveOptions()
            Dim r As RegistryKey = Registry.CurrentUser
            r = r.CreateSubKey("Software")
            If Not r Is Nothing Then
                r = r.CreateSubKey("TagID")
            End If
            If Not r Is Nothing Then
                r.SetValue("DisplayFlags", DisplayFlags)
                r.SetValue("DisplayTextEncoding", DisplayTextEncoding)
                r.SetValue("FramesOrder", CInt(FramesOrder))
                r.SetValue("PromptOnConflictingFrames", PromptOnConflictingFrames)
                r.SetValue("AddConflictingFrames", AddConflictingFrames)
                r.SetValue("DisplayOneLineEdit", DisplayOneLineEdit)
                r.SetValue("ForceOneLineEdit", CInt(ForceOneLineEdit))
                Dim fs As New FrameString
                fs.Flags = DefaultFlags
                fs.TextEncoding = DefaultTextEncoding
                r.SetValue("DefaultFlagsEncoding", "{" & fs.GetParameterString & "}")
                r.SetValue("AutoNormalizeOnLoad", AutoNormalizeOnLoad)
                r.SetValue("SyncMethod", CInt(SyncMethod))
                r.SetValue("SyncFields", CInt(SyncFields))
                r.SetValue("AutoSave", AutoSave)
            End If

            SaveCategoriesXmlFile()
        End Sub

        Private Shared Sub SaveCategoriesXmlFile()
            Dim xmldoc As New XmlDocument()
            Dim x As XmlElement = xmldoc.CreateElement("FramesDefaultCategories")
            Dim fd As FrameDescription
            For Each fd In FrameDescriptions
                Dim xcom As XmlComment = xmldoc.CreateComment(fd.Summary)
                x.AppendChild(xcom)
                Dim xcat As XmlElement = xmldoc.CreateElement(fd.FrameID)
                xcat.SetAttribute("Category", fd.Category)
                x.AppendChild(xcat)
            Next
            xmldoc.AppendChild(x)
            Dim xComment As XmlComment = xmldoc.CreateComment("This file was created for TagID. More info at http://www34.brinkster.com/kingherc/.")
            xmldoc.AppendChild(xComment)
            Try
                xmldoc.Save(Directory.GetCurrentDirectory & "\" & Helper.FrameCategoriesFileName)
            Catch ex As Exception

            End Try
        End Sub

#End Region

#Region "LoadOptions"

        ''' <summary>
        ''' Tries to load options from the registry and the frame categories from the xml file.
        ''' </summary>
        ''' <remarks>The registry options can be found at HKEY_CURRENT_USER\Software\TagID. The chosen frame categories must be in an xml file in the running directory of the program. If the xml file is not loaded, the default xml is loaded and saved at that location.</remarks>
        Public Sub LoadOptions()
            Dim r As RegistryKey = Registry.CurrentUser
            r = r.OpenSubKey("Software")
            If Not r Is Nothing Then
                r = r.OpenSubKey("TagID")
            End If
            If Not r Is Nothing Then
                DisplayFlags = r.GetValue("DisplayFlags")
                DisplayTextEncoding = r.GetValue("DisplayTextEncoding")
                FramesOrder = r.GetValue("FramesOrder")
                PromptOnConflictingFrames = r.GetValue("PromptOnConflictingFrames")
                AddConflictingFrames = r.GetValue("AddConflictingFrames")
                DisplayOneLineEdit = r.GetValue("DisplayOneLineEdit")
                ForceOneLineEdit = r.GetValue("ForceOneLineEdit")
                Dim fs As New FrameString(r.GetValue("DefaultFlagsEncoding"))
                DefaultFlags = fs.Flags
                DefaultTextEncoding = fs.TextEncoding
                AutoNormalizeOnLoad = r.GetValue("AutoNormalizeOnLoad")
                SyncMethod = r.GetValue("SyncMethod")
                SyncFields = r.GetValue("SyncFields")
                AutoSave = r.GetValue("AutoSave")
            End If

            LoadCategoriesXmlFile()
            OnOptionsChanged()
        End Sub

        Private Shared Sub LoadCategoriesXmlFile()
            FrameDescriptions = New FrameDescriptionList()
        End Sub

#End Region

#Region "Enums"

        Public Enum FramesOrderEnum
            ''' <summary>
            ''' The ID3v2 frames are categorized. Their categories are found in Helper.FrameDescriptions.
            ''' </summary>
            Categorized = 1
            ''' <summary>
            ''' The ID3v2 frames are shown in alphabetical order.
            ''' </summary>
            Alphabetical = 2
            ''' <summary>
            ''' The ID3v2 frames are not ordered. They are shown in the order they are read (or in the order to be written).
            ''' </summary>
            None = 3
        End Enum

        Public Enum SyncMethodEnum
            ''' <summary>
            ''' Synchronizes ID3v1 tag with info dragged from the ID3v2 tag (the fields to be synchronized are chosen by the SyncFieldsEnum).
            ''' </summary>
            Sync2from1 = 1
            ''' <summary>
            ''' Synchronizes ID3v2 tag with info dragged from the ID3v1 tag (the fields to be synchronized are chosen by the SyncFieldsEnum).
            ''' </summary>
            Sync1from2 = 2
            ''' <summary>
            ''' Synchronizes both ID3v2 and ID3v1 tags. This option is used along with the SyncFieldsEnum.SyncBlankFields option.
            ''' </summary>
            SyncBoth1and2 = 3
        End Enum

        Public Enum SyncFieldsEnum
            ''' <summary>
            ''' Synchronizes (fills) fields/frames that are empty. More info can be found at the TagID.Editor.ID3TagEditor.SyncID3Tags method.
            ''' </summary>
            SyncBlankFields = 1
            ''' <summary>
            ''' Synchronizes (fills) all fields/frames. More info can be found at the TagID.Editor.ID3TagEditor.SyncID3Tags method.
            ''' </summary>
            SyncAllFields = 2
        End Enum

#End Region

    End Class

#End Region

End Class