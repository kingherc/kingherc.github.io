#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Namespace UltraID3LibExtender.TypeEditors

    <ToolboxItem(False)> _
    Public Class BitmapControl

        Private editorService As IWindowsFormsEditorService
        Private context As ITypeDescriptorContext
        Private provider As IServiceProvider

        Public Sub New(ByVal bmp As Bitmap, ByVal editorService As Windows.Forms.Design.IWindowsFormsEditorService, ByVal context As ITypeDescriptorContext, ByVal provider As IServiceProvider)
            InitializeComponent()
            Me.Bmp = bmp
            Me.editorService = editorService
            Me.context = context
            Me.provider = provider
        End Sub

        Private _bmp As Bitmap
        Public Property Bmp() As Bitmap
            Get
                Return _bmp
            End Get
            Set(ByVal value As Bitmap)
                _bmp = value

                If value Is Nothing Then
                    value = pb.ErrorImage
                End If
                pb.Image = value
                BitmapControl_Resize(Me, EventArgs.Empty)
            End Set
        End Property

        Private Sub tsOpenImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsOpenImage.Click
            Dim b As New System.Drawing.Design.BitmapEditor
            Bmp = b.EditValue(context, provider, Bmp)
        End Sub

        Private Sub BitmapControl_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
            If Not pb.Image Is Nothing Then
                If pb.Image.Width > pb.ClientSize.Width Or pb.Image.Height > pb.ClientSize.Height Then
                    pb.SizeMode = PictureBoxSizeMode.Zoom
                Else
                    pb.SizeMode = PictureBoxSizeMode.CenterImage
                End If
            End If
        End Sub

        Private Sub tsSaveImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsSaveImage.Click
            If Not Bmp Is Nothing Then
                SaveFile.FileName = "StoredImage"
                SaveFile.AddExtension = True
                If Bmp.RawFormat.Equals(ImageFormat.Bmp) Then
                    SaveFile.DefaultExt = ".bmp"
                ElseIf Bmp.RawFormat.Equals(ImageFormat.Emf) Then
                    SaveFile.DefaultExt = ".emf"
                ElseIf Bmp.RawFormat.Equals(ImageFormat.Gif) Then
                    SaveFile.DefaultExt = ".gif"
                ElseIf Bmp.RawFormat.Equals(ImageFormat.Icon) Then
                    SaveFile.DefaultExt = ".ico"
                ElseIf Bmp.RawFormat.Equals(ImageFormat.Jpeg) Then
                    SaveFile.DefaultExt = ".jpg"
                ElseIf Bmp.RawFormat.Equals(ImageFormat.Png) Then
                    SaveFile.DefaultExt = ".png"
                ElseIf Bmp.RawFormat.Equals(ImageFormat.Tiff) Then
                    SaveFile.DefaultExt = ".tiff"
                ElseIf Bmp.RawFormat.Equals(ImageFormat.Wmf) Then
                    SaveFile.DefaultExt = ".wmf"
                Else
                    SaveFile.DefaultExt = ""
                    SaveFile.AddExtension = False
                End If
                If SaveFile.DefaultExt = "" Then
                    SaveFile.Filter = "All files|*.*"
                Else
                    SaveFile.Filter = " Image format with extension " & SaveFile.DefaultExt & "|*" & SaveFile.DefaultExt
                End If
                If SaveFile.ShowDialog = DialogResult.OK Then
                    Bmp.Save(SaveFile.FileName, Bmp.RawFormat)
                End If
            End If
        End Sub

        Private Sub tsDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsDelete.Click
            Bmp = Nothing
        End Sub

    End Class

End Namespace
