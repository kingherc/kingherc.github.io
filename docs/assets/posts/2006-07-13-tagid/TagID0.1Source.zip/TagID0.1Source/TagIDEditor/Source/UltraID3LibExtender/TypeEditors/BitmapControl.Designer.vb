#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Namespace UltraID3LibExtender.TypeEditors
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class BitmapControl
        Inherits System.Windows.Forms.UserControl

        'UserControl overrides dispose to clean up the component list.
        <System.Diagnostics.DebuggerNonUserCode()> _
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Me.pb = New System.Windows.Forms.PictureBox
            Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
            Me.tsOpenImage = New System.Windows.Forms.ToolStripButton
            Me.tsSaveImage = New System.Windows.Forms.ToolStripButton
            Me.tsDelete = New System.Windows.Forms.ToolStripButton
            Me.SaveFile = New System.Windows.Forms.SaveFileDialog
            CType(Me.pb, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.ToolStrip1.SuspendLayout()
            Me.SuspendLayout()
            '
            'pb
            '
            Me.pb.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                        Or System.Windows.Forms.AnchorStyles.Left) _
                        Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.pb.Location = New System.Drawing.Point(27, 3)
            Me.pb.Name = "pb"
            Me.pb.Size = New System.Drawing.Size(139, 134)
            Me.pb.TabIndex = 0
            Me.pb.TabStop = False
            '
            'ToolStrip1
            '
            Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Left
            Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
            Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsOpenImage, Me.tsSaveImage, Me.tsDelete})
            Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
            Me.ToolStrip1.Name = "ToolStrip1"
            Me.ToolStrip1.Size = New System.Drawing.Size(32, 140)
            Me.ToolStrip1.TabIndex = 1
            Me.ToolStrip1.Text = "ToolStrip1"
            '
            'tsOpenImage
            '
            Me.tsOpenImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
            Me.tsOpenImage.Image = Global.TagID.Editor.My.Resources.Resources.imgFolderOpen
            Me.tsOpenImage.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.tsOpenImage.Name = "tsOpenImage"
            Me.tsOpenImage.Size = New System.Drawing.Size(21, 20)
            Me.tsOpenImage.Text = "Open Image..."
            '
            'tsSaveImage
            '
            Me.tsSaveImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
            Me.tsSaveImage.Image = Global.TagID.Editor.My.Resources.Resources.imgSave
            Me.tsSaveImage.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.tsSaveImage.Name = "tsSaveImage"
            Me.tsSaveImage.Size = New System.Drawing.Size(21, 20)
            Me.tsSaveImage.Text = "Save Image..."
            '
            'tsDelete
            '
            Me.tsDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
            Me.tsDelete.Image = Global.TagID.Editor.My.Resources.Resources.imgDelete
            Me.tsDelete.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.tsDelete.Name = "tsDelete"
            Me.tsDelete.Size = New System.Drawing.Size(29, 20)
            Me.tsDelete.Text = "Delete Image"
            '
            'SaveFile
            '
            Me.SaveFile.Title = "Save Image to..."
            '
            'BitmapControl
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.Controls.Add(Me.ToolStrip1)
            Me.Controls.Add(Me.pb)
            Me.Name = "BitmapControl"
            Me.Size = New System.Drawing.Size(169, 140)
            CType(Me.pb, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ToolStrip1.ResumeLayout(False)
            Me.ToolStrip1.PerformLayout()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub
        Friend WithEvents pb As System.Windows.Forms.PictureBox
        Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
        Friend WithEvents tsOpenImage As System.Windows.Forms.ToolStripButton
        Friend WithEvents tsSaveImage As System.Windows.Forms.ToolStripButton
        Friend WithEvents tsDelete As System.Windows.Forms.ToolStripButton
        Friend WithEvents SaveFile As System.Windows.Forms.SaveFileDialog

    End Class

End Namespace
