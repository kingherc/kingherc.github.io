#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Namespace UltraID3LibExtender.TypeEditors
    Friend Class ID3InvolvedPeopleListEditor
        Inherits CollectionEditor

        Public Sub New()
            MyBase.New(GetType(InvolvedPersonCollection))
        End Sub

        Protected Shadows ReadOnly Property CollectionItemType() As Type
            Get
                Return GetType(InvolvedPerson)
            End Get
        End Property

        Protected Shadows ReadOnly Property CollectionType() As Type
            Get
                Return GetType(InvolvedPersonCollection)
            End Get
        End Property

        Protected Shadows ReadOnly Property NewItemTypes() As Type
            Get
                Return GetType(InvolvedPerson)
            End Get
        End Property

        Protected Overrides Function CreateCollectionItemType() As System.Type
            Return GetType(InvolvedPerson)
            Return MyBase.CreateCollectionItemType()
        End Function

        Protected Overrides Function CreateNewItemTypes() As System.Type()
            Return New Type() {GetType(InvolvedPerson)}
            Return MyBase.CreateNewItemTypes()
        End Function

        Protected Overrides Function CreateInstance(ByVal itemType As System.Type) As Object
            If itemType Is GetType(InvolvedPerson) Then
                Return New InvolvedPerson("New Person", "New Involvement")
            End If
            Return MyBase.CreateInstance(itemType)
        End Function

        Protected Overrides Function GetDisplayText(ByVal value As Object) As String
            If value.GetType Is GetType(InvolvedPerson) Then
                Return CType(value, InvolvedPerson).InvolvementType & " - " & CType(value, InvolvedPerson).PersonName
            End If
            Return MyBase.GetDisplayText(value)
        End Function

        Protected Overrides Function GetItems(ByVal editValue As Object) As Object()
            Dim c As InvolvedPersonCollection = editValue
            Dim o(c.Count - 1) As InvolvedPerson
            Dim i As Integer = 0
            For i = 0 To c.Count - 1
                o(i) = c.Item(i)
            Next
            Return o
            Return MyBase.GetItems(editValue)
        End Function

        Protected Overrides Function SetItems(ByVal editValue As Object, ByVal value() As Object) As Object
            Dim str As String = ""
            Dim c As New InvolvedPersonCollection
            Dim i As Integer
            For i = 0 To value.Length - 1
                If Not CType(value(i), InvolvedPerson).IsSet Then
                    str &= i & ","
                End If
                c.Add(value(i))
            Next
            If str.Length > 0 Then
                str = str.Substring(0, str.Length - 1)
                MessageBox.Show("The following entries in the collection are not correctly set:" & vbCrLf & str & vbCrLf & "This may be because the InvolvementType and PersonName fields are not filled for each entry." & vbCrLf & "It's best that you fill them before continuing.", "Suggestion", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
            Return c
            Return MyBase.SetItems(editValue, value)
        End Function

    End Class

    Friend Class InvolvedPersonProvider
        Inherits TypeDescriptionProvider

        Private _baseProvider As TypeDescriptionProvider

        Public Sub New(ByVal t As Type)
            _baseProvider = TypeDescriptor.GetProvider(t)
        End Sub

        Public Overloads Overrides Function GetTypeDescriptor(ByVal objectType As Type, ByVal instance As Object) As ICustomTypeDescriptor
            Return New InvolvedPersonDescriptor(Me, _baseProvider.GetTypeDescriptor(objectType, instance), objectType)
        End Function

        Private Class InvolvedPersonDescriptor
            Inherits CustomTypeDescriptor

            Private _objectType As Type
            Private _provider As InvolvedPersonProvider

            Public Sub New(ByVal provider As InvolvedPersonProvider, ByVal descriptor As ICustomTypeDescriptor, ByVal objectType As Type)
                MyBase.New(descriptor)
                If provider Is Nothing Or descriptor Is Nothing Or objectType Is Nothing Then
                    Throw New ArgumentNullException(Me.GetType.ToString & "'s initialization failed: Provider or Descriptor or objectType is Nothing.")
                End If
                _objectType = objectType
                _provider = provider
            End Sub

#Region "Properties"

            Public Overloads Overrides Function GetProperties() As PropertyDescriptorCollection
                Return GetProperties(Nothing)
            End Function

            Public Overloads Overrides Function GetProperties(ByVal attributes As Attribute()) As PropertyDescriptorCollection
                Dim props As New PropertyDescriptorCollection(Nothing)
                For Each prop As PropertyDescriptor In MyBase.GetProperties(attributes)
                    If prop.Name = "IsSet" Then
                        prop = TypeDescriptor.CreateProperty(prop.ComponentType, prop, New Attribute() {New BrowsableAttribute(False)})
                    End If
                    props.Add(prop)
                Next
                Return props
            End Function

#End Region

        End Class

    End Class

    Friend Class ID3InvolvedPeopleListConverter
        Inherits TypeConverter

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext, ByVal t As Type) As Boolean
            If t Is GetType(String) Then
                Return True
            End If
            Return MyBase.CanConvertTo(context, t)
        End Function

        Public Overloads Overrides Function ConvertTo(ByVal context As ITypeDescriptorContext, ByVal culture As Globalization.CultureInfo, ByVal value As Object, ByVal destinationType As Type) As Object
            If destinationType Is GetType(String) Then
                Return CType(value, InvolvedPersonCollection).Count & " involved persons."
            End If
            Return MyBase.ConvertTo(context, culture, value, destinationType)
        End Function

    End Class

End Namespace