#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class FrameBrowser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnOK = New System.Windows.Forms.Button
        Me.lbFrames = New System.Windows.Forms.ListBox
        Me.lblSort = New System.Windows.Forms.LinkLabel
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.txtDescription = New System.Windows.Forms.TextBox
        Me.lblNotSupported = New System.Windows.Forms.Label
        Me.lblCategory = New System.Windows.Forms.Label
        Me.lblInstances = New System.Windows.Forms.Label
        Me.lblID = New System.Windows.Forms.Label
        Me.lblName = New System.Windows.Forms.Label
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnOK
        '
        Me.btnOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOK.Location = New System.Drawing.Point(258, 367)
        Me.btnOK.Margin = New System.Windows.Forms.Padding(4)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(89, 28)
        Me.btnOK.TabIndex = 2
        Me.btnOK.Text = "OK"
        '
        'lbFrames
        '
        Me.lbFrames.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbFrames.FormattingEnabled = True
        Me.lbFrames.ItemHeight = 16
        Me.lbFrames.Location = New System.Drawing.Point(3, 3)
        Me.lbFrames.Name = "lbFrames"
        Me.lbFrames.Size = New System.Drawing.Size(241, 372)
        Me.lbFrames.Sorted = True
        Me.lbFrames.TabIndex = 3
        '
        'lblSort
        '
        Me.lblSort.AutoSize = True
        Me.lblSort.Location = New System.Drawing.Point(3, 378)
        Me.lblSort.Name = "lblSort"
        Me.lblSort.Size = New System.Drawing.Size(34, 17)
        Me.lblSort.TabIndex = 5
        Me.lblSort.TabStop = True
        Me.lblSort.Text = "Sort"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(12, 12)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.lbFrames)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblSort)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtDescription)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblNotSupported)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblCategory)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblInstances)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblID)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblName)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnOK)
        Me.SplitContainer1.Size = New System.Drawing.Size(602, 400)
        Me.SplitContainer1.SplitterDistance = 247
        Me.SplitContainer1.TabIndex = 6
        '
        'txtDescription
        '
        Me.txtDescription.BackColor = System.Drawing.SystemColors.Control
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtDescription.Location = New System.Drawing.Point(8, 112)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.ReadOnly = True
        Me.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDescription.Size = New System.Drawing.Size(339, 248)
        Me.txtDescription.TabIndex = 10
        Me.txtDescription.Text = "Description"
        '
        'lblNotSupported
        '
        Me.lblNotSupported.AutoSize = True
        Me.lblNotSupported.ForeColor = System.Drawing.Color.Red
        Me.lblNotSupported.Location = New System.Drawing.Point(5, 79)
        Me.lblNotSupported.Name = "lblNotSupported"
        Me.lblNotSupported.Size = New System.Drawing.Size(208, 17)
        Me.lblNotSupported.TabIndex = 9
        Me.lblNotSupported.Text = "This frame is not yet supported."
        Me.lblNotSupported.Visible = False
        '
        'lblCategory
        '
        Me.lblCategory.AutoSize = True
        Me.lblCategory.Location = New System.Drawing.Point(5, 62)
        Me.lblCategory.Name = "lblCategory"
        Me.lblCategory.Size = New System.Drawing.Size(65, 17)
        Me.lblCategory.TabIndex = 8
        Me.lblCategory.Text = "Category"
        '
        'lblInstances
        '
        Me.lblInstances.AutoSize = True
        Me.lblInstances.Location = New System.Drawing.Point(5, 45)
        Me.lblInstances.Name = "lblInstances"
        Me.lblInstances.Size = New System.Drawing.Size(68, 17)
        Me.lblInstances.TabIndex = 5
        Me.lblInstances.Text = "Instances"
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Location = New System.Drawing.Point(5, 28)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(65, 17)
        Me.lblID.TabIndex = 4
        Me.lblID.Text = "Frame ID"
        '
        'lblName
        '
        Me.lblName.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.lblName.Location = New System.Drawing.Point(3, 3)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(135, 25)
        Me.lblName.TabIndex = 3
        Me.lblName.Text = "Frame Name"
        '
        'FrameBrowser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(626, 424)
        Me.Controls.Add(Me.SplitContainer1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "FrameBrowser"
        Me.ShowIcon = False
        Me.Text = "ID3v2 Frames Browser"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.Panel2.PerformLayout()
        Me.SplitContainer1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents lbFrames As System.Windows.Forms.ListBox
    Friend WithEvents lblSort As System.Windows.Forms.LinkLabel

    Public Sub New(Optional ByVal sortmethod As SortMethods = SortMethods.ByFrameName)
        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Me.SortMethod = sortmethod
    End Sub
    Public Sub New(ByVal frameIDorName As String, ByVal TrueForIDFalseForName As Boolean, Optional ByVal sortMethod As SortMethods = SortMethods.ByFrameName)
        Me.New(sortMethod)
        If TrueForIDFalseForName Then
            ChangeToFrameID(frameIDorName)
        Else
            ChangeToFrameName(frameIDorName)
        End If
    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents lblInstances As System.Windows.Forms.Label
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents lblCategory As System.Windows.Forms.Label
    Friend WithEvents lblNotSupported As System.Windows.Forms.Label
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox

End Class