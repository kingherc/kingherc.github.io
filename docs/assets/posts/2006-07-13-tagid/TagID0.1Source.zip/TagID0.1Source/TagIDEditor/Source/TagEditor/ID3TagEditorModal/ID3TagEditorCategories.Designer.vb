#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class ID3TagEditorCategories
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.OK_Button = New System.Windows.Forms.Button
        Me.Cancel_Button = New System.Windows.Forms.Button
        Me.tv = New System.Windows.Forms.TreeView
        Me.mn = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnExpandAll = New System.Windows.Forms.ToolStripMenuItem
        Me.mnCollapseAll = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.mnNewCategory = New System.Windows.Forms.ToolStripMenuItem
        Me.imgs = New System.Windows.Forms.ImageList(Me.components)
        Me.lblDescription = New System.Windows.Forms.Label
        Me.btnLoadDefault = New System.Windows.Forms.Button
        Me.mnRenameCategory = New System.Windows.Forms.ToolStripMenuItem
        Me.mn.SuspendLayout()
        Me.SuspendLayout()
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.OK_Button.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.OK_Button.Location = New System.Drawing.Point(366, 339)
        Me.OK_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(89, 28)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(463, 339)
        Me.Cancel_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(89, 28)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'tv
        '
        Me.tv.AllowDrop = True
        Me.tv.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tv.ContextMenuStrip = Me.mn
        Me.tv.ImageIndex = 0
        Me.tv.ImageList = Me.imgs
        Me.tv.LabelEdit = True
        Me.tv.Location = New System.Drawing.Point(12, 12)
        Me.tv.Name = "tv"
        Me.tv.SelectedImageIndex = 0
        Me.tv.Size = New System.Drawing.Size(347, 355)
        Me.tv.TabIndex = 2
        '
        'mn
        '
        Me.mn.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnExpandAll, Me.mnCollapseAll, Me.ToolStripSeparator1, Me.mnNewCategory, Me.mnRenameCategory})
        Me.mn.Name = "mn"
        Me.mn.Size = New System.Drawing.Size(210, 98)
        '
        'mnExpandAll
        '
        Me.mnExpandAll.Name = "mnExpandAll"
        Me.mnExpandAll.Size = New System.Drawing.Size(209, 22)
        Me.mnExpandAll.Text = "Expand All"
        '
        'mnCollapseAll
        '
        Me.mnCollapseAll.Name = "mnCollapseAll"
        Me.mnCollapseAll.Size = New System.Drawing.Size(209, 22)
        Me.mnCollapseAll.Text = "Collapse All"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(206, 6)
        '
        'mnNewCategory
        '
        Me.mnNewCategory.Name = "mnNewCategory"
        Me.mnNewCategory.Size = New System.Drawing.Size(209, 22)
        Me.mnNewCategory.Text = "New Category"
        '
        'imgs
        '
        Me.imgs.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imgs.ImageSize = New System.Drawing.Size(16, 16)
        Me.imgs.TransparentColor = System.Drawing.Color.Transparent
        '
        'lblDescription
        '
        Me.lblDescription.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblDescription.Location = New System.Drawing.Point(365, 12)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(187, 289)
        Me.lblDescription.TabIndex = 3
        Me.lblDescription.Text = "Drag frames from one category to another. To create a new category, rename a cate" & _
            "gory etc. right-click to display the menu. An empty category will be ignored/del" & _
            "eted."
        '
        'btnLoadDefault
        '
        Me.btnLoadDefault.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnLoadDefault.Location = New System.Drawing.Point(366, 304)
        Me.btnLoadDefault.Name = "btnLoadDefault"
        Me.btnLoadDefault.Size = New System.Drawing.Size(186, 28)
        Me.btnLoadDefault.TabIndex = 4
        Me.btnLoadDefault.Text = "Load Default Categories"
        Me.btnLoadDefault.UseVisualStyleBackColor = True
        '
        'mnRenameCategory
        '
        Me.mnRenameCategory.Name = "mnRenameCategory"
        Me.mnRenameCategory.Size = New System.Drawing.Size(209, 22)
        Me.mnRenameCategory.Text = "Rename Category"
        '
        'EditCategoriesDialog
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(565, 380)
        Me.Controls.Add(Me.btnLoadDefault)
        Me.Controls.Add(Me.lblDescription)
        Me.Controls.Add(Me.tv)
        Me.Controls.Add(Me.Cancel_Button)
        Me.Controls.Add(Me.OK_Button)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "EditCategoriesDialog"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Edit Frame Categories"
        Me.mn.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents tv As System.Windows.Forms.TreeView
    Friend WithEvents lblDescription As System.Windows.Forms.Label
    Friend WithEvents imgs As System.Windows.Forms.ImageList
    Friend WithEvents btnLoadDefault As System.Windows.Forms.Button
    Friend WithEvents mn As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnExpandAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnCollapseAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnNewCategory As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnRenameCategory As System.Windows.Forms.ToolStripMenuItem

End Class