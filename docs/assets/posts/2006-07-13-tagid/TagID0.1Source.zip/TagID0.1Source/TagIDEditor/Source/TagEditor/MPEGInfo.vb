#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

''' <summary>
''' The MPEGInfo class encapsulates info dragged from the MPEG track of a file.
''' </summary>
''' <remarks>The MPEGInfo class encapsulates info dragged from the MPEG track of a file (dragged from UltraID3Lib's MPEGTrackInfo and MPEGFrameInfo using UltraID3 for the selected file). It stores the info and shows it appropriately in a property grid (hides properties with no values and shows any exceptions of UltraID3.GetExceptions as properties).</remarks>
Public Class MPEGInfo

#Region "New, ResetValues, FilePath property"

    Private Sub New()
    End Sub

    ''' <summary>
    ''' Initializes a new instance of MPEGInfo.
    ''' </summary>
    ''' <param name="filepath">The path of the file to open and search for info to store.</param>
    ''' <param name="CanChangeFile">Whether the user will be able to change the file path (by changing the FilePath property).</param>
    Public Sub New(ByVal filepath As String, ByVal CanChangeFile As Boolean)
        ResetValues()
        Me.FilePath = filepath
        Me._canchangefile = CanChangeFile
    End Sub

    Private Sub ResetValues()
        _canchangefile = True
        _AverageBitrate = 0
        _duration = TimeSpan.Zero
        _FramesCount = 0
        _Bitrate = 0
        _Emphasis = EmphasisTypes.Unknown
        _Frequency = 0
        _Layer = LayerTypes.Unknown
        _Level = LevelTypes.Unknown
        _Mode = ModeTypes.Unknown
        _FlagCopyright = False
        _FlagOriginal = False
        _FlagPadding = False
        _FlagPrivate = False
        _FlagProtection = False
        _vbr = Nothing
        _u = Nothing
    End Sub

    Private _fp As String = ""
    ''' <summary>
    ''' Changes the currently shown file info.
    ''' </summary>
    <Category("File Info")> _
    <Description("The path of the file whose MPEG info is shown.")> _
    <RefreshProperties(RefreshProperties.All)> _
    <DisplayName("File Path")> _
    Public Property FilePath() As String
        Get
            Return _fp
        End Get
        Set(ByVal value As String)
            If CanChangeFile Then
                If File.Exists(value) Then
                    _fp = value
                    ResetValues()

                    Dim u As New UltraID3
                    u.Read(value)
                    _u = u



                    Dim ti As MPEGFrameInfo
                    Try
                        ti = u.FirstMPEGFrameInfo
                    Catch ex As Exception
                        ti = Nothing
                    End Try
                    Dim mi As MPEGTrackInfo
                    Try
                        mi = u.GetMPEGTrackInfo
                    Catch ex As Exception
                        mi = Nothing
                    End Try

                    If Not mi Is Nothing Then
                        _AverageBitrate = mi.AverageBitRate
                        _FramesCount = mi.FrameCount
                    End If
                    Dim ts As TimeSpan = u.Duration
                    If Not ts.Ticks = 0 Then
                        _duration = ts
                    End If
                    If Not ti Is Nothing Then
                        _Bitrate = ti.Bitrate
                        _Emphasis = ti.Emphasis
                        _Frequency = ti.Frequency
                        _Layer = ti.Layer
                        _Level = ti.Level
                        _Mode = ti.Mode
                        _FlagCopyright = ti.CopyrightFlag
                        _FlagOriginal = ti.OriginalFlag
                        _FlagPadding = ti.PaddingFlag
                        _FlagPrivate = ti.PrivateFlag
                        _FlagProtection = ti.ProtectionFlag
                        _vbr = ti.VBRInfo
                    End If


                    OnFilePathChanged()
                End If
            End If
        End Set
    End Property

#End Region
#Region "Properties and Events"

    ''' <summary>
    ''' The size of the file in bytes.
    ''' </summary>
    <Category("File Info")> _
    <Description("The size of the file.")> _
    <DisplayName("File Size")> _
    <TypeConverter(GetType(MPEGInfoFileSizeConverter))> _
    Public ReadOnly Property FileSize() As Long
        Get
            If File.Exists(Me.FilePath) Then
                Return My.Computer.FileSystem.GetFileInfo(Me.FilePath).Length
            Else
                Return 0
            End If
        End Get
    End Property

    Private _canchangefile As Boolean
    ''' <summary>
    ''' If the FilePath property can/should be changed.
    ''' </summary>
    <Browsable(False)> _
    Public ReadOnly Property CanChangeFile() As Boolean
        Get
            Return _canchangefile
        End Get
    End Property

    Private _AverageBitrate As Short
    ''' <summary>
    ''' The average bitrate of the track in kilobits per second (kbps).
    ''' </summary>
    <Category("Track Info")> _
    <Description("The average bitrate of the track in kilobits per second (kbps).")> _
    <TypeConverter(GetType(MPEGInfoBitrateConverter))> _
    <DisplayName("Average Bitrate")> _
    Public ReadOnly Property AverageBitrate() As Short
        Get
            Return _AverageBitrate
        End Get
    End Property

    Private _duration As TimeSpan
    ''' <summary>
    ''' The duration of the track.
    ''' </summary>
    <Category("Track Info")> _
    <Description("The duration of the track.")> _
    <TypeConverter(GetType(MPEGInfoDurationConverter))> _
    Public ReadOnly Property Duration() As TimeSpan
        Get
            Return _duration
        End Get
    End Property

    Private _FramesCount As Long
    ''' <summary>
    ''' The number of MPEG frames in the track.
    ''' </summary>
    <Category("Track Info")> _
    <Description("The number of MPEG frames in the track.")> _
    <DisplayName("Frames Count")> _
    Public ReadOnly Property FramesCount() As Long
        Get
            Return _FramesCount
        End Get
    End Property

    Private _Bitrate As Short
    ''' <summary>
    ''' The bitrate in kilobits per second (kbps) of the first MPEG frame.
    ''' </summary>
    <Category("Info from first MPEG frame")> _
    <Description("The bitrate in kilobits per second (kbps).")> _
    <TypeConverter(GetType(MPEGInfoBitrateConverter))> _
    Public ReadOnly Property Bitrate() As Short
        Get
            Return _Bitrate
        End Get
    End Property

    Private _Emphasis As EmphasisTypes
    ''' <summary>
    ''' The emphasis of the first MPEG frame.
    ''' </summary>
    <Category("Info from first MPEG frame")> _
    Public ReadOnly Property Emphasis() As EmphasisTypes
        Get
            Return _Emphasis
        End Get
    End Property

    Private _Frequency As Integer
    ''' <summary>
    ''' The frequency in Hz of the first MPEG frame.
    ''' </summary>
    <Category("Info from first MPEG frame")> _
    <Description("The frequency in Hertz.")> _
    <TypeConverter(GetType(MPEGInfoFrequencyConverter))> _
    Public ReadOnly Property Frequency() As Integer
        Get
            Return _Frequency
        End Get
    End Property

    Private _Layer As LayerTypes
    ''' <summary>
    ''' The layer of the mpeg track.
    ''' </summary>
    <Category("Info from first MPEG frame")> _
    <Description("The layer of the mpeg track.")> _
    Public ReadOnly Property Layer() As LayerTypes
        Get
            Return _Layer
        End Get
    End Property

    Private _Level As LevelTypes
    ''' <summary>
    ''' The 'level' of the mpeg track.
    ''' </summary>
    <Category("Info from first MPEG frame")> _
    <Description("The 'level' of the mpeg track.")> _
    Public ReadOnly Property Level() As LevelTypes
        Get
            Return _Level
        End Get
    End Property

    Private _Mode As ModeTypes
    ''' <summary>
    ''' The 'mode' of the mpeg track.
    ''' </summary>
    <Category("Info from first MPEG frame")> _
    <Description("The 'mode' of the mpeg track.")> _
    Public ReadOnly Property Mode() As ModeTypes
        Get
            Return _Mode
        End Get
    End Property

    Private _FlagCopyright As Boolean
    ''' <summary>
    ''' If the track has the copyright flag.
    ''' </summary>
    <Category("Flags")> _
    <Description("If the track has the copyright flag.")> _
    <DisplayName("Copyright Flag")> _
    Public ReadOnly Property FlagCopyright() As Boolean
        Get
            Return _FlagCopyright
        End Get
    End Property

    Private _FlagOriginal As Boolean
    ''' <summary>
    ''' If the track has the original flag.
    ''' </summary>
    <Category("Flags")> _
    <Description("If the track has the original flag.")> _
    <DisplayName("Original Flag")> _
    Public ReadOnly Property FlagOriginal() As Boolean
        Get
            Return _FlagOriginal
        End Get
    End Property

    Private _FlagPadding As Boolean
    ''' <summary>
    ''' If the track has the Padding flag.
    ''' </summary>
    <Category("Flags")> _
    <Description("If the track has the Padding flag.")> _
    <DisplayName("Padding Flag")> _
    Public ReadOnly Property FlagPadding() As Boolean
        Get
            Return _FlagPadding
        End Get
    End Property

    Private _FlagPrivate As Boolean
    ''' <summary>
    ''' If the track has the Private flag.
    ''' </summary>
    <Category("Flags")> _
    <Description("If the track has the Private flag.")> _
    <DisplayName("Private Flag")> _
    Public ReadOnly Property FlagPrivate() As Boolean
        Get
            Return _FlagPrivate
        End Get
    End Property

    Private _FlagProtection As Boolean
    ''' <summary>
    ''' If the track has the Protection flag.
    ''' </summary>
    <Category("Flags")> _
    <Description("If the track has the Protection flag.")> _
    <DisplayName("Protection Flag")> _
    Public ReadOnly Property FlagProtection() As Boolean
        Get
            Return _FlagProtection
        End Get
    End Property

    Private _vbr As VBRInfo
    ''' <summary>
    ''' The VBRInfo of the mpeg file.
    ''' </summary>
    <Browsable(False)> _
    Public ReadOnly Property VBR() As VBRInfo
        Get
            Return _vbr
        End Get
    End Property

    ''' <summary>
    ''' VBR Duration.
    ''' </summary>
    ''' <returns>If it doesn't exist, returns TimeSpan.Zero.</returns>
    <Category("Variable Bitrate (VBR) Info")> _
    <Description("VBR Duration.")> _
    <DisplayName("Duration")> _
    <TypeConverter(GetType(MPEGInfoDurationConverter))> _
    Public ReadOnly Property VBRDuration() As TimeSpan
        Get
            If Not _vbr Is Nothing Then
                If _vbr.FoundFlag And _vbr.Duration.HasValue Then
                    Return _vbr.Duration.Value
                Else
                    Return TimeSpan.Zero
                End If
            Else
                Return TimeSpan.Zero
            End If
        End Get
    End Property

    ''' <summary>
    ''' VBR Frames Count.
    ''' </summary>
    ''' <returns>If it doesn't exist, returns 0.</returns>
    <Category("Variable Bitrate (VBR) Info")> _
    <Description("VBR Frames Count.")> _
    <DisplayName("Frames Count")> _
    Public ReadOnly Property VBRFramesCount() As Long
        Get
            If Not _vbr Is Nothing Then
                If _vbr.FoundFlag And _vbr.FrameCount.HasValue Then
                    Return _vbr.FrameCount.Value
                Else
                    Return 0
                End If
            Else
                Return 0
            End If
        End Get
    End Property

    ''' <summary>
    ''' VBR Quality Rating.
    ''' </summary>
    ''' <returns>If it doesn't exist, returns 0.</returns>
    <Category("Variable Bitrate (VBR) Info")> _
    <Description("VBR Quality Rating.")> _
    <DisplayName("Quality Rating")> _
    Public ReadOnly Property VBRQualityRating() As Integer
        Get
            If Not _vbr Is Nothing Then
                If _vbr.FoundFlag And _vbr.QualityRating.HasValue Then
                    Return _vbr.QualityRating.Value
                Else
                    Return 0
                End If
            Else
                Return 0
            End If
        End Get
    End Property

    ''' <summary>
    ''' VBR Size.
    ''' </summary>
    ''' <returns>If it doesn't exist, returns 0.</returns>
    <Category("Variable Bitrate (VBR) Info")> _
    <Description("VBR Size.")> _
    <DisplayName("Size")> _
    <TypeConverter(GetType(MPEGInfoFileSizeConverter))> _
    Public ReadOnly Property VBRSize() As Long
        Get
            If Not _vbr Is Nothing Then
                If _vbr.FoundFlag And _vbr.Size.HasValue Then
                    Return _vbr.Size.Value
                Else
                    Return 0
                End If
            Else
                Return 0
            End If
        End Get
    End Property

    ''' <summary>
    ''' VBR Table of Contents.
    ''' </summary>
    ''' <returns>If it doesn't exist, returns Nothing.</returns>
    <Category("Variable Bitrate (VBR) Info")> _
    <Description("VBR Table of Contents.")> _
    <DisplayName("Table of Contents")> _
    <Editor(GetType(System.ComponentModel.Design.BinaryEditor), GetType(UITypeEditor))> _
    <TypeConverter(GetType(UltraID3LibExtender.TypeEditors.BytesConverter))> _
    Public Property VBRTableOfContents() As Byte()
        Get
            If Not _vbr Is Nothing Then
                If _vbr.FoundFlag And _vbr.TableOfContentsExists Then
                    Return _vbr.TableOfContents
                Else
                    Return Nothing
                End If
            Else
                Return Nothing
            End If
        End Get
        Set(ByVal value As Byte())

        End Set
    End Property

    Private _u As UltraID3
    ''' <summary>
    ''' The UltraID3 used to get the mpeg file info.
    ''' </summary>
    <Browsable(False)> _
    Public ReadOnly Property UltraID3Parent() As UltraID3
        Get
            Return _u
        End Get
    End Property

    ''' <summary>
    ''' Trigerred when the FilePath property is changed. The property can be changed only when CanChangeFile is true.
    ''' </summary>
    Public Event FilePathChanged()
    Protected Sub OnFilePathChanged()
        RaiseEvent FilePathChanged()
    End Sub

#End Region

#Region "MPEGInfoFilePathConverter"
    <EditorBrowsable(EditorBrowsableState.Never)> _
    Private Class MPEGInfoFilePathConverter
        Inherits TypeConverter

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext, ByVal t As Type) As Boolean
            If t Is GetType(String) Then
                Return True
            End If
            Return MyBase.CanConvertTo(context, t)
        End Function

        Public Overloads Overrides Function ConvertTo(ByVal context As ITypeDescriptorContext, ByVal culture As Globalization.CultureInfo, ByVal value As Object, ByVal destinationType As Type) As Object
            If destinationType Is GetType(String) Then
                If value = "" Then
                    Return "No file selected."
                Else
                    Return value
                End If
            End If
            Return MyBase.ConvertTo(context, culture, value, destinationType)
        End Function

    End Class
#End Region
#Region "MPEGInfoBitrateConverter"
    <EditorBrowsable(EditorBrowsableState.Never)> _
    Private Class MPEGInfoBitrateConverter
        Inherits TypeConverter

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext, ByVal t As Type) As Boolean
            If t Is GetType(String) Then
                Return True
            End If
            Return MyBase.CanConvertTo(context, t)
        End Function

        Public Overloads Overrides Function ConvertTo(ByVal context As ITypeDescriptorContext, ByVal culture As Globalization.CultureInfo, ByVal value As Object, ByVal destinationType As Type) As Object
            If destinationType Is GetType(String) Then
                If Not value = 0 Then
                    Return CStr(value) & " kbps"
                Else
                    Return CStr(value)
                End If
            End If
            Return MyBase.ConvertTo(context, culture, value, destinationType)
        End Function

    End Class
#End Region
#Region "MPEGInfoDurationConverter"
    <EditorBrowsable(EditorBrowsableState.Never)> _
    Private Class MPEGInfoDurationConverter
        Inherits TypeConverter

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext, ByVal t As Type) As Boolean
            If t Is GetType(String) Then
                Return True
            End If
            Return MyBase.CanConvertTo(context, t)
        End Function

        Public Overloads Overrides Function ConvertTo(ByVal context As ITypeDescriptorContext, ByVal culture As Globalization.CultureInfo, ByVal value As Object, ByVal destinationType As Type) As Object
            If destinationType Is GetType(String) Then
                If Not value = TimeSpan.Zero Then
                    Return UsefulMethods.cTimeSpanToString(value)
                Else
                    Return ""
                End If
            End If
            Return MyBase.ConvertTo(context, culture, value, destinationType)
        End Function

    End Class
#End Region
#Region "MPEGInfoFrequencyConverter"
    <EditorBrowsable(EditorBrowsableState.Never)> _
    Private Class MPEGInfoFrequencyConverter
        Inherits TypeConverter

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext, ByVal t As Type) As Boolean
            If t Is GetType(String) Then
                Return True
            End If
            Return MyBase.CanConvertTo(context, t)
        End Function

        Public Overloads Overrides Function ConvertTo(ByVal context As ITypeDescriptorContext, ByVal culture As Globalization.CultureInfo, ByVal value As Object, ByVal destinationType As Type) As Object
            If destinationType Is GetType(String) Then
                If value = 0 Then
                    Return ""
                Else
                    If value > 1000 Then
                        Return CStr(value / 1000) & " kHz"
                    Else
                        Return CStr(value) & " Hz"
                    End If
                End If
            End If
            Return MyBase.ConvertTo(context, culture, value, destinationType)
        End Function

    End Class
#End Region
#Region "MPEGInfoFileSizeConverter"
    <EditorBrowsable(EditorBrowsableState.Never)> _
    Private Class MPEGInfoFileSizeConverter
        Inherits TypeConverter

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext, ByVal t As Type) As Boolean
            If t Is GetType(String) Then
                Return True
            End If
            Return MyBase.CanConvertTo(context, t)
        End Function

        Public Overloads Overrides Function ConvertTo(ByVal context As ITypeDescriptorContext, ByVal culture As Globalization.CultureInfo, ByVal value As Object, ByVal destinationType As Type) As Object
            If destinationType Is GetType(String) Then
                Return Helper.UsefulMethods.cBytesLengthDescription(value)
            End If
            Return MyBase.ConvertTo(context, culture, value, destinationType)
        End Function

    End Class
#End Region
#Region "MPEGInfoExceptionConverter"
    <EditorBrowsable(EditorBrowsableState.Never)> _
    Private Class MPEGInfoExceptionConverter
        Inherits TypeConverter

        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext, ByVal t As Type) As Boolean
            If t Is GetType(String) Then
                Return True
            End If
            Return MyBase.CanConvertTo(context, t)
        End Function

        Public Overloads Overrides Function ConvertTo(ByVal context As ITypeDescriptorContext, ByVal culture As Globalization.CultureInfo, ByVal value As Object, ByVal destinationType As Type) As Object
            If destinationType Is GetType(String) Then
                Return CType(value, ID3MetaDataException).Message
            End If
            Return MyBase.ConvertTo(context, culture, value, destinationType)
        End Function

    End Class
#End Region

#Region "MPEGInfoProvider and MPEGInfoDescriptor"

    Friend Class MPEGInfoProvider
        Inherits TypeDescriptionProvider


        Private _baseProvider As TypeDescriptionProvider

        Public Sub New(ByVal t As Type)
            _baseProvider = TypeDescriptor.GetProvider(t)
        End Sub

        Public Overloads Overrides Function GetTypeDescriptor(ByVal objectType As Type, ByVal instance As Object) As ICustomTypeDescriptor
            Return New MPEGInfoDescriptor(Me, _baseProvider.GetTypeDescriptor(objectType, instance), instance)
        End Function

        Private Class MPEGInfoDescriptor
            Inherits CustomTypeDescriptor

            Private _instance As MPEGInfo
            Private _provider As MPEGInfoProvider

            Public Sub New(ByVal provider As MPEGInfoProvider, ByVal descriptor As ICustomTypeDescriptor, ByVal instance As MPEGInfo)
                MyBase.New(descriptor)
                If Not instance Is Nothing Then
                    If provider Is Nothing Or descriptor Is Nothing Or instance.GetType Is Nothing Then
                        Throw New ArgumentNullException(Me.GetType.ToString & "'s initialization failed: Provider or Descriptor or objectType is Nothing.")
                    End If
                    _instance = instance
                    _provider = provider
                End If
            End Sub

#Region "Attributes"

            Public Overloads Overrides Function GetAttributes() As AttributeCollection
                Return MyBase.GetAttributes()
            End Function

#End Region

#Region "Properties"

            Public Overloads Overrides Function GetProperties() As PropertyDescriptorCollection
                Return GetProperties(Nothing)
            End Function

            ''' <summary>
            ''' Returns the properties of the MPEGInfo class.
            ''' </summary>
            ''' <remarks>The properties that have unknown or no value are made non-browsable. Also, for each exception in UltraID3Parent.GetExceptions, an UltraID3ExceptionPropertyDescriptor is made.</remarks>
            Public Overloads Overrides Function GetProperties(ByVal attributes As Attribute()) As PropertyDescriptorCollection
                Dim props As New PropertyDescriptorCollection(Nothing)
                Dim p As PropertyDescriptor
                For Each p In MyBase.GetProperties(attributes)

                    Dim makenonbrowsable As Boolean = False
                    Try
                        Select Case p.Name
                            Case "FilePath"
                                p = TypeDescriptor.CreateProperty(p.ComponentType, p.Name, p.PropertyType, New Attribute() {New ReadOnlyAttribute(Not _instance.CanChangeFile)})
                                If _instance.CanChangeFile Then
                                    p = TypeDescriptor.CreateProperty(p.ComponentType, p.Name, p.PropertyType, New Attribute() {New EditorAttribute(GetType(System.Windows.Forms.Design.FileNameEditor), GetType(UITypeEditor))})
                                Else
                                    p = TypeDescriptor.CreateProperty(p.ComponentType, p.Name, p.PropertyType, New Attribute() {New TypeConverterAttribute(GetType(MPEGInfoFilePathConverter))})
                                End If
                            Case "FileSize"
                                If _instance.FileSize = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "AverageBitrate"
                                If _instance.AverageBitrate = 0 Or _instance.FramesCount = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "Duration"
                                If _instance.Duration = TimeSpan.Zero Or _instance.FramesCount = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "FramesCount"
                                If _instance.FramesCount = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "Bitrate"
                                If _instance.Bitrate = 0 Or _instance.FramesCount = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "Emphasis"
                                If _instance.Emphasis = EmphasisTypes.Unknown Or _instance.FramesCount = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "Frequency"
                                If _instance.Frequency = 0 Or _instance.FramesCount = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "Layer"
                                If _instance.Layer = LayerTypes.Unknown Or _instance.FramesCount = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "Level"
                                If _instance.Level = LevelTypes.Unknown Or _instance.FramesCount = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "Mode"
                                If _instance.Mode = ModeTypes.Unknown Or _instance.FramesCount = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "FlagCopyright"
                                If _instance.FramesCount = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "FlagOriginal"
                                If _instance.FramesCount = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "FlagPadding"
                                If _instance.FramesCount = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "FlagPrivate"
                                If _instance.FramesCount = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "FlagProtection"
                                If _instance.FramesCount = 0 Then
                                    makenonbrowsable = True
                                End If
                            Case "VBRDuration"
                                If _instance.VBRDuration = TimeSpan.Zero Or _instance.FramesCount = 0 Or Not (_instance.VBR.FoundFlag) Then
                                    makenonbrowsable = True
                                End If
                            Case "VBRFramesCount"
                                If _instance.VBRFramesCount = 0 Or _instance.FramesCount = 0 Or Not (_instance.VBR.FoundFlag) Then
                                    makenonbrowsable = True
                                End If
                            Case "VBRQualityRating"
                                If _instance.VBRQualityRating = 0 Or _instance.FramesCount = 0 Or Not (_instance.VBR.FoundFlag) Then
                                    makenonbrowsable = True
                                End If
                            Case "VBRSize"
                                If _instance.VBRSize = 0 Or _instance.FramesCount = 0 Or Not (_instance.VBR.FoundFlag) Then
                                    makenonbrowsable = True
                                End If
                            Case "VBRTableOfContents"
                                If _instance.VBRTableOfContents Is Nothing Or _instance.FramesCount = 0 Or Not (_instance.VBR.FoundFlag) Then
                                    makenonbrowsable = True
                                End If
                        End Select
                    Catch ex As Exception
                        makenonbrowsable = True
                    End Try

                    If makenonbrowsable Then
                        p = TypeDescriptor.CreateProperty(p.ComponentType, p.Name, p.PropertyType, New Attribute() {New BrowsableAttribute(False)})
                    End If

                    props.Add(p)
                Next

                'Add Exception properties
                Try
                    Dim i As Integer
                    Dim exs As ID3MetaDataException() = _instance.UltraID3Parent.GetExceptions
                    For i = 0 To exs.Length - 1
                        Dim ex As ID3MetaDataException = exs(i)
                        props.Add(New UltraID3ExceptionPropertyDescriptor(_instance, i))
                    Next
                Catch ex As Exception

                End Try

                Return props
            End Function

#End Region

        End Class


    End Class

#End Region
#Region "UltraID3ExceptionPropertyDescriptor"

    Friend Class UltraID3ExceptionPropertyDescriptor
        Inherits PropertyDescriptor

        Private par As MPEGInfo
        ''' <summary>
        ''' The parent MPEGInfo that contains the specific exception.
        ''' </summary>
        Public Property Parent() As MPEGInfo
            Get
                Return par
            End Get
            Set(ByVal value As MPEGInfo)
                par = value
            End Set
        End Property

        Private pos As Integer
        ''' <summary>
        ''' The index of the specific exception in the array of the parent MPEGInfo's UltraID3Parent.GetExceptions.
        ''' </summary>
        Public ReadOnly Property ExceptionIndex() As Integer
            Get
                Return pos
            End Get
        End Property

        ''' <summary>
        ''' Initializes a new UltraID3ExceptionPropertyDescriptor.
        ''' </summary>
        ''' <param name="parent">The parent MPEGInfo containing the specific exception for which this property descriptor is created.</param>
        ''' <param name="exceptionindex">The index of the exception in the parent MPEGInfo's UltraID3Lib.</param>
        Sub New(ByRef parent As MPEGInfo, ByVal exceptionindex As Integer)
            MyBase.New("E" & exceptionindex, Nothing)
            Me.Parent = parent
            pos = exceptionindex
        End Sub

        ''' <summary>
        ''' Gets the attributes of the property.
        ''' </summary>
        ''' <remarks>The MPEGInfoExceptionConverter is applied. Also the category attribute is applied with 'Errors: Critical' if the exception level is Error or with 'Errors: Warnings' is the exception level is Warning.</remarks>
        Public Overrides ReadOnly Property Attributes() As System.ComponentModel.AttributeCollection
            Get
                Dim atts As AttributeCollection = MyBase.Attributes

                Dim inst As ID3MetaDataException = GetValue(Parent)
                If Not inst Is Nothing Then
                    Dim cat As String = ""
                    If inst.ExceptionLevel = ID3ExceptionLevels.Error Then
                        cat = "File Info - Errors: Critical"
                    ElseIf inst.ExceptionLevel = ID3ExceptionLevels.Warning Then
                        cat = "File Info - Errors: Warnings"
                    End If
                    atts = AttributeCollection.FromExisting(atts, New Attribute() {New CategoryAttribute(cat), New DisplayNameAttribute(inst.GetType.Name), New ReadOnlyAttribute(True), New TypeConverterAttribute(GetType(MPEGInfoExceptionConverter))})
                End If

                Return atts
            End Get
        End Property

        Public Overrides Function CanResetValue(ByVal component As Object) As Boolean
            Return False
        End Function

        Public Overrides ReadOnly Property ComponentType() As System.Type
            Get
                Return GetType(MPEGInfo)
            End Get
        End Property

        Public Overrides Function GetValue(ByVal component As Object) As Object
            Try
                Return CType(component, MPEGInfo).UltraID3Parent.GetExceptions()(ExceptionIndex)
            Catch ex As Exception
                Return Nothing
            End Try
        End Function

        Public Overrides ReadOnly Property IsReadOnly() As Boolean
            Get
                Return False
            End Get
        End Property

        Public Overrides ReadOnly Property PropertyType() As System.Type
            Get
                Return GetValue(Parent).GetType
            End Get
        End Property

        Public Overrides Sub SetValue(ByVal component As Object, ByVal value As Object)

        End Sub

        Public Overrides Sub ResetValue(ByVal component As Object)

        End Sub

        Public Overrides Function ShouldSerializeValue(ByVal component As Object) As Boolean
            Return False
        End Function

    End Class

#End Region

End Class