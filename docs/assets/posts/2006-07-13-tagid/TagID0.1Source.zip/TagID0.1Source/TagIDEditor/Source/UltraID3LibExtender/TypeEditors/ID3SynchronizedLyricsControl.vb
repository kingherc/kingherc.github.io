#Region "License"

'TagID
'Copyright (C) 2006 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA


'Linking TagID statically or dynamically with other modules is making a combined work based on TagID. Thus, the terms and conditions of the GNU General Public License cover the whole combination.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of UltraIDLib: MP3 ID3 Tag Editor under the UltraIDLib: MP3 ID3 Tag Editor License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.


'In addition, as a special exception, the copyright holders of TagID give you permission to combine TagID program with free software programs or libraries that are released under the GNU LGPL and with code included in the standard release of Wasp Icon Theme under the Design Science License (or modified versions of such code, with unchanged license). You may copy and distribute such a system following the terms of the GNU GPL for TagID and the licenses of the other code concerned, provided that you include the source code of that other code when and as the GNU GPL requires distribution of source code.

'Note that people who make modified versions of TagID are not obligated to grant this special exception for their modified versions; it is their choice whether to do so. The GNU General Public License gives permission to release a modified version without this exception; this exception also makes it possible to release a modified version which carries forward this exception.

#End Region

Imports System.Windows.Forms
Imports System.Text.RegularExpressions

Namespace UltraID3LibExtender.TypeEditors
    Public Class ID3SynchronizedLyricsControl

#Region "Constructor and Properties"

        Public Sub New(ByVal lyrics As SynchronizedLyricCollection)
            InitializeComponent()

            Dim sl As New ID3SynchronizedLyricsFrame()
            sl.SynchronizedLyrics.Clear()
            Dim l As SynchronizedLyric
            For Each l In lyrics
                sl.SynchronizedLyrics.Add(l.Lyric, l.Position)
            Next
            Me.Lyrics = sl.SynchronizedLyrics
            ReloadLyricsList()
        End Sub

        Private _lyrics As SynchronizedLyricCollection
        Public Property Lyrics() As SynchronizedLyricCollection
            Get
                Return _lyrics
            End Get
            Set(ByVal value As SynchronizedLyricCollection)
                _lyrics = value
            End Set
        End Property

        Private _pos As Double
        Public Property Pos() As Double
            Get
                Return _pos
            End Get
            Set(ByVal value As Double)
                _pos = value
                Dim ts As New TimeSpan(0, 0, 0, Math.Truncate(value), (value - Math.Truncate(value)) * 1000)
                lblTimer.Text = UsefulMethods.MinimumDigits(ts.Hours, 2) & ":" & UsefulMethods.MinimumDigits(ts.Minutes, 2) & ":" & UsefulMethods.MinimumDigits(ts.Seconds, 2) & "," & UsefulMethods.MinimumDigits(ts.Milliseconds, 3)
                If chkFollowFile.Checked Then
                    Dim i As Integer = LyricsList.SelectedIndex, c As Integer = LyricsList.Items.Count
                    Do
                        i += 1
                        If i = c Then
                            Exit Do
                        End If
                    Loop Until TimeSpan.FromMilliseconds(Lyrics.Item(i).Position).CompareTo(ts) > 0
                    LyricsList.SelectedIndex = i - 1
                End If
            End Set
        End Property

        Public ReadOnly Property PosMilliseconds() As Integer
            Get
                Dim ts As New TimeSpan(0, 0, 0, Math.Truncate(Pos), (Pos - Math.Truncate(Pos)) * 1000)
                Return ts.TotalMilliseconds
            End Get
        End Property

        Private Sub ID3SynchronizedLyricsControl_HandleDestroyed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.HandleDestroyed
            Try
                wmp.Stop()
                wmp.Open("")
            Catch ex As Exception

            End Try
        End Sub

#End Region

#Region "Import .srt"

        Private Sub mnImportSrt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnImportSrt.Click
            OpenFile.Filter = "SubRip subtitles file .srt|*.srt"
            If OpenFile.ShowDialog() = Windows.Forms.DialogResult.OK Then
                Dim sr As New StreamReader(OpenFile.FileName)
                Dim sl As New ID3SynchronizedLyricsFrame()

                Dim i As Integer = 1, previ As Integer, line As String = Nothing
                Do
                    previ = i
                    Do
                        line = sr.ReadLine
                    Loop Until CStr(line) = CStr(i) Or line = Nothing
                    If Not line = Nothing Then
                        Dim timestamp As String = sr.ReadLine
                        Dim lyric As String = Nothing
                        Do
                            line = sr.ReadLine
                            If Not line = Nothing Then 'Last empty line will not be added.
                                lyric &= line & vbCrLf
                            End If
                        Loop Until line = Nothing
                        If Not lyric = Nothing Then
                            lyric = lyric.Substring(0, lyric.LastIndexOf(vbCrLf)) 'Cut the last vbcrlf
                        End If

                        'Processing lyric
                        Dim msstart As Integer = 0, msend As Integer = 0
                        Dim r As New Regex("(\d\d):(\d\d):(\d\d),(\d\d\d) --> (\d\d):(\d\d):(\d\d),(\d\d\d)")
                        Dim m As Match = r.Match(timestamp)
                        If Not m Is Match.Empty Then
                            Dim gi As Integer
                            For gi = 1 To m.Groups.Count - 1
                                Dim timems As Integer = 0
                                Dim posi As Integer = gi Mod 4
                                If posi = 0 Then
                                    timems += CInt(m.Groups(gi).Value)
                                Else
                                    timems += CInt(m.Groups(gi).Value) * (60 ^ Math.Max(3 - posi, 0)) * 1000
                                End If
                                If gi <= 4 Then
                                    msstart += timems
                                Else
                                    msend += timems
                                End If
                            Next
                        End If

                        If Not i = 1 Then
                            'If previous lyric is empty and is at the same position as the current lyrics, then remove it before adding the current lyric.
                            Dim prevl As SynchronizedLyric = sl.SynchronizedLyrics.Item(sl.SynchronizedLyrics.Count - 1)
                            If prevl.Position.Value = msstart And prevl.Lyric.Trim = "" Then
                                sl.SynchronizedLyrics.RemoveAt(sl.SynchronizedLyrics.Count - 1)
                            End If
                        End If

                        sl.SynchronizedLyrics.Add(lyric, msstart)
                        sl.SynchronizedLyrics.Add(vbCrLf, msend)

                        i += 1
                    End If
                Loop Until previ = i

                sr.Close()
                For i = 0 To sl.SynchronizedLyrics.Count - 1
                    Me.Lyrics.Add(sl.SynchronizedLyrics.Item(i).Lyric, sl.SynchronizedLyrics.Item(i).Position)
                Next
                Me.Lyrics.Sort()
                ReloadLyricsList()
            End If
            OpenFile.Filter = ""
        End Sub

#End Region

#Region "Export .srt"

        Private Sub mnExport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnExport.Click
            If Lyrics.Count > 0 Then
                SaveFile.Filter = "SubRip subtitles file .srt|*.srt"
                If SaveFile.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    Dim sr As New StreamWriter(SaveFile.FileName, False)

                    Dim i As Integer = 0, lyriccount = 1
                    Do
                        sr.WriteLine(lyriccount)
                        Dim timestart As New TimeSpan(0, 0, 0, 0, Lyrics.Item(i).Position), timeend As TimeSpan, lyric As String = Lyrics.Item(i).Lyric
                        sr.Write(UsefulMethods.MinimumDigits(timestart.Hours, 2) & ":" & UsefulMethods.MinimumDigits(timestart.Minutes, 2) & ":" & UsefulMethods.MinimumDigits(timestart.Seconds, 2) & "," & UsefulMethods.MinimumDigits(timestart.Milliseconds, 3) & " --> ")
                        'Search for end time.
                        i += 1
                        If Not i >= Lyrics.Count Then
                            timeend = New TimeSpan(0, 0, 0, 0, Lyrics.Item(i).Position)
                            If Lyrics.Item(i).Lyric.Trim = Nothing Then
                                i += 1
                            End If
                        Else
                            timeend = timestart.Add(New TimeSpan(0, 1, 0))
                        End If
                        sr.WriteLine(UsefulMethods.MinimumDigits(timeend.Hours, 2) & ":" & UsefulMethods.MinimumDigits(timeend.Minutes, 2) & ":" & UsefulMethods.MinimumDigits(timeend.Seconds, 2) & "," & UsefulMethods.MinimumDigits(timeend.Milliseconds, 3))
                        sr.WriteLine(lyric)
                        sr.WriteLine()
                        lyriccount += 1
                    Loop Until i >= Lyrics.Count

                    sr.Close()
                End If
                SaveFile.Filter = ""
            Else
                MessageBox.Show("There are no lyrics stored to save.", "No lyrics stored", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End Sub

#End Region

#Region "Miscellanious"

        Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()
        End Sub

        Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
            Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
            Me.Close()
        End Sub

        Private Sub btnOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpen.Click
            If OpenFile.ShowDialog = Windows.Forms.DialogResult.OK Then
                wmp.Open(OpenFile.FileName)
                lblFile.Text = Path.GetFileName(OpenFile.FileName)
            End If
        End Sub

        Private Sub ReloadLyricsList()
            LyricsList.Items.Clear()
            Dim l As SynchronizedLyric
            For Each l In Lyrics
                Dim ts As New TimeSpan(0, 0, 0, 0, l.Position)
                LyricsList.Items.Add(UsefulMethods.MinimumDigits(ts.Hours, 2) & ":" & UsefulMethods.MinimumDigits(ts.Minutes, 2) & ":" & UsefulMethods.MinimumDigits(ts.Seconds, 2) & "," & UsefulMethods.MinimumDigits(ts.Milliseconds, 3) & " " & l.Lyric)
            Next
        End Sub

        Private Function TimeSpanToString(ByVal ts As TimeSpan) As String
            Return UsefulMethods.MinimumDigits(ts.Hours, 2) & ":" & UsefulMethods.MinimumDigits(ts.Minutes, 2) & ":" & UsefulMethods.MinimumDigits(ts.Seconds, 2) & "," & UsefulMethods.MinimumDigits(ts.Milliseconds, 3)
        End Function

        Private Function StringToTimeSpan(ByVal s As String) As TimeSpan
            Dim ts As New TimeSpan
            ts = ts.Add(TimeSpan.FromHours(s.Substring(0, s.IndexOf(":"))))
            s = s.Substring(s.IndexOf(":") + 1)
            ts = ts.Add(TimeSpan.FromMinutes(s.Substring(0, s.IndexOf(":"))))
            s = s.Substring(s.IndexOf(":") + 1)
            ts = ts.Add(TimeSpan.FromSeconds(s.Substring(0, s.IndexOf(","))))
            s = s.Substring(s.IndexOf(",") + 1)
            ts = ts.Add(TimeSpan.FromMilliseconds(CInt(s)))
            Return ts
        End Function

        Private Sub SelectLyricByPosition(ByVal ts As TimeSpan)
            Dim str As String = TimeSpanToString(ts)
            Dim i As Integer
            For i = 0 To LyricsList.Items.Count - 1
                If CStr(LyricsList.Items(i)).Substring(0, CStr(LyricsList.Items(i)).IndexOf(" ")) = str Then
                    LyricsList.SelectedItem = LyricsList.Items(i)
                End If
            Next
        End Sub

#End Region

#Region "LyricsList, txtTime, txtLyric, tmr, wmp events"

        Private Sub tmr_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmr.Tick
            If wmp.PlayState = MediaPlayer.MPPlayStateConstants.mpPlaying Then
                Pos = wmp.CurrentPosition
            End If
        End Sub

        Private Sub wmp_PlayStateChange(ByVal sender As Object, ByVal e As AxMediaPlayer._MediaPlayerEvents_PlayStateChangeEvent) Handles wmp.PlayStateChange
            If e.newState = MediaPlayer.MPPlayStateConstants.mpPlaying Then
                If chkFollowFile.Checked Then
                    LyricsList.SelectedIndex = 0
                End If
                tmr.Enabled = True
            Else
                tmr.Enabled = False
            End If
        End Sub

        Private changed As Boolean = True

        Private Sub LyricsList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LyricsList.SelectedIndexChanged
            If Not LyricsList.SelectedIndex = -1 Then
                changed = False
                Dim l As SynchronizedLyric = Lyrics.Item(LyricsList.SelectedIndex)
                txtLyric.Text = l.Lyric
                Dim ts As New TimeSpan(0, 0, 0, 0, l.Position)
                txtTime.Text = TimeSpanToString(ts)
                changed = True
            End If
        End Sub

        Private Sub LyricsList_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles LyricsList.KeyDown
            If e.KeyCode = Keys.Delete Then
                mnDeleteLyric_Click(Me, System.EventArgs.Empty)
            ElseIf e.KeyCode = Keys.Insert Then
                mnNewLyric_Click(Me, System.EventArgs.Empty)
            End If
        End Sub

        Private Sub txtTime_KeyDown(ByVal sender As System.Object, ByVal e As KeyEventArgs) Handles txtTime.KeyDown
            If e.KeyData = Keys.Enter Then
                txtTime_Changed()
            End If
        End Sub
        Private Sub txtTime_LostFocus(ByVal sender As System.Object, ByVal e As EventArgs) Handles txtTime.LostFocus
            txtTime_Changed()
        End Sub
        Private Sub txtTime_Changed()
            If changed And Not LyricsList.SelectedIndex = -1 Then
                Dim l As SynchronizedLyric = Lyrics.Item(LyricsList.SelectedIndex)
                Dim ts As TimeSpan = StringToTimeSpan(txtTime.Text)
                l.Position = ts.TotalMilliseconds
                Lyrics.RemoveAt(LyricsList.SelectedIndex)
                Lyrics.Add(l.Lyric, l.Position)
                Lyrics.Sort()
                ReloadLyricsList()
                SelectLyricByPosition(ts)
            End If
        End Sub

        Private Sub txtLyric_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtLyric.TextChanged
            If changed And Not LyricsList.SelectedIndex = -1 Then
                Dim l As SynchronizedLyric = Lyrics.Item(LyricsList.SelectedIndex)
                l.Lyric = txtLyric.Text
                Lyrics.RemoveAt(LyricsList.SelectedIndex)
                Lyrics.Add(l.Lyric, l.Position)
                Lyrics.Sort()
                Dim ts As TimeSpan = TimeSpan.FromMilliseconds(l.Position)
                Dim i As Integer = LyricsList.SelectedIndex
                LyricsList.Items(i) = TimeSpanToString(ts) & " " & l.Lyric
                LyricsList.SelectedIndex = i
            End If
        End Sub

#End Region

#Region "Context menus"

        Private Sub mnNewLyric_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnNewLyric.Click
            If Not PosMilliseconds = 0 Then
                Lyrics.Add(vbCrLf, PosMilliseconds + 1)
                Lyrics.Sort()
                ReloadLyricsList()
                Dim ts As TimeSpan = TimeSpan.FromMilliseconds(PosMilliseconds + 1)
                SelectLyricByPosition(ts)
            Else
                Lyrics.Add(vbCrLf, 1)
                ReloadLyricsList()
                SelectLyricByPosition(New TimeSpan(0, 0, 0, 0, 1))
            End If
        End Sub

        Private Sub mnDeleteLyric_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDeleteLyric.Click
            If Not LyricsList.SelectedIndex = -1 Then
                Lyrics.RemoveAt(LyricsList.SelectedIndex)
                Dim i As Integer = LyricsList.SelectedIndex
                LyricsList.Items.RemoveAt(i)
                If Not i = 0 Then
                    LyricsList.SelectedIndex = i - 1
                ElseIf LyricsList.Items.Count > 0 Then
                    LyricsList.SelectedIndex = 0
                End If
            End If
        End Sub

#End Region

#Region "Help button"

        Private Sub btnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelp.Click
            MessageBox.Show("This dialog helps you edit synchronized lyrics whose measure unit is milliseconds. Its main part is the lyrics list, and the two text boxes under that: the time text box and the lyric text box." & vbCrLf & "To edit a lyric, select it and change the time and lyric text boxes. You can also right-click the lyric list to delete the selected lyric (or click the delete key), or to insert a new lyric (or click the insert key) at the current media player's position, or to import/export a .srt file." & vbCrLf & "Apart from the lyrics-editing features, the dialog also has a windows media player 6 to help you adjust your lyrics' positions. You can choose a file by clicking the Play File button. Then you can click the media player's play button. When playing, the current position and the current file of the media player are shown appropriately in the upper-left corner of the dialog." & vbCrLf & "In addition, you can check the Follow file checkbox in order to 'follow' the current position of the media player when playing a file." & vbCrLf & vbCrLf & "* This dialog can handle only a small number of lyrics (eg. of a song and not of a movie). If you wish to edit a large number of lyrics, use a .srt editor and then import the lyrics.", "Synchronized Lyrics Edit control Help", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Sub

#End Region

#Region "FollowFile"

        Private Sub chkFollowFile_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFollowFile.CheckedChanged
            If chkFollowFile.Checked Then
                LyricsList.SelectedIndex = 0
                LyricsList.Enabled = False
                txtTime.ReadOnly = True
                txtLyric.ReadOnly = True
            Else
                LyricsList.Enabled = True
                txtTime.ReadOnly = False
                txtLyric.ReadOnly = False
            End If
        End Sub

#End Region

    End Class

End Namespace
