﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace D2WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the numbers
                int number1 = int.Parse(txtNumber1.Text);
                int number2 = int.Parse(txtNumber2.Text);

                // Do the action
                int result = 0;
                switch (cmbAction.Text)
                {
                    case "Add":
                        result = number1 + number2;
                        break;
                    case "Subtract":
                        result = number1 - number2;
                        break;
                    case "Divide":
                        result = number1 / number2;
                        break;
                    case "Multiply":
                        result = number1 * number2;
                        break;
                    default:
                        MessageBox.Show("Select an action");
                        return;
                }

                // Show result
                MessageBox.Show("The result is: " + result.ToString());
            }
            catch (DivideByZeroException ex)
            {
                MessageBox.Show("Dividing by zero is invalid");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected error: \n" + ex.Message);
            }
        }
    }
}
