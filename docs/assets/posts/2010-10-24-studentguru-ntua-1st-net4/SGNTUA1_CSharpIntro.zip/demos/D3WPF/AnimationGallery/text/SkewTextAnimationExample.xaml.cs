using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Data;


namespace Microsoft.Samples.Animation.AnimationGallery
{


    public partial class SkewTextAnimationExample : Page
    {
    
        
        
    }


}
