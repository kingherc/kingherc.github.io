﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace D1HelloWorld
{

    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!");

            // ----- Τύποι τιμής και αναφοράς -----

            // Value types
            byte aByte = 1;
            short smallNumber = 50;
            int integer = 34;
            long bigInteger = 8000;
            double withPrecision = 3.14;
            char aCharacter = 'B';
            string manyCharacters = "A string";
            bool trueOrFalse = true;

            // Reference types
            Random rnd = new Random();
            rnd = null;

            // ----- Απαριθμήσεις, πίνακες, δομές -----

            Color variable = Color.Red;

            int[] singleDim = new int[20];
            int[,] twoDim = new int[,] {{1,2,3},{4,5,6}};
            Color[][] jagged;

            MyStruct sct = new MyStruct();
            sct.i = 2; sct.s = "Message";

            // ----- Κληρονομικότητα -----

            Vehicle v = new Vehicle();
            Car car = new Car();
            Console.WriteLine(v.GetMaxSpeed().ToString());
            Console.WriteLine(car.GetMaxSpeed().ToString());

            // ----- Χειρισμός εξαιρέσεων -----

            try
            {
                // ... run code
                int num1 = 6;
                int num2 = 0;
                int newNumber = num1 / num2;
            }
            catch (Exception e)
            {
                // ... handle exception
                Console.WriteLine(e.Message);
            }
            finally
            {
                // ... end gracefully, e.g. close a file;
            }

            // ----- Συμβάντα (events) -----

            // Main() code
            Person p = new Person();
            p.Changed += new Person.ChangedHandler(p_Changed);
            p.Change();

            // ----- Generics -----

            List<Person> list = new List<Person>();
            Person a = new Person();
            Person b = new Person();
            list.Add(a); list.Add(b);
            Print(list);

            // ----- Anonymous -----

            p.Changed += delegate() { Console.WriteLine("Changed!!"); };
            p.Changed += () => { Console.WriteLine("Changed!!!"); };
            p.Change();

            int[] source = new[] { 3, 8, 4, 6, 1, 7, 9, 2, 4, 8 };
            foreach (int i in source.Where(x => x > 5)) Console.WriteLine(i);

            // ----- ...και πολλά ακόμα -----

            var an = new { Amount = 108, Message = "Hello" };
            Console.WriteLine(String.Format("Price: {0}, Message: {1}", an.Amount, an.Message));

            dynamic o = new Person();
            // o.someMethod("arg1", 78, null);
            // no compiler error, but runtime error.

            Console.WriteLine("Αλήθεια".MakeQuestion());

            System.Console.ReadLine();
        }

        static void p_Changed()
        {
            Console.WriteLine("Changed!");
        }

        static void Print<T>(List<T> myList)
        {
            foreach (T myObject in myList)
                Console.WriteLine(myObject.ToString());
        }

    }

    enum Color
    {
        Red, Green, Blue
    }

    struct MyStruct
    {
        public int i;
        public string s;
    }

    // ----- Κλάσεις και Interfaces -----

    //public interface IPersonAge
    //{
    //    int YearOfBirth { get; set; }
    //    int CalculateAge(int baseYear);
    //}

    //public class Person : IPersonAge
    //{
    //    private int yob;

    //    public int YearOfBirth
    //    {
    //        get { return yob; }
    //        set { yob = value; }
    //    }

    //    public int CalculateAge(int baseYear)
    //    {
    //        return baseYear - YearOfBirth;
    //    }
    //}

    // ----- Κληρονομικότητα -----

    public class Vehicle
    {
        public virtual int GetMaxSpeed() { return 140; }
    }

    public class Car : Vehicle
    {
        public override int GetMaxSpeed() { return 200; }
    }

    // ----- Συμβάντα (events) -----

    public class Person
    {
        // Event
        public delegate void ChangedHandler();
        public event ChangedHandler Changed;
        protected virtual void OnChanged()
        {
            if (Changed != null) Changed();
        }

        // Method
        public void Change()
        {
            // ...do stuff
            OnChanged();
        }
    }

    public static class MyExtensions
    {
        public static String MakeQuestion(this String str)
        {
            return str + "?";
        }
    }   

}
