﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SilverlightRIAServices.Web;
using System.ServiceModel.DomainServices.Client;

namespace SilverlightRIAServices
{
    public partial class MainPage : UserControl
    {
        private CustomersDomainContext customersContext = new CustomersDomainContext();

        public MainPage()
        {
            InitializeComponent();
        }

        private void loadCustomers()
        {
            EntityQuery<Customer> query =
                from c in customersContext.GetCustomersQuery()
                where c.ContactName.StartsWith("I")
                orderby c.CustomerID
                select c;

            LoadOperation<Customer> loadOp = customersContext.Load(query);
            dataGrid1.ItemsSource = loadOp.Entities;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            loadCustomers();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Customer newCustomer = new Customer()
            {
                CustomerID = "IRPSA",
                ContactName = "Iraklis Psaroudakis",
                ContactTitle = "Mr.",
                Address = "200, Address St.",
                City = "Athens",
                PostalCode = "12345",
                Region = "Attiki",
                Country = "Greece",
                Phone = "1234567",
                Fax = "12334656",
                CompanyName = "www.StudentGuru.gr"
            };

            try
            {
                customersContext.Customers.Add(newCustomer);
                customersContext.SubmitChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            loadCustomers();
        }
    }
}
