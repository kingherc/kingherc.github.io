﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ClientWindowsForms.NorthwindServiceReference;

namespace ClientWindowsForms
{
    public partial class FormNorthwindService : Form
    {
        public FormNorthwindService()
        {
            InitializeComponent();
        }

        private void loadCustomers()
        {
            NorthwindServiceClient client = new NorthwindServiceClient();

            Customer[] customers = client.GetCustomers();
            dataGridView1.DataSource = customers;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loadCustomers();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            NorthwindServiceClient client = new NorthwindServiceClient();

            Customer newCustomer = new Customer()
            {
                CustomerID = "IRPSA",
                ContactName = "Iraklis Psaroudakis",
                ContactTitle = "Mr.",
                Address = "200, Address St.",
                City = "Athens",
                PostalCode = "12345",
                Region = "Attiki",
                Country = "Greece",
                Phone = "1234567",
                Fax = "12334656",
                CompanyName = "www.StudentGuru.gr"
            };


            bool result = client.AddCustomer(newCustomer);
            if (result)
            {
                MessageBox.Show("Success!");
                loadCustomers();
            }
            else
            {
                MessageBox.Show("Error while adding new customer");
            }
        }

    }
}
