﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ClientWpf.MathServiceReference;
using System.ServiceModel;

namespace ClientWpf
{
    /// <summary>
    /// Interaction logic for PageMathService.xaml
    /// </summary>
    public partial class PageMathService : Page
    {
        public PageMathService()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, RoutedEventArgs e)
        {
            int number1 = int.Parse(txtNumber1.Text);
            int number2 = int.Parse(txtNumber2.Text);
            Double? result = null;

            MathServiceClient proxy = new MathServiceClient();

            if (radioButtonAdd.IsChecked.Value)
            {
                result = proxy.Add(number1, number2);
            }
            else if (radioButtonSubtract.IsChecked.Value)
            {
                result = proxy.Subtract(number1, number2);
            }
            else if (radioButtonMultiply.IsChecked.Value)
            {
                result = proxy.Multiply(number1, number2);
            }
            else if (radioButtonDivide.IsChecked.Value)
            {
                result = proxy.Divide(number1, number2);
            }

            if (result.HasValue)
            {
                MessageBox.Show(String.Format("The result is: {0}", result.ToString()));
            }
        }
    }
}
