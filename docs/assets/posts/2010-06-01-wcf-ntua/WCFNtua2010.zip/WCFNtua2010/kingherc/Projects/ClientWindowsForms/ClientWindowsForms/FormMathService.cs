﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ClientWindowsForms.MathServiceReference;
using System.ServiceModel;

namespace ClientWindowsForms
{
    public partial class FormMathService : Form
    {
        public FormMathService()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int number1 = int.Parse(txtNumber1.Text);
            int number2 = int.Parse(txtNumber2.Text);
            Double? result = null;

            MathServiceClient proxy = new MathServiceClient();

            if (radioButtonAdd.Checked)
            {
                result = proxy.Add(number1, number2);
            }
            else if (radioButtonSubtract.Checked)
            {
                result = proxy.Subtract(number1, number2);
            }
            else if (radioButtonMultiply.Checked)
            {
                result = proxy.Multiply(number1, number2);
            }
            else if (radioButtonDivide.Checked)
            {
                result = proxy.Divide(number1, number2);
            }

            if (result.HasValue)
            {
                MessageBox.Show(String.Format("The result is: {0}", result.ToString()));
            }
        }

        private void FormMathService_Load(object sender, EventArgs e)
        {

        }
    }
}
