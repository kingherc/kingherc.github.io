﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SimpleService
{
    public class NorthwindService : INorthwindService
    {
        public Customer[] GetCustomers()
        {
            using (NorthwindDataContext db = new NorthwindDataContext())
            {
                var query = from c in db.Customers
                            select c;

                return query.ToArray<Customer>();
            }
        }

        public Customer GetCustomerById(string id)
        {
            using (NorthwindDataContext db = new NorthwindDataContext())
            {
                var query = from c in db.Customers
                            where c.CustomerID == id
                            select c;

                return query.SingleOrDefault<Customer>();
            }
        }

        public bool AddCustomer(Customer c)
        {
            using (NorthwindDataContext db = new NorthwindDataContext())
            {

                try
                {
                    db.Customers.InsertOnSubmit(c);
                    db.SubmitChanges();
                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }
            }

        }
    }
}
