﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using ClientSilverlight.NorthwindServiceReference;

namespace ClientSilverlight
{
    public partial class PageNorthwindService : Page
    {
        public PageNorthwindService()
        {
            InitializeComponent();
        }

        private void buttonGetCustomers_Click(object sender, RoutedEventArgs e)
        {
            loadCustomers();
        }

        private void loadCustomers()
        {
            NorthwindServiceClient client = new NorthwindServiceClient();

            client.GetCustomersCompleted += new EventHandler<GetCustomersCompletedEventArgs>(client_GetCustomersCompleted);
            client.GetCustomersAsync();
        }

        void client_GetCustomersCompleted(object sender, GetCustomersCompletedEventArgs e)
        {
            Customer[] customers = e.Result.ToArray();
            dg.ItemsSource = customers;
        }

        private void buttonAddSampleUser_Click(object sender, RoutedEventArgs e)
        {
            NorthwindServiceClient client = new NorthwindServiceClient();

            Customer newCustomer = new Customer()
            {
                CustomerID = "IRPSA",
                ContactName = "Iraklis Psaroudakis",
                ContactTitle = "Mr.",
                Address = "200, Address St.",
                City = "Athens",
                PostalCode = "12345",
                Region = "Attiki",
                Country = "Greece",
                Phone = "1234567",
                Fax = "12334656",
                CompanyName = "www.StudentGuru.gr"
            };

            client.AddCustomerCompleted += new EventHandler<AddCustomerCompletedEventArgs>(client_AddCustomerCompleted);
            client.AddCustomerAsync(newCustomer);
        }

        void client_AddCustomerCompleted(object sender, AddCustomerCompletedEventArgs e)
        {
            if (e.Result)
            {
                MessageBox.Show("Success!");
                loadCustomers();
            }
            else
            {
                MessageBox.Show("Error while adding new customer");
            }
        }

    }
}
