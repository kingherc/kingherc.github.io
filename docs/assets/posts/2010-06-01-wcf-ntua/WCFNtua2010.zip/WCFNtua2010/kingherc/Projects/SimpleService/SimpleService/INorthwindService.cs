﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SimpleService
{
    [ServiceContract]
    public interface INorthwindService
    {
        [OperationContract]
        Customer[] GetCustomers();

        [OperationContract]
        Customer GetCustomerById(string id);

        [OperationContract]
        bool AddCustomer(Customer c);

    }
}
