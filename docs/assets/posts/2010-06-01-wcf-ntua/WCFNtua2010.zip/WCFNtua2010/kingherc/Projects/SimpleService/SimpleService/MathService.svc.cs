﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SimpleService
{
    public class MathService : IMathService
    {
        public int Add(int a, int b)
        {
            return (a + b);
        }

        public int Subtract(int a, int b)
        {
            return (a - b);
        }

        public int Multiply(int a, int b)
        {
            return (a * b);
        }

        public double Divide(int a, int b)
        {
            if (b <= 0)
            {
                throw new FaultException(new FaultReason("Cannot divide by zero"));
            }
            else
            {
                return ((double)a / b);
            }
        }
    }
}
