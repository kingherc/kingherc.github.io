﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using ClientSilverlight.MathServiceReference;
using System.ServiceModel;

namespace ClientSilverlight
{
    public partial class PageMathService : Page
    {
        public PageMathService()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, RoutedEventArgs e)
        {
            int number1 = int.Parse(txtNumber1.Text);
            int number2 = int.Parse(txtNumber2.Text);

            MathServiceClient proxy = new MathServiceClient();

            if (radioButtonAdd.IsChecked.Value)
            {
                proxy.AddCompleted += new EventHandler<AddCompletedEventArgs>(proxy_AddCompleted);
                proxy.AddAsync(number1, number2);
            }
            else if (radioButtonSubtract.IsChecked.Value)
            {
                proxy.SubtractCompleted += new EventHandler<SubtractCompletedEventArgs>(proxy_SubtractCompleted);
                proxy.SubtractAsync(number1, number2);
            }
            else if (radioButtonMultiply.IsChecked.Value)
            {
                proxy.MultiplyCompleted += new EventHandler<MultiplyCompletedEventArgs>(proxy_MultiplyCompleted);
                proxy.MultiplyAsync(number1, number2);
            }
            else if (radioButtonDivide.IsChecked.Value)
            {
                proxy.DivideCompleted += new EventHandler<DivideCompletedEventArgs>(proxy_DivideCompleted);
                proxy.DivideAsync(number1, number2);
            }
        }

        private void showResult(String result)
        {
            MessageBox.Show(String.Format("The result is: {0}", result));
        }

        void proxy_DivideCompleted(object sender, DivideCompletedEventArgs e)
        {
            showResult(e.Result.ToString());
        }

        void proxy_MultiplyCompleted(object sender, MultiplyCompletedEventArgs e)
        {
            showResult(e.Result.ToString());
        }

        void proxy_SubtractCompleted(object sender, SubtractCompletedEventArgs e)
        {
            showResult(e.Result.ToString());
        }

        void proxy_AddCompleted(object sender, AddCompletedEventArgs e)
        {
            showResult(e.Result.ToString());
        }

    }
}
