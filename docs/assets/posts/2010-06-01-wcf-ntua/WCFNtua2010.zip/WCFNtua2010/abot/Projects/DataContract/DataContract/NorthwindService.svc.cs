﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace DataContract
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "NorthwindService" in code, svc and config file together.
    public class NorthwindService : INorthwindService
    {
      
        public Customer[] GetAllCustomers()
        {
            using (NorthWindDataContext db = new NorthWindDataContext())
            {
                var query = from c in db.Customers
                            select c;
                return query.ToArray<Customer>();
            }
        }

        public Customer GetCustomerById(string id)
        {
            using (NorthWindDataContext db = new NorthWindDataContext())
            {
                var query = from c in db.Customers
                            where c.CustomerID==id
                            select c;
                return query.SingleOrDefault<Customer>();
            }
        }

        public bool AddCustomer(Customer c)
        {
            using (NorthWindDataContext db = new NorthWindDataContext())
            {

                try
                {
                    db.Customers.InsertOnSubmit(c);
                    db.SubmitChanges();
                    return true;
                }
                catch (Exception ex)
                {
                    //throw new FaultException( new FaultReason(ex.Message));
                    return false;
                }
            }
        }
    }
}
