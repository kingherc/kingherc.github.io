﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    class MathService
    {
        public int Add(int a, int b)
        {
            return (a + b);
        }

        public int Subtract(int a, int b)
        {
            return (a - b);
        }

        public int Multiply(int a, int b)
        {
            return (a * b);
        }

        public double Divide(int a, int b)
        {
            if (b <= 0)
            {
                throw new Exception("Cannot divide by zero");
            }
            else
            {
                return ((double)a / b);
            }
        }
    }
}
