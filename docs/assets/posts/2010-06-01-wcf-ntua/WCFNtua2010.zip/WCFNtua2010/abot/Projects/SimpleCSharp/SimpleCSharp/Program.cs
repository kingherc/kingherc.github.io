﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Welcome to our app");
            Console.WriteLine("Please press h and press enter for available options");
            String c = String.Empty;
            while (c != "q")
            {
                Console.Write("Please provide input command (h for help):");
                c = Console.ReadLine();
                switch (c)
                {
                    case "h": printHelpMenu(); break;
                    case "math": mathMenu(); break;
                    case "q": break;
                    default: processUnkownCommand(c); break;
                }

            }
        }

        private static void mathMenu()
        {
            Console.WriteLine("Welcome to the math menu");
            Console.WriteLine("Type the math calculation in the format a+b or a-b or a*b or a/b and press enter to see the result.Type exit to quit this menu");
            MathService m = new MathService();
            String input = Console.ReadLine();
            int a, b;
            while (input != "exit")
            {
                if (input.Contains("+"))
                {
                    String[] operands = input.Split('+');
                    if (operands.Length == 2)
                    {
                        if (int.TryParse(operands[0], out a) && int.TryParse(operands[1], out b))
                            Console.WriteLine("{0}={1}", input, m.Add(a, b));
                        else
                            Console.WriteLine("Arguments must be integers!");
                    }
                    else
                        Console.WriteLine("Too many arguments!");
                }
                else if (input.Contains("-"))
                {
                    String[] operands = input.Split('-');
                    if (operands.Length == 2)
                    {
                        if (int.TryParse(operands[0], out a) && int.TryParse(operands[1], out b))
                            Console.WriteLine("{0}={1}", input, m.Subtract(a, b));
                        else
                            Console.WriteLine("Arguments must be integers!");
                    }
                    else
                        Console.WriteLine("Too many arguments!");
                }
                else if (input.Contains("*"))
                {
                    String[] operands = input.Split('*');
                    if (operands.Length == 2)
                    {
                        if (int.TryParse(operands[0], out a) && int.TryParse(operands[1], out b))
                            Console.WriteLine("{0}={1}", input, m.Multiply(a, b));
                        else
                            Console.WriteLine("Arguments must be integers!");
                    }
                    else
                        Console.WriteLine("Too many arguments!");
                }
                else if (input.Contains("/"))
                {
                    String[] operands = input.Split('/');
                    if (operands.Length == 2)
                    {
                        if (int.TryParse(operands[0], out a) && int.TryParse(operands[1], out b))
                            try
                            {
                                Console.WriteLine("{0}={1}", input, m.Divide(a, b));
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine("Exception occured: {0}", e.Message);
                            }
                        else
                            Console.WriteLine("Arguments must be integers!");
                    }
                    else
                        Console.WriteLine("Too many arguments!");
                }
                else if (!input.Equals("exit"))
                {
                    Console.WriteLine("Unknown command");
                }
                input = Console.ReadLine();
            }
            Console.WriteLine("Exiting math menu");
        }

        private static void processUnkownCommand(string c)
        {
            Console.WriteLine("{0} does not exist!Please review help by typing h.", c);
        }

        private static void printHelpMenu()
        {
            Console.WriteLine("-------------[ Help Menu ]-------------");
            Console.WriteLine("|h   :Displays this menu              |");
            Console.WriteLine("|q   :Exits this fantastic program    |");
            Console.WriteLine("|math:Initiates the math functionality|");
            Console.WriteLine("---------------------------------------");
        }
    }
}
