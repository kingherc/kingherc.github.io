﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HostApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(MathService));
            host.Open();

            Console.ReadKey();
            host.Close(); 
        }
    }
}
