﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace DataContract
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "DataContractService" in code, svc and config file together.
    public class DataContractService : IDataContractService
    {
        public string Greet(Person input)
        {
            return String.Format("Hello {0}. You are {1} years old.", input.Name, DateTime.Now.Year - input.BirthYear);
        }
    }
}
