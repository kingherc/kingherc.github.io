﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Consumer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //NorthwindService.NorthwindServiceClient client = new NorthwindService.NorthwindServiceClient();
            //this.customerBindingSource.DataSource = client.GetAllCustomers();
            LocalService.MathServiceClient client2 = new LocalService.MathServiceClient();
            MessageBox.Show(client2.Add(1, 2).ToString());
        }
    }
}
