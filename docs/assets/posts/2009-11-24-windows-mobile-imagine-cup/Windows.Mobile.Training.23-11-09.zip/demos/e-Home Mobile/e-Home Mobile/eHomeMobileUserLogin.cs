﻿using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace e_Home_Mobile
{
    public partial class eHomeMobileUserLogin : Form
    {

        public eHomeMobileUserLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((Password.Text == "password") & (UserName.Text == "user"))
            {
                MessageBox.Show("Έχετε συνδεθεί επιτυχώς");
                this.DialogResult = DialogResult.OK;
            }
            else
                MessageBox.Show("Τα στοιχεία που πληκτρολογήσατε δεν είναι έγκυρα. Παρακαλώ ξαναδοκιμάστε.");
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

    }
}