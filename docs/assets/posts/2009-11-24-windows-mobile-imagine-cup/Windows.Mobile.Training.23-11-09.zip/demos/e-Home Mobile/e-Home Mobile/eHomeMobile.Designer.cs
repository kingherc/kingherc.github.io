﻿namespace e_Home_Mobile
{
    partial class eHomeMobile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(eHomeMobile));
            this.mainMenu = new System.Windows.Forms.MainMenu();
            this.RightMenu = new System.Windows.Forms.MenuItem();
            this.UserLogIn = new System.Windows.Forms.MenuItem();
            this.menuItem11 = new System.Windows.Forms.MenuItem();
            this.LogOut = new System.Windows.Forms.MenuItem();
            this.LeftMenu = new System.Windows.Forms.MenuItem();
            this.Help = new System.Windows.Forms.MenuItem();
            this.eHomeInternetHelp = new System.Windows.Forms.MenuItem();
            this.AbouteHome = new System.Windows.Forms.MenuItem();
            this.menuItem6 = new System.Windows.Forms.MenuItem();
            this.Exit = new System.Windows.Forms.MenuItem();
            this.statusBar1 = new System.Windows.Forms.StatusBar();
            this.button1 = new System.Windows.Forms.Button();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelC = new System.Windows.Forms.Label();
            this.numericUpDownTemperature = new System.Windows.Forms.NumericUpDown();
            this.radioButtonTemperatureOff = new System.Windows.Forms.RadioButton();
            this.radioButtonTemperatureOn = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.trackBarLuminosity = new System.Windows.Forms.TrackBar();
            this.radioButtonLuminosityOff = new System.Windows.Forms.RadioButton();
            this.radioButtonLuminosityOn = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.areasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBoxArea = new System.Windows.Forms.ComboBox();
            this.homeDataSet = new e_Home_Mobile.homeDataSet();
            this.label7 = new System.Windows.Forms.Label();
            this.areasTableAdapter = new e_Home_Mobile.homeDataSetTableAdapters.AreasTableAdapter();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.areasBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.homeDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // mainMenu
            // 
            this.mainMenu.MenuItems.Add(this.RightMenu);
            this.mainMenu.MenuItems.Add(this.LeftMenu);
            // 
            // RightMenu
            // 
            this.RightMenu.MenuItems.Add(this.UserLogIn);
            this.RightMenu.MenuItems.Add(this.menuItem11);
            this.RightMenu.MenuItems.Add(this.LogOut);
            this.RightMenu.Text = "Χρήστης";
            // 
            // UserLogIn
            // 
            this.UserLogIn.Text = "&Σύνδεση Χρήστη";
            this.UserLogIn.Click += new System.EventHandler(this.UserLogIn_Click);
            // 
            // menuItem11
            // 
            this.menuItem11.Text = "-";
            // 
            // LogOut
            // 
            this.LogOut.Enabled = false;
            this.LogOut.Text = "&Αποσύνδεση...";
            this.LogOut.Click += new System.EventHandler(this.LogOut_Click);
            // 
            // LeftMenu
            // 
            this.LeftMenu.MenuItems.Add(this.Help);
            this.LeftMenu.MenuItems.Add(this.menuItem6);
            this.LeftMenu.MenuItems.Add(this.Exit);
            this.LeftMenu.Text = "Μενού";
            // 
            // Help
            // 
            this.Help.MenuItems.Add(this.eHomeInternetHelp);
            this.Help.MenuItems.Add(this.AbouteHome);
            this.Help.Text = "&Βοήθεια";
            // 
            // eHomeInternetHelp
            // 
            this.eHomeInternetHelp.Text = "&Ηλεκτρονική Βοήθεια";
            this.eHomeInternetHelp.Click += new System.EventHandler(this.eHomeInternetHelp_Click);
            // 
            // AbouteHome
            // 
            this.AbouteHome.Text = "&Σχετικά με το e-Home Mobile...";
            this.AbouteHome.Click += new System.EventHandler(this.AbouteHome_Click);
            // 
            // menuItem6
            // 
            this.menuItem6.Text = "-";
            // 
            // Exit
            // 
            this.Exit.Text = "&\'Εξοδος";
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // statusBar1
            // 
            this.statusBar1.Location = new System.Drawing.Point(0, 246);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Size = new System.Drawing.Size(240, 22);
            this.statusBar1.Text = "Δεν έχετε συνδεθεί...";
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(76, 220);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(161, 20);
            this.button1.TabIndex = 1;
            this.button1.Text = "Αποθήκευση Ρυθμίσεων";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Enabled = false;
            this.numericUpDown2.Location = new System.Drawing.Point(4, 23);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(100, 22);
            this.numericUpDown2.TabIndex = 6;
            this.numericUpDown2.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // radioButton5
            // 
            this.radioButton5.Checked = true;
            this.radioButton5.Location = new System.Drawing.Point(110, 30);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(42, 20);
            this.radioButton5.TabIndex = 3;
            this.radioButton5.Text = "Off";
            // 
            // radioButton6
            // 
            this.radioButton6.Location = new System.Drawing.Point(110, 4);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(42, 20);
            this.radioButton6.TabIndex = 2;
            this.radioButton6.TabStop = false;
            this.radioButton6.Text = "On";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(4, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 15);
            this.label3.Text = "Θέρμανση:";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(4, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 20);
            this.label5.Text = "Ένταση:";
            // 
            // trackBar2
            // 
            this.trackBar2.Enabled = false;
            this.trackBar2.Location = new System.Drawing.Point(60, 51);
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(100, 33);
            this.trackBar2.TabIndex = 4;
            // 
            // radioButton7
            // 
            this.radioButton7.Checked = true;
            this.radioButton7.Location = new System.Drawing.Point(110, 30);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(42, 20);
            this.radioButton7.TabIndex = 3;
            this.radioButton7.Text = "Off";
            // 
            // radioButton8
            // 
            this.radioButton8.Location = new System.Drawing.Point(110, 4);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(42, 20);
            this.radioButton8.TabIndex = 2;
            this.radioButton8.TabStop = false;
            this.radioButton8.Text = "On";
            // 
            // comboBox2
            // 
            this.comboBox2.Items.Add("Κεντρικά");
            this.comboBox2.Location = new System.Drawing.Point(4, 23);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(100, 22);
            this.comboBox2.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(4, 4);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 15);
            this.label6.Text = "Φωτισμός:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.labelC);
            this.panel2.Controls.Add(this.numericUpDownTemperature);
            this.panel2.Controls.Add(this.radioButtonTemperatureOff);
            this.panel2.Controls.Add(this.radioButtonTemperatureOn);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(4, 76);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(233, 64);
            // 
            // labelC
            // 
            this.labelC.Location = new System.Drawing.Point(212, 24);
            this.labelC.Name = "labelC";
            this.labelC.Size = new System.Drawing.Size(18, 22);
            this.labelC.Text = "°C";
            // 
            // numericUpDownTemperature
            // 
            this.numericUpDownTemperature.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.numericUpDownTemperature.Enabled = false;
            this.numericUpDownTemperature.Location = new System.Drawing.Point(130, 24);
            this.numericUpDownTemperature.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numericUpDownTemperature.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownTemperature.Name = "numericUpDownTemperature";
            this.numericUpDownTemperature.Size = new System.Drawing.Size(76, 22);
            this.numericUpDownTemperature.TabIndex = 6;
            this.numericUpDownTemperature.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDownTemperature.ValueChanged += new System.EventHandler(this.numericUpDownTemperature_ValueChanged);
            // 
            // radioButtonTemperatureOff
            // 
            this.radioButtonTemperatureOff.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioButtonTemperatureOff.Checked = true;
            this.radioButtonTemperatureOff.Location = new System.Drawing.Point(61, 26);
            this.radioButtonTemperatureOff.Name = "radioButtonTemperatureOff";
            this.radioButtonTemperatureOff.Size = new System.Drawing.Size(42, 20);
            this.radioButtonTemperatureOff.TabIndex = 3;
            this.radioButtonTemperatureOff.Text = "Off";
            // 
            // radioButtonTemperatureOn
            // 
            this.radioButtonTemperatureOn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioButtonTemperatureOn.Location = new System.Drawing.Point(3, 26);
            this.radioButtonTemperatureOn.Name = "radioButtonTemperatureOn";
            this.radioButtonTemperatureOn.Size = new System.Drawing.Size(42, 20);
            this.radioButtonTemperatureOn.TabIndex = 2;
            this.radioButtonTemperatureOn.TabStop = false;
            this.radioButtonTemperatureOn.Text = "On";
            this.radioButtonTemperatureOn.CheckedChanged += new System.EventHandler(this.radioButtonTemperatureOn_CheckedChanged);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.Location = new System.Drawing.Point(3, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 15);
            this.label4.Text = "Θέρμανση:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.trackBarLuminosity);
            this.panel1.Controls.Add(this.radioButtonLuminosityOff);
            this.panel1.Controls.Add(this.radioButtonLuminosityOn);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(3, 146);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(233, 68);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(130, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 20);
            this.label2.Text = "Ένταση:";
            // 
            // trackBarLuminosity
            // 
            this.trackBarLuminosity.Enabled = false;
            this.trackBarLuminosity.Location = new System.Drawing.Point(130, 30);
            this.trackBarLuminosity.Name = "trackBarLuminosity";
            this.trackBarLuminosity.Size = new System.Drawing.Size(100, 33);
            this.trackBarLuminosity.TabIndex = 4;
            this.trackBarLuminosity.ValueChanged += new System.EventHandler(this.trackBarLuminosity_ValueChanged);
            // 
            // radioButtonLuminosityOff
            // 
            this.radioButtonLuminosityOff.Checked = true;
            this.radioButtonLuminosityOff.Location = new System.Drawing.Point(61, 36);
            this.radioButtonLuminosityOff.Name = "radioButtonLuminosityOff";
            this.radioButtonLuminosityOff.Size = new System.Drawing.Size(42, 20);
            this.radioButtonLuminosityOff.TabIndex = 3;
            this.radioButtonLuminosityOff.Text = "Off";
            // 
            // radioButtonLuminosityOn
            // 
            this.radioButtonLuminosityOn.Location = new System.Drawing.Point(5, 36);
            this.radioButtonLuminosityOn.Name = "radioButtonLuminosityOn";
            this.radioButtonLuminosityOn.Size = new System.Drawing.Size(42, 20);
            this.radioButtonLuminosityOn.TabIndex = 2;
            this.radioButtonLuminosityOn.TabStop = false;
            this.radioButtonLuminosityOn.Text = "On";
            this.radioButtonLuminosityOn.CheckedChanged += new System.EventHandler(this.radioButtonLuminosityOn_CheckedChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(5, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 15);
            this.label1.Text = "Φωτισμός:";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.comboBoxArea);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(233, 67);
            // 
            // areasBindingSource
            // 
            this.areasBindingSource.DataMember = "Areas";
            this.areasBindingSource.DataSource = this.homeDataSet;
            // 
            // comboBoxArea
            // 
            this.comboBoxArea.DataSource = this.areasBindingSource;
            this.comboBoxArea.DisplayMember = "name";
            this.comboBoxArea.Location = new System.Drawing.Point(5, 23);
            this.comboBoxArea.Name = "comboBoxArea";
            this.comboBoxArea.Size = new System.Drawing.Size(224, 22);
            this.comboBoxArea.TabIndex = 1;
            this.comboBoxArea.SelectedIndexChanged += new System.EventHandler(this.comboBoxArea_SelectedIndexChanged);
            // 
            // homeDataSet
            // 
            this.homeDataSet.DataSetName = "homeDataSet";
            this.homeDataSet.Prefix = "";
            this.homeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(3, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(226, 20);
            this.label7.Text = "Select a room:";
            // 
            // areasTableAdapter
            // 
            this.areasTableAdapter.ClearBeforeFill = true;
            // 
            // eHomeMobile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.statusBar1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Menu = this.mainMenu;
            this.Name = "eHomeMobile";
            this.Text = "e-Home Mobile";
            this.Load += new System.EventHandler(this.eHomeMobile_Load);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.areasBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.homeDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MenuItem RightMenu;
        private System.Windows.Forms.MenuItem LeftMenu;
        private System.Windows.Forms.MenuItem Exit;
        private System.Windows.Forms.MenuItem Help;
        private System.Windows.Forms.MenuItem UserLogIn;
        private System.Windows.Forms.MenuItem menuItem11;
        private System.Windows.Forms.MenuItem LogOut;
        private System.Windows.Forms.MenuItem menuItem6;
        private System.Windows.Forms.StatusBar statusBar1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MenuItem eHomeInternetHelp;
        private System.Windows.Forms.MenuItem AbouteHome;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelC;
        private System.Windows.Forms.NumericUpDown numericUpDownTemperature;
        private System.Windows.Forms.RadioButton radioButtonTemperatureOff;
        private System.Windows.Forms.RadioButton radioButtonTemperatureOn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TrackBar trackBarLuminosity;
        private System.Windows.Forms.RadioButton radioButtonLuminosityOff;
        private System.Windows.Forms.RadioButton radioButtonLuminosityOn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox comboBoxArea;
        private System.Windows.Forms.Label label7;
        private homeDataSet homeDataSet;
        private e_Home_Mobile.homeDataSetTableAdapters.AreasTableAdapter areasTableAdapter;
        private System.Windows.Forms.BindingSource areasBindingSource;
    }
}

