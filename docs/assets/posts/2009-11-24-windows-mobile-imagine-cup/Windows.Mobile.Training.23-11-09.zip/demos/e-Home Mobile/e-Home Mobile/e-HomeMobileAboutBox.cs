﻿using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace e_Home_Mobile
{
    public partial class e_HomeMobileAboutBox : Form
    {
        public e_HomeMobileAboutBox()
        {
            InitializeComponent();
        }

    }
}