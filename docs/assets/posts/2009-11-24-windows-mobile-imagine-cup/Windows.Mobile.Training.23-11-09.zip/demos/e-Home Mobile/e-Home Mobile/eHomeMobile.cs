﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Linq;

namespace e_Home_Mobile
{
    public partial class eHomeMobile : Form
    {

        #region "Constructor"

        public eHomeMobile()
        {
            InitializeComponent();
        }

        #endregion

        #region "FormLoad, Save"

        private void button1_Click(object sender, EventArgs e)
        {
            this.areasTableAdapter.Update(this.homeDataSet);
            MessageBox.Show("Οι ρυθμίσεις αποθηκεύτηκαν!");
        }

        private void eHomeMobile_Load(object sender, EventArgs e)
        {
            // Fill the DataTable with data from the DataBase.
            this.areasTableAdapter.Fill(this.homeDataSet.Areas);
            LogMeOut();
        }

        #endregion

        #region "Log in and Log out"

        private void UserLogIn_Click(object sender, EventArgs e)
        {
            eHomeMobileUserLogin frm = new eHomeMobileUserLogin();
            {
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    LogMeIn();
                }
            }
        }

        private void LogOut_Click(object sender, EventArgs e)
        {
            LogMeOut();
        }

        private void LogMeIn()
        {
            button1.Enabled = true;
            panel1.Enabled = true;
            panel2.Enabled = true;
            panel3.Enabled = true;
            statusBar1.Text = "Έχετε συνδεθεί επιτυχώς!";
            LogOut.Enabled = true;
            UserLogIn.Enabled = false;
        }

        private void LogMeOut()
        {
           //frm.LoginVar = false;
            button1.Enabled = false;
            LogOut.Enabled = false;
            UserLogIn.Enabled = true;
            panel1.Enabled = false;
            panel2.Enabled = false;
            panel3.Enabled = false;
            statusBar1.Text = "Δεν έχετε συνδεθεί...";
        }

        #endregion

        #region "Help, About, Exit"

        private void eHomeInternetHelp_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("IExplore.exe", "http://www.studentguru.gr");
        }

        private void AbouteHome_Click(object sender, EventArgs e)
        {
            e_HomeMobileAboutBox frm = new e_HomeMobileAboutBox();
            frm.ShowDialog();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Close();
        }

        #endregion

        #region "comboBoxArea"

        private void comboBoxArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            var dr = getSelectedAreaDataRow();
            
            numericUpDownTemperature.Value = dr.temperature;
            trackBarLuminosity.Value = dr.luminosity;
            radioButtonLuminosityOn.Checked = dr.luminosityenabled;
            radioButtonLuminosityOff.Checked = !dr.luminosityenabled;
            radioButtonTemperatureOn.Checked = dr.temperatureenabled;
            radioButtonTemperatureOff.Checked = !dr.temperatureenabled;
        }

        private homeDataSet.AreasRow getSelectedAreaDataRow() {
            var query = from o in this.homeDataSet.Areas
                        where o.name == comboBoxArea.Text
                        select o;
            var dr = query.ToArray()[0];
            return dr;
        }

        #endregion

        #region "Values Changing"

        private void radioButtonTemperatureOn_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDownTemperature.Enabled = radioButtonTemperatureOn.Checked;
            var dr = getSelectedAreaDataRow();
            dr.temperatureenabled = radioButtonTemperatureOn.Checked;
        }

        private void radioButtonLuminosityOn_CheckedChanged(object sender, EventArgs e)
        {
            trackBarLuminosity.Enabled = radioButtonLuminosityOn.Checked;
            var dr = getSelectedAreaDataRow();
            dr.luminosityenabled = radioButtonLuminosityOn.Checked;
        }

        private void numericUpDownTemperature_ValueChanged(object sender, EventArgs e)
        {
            var dr = getSelectedAreaDataRow();
            dr.temperature = (short) numericUpDownTemperature.Value;
        }

        private void trackBarLuminosity_ValueChanged(object sender, EventArgs e)
        {
            var dr = getSelectedAreaDataRow();
            dr.luminosity = (short) trackBarLuminosity.Value;
        }

        #endregion

    }
}
