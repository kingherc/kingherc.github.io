﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Msdn.UIFramework;
using CheeseGame3.Properties;
using System.IO;
using System.Media;

// Based on the MSDN Technical Article "Games Programming with Cheese" by Rob Miles, Department of Computer Science, University of Hull. link: http://msdn2.microsoft.com/en-us/library/aa446511.aspx

// Reformed and remade by Iraklis Psaroudakis (aka kingherc).

namespace CheeseGame3
{
    public partial class Form1 : UIForm
    {

        private ImageElement cheeseImage;
        private String currentPath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);

        private bool goingRight = true;
        private bool goingDown = true;
        private int speed = 8;
        private int maxSpeed = 15; 
        private int previousSpeed;

        private ImageElement breadImage;

        private System.Windows.Forms.KeyEventArgs keyArgs = null; // Flag for which key the user holds
        private System.Windows.Forms.MouseEventArgs mouseArgs = null; // Flag, if the user touches the screen with the stylus.

        private SoundPlayer bathitsound;
        private SoundPlayer tomatohitsound; // Sound for the burp.wav
        private int tomatoDrawHeight = 0; // Y-coordinate at which the tomatoes are drawn, indicating the upper bound of the game area. In this step it's just 0.
        private int tomatoSpacing = 4; // Spacing between tomatoes.
        private int noOfTomatoes; // Tomatoes number that fit the screen's width
        private ImageElement[] tomatoes; // An array of the tomatoes.

        private TextBlock messageBlock; // the message's bounding rectangle.
        private int level = 1; // current level

        private string stateFileName = "GameState.bin"; // designates the filename of the binary file saving the game's state.

        public Form1()
        {
            InitializeComponent();

            this.MenuBar.Visible = false;
            this.TitleBar.Visible = false;
            this.BackgroundImage = new Bitmap(currentPath + @"\Resources\bg.jpg");

            breadImage = new ImageElement()
            {
                Source = @"Resources\bread.png",
                Top = this.ClientSize.Height / 2,
                Left = 0,
                AlphaChannel = true,
            };
            breadImage.Left = (this.ClientSize.Width - breadImage.Width) / 2;
            this.Canvas.AddElement<ImageElement>(() => breadImage);

            cheeseImage = new ImageElement()
            {
                Source = @"Resources\cheese.png",               
                Top = 0,
                Left = 0,
                AlphaChannel = true,
            };
            this.Canvas.AddElement<ImageElement>(() => cheeseImage);

            FileStream bathitsoundmem = new FileStream(currentPath + @"\Resources\click.wav", FileMode.Open);
            bathitsound = new SoundPlayer(bathitsoundmem);
            bathitsound.Load();
            bathitsoundmem.Close();

            FileStream tomatohitsoundmem = new FileStream(currentPath + @"\Resources\burp.wav", FileMode.Open);
            tomatohitsound = new SoundPlayer(tomatohitsoundmem);
            tomatohitsound.Load();
            tomatohitsoundmem.Close();

            initializeTomatoes();
            placeTomatoes();

            messageBlock = new TextBlock()
            {
                Top = this.ClientSize.Height - 15,
                Left = 0,
                FontSize = 10,
                FontStyle = FontStyle.Regular,
                Foreground = Color.Red,
            };
            this.Canvas.AddElement(() => messageBlock);

            loadState();


            this.timer1.Enabled = true;
        }

        private void updatePositions()
        {
            // Bounce effect
            if (this.goingRight)
                cheeseImage.Left += speed;
            else
                cheeseImage.Left -= speed;

            if ((cheeseImage.Left + cheeseImage.Width) >= this.Width)
                goingRight = false;
            if (cheeseImage.Left <= 0)
                goingRight = true;

            if (this.goingDown)
                cheeseImage.Top += speed;
            else
                cheeseImage.Top -= speed;

            if ((cheeseImage.Top + cheeseImage.Height) >= this.Height)
            {
                goingDown = false;
            }
            if (cheeseImage.Top <= 0)
            {
                goingDown = true;
            }

            if (keyArgs != null)
            {
                switch (keyArgs.KeyCode)
                {
                    case Keys.Up:
                        breadImage.Top -= speed + 1;
                        break;
                    case Keys.Down:
                        breadImage.Top += speed + 1;
                        break;
                    case Keys.Left:
                        breadImage.Left -= speed + 1;
                        break;
                    case Keys.Right:
                        breadImage.Left += speed + 1;
                        break;
                }
            }

            if (mouseArgs != null)
            {
                /* To move the bread with the mouse, we have two known facts: the mouse's point and the bread's current location. We'll use the following algebric representation to find where to move the bread: Imagine a circle of a radius equal to "speed", with the bread's center as its center. Imagine also the line connecting the bread's center and the mouse's point. The new location of the bread should be the intersection of the circle and the line (by choosing one of the two intersections). The following are based on the solved equations (by taking the center of the bread as the starting point O of the coordinates). */
                
                double x1 = breadImage.Left + breadImage.Width / 2.0;
                double y1 = breadImage.Top + breadImage.Height / 2.0;
                double x2 = mouseArgs.X;
                double y2 = mouseArgs.Y;
                if (!((Math.Abs(x1 - x2) < 2.0) && (Math.Abs(y1 - y2) < 2.0)))
                {
                    double newx, newy;
                    newx = (speed + 1) * (x2 - x1) / Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
                    newy = (y2 - y1) * newx / (x2 - x1);
                    newx += x1;
                    newy += y1;
                    breadImage.Left = (int)(newx - breadImage.Width / 2.0);
                    breadImage.Top = (int)(newy - breadImage.Height / 2.0);
                }
            }


            // Dealing with collisions of cheese and bread.

            Rectangle cheeseRectangle = GetImageElementRectangle(cheeseImage);
            Rectangle breadRectangle = GetImageElementRectangle(breadImage);

            if (goingDown) // The collisions happen only when the cheese is going down.
            {
                if (cheeseRectangle.IntersectsWith(breadRectangle)) // We have a collision
                {
                    // Play the click.wav sound
                    bathitsound.Play();
                    // if the cheese's bottom right corner is in the bread rectangle
                    bool rightIn = breadRectangle.Contains(cheeseRectangle.Right, cheeseRectangle.Bottom);
                    // if the cheese's bottom left corner is in the bread rectangle
                    bool leftIn = breadRectangle.Contains(cheeseRectangle.Left, cheeseRectangle.Bottom);

                    // now deal with the three types of bounces
                    if (rightIn & leftIn) // 1. the cheese came down to the bread directly
                    {
                        goingDown = false; // reverse vertical movement only
                    }
                    else
                    {
                        goingDown = false; // reverse vertical movement and then reverse horizontal movement accordingly
                        if (rightIn) // 2. the cheese came down to the bread on the bread's left side.
                        {
                            goingRight = false;
                        }
                        if (leftIn) // 3. the cheese came down to the bread on the bread's right side.
                        {
                            goingRight = true;
                        }
                    }
                }
            }
            else
            {
                for (int i = 0; i < tomatoes.Length; i++)
                {
                    if (!tomatoes[i].Visible)
                    {
                        continue; // if tomato is already destroyed, examine the next tomato in the array.
                    }
                    // Check to see if cheese has collided with this tomato
                    if (cheeseRectangle.IntersectsWith(GetImageElementRectangle(tomatoes[i])))
                    {
                        tomatohitsound.Play();
                        // hide the tomato
                        tomatoes[i].Visible = false;
                        // bounce down
                        goingDown = true;
                        break; // only destroy one at a time
                    }
                }
            }


            messageBlock.Text = @"Level: " + level;
            bool gotTomato = false; // if there's at least one tomato visible
            for (int i = 0; i < tomatoes.Length; i++)
            {
                if (tomatoes[i].Visible)
                {
                    gotTomato = true;
                    break;
                }
            }
            if (!gotTomato)
            {
                newLevel();
            }


        }

        // Called whenever all the tomatoes have been destroyed.
        private void newLevel()
        {
            // increase level
            level++;
            // re-place all tomatoes
            placeTomatoes();
            // speed things up
            if (speed < maxSpeed)
            {
                changeSpeed(1);
            }
        }



        // Called once, at the application start, to set up all the tomatoes.
        private void initializeTomatoes()
        {
            ImageElement tomatoImage = new ImageElement()
            {
                Source = @"Resources\tomato.png"
            };

            // Calculate how many tomatoes can fit the screen's width:
            noOfTomatoes = (this.ClientSize.Width - tomatoSpacing) / (tomatoImage.Width + tomatoSpacing);
            tomatoes = new ImageElement[noOfTomatoes];

            // Define the bounding rectangle for each tomato
            int tomatoX = tomatoSpacing / 2;
            for (int i = 0; i < tomatoes.Length; i++)
            {
                tomatoes[i] = new ImageElement()
                {
                    Source = tomatoImage.Source,
                    Left = tomatoX,
                    Top = tomatoDrawHeight,
                    AlphaChannel = true,
                };
                this.Canvas.AddElement(() => tomatoes[i]);
                tomatoX = tomatoX + tomatoImage.Width + tomatoSpacing;
            }
        }

        // Called to place a row of un-hit tomatoes.
        private void placeTomatoes()
        {
            for (int i = 0; i < tomatoes.Length; i++)
            {
                tomatoes[i].Top = tomatoDrawHeight;
                tomatoes[i].Visible = true;
            }
        }


        public void changeSpeed(int change)
        {
            previousSpeed = speed;
            speed += change;
            if (speed > maxSpeed)
                speed = maxSpeed;
            if (speed < 0)
                speed = 0;
            if (speed == 0)
            {
                timer1.Enabled = false;
                menuItem1.Text = "Unpause";
            }
            else
            {
                timer1.Enabled = true;
                menuItem1.Text = "Pause";
            }
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            updatePositions();
            this.Invalidate();
        }

        private void menuItem3_Click(object sender, EventArgs e)
        {
            changeSpeed(1);
        }

        private void menuItem4_Click(object sender, EventArgs e)
        {
            changeSpeed(-1);
        }

        private void menuItem1_Click(object sender, EventArgs e)
        {
            if (speed == 0)
            {
                changeSpeed(previousSpeed);
            }
            else
            {
                changeSpeed(speed * -1);
            }

        }

        private void menuItem6_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            keyArgs = e;

        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            keyArgs = null;
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseArgs = e;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            mouseArgs = e;
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseArgs = null;
        }

        private Rectangle GetImageElementRectangle(ImageElement ie)
        {
            return new Rectangle(ie.Rectangle.Left, ie.Rectangle.Top, ie.Width, ie.Height);
        }

        private bool saveState()
        {
            Stream stream = null;
            BinaryWriter writer = null;
            try
            {
                stream = File.Open(Path.Combine(currentPath, stateFileName), System.IO.FileMode.OpenOrCreate);
                writer = new BinaryWriter(stream);
                writer.Write(cheeseImage.Left);
                writer.Write(cheeseImage.Top);
                writer.Write(breadImage.Left);
                writer.Write(breadImage.Top);
                writer.Write(speed);
                writer.Write(goingDown);
                writer.Write(goingRight);
                foreach (ImageElement t in tomatoes)
                {
                    writer.Write(t.Left);
                    writer.Write(t.Top);
                    writer.Write(t.Visible);
                }
                writer.Write(tomatoDrawHeight);
                writer.Write(level);
            }
            catch
            {
                return false;
            }
            finally
            {
                try
                {
                    writer.Close();
                    stream.Close();
                }
                catch { }
            }
            return true;
        }

        private bool loadState()
        {
            if (!File.Exists(Path.Combine(currentPath, stateFileName)))
            {
                return false;
            }
            Stream stream = null;
            BinaryReader reader = null;
            try
            {
                stream = File.OpenRead(currentPath + stateFileName);
                reader = new BinaryReader(stream);

                cheeseImage.Left = reader.ReadInt32();
                cheeseImage.Top = reader.ReadInt32();
                breadImage.Left = reader.ReadInt32();
                breadImage.Top = reader.ReadInt32();
                speed = reader.ReadInt32();
                goingDown = reader.ReadBoolean();
                goingRight = reader.ReadBoolean();
                for (int i = 0; i < tomatoes.Length; i++)
                {
                    tomatoes[i].Left = reader.ReadInt32();
                    tomatoes[i].Top = reader.ReadInt32();
                    tomatoes[i].Visible = reader.ReadBoolean();
                }
                tomatoDrawHeight = reader.ReadInt32();
                level = reader.ReadInt32();

                reader.Close();
                stream.Close();
            }
            catch
            {
                return false;
            }
            finally
            {
                try
                {
                    if (reader != null) reader.Close();
                }
                catch { }
                try
                {
                    if (stream != null) stream.Close();
                }
                catch { }
            }
            return true;
        }

        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            saveState();
        }


    }
}