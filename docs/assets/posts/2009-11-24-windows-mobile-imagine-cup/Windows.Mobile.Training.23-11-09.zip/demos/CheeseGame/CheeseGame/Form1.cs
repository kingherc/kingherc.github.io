﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Media;
using System.IO;

// Based on the MSDN Technical Article "Games Programming with Cheese"
// by Rob Miles, Department of Computer Science, University of Hull
// link: http://msdn2.microsoft.com/en-us/library/aa446511.aspx

// Reformed and remade by Iraklis Psaroudakis (aka kingherc).

namespace CheeseGame
{
    public partial class Form1 : Form
    {

        #region Variables

        // variables for the message
        private string messageString; // variable for the message displayed at the top.
        private Rectangle messageRectangle; // the message's bounding rectangle.
        private int messageHeight = 15; // the height of the message displayed at the top.
        private Font messageFont = null; // the font for the message to draw at the top.
        private System.Drawing.SolidBrush messageBrush; // the font's color for the message.
        private System.Drawing.Pen linePen; // the color of the line (the one that goes further down at each next level).

        // Game status variables
        private int scoreValue = 0; // the score
        private int highScoreValue = 100; // the highest score
        private string highScoreName = "NoName";
        private int livesLeft; // lives left
        private const int startLives = 3; // lives when the game starts
        private bool gameLive = false; // a flag which shows whether the game is running or over/paused.
        private int maxSpeed = 7; // maximum speed for the game.
        private int speed = 3; // current speed of the game.
        private bool testingGame = false; // Causes the bread/bat to automatically track the cheese. (~ God Mode)

        // tomatoes variables
        struct tomato
        {
            public Rectangle rectangle;
            public bool visible;
        }
        private int tomatoSpacing = 4; // spacing between tomatoes.
        private int tomatoLevelStartHeight; // starting/highest height for the tomatoes.
        private int tomatoDrawHeight; // height at which the tomatoes are drawn, indicating the upper bound of the game area.
        private int noOfTomatoes; // tomatoes number which is set at the start by initializeTomatoes
        private tomato[] tomatoes; // an array of the tomatoes.

        // ham variables
        private bool hamPresent = false; // True when the ham is displayed.
        private int hamLikelihood = 5; // Range 0 to 10. The larger the value the more likely the ham is to appear
        private int hamTimerCount; // Counts down ticks before the ham disappears. Set at a random number when the ham appears.
        private Random randomNumbers; // Generates random numbers for the ham.

        // painting variables
        private Image tomatoImage = CheeseGame.Properties.Resources.tomato;
        private Image cheeseImage = CheeseGame.Properties.Resources.cheese;
        private Image breadImage = CheeseGame.Properties.Resources.bread;
        private Image hamImage = CheeseGame.Properties.Resources.ham;
        private Bitmap backBuffer = null; //Background buffer bitmap. The game first draws on this and then displays it.
        private Rectangle cheeseRectangle; // Position and bounding box for cheese.
        private Rectangle breadRectangle; // Position and bounding box for bread.
        private Rectangle hamRectangle; // Position and bounding box for ham.
        private System.Drawing.Imaging.ImageAttributes transparentWhite; //Image attribute to make the white color in our drawing transparent.

        // Sound variables
        private SoundPlayer bathitsound;
        private SoundPlayer tomatohitsound;
        private SoundPlayer hamhitsound;

        // Directory variables
        private string applicationDirectory; // stores the file path of the application's working directory
        private string highScoreFile = "HighScore.txt"; // designates the filename of the text file (stored in dirpath) containing the high scorer.
        private string stateFileName = "GameState.bin"; // designates the filename of the binary file saving the game's state.

        #endregion

        #region Form events (initialization, keyboard, mouse)

        // Called when the form is created.
        public Form1() 
        {
            InitializeComponent(); // Needed by Visual Studio

            // the following gets the application's working directory path
            applicationDirectory = new Uri(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)).LocalPath;
            if (!(applicationDirectory.EndsWith(@"/") || applicationDirectory.EndsWith(@"\")))
            {
                applicationDirectory += @"/"; // make sure we have a path separater on the end
            }

            //Initializing variables:
            transparentWhite = new System.Drawing.Imaging.ImageAttributes();
            transparentWhite.SetColorKey(Color.White, Color.White);
            LoadHighScore();
            cheeseRectangle = new Rectangle(0,0, cheeseImage.Width, cheeseImage.Height);
            hamRectangle = new Rectangle(0, 0, hamImage.Width, hamImage.Height);
            breadRectangle = new Rectangle((this.ClientSize.Width - breadImage.Width) / 2, this.ClientSize.Height / 2, breadImage.Width, breadImage.Height);
            messageFont = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Regular);
            messageBrush = new SolidBrush(Color.Red);
            messageRectangle = new Rectangle(0, 0, this.ClientSize.Width, messageHeight);
            linePen = new Pen(Color.Gray, 2);
            tomatoLevelStartHeight = messageRectangle.Bottom + 1;
            randomNumbers = new Random();
            initializeTomatoes();

            //Initialize sounds:
            MemoryStream bathitsoundmem = new MemoryStream(CheeseGame.Properties.Resources.click);
            bathitsound = new SoundPlayer(bathitsoundmem);
            bathitsound.Load();
            bathitsoundmem.Close();
            MemoryStream tomatohitsoundmem = new MemoryStream(CheeseGame.Properties.Resources.burp);
            tomatohitsound = new SoundPlayer(tomatohitsoundmem);
            tomatohitsound.Load();
            tomatohitsoundmem.Close();
            MemoryStream hamhitsoundmem = new MemoryStream(CheeseGame.Properties.Resources.pig);
            hamhitsound = new SoundPlayer(hamhitsoundmem);
            hamhitsound.Load();
            hamhitsoundmem.Close();

            // reload the state of the previous game.
            if (!loadState())
            {
                gameLive = false;
            }
            if (gameLive)
            {
                // sleep if the game is active - user can then start by resuming
                sleep();
            }
            else
            {
                timer1.Enabled = true;
            }
            updateMessageHighScore();
        }

        private void Form1_LostFocus(object sender, EventArgs e)
        {
            if (speed != 0)
            {
                sleep(); // If the window loses focus, pause the game.
            }
        }

        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            SaveHighScore();
            saveState();
        }

        // When the event KeyDown happens (that is when the user presses down a key), the event automatically
        // calls this method supplying the variable e with the key being pressed. So, to monitor when a key
        // is pressed, we will check whether the keyArgs (= e) variable is null or not. If it's not null,
        // the user is currently pressing a key which we will use to move things around.
        private System.Windows.Forms.KeyEventArgs keyArgs = null;
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            keyArgs = e;
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            keyArgs = null;
        }

        // The same logic as with the keys is applied for the mouse (if a mouse exists for the device).
        // Note: The stylus on the PocketPC acts as a mouse.
        private System.Windows.Forms.MouseEventArgs mouseArgs = null;
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            mouseArgs = e;
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseArgs = e;
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseArgs = null;
        }

        #endregion

        #region Game State (highscore, saving, loading)

        // The following method saves the high scorer and his score to
        // a text file in the application's directory.
        public void SaveHighScore()
        {
            System.IO.TextWriter writer = null;
            try // try-catch-finally is the standard methodology of error handling in C#.
            {
                writer = new System.IO.StreamWriter(applicationDirectory + highScoreFile);
                writer.WriteLine(highScoreName);
                writer.WriteLine(highScoreValue);
            }
            catch { }
            finally // always close the stream, even if there is an error.
            {
                if (writer != null)
                {
                    writer.Close();
                }
            }
        }

        // The following method loads the high scorer and his score from
        // a text file in the application's directory.
        public void LoadHighScore()
        {
            System.IO.TextReader reader = null;
            try
            {
                reader = new System.IO.StreamReader(applicationDirectory + highScoreFile);
                highScoreName = reader.ReadLine();
                string highScoreString = reader.ReadLine();
                highScoreValue = int.Parse(highScoreString);
            }
            catch { }
            finally // always close the stream, even if there is an error.
            {
                if (reader != null)
                {
                    reader.Close();
                }
            }
        }

        // The following method saves the current state of the game (all variables)
        // to a binary file in the application's directory.
        private bool saveState()
        {
            System.IO.Stream stream = null;
            System.IO.BinaryWriter writer = null;
            try
            {
                stream = System.IO.File.Open(applicationDirectory + stateFileName, System.IO.FileMode.OpenOrCreate);
                writer = new System.IO.BinaryWriter(stream);
                writer.Write(highScoreName);
                writer.Write(highScoreValue);
                writer.Write(gameLive);
                if (gameLive)
                {
                    writer.Write(cheeseRectangle.X);
                    writer.Write(cheeseRectangle.Y);
                    writer.Write(breadRectangle.X);
                    writer.Write(breadRectangle.Y);
                    writer.Write(speed);
                    writer.Write(goingDown);
                    writer.Write(goingRight);
                    writer.Write(hamPresent);
                    writer.Write(hamRectangle.X);
                    writer.Write(hamRectangle.Y);
                    writer.Write(hamTimerCount);
                    foreach (tomato t in tomatoes)
                    {
                        writer.Write(t.rectangle.X);
                        writer.Write(t.rectangle.Y);
                        writer.Write(t.visible);
                    }
                    writer.Write(tomatoDrawHeight);
                    writer.Write(livesLeft);
                    writer.Write(scoreValue);
                    writer.Write(messageString);
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                try
                {
                    writer.Close();
                    stream.Close();
                }
                catch { }
            }
            return true;
        }

        // The following method loads a state of the game (all variables)
        // from a binary file in the application's directory. That way, a user can
        // resume a previous game stored in the file.
        private bool loadState()
        {
            if (!System.IO.File.Exists(applicationDirectory + stateFileName))
            {
                return false;
            }
            System.IO.Stream stream = null;
            System.IO.BinaryReader reader = null;
            try
            {
                stream = System.IO.File.OpenRead(applicationDirectory + stateFileName);
                reader = new System.IO.BinaryReader(stream);
                highScoreName = reader.ReadString();
                highScoreValue = reader.ReadInt32();
                gameLive = reader.ReadBoolean();
                if (gameLive)
                {
                    cheeseRectangle.X = reader.ReadInt32();
                    cheeseRectangle.Y = reader.ReadInt32();
                    breadRectangle.X = reader.ReadInt32();
                    breadRectangle.Y = reader.ReadInt32();
                    speed = reader.ReadInt32();
                    goingDown = reader.ReadBoolean();
                    goingRight = reader.ReadBoolean();
                    hamPresent = reader.ReadBoolean();
                    hamRectangle.X = reader.ReadInt32();
                    hamRectangle.Y = reader.ReadInt32();
                    hamTimerCount = reader.ReadInt32();
                    for (int i = 0; i < tomatoes.Length; i++)
                    {
                        tomatoes[i].rectangle.X = reader.ReadInt32();
                        tomatoes[i].rectangle.Y = reader.ReadInt32();
                        tomatoes[i].visible = reader.ReadBoolean();
                    }
                    tomatoDrawHeight = reader.ReadInt32();
                    livesLeft = reader.ReadInt32();
                    scoreValue = reader.ReadInt32();
                    messageString = reader.ReadString();
                }
                reader.Close();
                stream.Close();
            }
            catch
            {
                return false;
            }
            finally
            {
                try
                {
                    if (reader != null) reader.Close();
                }
                catch { }
                try
                {
                    if (stream != null) stream.Close();
                }
                catch { }
            }
            return true;
        }

        #endregion

        #region Game Status (start, lose, level)

        // Called to start a new game
        private void startGame()
        {
            livesLeft = startLives;
            scoreValue = 0;
            updateMessage();
            speed = 3;

            // place the tomatoes at the starting height and initalize them
            tomatoDrawHeight = tomatoLevelStartHeight;
            placeTomatoes();

            // put the bat in the middle of the screen and the cheese "on" the bat.
            breadRectangle.X = (this.ClientSize.Width - breadRectangle.Width) / 2;
            breadRectangle.Y = this.ClientSize.Height / 2;
            cheeseRectangle.X = (this.ClientSize.Width - cheeseRectangle.Width) / 2;
            cheeseRectangle.Y = breadRectangle.Y - cheeseRectangle.Height;

            // starts the game logic
            gameLive = true;
        }

        // Called when the cheese hits the ground.
        private void loseLife()
        {
            if (!gameLive)
            {
                return; // lose a life only when the game is live
            }
            livesLeft--;
            if (livesLeft > 0)
            {
                updateMessage();
            }
            else
            {
                // stop the game
                gameLive = false;
                updateMessageHighScore();
                // do the high score thing
                if (scoreValue > highScoreValue)
                {
                    timer1.Enabled = false;
                    updateMessageHighScore();
                    HighScore fScore = new HighScore();
                    if (fScore.ShowDialog() == DialogResult.OK)
                    {
                        highScoreValue = scoreValue;
                        highScoreName = fScore.scoreName;
                        updateMessageHighScore();
                    }
                    timer1.Enabled = true;
                }
            }
        }

        private void updateMessage()
        {
            messageString = "Score: " + scoreValue + "  Lives: " + livesLeft;
        }

        private void updateMessageHighScore()
        {
            messageString = "High score : " + highScoreValue + " " + highScoreName;
        }

        // Called whenever all the tomatoes have been destroyed.
        private void newLevel() 
        {
            if (!gameLive)
            {
                return;
            }

            // set up the tomatoes a bit lower (depending on the device).
            int multiplier = 5;
            if (Microsoft.WindowsCE.Forms.SystemSettings.Platform == Microsoft.WindowsCE.Forms.WinCEPlatform.PocketPC)
            {
                multiplier = 5;
            } else if (Microsoft.WindowsCE.Forms.SystemSettings.Platform == Microsoft.WindowsCE.Forms.WinCEPlatform.Smartphone) {
                multiplier = 3;
            }
            tomatoDrawHeight += tomatoSpacing * multiplier;

            // if tomatoes are very low, put them back at the starting tomato height.
            if (tomatoDrawHeight >
               (ClientSize.Height - (breadRectangle.Height + cheeseImage.Height + tomatoImage.Height)))
            {
                tomatoDrawHeight = tomatoLevelStartHeight;
                livesLeft++;
            }
            placeTomatoes();
            // speed things up
            if (speed < maxSpeed)
            {
                changeSpeed(1);
            }
        }

        #endregion

        #region Tomatoes (initialization, placing)

        // called once to set up all the tomatoes.
        private void initializeTomatoes()
        {
            noOfTomatoes = (this.ClientSize.Width - tomatoSpacing) / (tomatoImage.Width + tomatoSpacing);
            tomatoes = new tomato[noOfTomatoes];

            // defining the rectangle for each tomato
            int tomatoX = tomatoSpacing / 2;
            for (int i = 0; i < tomatoes.Length; i++)
            {
                tomatoes[i].rectangle =
                   new Rectangle(tomatoX, tomatoDrawHeight,
                   tomatoImage.Width, tomatoImage.Height);
                tomatoX = tomatoX + tomatoImage.Width + tomatoSpacing;
            }
        }

        // called to place a row of tomatoes.
        private void placeTomatoes()
        {
            for (int i = 0; i < tomatoes.Length; i++)
            {
                tomatoes[i].rectangle.Y = tomatoDrawHeight;
                tomatoes[i].visible = true;
            }
        }

        #endregion

        #region Painting (form paint, timer trigger)

        // Painting the objects onto the form. This method is called by Windows automatically for us to
        // draw the form. We use a Graphics object to draw things in .NET. The e variable contains
        // a Graphics object referring to the form.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (backBuffer == null)
            {
                backBuffer = new Bitmap(this.ClientSize.Width, this.ClientSize.Height);
            }

            using (Graphics g = Graphics.FromImage(backBuffer))
            {
                g.Clear(Color.White);

                // Draw ham, bat, cheese, line, message.
                if (hamPresent)
                {
                    g.DrawImage(hamImage, hamRectangle, 0, 0, hamRectangle.Width, hamRectangle.Height, GraphicsUnit.Pixel, transparentWhite);
                }
                g.DrawImage(breadImage, breadRectangle, 0, 0, breadImage.Width, breadImage.Height, GraphicsUnit.Pixel, transparentWhite);
                g.DrawImage(cheeseImage, cheeseRectangle, 0, 0, cheeseImage.Width, cheeseImage.Height, GraphicsUnit.Pixel, transparentWhite);
                g.DrawLine(linePen, 0, tomatoDrawHeight - 1, this.ClientSize.Width, tomatoDrawHeight - 1);
                g.DrawString(messageString, messageFont, messageBrush, messageRectangle);

                // Draw tomatoes & check for new level
                bool gotTomato = false;
                for (int i = 0; i < tomatoes.Length; i++)
                {
                    if (tomatoes[i].visible)
                    {
                        gotTomato = true;
                        g.DrawImage(tomatoImage, tomatoes[i].rectangle, 0, 0, tomatoes[i].rectangle.Width, tomatoes[i].rectangle.Height, GraphicsUnit.Pixel, transparentWhite);
                    }
                }
                if (!gotTomato)
                {
                    newLevel();
                }
            }
            e.Graphics.DrawImage(backBuffer, 0, 0); // Draw the buffer onto the form
        }
        protected override void OnPaintBackground(PaintEventArgs pevent)
        {
            // Don't allow the form's background to paint. This prevents the screen from glitching.
        } 

        // This timer is actually the game's refresh rate.
        private void timer1_Tick(object sender, EventArgs e)
        {
            updatePositions();
            hamTick();
            Invalidate();
        }

        #endregion

        #region Speed & Positioning (speed, wake, sleep, updatepositions)

        // Accelerate or decelarate speed
        int previousSpeed; // used by the pause/unpause button.
        public void changeSpeed(int change)
        {
            previousSpeed = speed;
            speed += change;
            if (speed > maxSpeed)
            {
                speed = maxSpeed;
            }
            if (speed < 0)
            {
                speed = 0;
            }
            if (speed == 0)
            {
                timer1.Enabled = false;
                menuItem1.Text = "Unpause";
            }
            else
            {
                timer1.Enabled = true;
                menuItem1.Text = "Pause";
            }
        }

        private void sleep()
        {
            if (speed != 0)
            {
                changeSpeed(speed * -1);
            }
        }

        private void wake()
        {
            if (speed == 0)
            {
                changeSpeed(previousSpeed);
            }
        }

        private bool goingRight = true; // flag showing whether the cheese goes right or left.
        private bool goingDown = true; // flag showing whether the cheese goes up or down.

        // Called at each tick of the timer. Containing most of the game logic.
        private void updatePositions()
        {
            // Move the cheese horizontally.
            if (goingRight)
            {
                cheeseRectangle.X += speed;
            }
            else
            {
                cheeseRectangle.X -= speed;
            }

            if (cheeseRectangle.Right >= this.Width) 
            {
                goingRight = false;
            }
            if (cheeseRectangle.X <= 0)
            {
                goingRight = true;
            }

            // Move the cheese vertically.
            if (goingDown)
            {
                cheeseRectangle.Y += speed;
            }
            else
            {
                cheeseRectangle.Y -= speed;
            }

            if (cheeseRectangle.Bottom >= this.Height) // if cheese hits the ground
            {
                loseLife();
                goingDown = false;
            }
            if (cheeseRectangle.Y <= tomatoDrawHeight) // if cheese hits the ceiling
            {
                goingDown = true;
            }

            if (!gameLive)
            {
                // when the game isn't live, this makes the method to exit. That means that nothing
                // else happens on the screen than that of the cheese moving around.
                return;
            }

            // Moving the bread.
            if (keyArgs != null)
            {
                switch (keyArgs.KeyCode)
                {
                    case Keys.Up:
                        breadRectangle.Y -= speed + 1;
                        break;
                    case Keys.Down:
                        breadRectangle.Y += speed + 1;
                        break;
                    case Keys.Left:
                        breadRectangle.X -= speed + 1;
                        break;
                    case Keys.Right:
                        breadRectangle.X += speed + 1;
                        break;
                }
            }
            if (mouseArgs != null)
            {
                // To move the bat with the mouse, we have two known facts: the mouse's point and the
                // bread's current location. We'll use the following algebric representation to find the
                // where to move the bread: Imagine a circle of a radius equal to "speed", with the
                // bread's center as its center. Imagine also the line connecting the bread's center
                // and the mouse's point. The new location of the bread should be the
                // intersection of the circle and the line (by choosing the right of the two intersections).
                // The following are based on solving the equations (by taking the center of the bread
                // as the starting point O).

                double x1 = breadRectangle.X + breadRectangle.Width / 2.0;
                double y1 = breadRectangle.Y + breadRectangle.Height / 2.0;
                double x2 = mouseArgs.X;
                double y2 = mouseArgs.Y;
                if (!((Math.Abs(x1 - x2) < 2.0) && (Math.Abs(y1 - y2) < 2.0)))
                {
                    double newx, newy;
                    newx = (speed + 1) * (x2 - x1) / Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
                    newy = (y2 - y1) * newx / (x2 - x1);
                    newx += x1;
                    newy += y1;
                    breadRectangle.X = (int)(newx - breadRectangle.Width / 2.0);
                    breadRectangle.Y = (int)(newy - breadRectangle.Height / 2.0);
                }
            }

            if (testingGame)
            {
                breadRectangle.X = cheeseRectangle.X;
                breadRectangle.Y = ClientSize.Height - breadRectangle.Height;
            }

            // Dealing with collisions of cheese and bread. They happen only when the cheese is going down.
            if (goingDown)
            {
                if (cheeseRectangle.IntersectsWith(breadRectangle)) // We have a collision
                {
                    bathitsound.Play();
                    bool rightIn = breadRectangle.Contains(cheeseRectangle.Right, cheeseRectangle.Bottom);
                    // if the cheese's bottom right corner is in the bread rectangle
                    bool leftIn = breadRectangle.Contains(cheeseRectangle.Left, cheeseRectangle.Bottom);
                    // if the cheese's bottom left corner is in the bread rectangle

                    // now deal with the three types of bounces
                    if (rightIn & leftIn) // 1. the cheese came down to the bread directly
                    {
                        goingDown = false; // reverse vertical movement
                    }
                    else
                    {
                        goingDown = false; // reverse vertical movement
                        // now reverse horizontal movement
                        if (rightIn) // 2. the cheese came down to the bread on the bread's left side.
                        {
                            goingRight = false;
                        }
                        if (leftIn) // 3. the cheese came down to the bread on the bread's right side.
                        {
                            goingRight = true;
                        }
                    }
                }
            }
            else
            // Dealing with collisions of cheese and tomatoes. They happen only when the cheese is going upwards.
            {
                
                for (int i = 0; i < tomatoes.Length; i++)
                {
                    if (!tomatoes[i].visible)
                    {
                        continue; // if tomato is already destroyed, examine the next tomato in the array.
                    }
                    if (cheeseRectangle.IntersectsWith(tomatoes[i].rectangle))
                    {
                        tomatohitsound.Play();
                        // hide the tomato
                        tomatoes[i].visible = false;
                        // bounce down
                        goingDown = true;
                        // update the score
                        scoreValue = scoreValue + 10;
                        updateMessage();
                        startHam();
                        break; // only destroy one at a time
                    }
                }
            }


        }

        #endregion

        #region Ham (startHam, hamTick)

        private void startHam() // Called when a tomato is destroyed, to make the ham active.
        {
            if (hamPresent)
            {
                return; // don't continue if the ham is already present
            }
            // decide how often the ham appears
            if (randomNumbers.Next(10) > hamLikelihood)
            {
                return; // do not display the bonus ham this time
            }
            // position the ham at a random position
            hamRectangle.X = randomNumbers.Next(ClientSize.Width - hamRectangle.Width);
            hamRectangle.Y = tomatoes[0].rectangle.Bottom + randomNumbers.Next(ClientSize.Height - hamRectangle.Height - tomatoes[0].rectangle.Bottom);
            // set how long the ham is displayed for (at least 50 ticks)
            hamTimerCount = 50 + randomNumbers.Next(100);
            // turn the ham on
            hamPresent = true;
        }

        private void hamTick()
        {
            if (!hamPresent)
            {
                return; // do nothing if the ham is disabled
            }

            if (breadRectangle.IntersectsWith(hamRectangle)) //be careful: bread and not cheese!
            {
                scoreValue = scoreValue + 100;
                updateMessage();
                hamhitsound.Play();
                hamPresent = false; // turn the ham off
            }
            else
            {
                // count down the timeout
                hamTimerCount--;
                if (hamTimerCount == 0)
                {
                    // timed out - remove the ham
                    hamPresent = false;
                }
            }
        }

        #endregion

        #region Menu Items

        private void menuItem6_Click(object sender, EventArgs e)
        {
            SaveHighScore();
            this.Close();
            Application.Exit();
        }

        private void menuItem4_Click(object sender, EventArgs e)
        {
            changeSpeed(1);
        }

        private void menuItem5_Click(object sender, EventArgs e)
        {
            changeSpeed(-1);
        }

        private void menuItem8_Click(object sender, EventArgs e)
        {
            startGame();
        }

        // Pause and Unpause
        private void menuItem1_Click(object sender, EventArgs e)
        {
            if (speed == 0)
            {
                wake();
            }
            else
            {
                sleep();
            }
        }

        #endregion

    }
}