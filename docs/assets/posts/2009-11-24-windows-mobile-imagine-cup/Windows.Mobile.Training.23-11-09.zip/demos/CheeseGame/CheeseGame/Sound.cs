/*
using System.Runtime.InteropServices;
using System.IO;
using System;

// This shows a classic way to access Windows CE API functions
// within a managed application. Search the Windows Mobile SDK
// for the PlaySound function and see how we can access it
// through an API call. PlaySound may be used as an alternative
// to the managed SoundPlayer class. As SoundPlayer is used in our
// main project, this file has been commented out.

namespace CheeseGame
{
	/// <summary>
	/// Summary description for Sound.
	/// </summary>
	public class Sound
	{

		/// <summary>
		/// Controls the playback of sound in our game
		/// </summary>
		public static bool Enabled = true ;

		/// <summary>
		/// The byte array which holds the sample
		/// </summary>
		private byte[] soundBytes;

		/// <summary>
		/// Flags to control the Windows CE function which will
		/// play our sound.
		/// </summary>
		private enum Flags 
		{
			SND_SYNC = 0x0000,  // play synchronously (default)
			SND_ASYNC = 0x0001,  // play asynchronously 
			SND_NODEFAULT = 0x0002,  // silence (!default) if sound not found 
			SND_MEMORY = 0x0004,  // pszSound points to a memory file 
			SND_LOOP = 0x0008,  // loop the sound until next sndPlaySound 
			SND_NOSTOP = 0x0010,  // don't stop any currently playing sound 
			SND_NOWAIT = 0x00002000, // don't wait if the driver is busy 
			SND_ALIAS = 0x00010000, // name is a registry alias 
			SND_ALIAS_ID = 0x00110000, // alias is a predefined ID 
			SND_FILENAME = 0x00020000, // name is file name 
			SND_RESOURCE = 0x00040004  // name is resource name or atom 
		}

		/// <summary>
		/// The method which will play our sounds. 
		/// </summary>
		/// <param name="szSound">The byte array holding the sound</param>
		/// <param name="hMod">a handle to task with the sound resource</param>
		/// <param name="flags">Flags to control the playback mode</param>
		/// <returns></returns>
		[DllImport("CoreDll.DLL", EntryPoint="PlaySound", SetLastError=true)]
		private extern static int WCE_PlaySoundBytes (byte[] szSound, IntPtr hMod, int flags);

		/// <summary>
		/// Create a sound instance and store the sample.
		/// </summary>
		/// <param name="soundStream">the stream to read the sound from</param>
		public Sound( Stream soundStream)    
		{
			// create a byte array to hold the sample
			soundBytes = new byte [soundStream.Length];
			// read the sample from the sream
			soundStream.Read(soundBytes, 0,(int)soundStream.Length);
		}
        public Sound(Byte[] sound_Bytes)
        {
            soundBytes = sound_Bytes;
        }

		/// <summary>
		/// Play the sound
		/// </summary>
		public void Play () 
		{
			if ( Sound.Enabled ) 
			{
				WCE_PlaySoundBytes (
					soundBytes, // sample array
					IntPtr.Zero, // null - not using a resource
					(int) (Flags.SND_ASYNC | Flags.SND_MEMORY) // playback mode
					);
			}
		}
	}
}
*/