﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CheeseGame2.Properties;
using System.IO;
using System.Media;

// Based on the MSDN Technical Article "Games Programming with Cheese"
// by Rob Miles, Department of Computer Science, University of Hull
// link: http://msdn2.microsoft.com/en-us/library/aa446511.aspx

// Reformed and remade by Iraklis Psaroudakis (aka kingherc).

namespace CheeseGame2
{
    public partial class Form1 : Form
    {

        #region "Run 1. Drawing a moving cheese."

        //#region "Variables and Declarations"
   
        //private Rectangle cheeseRectangle; // Position and bounding box for cheese.

        //#endregion

        //#region "Application Start"

        //public Form1()
        //{
        //    InitializeComponent();

        //    cheeseRectangle = new Rectangle(0, 0, Resources.cheese.Width, Resources.cheese.Height);
        //    this.timer1.Enabled = true;
        //}

        //#endregion

        //#region "Painting the Form"

        //private void Form1_Paint(object sender, PaintEventArgs e)
        //{
        //    e.Graphics.DrawImage(Resources.cheese, cheeseRectangle.X, cheeseRectangle.Y);
        //}

        //#endregion

        //#region "updatePositions() and Timer"

        //private void updatePositions()
        //{
        //    cheeseRectangle.X++;
        //    cheeseRectangle.Y++;
        //}

        //private void timer1_Tick(object sender, EventArgs e)
        //{
        //    updatePositions();
        //    this.Invalidate();
        //}

        //#endregion

        #endregion

        #region "Run 2. Bounce effect & Speed."

        //#region "Variables and Declarations, UPDATED"

        //private Rectangle cheeseRectangle; // Position and bounding box for cheese.

        //// NEW
        //private bool goingRight = true; // Whether the cheese is going right or left.
        //private bool goingDown = true; // Whether the cheese is going down or up.
        //private int speed = 3; // Speed of game

        //#endregion

        //#region "Application Start"

        //public Form1()
        //{
        //    InitializeComponent();

        //    cheeseRectangle = new Rectangle(0, 0, Resources.cheese.Width, Resources.cheese.Height);
        //    this.timer1.Enabled = true;
        //}

        //#endregion

        //#region "Painting the Form"

        //private void Form1_Paint(object sender, PaintEventArgs e)
        //{
        //    e.Graphics.DrawImage(Resources.cheese, cheeseRectangle.X, cheeseRectangle.Y);
        //}

        //#endregion

        //#region "updatePositions() and Timer, UPDATED"

        //// NEW - UPDATED
        //private void updatePositions()
        //{
        //    // Bounce effect
        //    if (goingRight)
        //        cheeseRectangle.X += speed;
        //    else
        //        cheeseRectangle.X -= speed;

        //    if ((cheeseRectangle.X + Resources.cheese.Width) >= this.Width)
        //        goingRight = false;
        //    if (cheeseRectangle.X <= 0)
        //        goingRight = true;

        //    if (goingDown)
        //        cheeseRectangle.Y += speed;
        //    else
        //        cheeseRectangle.Y -= speed;

        //    if ((cheeseRectangle.Y + Resources.cheese.Height) >= this.Height)
        //    {
        //        goingDown = false;
        //    }
        //    if (cheeseRectangle.Y <= 0)
        //    {
        //        goingDown = true;
        //    }

        //}

        //private void timer1_Tick(object sender, EventArgs e)
        //{
        //    updatePositions();
        //    this.Invalidate();
        //}

        //#endregion

        #endregion

        #region "Run 3. Menus for Speed and Pause and Exit."

        //#region "Variables and Declarations, UPDATED"

        //private Rectangle cheeseRectangle; // Position and bounding box for cheese.

        //private bool goingRight = true; // Whether the cheese is going right or left.
        //private bool goingDown = true; // Whether the cheese is going down or up.
        //private int speed = 3; // Speed of game

        //// NEW
        //private int maxSpeed = 7; // Max speed of the game
        //private int previousSpeed; // used by the Pause/Unpause button.

        //#endregion

        //#region "Application Start"

        //public Form1()
        //{
        //    InitializeComponent();

        //    cheeseRectangle = new Rectangle(0, 0, Resources.cheese.Width, Resources.cheese.Height);
        //    this.timer1.Enabled = true;
        //}

        //#endregion

        //#region "Painting the Form"

        //private void Form1_Paint(object sender, PaintEventArgs e)
        //{
        //    e.Graphics.DrawImage(Resources.cheese, cheeseRectangle.X, cheeseRectangle.Y);
        //}

        //#endregion

        //#region "updatePositions() and Timer"

        //private void updatePositions()
        //{
        //    // Bounce effect
        //    if (goingRight)
        //        cheeseRectangle.X += speed;
        //    else
        //        cheeseRectangle.X -= speed;

        //    if ((cheeseRectangle.X + Resources.cheese.Width) >= this.Width)
        //        goingRight = false;
        //    if (cheeseRectangle.X <= 0)
        //        goingRight = true;

        //    if (goingDown)
        //        cheeseRectangle.Y += speed;
        //    else
        //        cheeseRectangle.Y -= speed;

        //    if ((cheeseRectangle.Y + Resources.cheese.Height) >= this.Height)
        //    {
        //        goingDown = false;
        //    }
        //    if (cheeseRectangle.Y <= 0)
        //    {
        //        goingDown = true;
        //    }

        //}

        //private void timer1_Tick(object sender, EventArgs e)
        //{
        //    updatePositions();
        //    this.Invalidate();
        //}

        //#endregion

        //#region "Change Speed, NEW"

        //public void changeSpeed(int change)
        //{
        //    previousSpeed = speed;
        //    speed += change;
        //    if (speed > maxSpeed)
        //        speed = maxSpeed;
        //    if (speed < 0)
        //        speed = 0;
        //    if (speed == 0)
        //    {
        //        timer1.Enabled = false;
        //        menuItem1.Text = "Unpause";
        //    }
        //    else
        //    {
        //        timer1.Enabled = true;
        //        menuItem1.Text = "Pause";
        //    }
        //}

        //#endregion

        //#region "Menus, NEW"

        //private void menuItem3_Click(object sender, EventArgs e)
        //{
        //    changeSpeed(1);
        //}

        //private void menuItem4_Click(object sender, EventArgs e)
        //{
        //    changeSpeed(-1);
        //}

        //private void menuItem1_Click(object sender, EventArgs e)
        //{
        //    if (speed == 0)
        //    {
        //        changeSpeed(previousSpeed);
        //    }
        //    else
        //    {
        //        changeSpeed(speed * -1);
        //    }
        //}

        //private void menuItem6_Click(object sender, EventArgs e)
        //{
        //    this.Close();
        //    Application.Exit();
        //}

        //#endregion

        #endregion

        #region "Run 4. Add bread and Double Buffering"

        //#region "Variables and Declarations, UPDATED"

        //private Rectangle cheeseRectangle; // Position and bounding box for cheese.
        //// NEW
        //private Rectangle breadRectangle; // Position and bounding box for bread.

        //private bool goingRight = true; // Whether the cheese is going right or left.
        //private bool goingDown = true; // Whether the cheese is going down or up.
        //private int speed = 3; // Speed of game
        //private int maxSpeed = 7; // Max speed of the game
        //private int previousSpeed; // used by the Pause/Unpause button.

        //// NEW
        //private Bitmap backBuffer = null; // Double Buffering

        //#endregion

        //#region "Application Start, UPDATED"

        //public Form1()
        //{
        //    InitializeComponent();

        //    cheeseRectangle = new Rectangle(0, 0, Resources.cheese.Width, Resources.cheese.Height);
        //    // NEW
        //    breadRectangle = new Rectangle((this.ClientSize.Width - Resources.bread.Width) / 2, this.ClientSize.Height / 2, Resources.bread.Width, Resources.bread.Height);
        //    this.timer1.Enabled = true;
        //}

        //#endregion

        //#region "Painting the Form, UPDATED"

        //// UPDATED
        //private void Form1_Paint(object sender, PaintEventArgs e)
        //{
        //    if (backBuffer == null)
        //    {
        //        backBuffer = new Bitmap(this.ClientSize.Width, this.ClientSize.Height);
        //    }

        //    using (Graphics g = Graphics.FromImage(backBuffer))
        //    {
        //        g.Clear(Color.White);

        //        g.DrawImage(Resources.bread, breadRectangle.X, breadRectangle.Y);
        //        g.DrawImage(Resources.cheese, cheeseRectangle.X, cheeseRectangle.Y);
        //    }
        //    e.Graphics.DrawImage(backBuffer, 0, 0);
        //}

        //// NEW
        //protected override void OnPaintBackground(PaintEventArgs e)
        //{
        //    // Don't allow the background to paint. 
        //}

        //#endregion

        //#region "updatePositions() and Timer"

        //private void updatePositions()
        //{

        //    if (goingRight)
        //        cheeseRectangle.X += speed;
        //    else
        //        cheeseRectangle.X -= speed;

        //    if ((cheeseRectangle.X + Resources.cheese.Width) >= this.Width)
        //        goingRight = false;
        //    if (cheeseRectangle.X <= 0)
        //        goingRight = true;

        //    if (goingDown)
        //        cheeseRectangle.Y += speed;
        //    else
        //        cheeseRectangle.Y -= speed;

        //    if ((cheeseRectangle.Y + Resources.cheese.Height) >= this.Height)
        //    {
        //        goingDown = false;
        //    }
        //    if (cheeseRectangle.Y <= 0)
        //    {
        //        goingDown = true;
        //    }

        //}

        //private void timer1_Tick(object sender, EventArgs e)
        //{
        //    updatePositions();
        //    this.Invalidate();
        //}

        //#endregion

        //#region "Change Speed"

        //public void changeSpeed(int change)
        //{
        //    previousSpeed = speed;
        //    speed += change;
        //    if (speed > maxSpeed)
        //        speed = maxSpeed;
        //    if (speed < 0)
        //        speed = 0;
        //    if (speed == 0)
        //    {
        //        timer1.Enabled = false;
        //        menuItem1.Text = "Unpause";
        //    }
        //    else
        //    {
        //        timer1.Enabled = true;
        //        menuItem1.Text = "Pause";
        //    }
        //}

        //#endregion

        //#region "Menus"

        //private void menuItem3_Click(object sender, EventArgs e)
        //{
        //    changeSpeed(1);
        //}

        //private void menuItem4_Click(object sender, EventArgs e)
        //{
        //    changeSpeed(-1);
        //}

        //private void menuItem1_Click(object sender, EventArgs e)
        //{
        //    if (speed == 0)
        //    {
        //        changeSpeed(previousSpeed);
        //    }
        //    else
        //    {
        //        changeSpeed(speed * -1);
        //    }
        //}

        //private void menuItem6_Click(object sender, EventArgs e)
        //{
        //    this.Close();
        //    Application.Exit();
        //}

        //#endregion

        #endregion

        #region "Run 5. Navigation."

        //#region "Variables and Declarations, UPDATED"

        //private Rectangle cheeseRectangle; // Position and bounding box for cheese.
        //private Rectangle breadRectangle; // Position and bounding box for bread.

        //private bool goingRight = true; // Whether the cheese is going right or left.
        //private bool goingDown = true; // Whether the cheese is going down or up.
        //private int speed = 3; // Speed of game
        //private int maxSpeed = 7; // Max speed of the game
        //private int previousSpeed; // used by the Pause/Unpause button.

        //private Bitmap backBuffer = null; // Double Buffering

        //// NEW
        //private System.Windows.Forms.KeyEventArgs keyArgs = null; // Flag for which key the user holds
        //// NEW
        //private System.Windows.Forms.MouseEventArgs mouseArgs = null; // Flag, if the user touches the screen with the stylus.

        //#endregion

        //#region "Application Start"

        //public Form1()
        //{
        //    InitializeComponent();

        //    cheeseRectangle = new Rectangle(0, 0, Resources.cheese.Width, Resources.cheese.Height);
        //    breadRectangle = new Rectangle((this.ClientSize.Width - Resources.bread.Width) / 2, this.ClientSize.Height / 2, Resources.bread.Width, Resources.bread.Height);
        //    this.timer1.Enabled = true;
        //}

        //#endregion

        //#region "Painting the Form"

        //private void Form1_Paint(object sender, PaintEventArgs e)
        //{
        //    if (backBuffer == null)
        //    {
        //        backBuffer = new Bitmap(this.ClientSize.Width, this.ClientSize.Height);
        //    }

        //    using (Graphics g = Graphics.FromImage(backBuffer))
        //    {
        //        g.Clear(Color.White);

        //        g.DrawImage(Resources.bread, breadRectangle.X, breadRectangle.Y);
        //        g.DrawImage(Resources.cheese, cheeseRectangle.X, cheeseRectangle.Y);
        //    }
        //    e.Graphics.DrawImage(backBuffer, 0, 0);
        //}

        //protected override void OnPaintBackground(PaintEventArgs e)
        //{
        //    // Don't allow the background to paint. 
        //}

        //#endregion

        //#region "updatePositions() and Timer, UPDATED"

        //// NEW - UPDATED
        //private void updatePositions()
        //{

        //    if (goingRight)
        //        cheeseRectangle.X += speed;
        //    else
        //        cheeseRectangle.X -= speed;

        //    if ((cheeseRectangle.X + Resources.cheese.Width) >= this.Width)
        //        goingRight = false;
        //    if (cheeseRectangle.X <= 0)
        //        goingRight = true;

        //    if (goingDown)
        //        cheeseRectangle.Y += speed;
        //    else
        //        cheeseRectangle.Y -= speed;

        //    if ((cheeseRectangle.Y + Resources.cheese.Height) >= this.Height)
        //    {
        //        goingDown = false;
        //    }
        //    if (cheeseRectangle.Y <= 0)
        //    {
        //        goingDown = true;
        //    }

        //    // NEW: ALL BELOW
        //    if (keyArgs != null)
        //    {
        //        switch (keyArgs.KeyCode)
        //        {
        //            case Keys.Up:
        //                breadRectangle.Y -= speed + 1;
        //                break;
        //            case Keys.Down:
        //                breadRectangle.Y += speed + 1;
        //                break;
        //            case Keys.Left:
        //                breadRectangle.X -= speed + 1;
        //                break;
        //            case Keys.Right:
        //                breadRectangle.X += speed + 1;
        //                break;
        //        }
        //    }

        //    // NEW: ALL BELOW
        //    if (mouseArgs != null)
        //    {
        //         /* To move the bread with the mouse, we have two known facts: the mouse's point and the bread's current location. We'll use the following algebric representation to find where to move the bread: Imagine a circle of a radius equal to "speed", with the bread's center as its center. Imagine also the line connecting the bread's center and the mouse's point. The new location of the bread should be the intersection of the circle and the line (by choosing one of the two intersections). The following are based on the solved equations (by taking the center of the bread as the starting point O of the coordinates). */

        //        double x1 = breadRectangle.X + breadRectangle.Width / 2.0;
        //        double y1 = breadRectangle.Y + breadRectangle.Height / 2.0;
        //        double x2 = mouseArgs.X;
        //        double y2 = mouseArgs.Y;
        //        if (!((Math.Abs(x1 - x2) < 2.0) && (Math.Abs(y1 - y2) < 2.0)))
        //        {
        //            double newx, newy;
        //            newx = (speed + 1) * (x2 - x1) / Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
        //            newy = (y2 - y1) * newx / (x2 - x1);
        //            newx += x1;
        //            newy += y1;
        //            breadRectangle.X = (int)(newx - breadRectangle.Width / 2.0);
        //            breadRectangle.Y = (int)(newy - breadRectangle.Height / 2.0);
        //        }
        //    }


        //}

        //private void timer1_Tick(object sender, EventArgs e)
        //{
        //    updatePositions();
        //    this.Invalidate();
        //}

        //#endregion

        //#region "Change Speed"

        //public void changeSpeed(int change)
        //{
        //    previousSpeed = speed;
        //    speed += change;
        //    if (speed > maxSpeed)
        //        speed = maxSpeed;
        //    if (speed < 0)
        //        speed = 0;
        //    if (speed == 0)
        //    {
        //        timer1.Enabled = false;
        //        menuItem1.Text = "Unpause";
        //    }
        //    else
        //    {
        //        timer1.Enabled = true;
        //        menuItem1.Text = "Pause";
        //    }
        //}

        //#endregion

        //#region "Menus"

        //private void menuItem3_Click(object sender, EventArgs e)
        //{
        //    changeSpeed(1);
        //}

        //private void menuItem4_Click(object sender, EventArgs e)
        //{
        //    changeSpeed(-1);
        //}

        //private void menuItem1_Click(object sender, EventArgs e)
        //{
        //    if (speed == 0)
        //    {
        //        changeSpeed(previousSpeed);
        //    }
        //    else
        //    {
        //        changeSpeed(speed * -1);
        //    }
        //}

        //private void menuItem6_Click(object sender, EventArgs e)
        //{
        //    this.Close();
        //    Application.Exit();
        //}

        //#endregion

        //#region "Form's key & mouse events"

        //// NEW
        //private void Form1_KeyDown(object sender, KeyEventArgs e)
        //{
        //    keyArgs = e;
        //}

        //// NEW
        //private void Form1_KeyUp(object sender, KeyEventArgs e)
        //{
        //    keyArgs = null;
        //}

        //// NEW
        //private void Form1_MouseMove(object sender, MouseEventArgs e)
        //{
        //    mouseArgs = e;
        //}

        //// NEW
        //private void Form1_MouseDown(object sender, MouseEventArgs e)
        //{
        //    mouseArgs = e;
        //}

        //// NEW
        //private void Form1_MouseUp(object sender, MouseEventArgs e)
        //{
        //    mouseArgs = null;
        //}


        //#endregion

        #endregion

        #region "Run 6. Collisions & Sound."

        //#region "Variables and Declarations, UPDATED"

        //private Rectangle cheeseRectangle; // Position and bounding box for cheese.
        //private Rectangle breadRectangle; // Position and bounding box for bread.

        //private bool goingRight = true; // Whether the cheese is going right or left.
        //private bool goingDown = true; // Whether the cheese is going down or up.
        //private int speed = 3; // Speed of game
        //private int maxSpeed = 7; // Max speed of the game
        //private int previousSpeed; // used by the Pause/Unpause button.

        //private Bitmap backBuffer = null; // Double Buffering

        //private System.Windows.Forms.KeyEventArgs keyArgs = null; // Flag for which key the user holds
        //private System.Windows.Forms.MouseEventArgs mouseArgs = null; // Flag, if the user touches the screen with the stylus.

        //// NEW
        //private SoundPlayer bathitsound; // Sound for the click.wav

        //#endregion

        //#region "Application Start, UPDATED"

        //public Form1()
        //{
        //    InitializeComponent();

        //    cheeseRectangle = new Rectangle(0, 0, Resources.cheese.Width, Resources.cheese.Height);
        //    breadRectangle = new Rectangle((this.ClientSize.Width - Resources.bread.Width) / 2, this.ClientSize.Height / 2, Resources.bread.Width, Resources.bread.Height);

        //    // NEW
        //    MemoryStream bathitsoundmem = new MemoryStream(Resources.click);
        //    bathitsound = new SoundPlayer(bathitsoundmem);
        //    bathitsound.Load();
        //    bathitsoundmem.Close();

        //    this.timer1.Enabled = true;
        //}

        //#endregion

        //#region "Painting the Form"

        //private void Form1_Paint(object sender, PaintEventArgs e)
        //{
        //    if (backBuffer == null)
        //    {
        //        backBuffer = new Bitmap(this.ClientSize.Width, this.ClientSize.Height);
        //    }

        //    using (Graphics g = Graphics.FromImage(backBuffer))
        //    {
        //        g.Clear(Color.White);

        //        g.DrawImage(Resources.bread, breadRectangle.X, breadRectangle.Y);
        //        g.DrawImage(Resources.cheese, cheeseRectangle.X, cheeseRectangle.Y);
        //    }
        //    e.Graphics.DrawImage(backBuffer, 0, 0);
        //}

        //protected override void OnPaintBackground(PaintEventArgs e)
        //{
        //    // Don't allow the background to paint. 
        //}

        //#endregion

        //#region "updatePositions() and Timer, UPDATED"

        //// NEW - UPDATED
        //private void updatePositions()
        //{

        //    if (goingRight)
        //        cheeseRectangle.X += speed;
        //    else
        //        cheeseRectangle.X -= speed;

        //    if ((cheeseRectangle.X + Resources.cheese.Width) >= this.Width)
        //        goingRight = false;
        //    if (cheeseRectangle.X <= 0)
        //        goingRight = true;

        //    if (goingDown)
        //        cheeseRectangle.Y += speed;
        //    else
        //        cheeseRectangle.Y -= speed;

        //    if ((cheeseRectangle.Y + Resources.cheese.Height) >= this.Height)
        //    {
        //        goingDown = false;
        //    }
        //    if (cheeseRectangle.Y <= 0)
        //    {
        //        goingDown = true;
        //    }

        //    if (keyArgs != null)
        //    {
        //        switch (keyArgs.KeyCode)
        //        {
        //            case Keys.Up:
        //                breadRectangle.Y -= speed + 1;
        //                break;
        //            case Keys.Down:
        //                breadRectangle.Y += speed + 1;
        //                break;
        //            case Keys.Left:
        //                breadRectangle.X -= speed + 1;
        //                break;
        //            case Keys.Right:
        //                breadRectangle.X += speed + 1;
        //                break;
        //        }
        //    }

        //    if (mouseArgs != null)
        //    {
        //        /* To move the bread with the mouse, we have two known facts: the mouse's point and the bread's current location. We'll use the following algebric representation to find where to move the bread: Imagine a circle of a radius equal to "speed", with the bread's center as its center. Imagine also the line connecting the bread's center and the mouse's point. The new location of the bread should be the intersection of the circle and the line (by choosing one of the two intersections). The following are based on the solved equations (by taking the center of the bread as the starting point O of the coordinates). */

        //        double x1 = breadRectangle.X + breadRectangle.Width / 2.0;
        //        double y1 = breadRectangle.Y + breadRectangle.Height / 2.0;
        //        double x2 = mouseArgs.X;
        //        double y2 = mouseArgs.Y;
        //        if (!((Math.Abs(x1 - x2) < 2.0) && (Math.Abs(y1 - y2) < 2.0)))
        //        {
        //            double newx, newy;
        //            newx = (speed + 1) * (x2 - x1) / Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
        //            newy = (y2 - y1) * newx / (x2 - x1);
        //            newx += x1;
        //            newy += y1;
        //            breadRectangle.X = (int)(newx - breadRectangle.Width / 2.0);
        //            breadRectangle.Y = (int)(newy - breadRectangle.Height / 2.0);
        //        }
        //    }

        //    // NEW - ALL BELOW
        //    // Dealing with collisions of cheese and bread.
        //    if (goingDown) // The collisions happen only when the cheese is going down.
        //    {
        //        if (cheeseRectangle.IntersectsWith(breadRectangle)) // We have a collision
        //        {
        //            // Play the click.wav sound
        //            bathitsound.Play();
        //            // if the cheese's bottom right corner is in the bread rectangle
        //            bool rightIn = breadRectangle.Contains(cheeseRectangle.Right, cheeseRectangle.Bottom);
        //            // if the cheese's bottom left corner is in the bread rectangle
        //            bool leftIn = breadRectangle.Contains(cheeseRectangle.Left, cheeseRectangle.Bottom);

        //            // now deal with the three types of bounces
        //            if (rightIn & leftIn) // 1. the cheese came down to the bread directly
        //            {
        //                goingDown = false; // reverse vertical movement only
        //            }
        //            else
        //            {
        //                goingDown = false; // reverse vertical movement and then reverse horizontal movement accordingly
        //                if (rightIn) // 2. the cheese came down to the bread on the bread's left side.
        //                {
        //                    goingRight = false;
        //                }
        //                if (leftIn) // 3. the cheese came down to the bread on the bread's right side.
        //                {
        //                    goingRight = true;
        //                }
        //            }
        //        }
        //    }

        //}

        //private void timer1_Tick(object sender, EventArgs e)
        //{
        //    updatePositions();
        //    this.Invalidate();
        //}

        //#endregion

        //#region "Change Speed"

        //public void changeSpeed(int change)
        //{
        //    previousSpeed = speed;
        //    speed += change;
        //    if (speed > maxSpeed)
        //        speed = maxSpeed;
        //    if (speed < 0)
        //        speed = 0;
        //    if (speed == 0)
        //    {
        //        timer1.Enabled = false;
        //        menuItem1.Text = "Unpause";
        //    }
        //    else
        //    {
        //        timer1.Enabled = true;
        //        menuItem1.Text = "Pause";
        //    }
        //}

        //#endregion

        //#region "Menus"

        //private void menuItem3_Click(object sender, EventArgs e)
        //{
        //    changeSpeed(1);
        //}

        //private void menuItem4_Click(object sender, EventArgs e)
        //{
        //    changeSpeed(-1);
        //}

        //private void menuItem1_Click(object sender, EventArgs e)
        //{
        //    if (speed == 0)
        //    {
        //        changeSpeed(previousSpeed);
        //    }
        //    else
        //    {
        //        changeSpeed(speed * -1);
        //    }
        //}

        //private void menuItem6_Click(object sender, EventArgs e)
        //{
        //    this.Close();
        //    Application.Exit();
        //}

        //#endregion

        //#region "Form's key & mouse events"

        //// NEW
        //private void Form1_KeyDown(object sender, KeyEventArgs e)
        //{
        //    keyArgs = e;
        //}

        //// NEW
        //private void Form1_KeyUp(object sender, KeyEventArgs e)
        //{
        //    keyArgs = null;
        //}

        //// NEW
        //private void Form1_MouseMove(object sender, MouseEventArgs e)
        //{
        //    mouseArgs = e;
        //}

        //// NEW
        //private void Form1_MouseDown(object sender, MouseEventArgs e)
        //{
        //    mouseArgs = e;
        //}

        //// NEW
        //private void Form1_MouseUp(object sender, MouseEventArgs e)
        //{
        //    mouseArgs = null;
        //}


        //#endregion

        #endregion

        #region "Run 7. Hitting the tomatoes."

        //#region "Variables and Declarations, UPDATED"

        //private Rectangle cheeseRectangle; // Position and bounding box for cheese.
        //private Rectangle breadRectangle; // Position and bounding box for bread.

        //private bool goingRight = true; // Whether the cheese is going right or left.
        //private bool goingDown = true; // Whether the cheese is going down or up.
        //private int speed = 3; // Speed of game
        //private int maxSpeed = 7; // Max speed of the game
        //private int previousSpeed; // used by the Pause/Unpause button.

        //private Bitmap backBuffer = null; // Double Buffering

        //private System.Windows.Forms.KeyEventArgs keyArgs = null; // Flag for which key the user holds
        //private System.Windows.Forms.MouseEventArgs mouseArgs = null; // Flag, if the user touches the screen with the stylus.
        //private SoundPlayer bathitsound; // Sound for the click.wav

        //// NEW - ALL BELOW
        //private SoundPlayer tomatohitsound; // Sound for the burp.wav
        //struct tomato
        //{
        //    public Rectangle rectangle; // The tomato's bounding rectangle
        //    public bool visible; // Whether the tomato has been hit or not
        //}
        //private int tomatoSpacing = 4; // Spacing between tomatoes.
        //private int tomatoDrawHeight = 0; // Y-coordinate at which the tomatoes are drawn, indicating the upper bound of the game area. In this step it's just 0.
        //private int noOfTomatoes; // Tomatoes number that fit the screen's width
        //private tomato[] tomatoes; // An array of the tomatoes.

        //#endregion

        //#region "Application Start, UPDATED"

        //public Form1()
        //{
        //    InitializeComponent();

        //    cheeseRectangle = new Rectangle(0, 0, Resources.cheese.Width, Resources.cheese.Height);
        //    breadRectangle = new Rectangle((this.ClientSize.Width - Resources.bread.Width) / 2, this.ClientSize.Height / 2, Resources.bread.Width, Resources.bread.Height);

        //    MemoryStream bathitsoundmem = new MemoryStream(Resources.click);
        //    bathitsound = new SoundPlayer(bathitsoundmem);
        //    bathitsound.Load();
        //    bathitsoundmem.Close();

        //    // NEW - ALL BELOW
        //    MemoryStream tomatohitsoundmem = new MemoryStream(Resources.burp);
        //    tomatohitsound = new SoundPlayer(tomatohitsoundmem);
        //    tomatohitsound.Load();
        //    tomatohitsoundmem.Close();

        //    initializeTomatoes();
        //    placeTomatoes();


        //    this.timer1.Enabled = true;
        //}

        //#endregion

        //#region "Painting the Form, UPDATED"

        //private void Form1_Paint(object sender, PaintEventArgs e)
        //{
        //    if (backBuffer == null)
        //    {
        //        backBuffer = new Bitmap(this.ClientSize.Width, this.ClientSize.Height);
        //    }

        //    using (Graphics g = Graphics.FromImage(backBuffer))
        //    {
        //        g.Clear(Color.White);

        //        g.DrawImage(Resources.bread, breadRectangle.X, breadRectangle.Y);
        //        g.DrawImage(Resources.cheese, cheeseRectangle.X, cheeseRectangle.Y);

        //        // NEW 
        //        for (int i = 0; i < tomatoes.Length; i++)
        //        {
        //            if (tomatoes[i].visible)
        //            {
        //                g.DrawImage(Resources.tomato, tomatoes[i].rectangle.X, tomatoes[i].rectangle.Y);
        //            }
        //        }

        //    }
        //    e.Graphics.DrawImage(backBuffer, 0, 0);
        //}

        //protected override void OnPaintBackground(PaintEventArgs e)
        //{
        //    // Don't allow the background to paint. 
        //}

        //#endregion

        //#region "updatePositions() and Timer, UPDATED"

        //private void updatePositions()
        //{

        //    if (goingRight)
        //        cheeseRectangle.X += speed;
        //    else
        //        cheeseRectangle.X -= speed;

        //    if ((cheeseRectangle.X + Resources.cheese.Width) >= this.Width)
        //        goingRight = false;
        //    if (cheeseRectangle.X <= 0)
        //        goingRight = true;

        //    if (goingDown)
        //        cheeseRectangle.Y += speed;
        //    else
        //        cheeseRectangle.Y -= speed;

        //    if ((cheeseRectangle.Y + Resources.cheese.Height) >= this.Height)
        //    {
        //        goingDown = false;
        //    }
        //    if (cheeseRectangle.Y <= 0)
        //    {
        //        goingDown = true;
        //    }

        //    if (keyArgs != null)
        //    {
        //        switch (keyArgs.KeyCode)
        //        {
        //            case Keys.Up:
        //                breadRectangle.Y -= speed + 1;
        //                break;
        //            case Keys.Down:
        //                breadRectangle.Y += speed + 1;
        //                break;
        //            case Keys.Left:
        //                breadRectangle.X -= speed + 1;
        //                break;
        //            case Keys.Right:
        //                breadRectangle.X += speed + 1;
        //                break;
        //        }
        //    }

        //    if (mouseArgs != null)
        //    {
        //        /* To move the bread with the mouse, we have two known facts: the mouse's point and the bread's current location. We'll use the following algebric representation to find where to move the bread: Imagine a circle of a radius equal to "speed", with the bread's center as its center. Imagine also the line connecting the bread's center and the mouse's point. The new location of the bread should be the intersection of the circle and the line (by choosing one of the two intersections). The following are based on the solved equations (by taking the center of the bread as the starting point O of the coordinates). */

        //        double x1 = breadRectangle.X + breadRectangle.Width / 2.0;
        //        double y1 = breadRectangle.Y + breadRectangle.Height / 2.0;
        //        double x2 = mouseArgs.X;
        //        double y2 = mouseArgs.Y;
        //        if (!((Math.Abs(x1 - x2) < 2.0) && (Math.Abs(y1 - y2) < 2.0)))
        //        {
        //            double newx, newy;
        //            newx = (speed + 1) * (x2 - x1) / Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
        //            newy = (y2 - y1) * newx / (x2 - x1);
        //            newx += x1;
        //            newy += y1;
        //            breadRectangle.X = (int)(newx - breadRectangle.Width / 2.0);
        //            breadRectangle.Y = (int)(newy - breadRectangle.Height / 2.0);
        //        }
        //    }

        //    // Dealing with collisions of cheese and bread.
        //    if (goingDown)
        //    {
        //        if (cheeseRectangle.IntersectsWith(breadRectangle))
        //        {
        //            bathitsound.Play();
        //            bool rightIn = breadRectangle.Contains(cheeseRectangle.Right, cheeseRectangle.Bottom);
        //            bool leftIn = breadRectangle.Contains(cheeseRectangle.Left, cheeseRectangle.Bottom);

        //            if (rightIn & leftIn)
        //            {
        //                goingDown = false;
        //            }
        //            else
        //            {
        //                goingDown = false;
        //                if (rightIn)
        //                {
        //                    goingRight = false;
        //                }
        //                if (leftIn)
        //                {
        //                    goingRight = true;
        //                }
        //            }
        //        }
        //    }
        //    // NEW - ALL BELOW
        //    // Dealing with collisions of cheese and tomatoes. They happen only when the cheese is going upwards.
        //    else
        //    {
        //        for (int i = 0; i < tomatoes.Length; i++)
        //        {
        //            if (!tomatoes[i].visible)
        //            {
        //                continue; // if tomato is already destroyed, examine the next tomato in the array.
        //            }
        //            // Check to see if cheese has collided with this tomato
        //            if (cheeseRectangle.IntersectsWith(tomatoes[i].rectangle))
        //            {
        //                tomatohitsound.Play();
        //                // hide the tomato
        //                tomatoes[i].visible = false;
        //                // bounce down
        //                goingDown = true;
        //                break; // only destroy one at a time
        //            }
        //        }
        //    }

        //}

        //private void timer1_Tick(object sender, EventArgs e)
        //{
        //    updatePositions();
        //    this.Invalidate();
        //}

        //#endregion

        //#region "Change Speed"

        //public void changeSpeed(int change)
        //{
        //    previousSpeed = speed;
        //    speed += change;
        //    if (speed > maxSpeed)
        //        speed = maxSpeed;
        //    if (speed < 0)
        //        speed = 0;
        //    if (speed == 0)
        //    {
        //        timer1.Enabled = false;
        //        menuItem1.Text = "Unpause";
        //    }
        //    else
        //    {
        //        timer1.Enabled = true;
        //        menuItem1.Text = "Pause";
        //    }
        //}

        //#endregion

        //#region "Menus"

        //private void menuItem3_Click(object sender, EventArgs e)
        //{
        //    changeSpeed(1);
        //}

        //private void menuItem4_Click(object sender, EventArgs e)
        //{
        //    changeSpeed(-1);
        //}

        //private void menuItem1_Click(object sender, EventArgs e)
        //{
        //    if (speed == 0)
        //    {
        //        changeSpeed(previousSpeed);
        //    }
        //    else
        //    {
        //        changeSpeed(speed * -1);
        //    }
        //}

        //private void menuItem6_Click(object sender, EventArgs e)
        //{
        //    this.Close();
        //    Application.Exit();
        //}

        //#endregion

        //#region "Form's key & mouse events"

        //// NEW
        //private void Form1_KeyDown(object sender, KeyEventArgs e)
        //{
        //    keyArgs = e;
        //}

        //// NEW
        //private void Form1_KeyUp(object sender, KeyEventArgs e)
        //{
        //    keyArgs = null;
        //}

        //// NEW
        //private void Form1_MouseMove(object sender, MouseEventArgs e)
        //{
        //    mouseArgs = e;
        //}

        //// NEW
        //private void Form1_MouseDown(object sender, MouseEventArgs e)
        //{
        //    mouseArgs = e;
        //}

        //// NEW
        //private void Form1_MouseUp(object sender, MouseEventArgs e)
        //{
        //    mouseArgs = null;
        //}


        //#endregion

        //#region "Tomatoes (initialization, placing), NEW"

        //// Called once, at the application start, to set up all the tomatoes.
        //private void initializeTomatoes()
        //{
        //    // Calculate how many tomatoes can fit the screen's width:
        //    noOfTomatoes = (this.ClientSize.Width - tomatoSpacing) / (Resources.tomato.Width + tomatoSpacing);
        //    tomatoes = new tomato[noOfTomatoes];

        //    // Define the bounding rectangle for each tomato
        //    int tomatoX = tomatoSpacing / 2;
        //    for (int i = 0; i < tomatoes.Length; i++)
        //    {
        //        tomatoes[i].rectangle =
        //           new Rectangle(tomatoX, tomatoDrawHeight, Resources.tomato.Width, Resources.tomato.Height);
        //        tomatoX = tomatoX + Resources.tomato.Width + tomatoSpacing;
        //    }
        //}

        //// Called to place a row of un-hit tomatoes.
        //private void placeTomatoes()
        //{
        //    for (int i = 0; i < tomatoes.Length; i++)
        //    {
        //        tomatoes[i].rectangle.Y = tomatoDrawHeight;
        //        tomatoes[i].visible = true;
        //    }
        //}

        //#endregion

        #endregion

        #region "Run 8. New Level."

        //#region "Variables and Declarations, UPDATED"

        //private Rectangle cheeseRectangle; // Position and bounding box for cheese.
        //private Rectangle breadRectangle; // Position and bounding box for bread.

        //private bool goingRight = true; // Whether the cheese is going right or left.
        //private bool goingDown = true; // Whether the cheese is going down or up.
        //private int speed = 3; // Speed of game
        //private int maxSpeed = 7; // Max speed of the game
        //private int previousSpeed; // used by the Pause/Unpause button.

        //private Bitmap backBuffer = null; // Double Buffering

        //private System.Windows.Forms.KeyEventArgs keyArgs = null; // Flag for which key the user holds
        //private System.Windows.Forms.MouseEventArgs mouseArgs = null; // Flag, if the user touches the screen with the stylus.
        //private SoundPlayer bathitsound; // Sound for the click.wav

        //private SoundPlayer tomatohitsound; // Sound for the burp.wav
        //struct tomato
        //{
        //    public Rectangle rectangle; // The tomato's bounding rectangle
        //    public bool visible; // Whether the tomato has been hit or not
        //}
        //private int tomatoSpacing = 4; // Spacing between tomatoes.
        //private int tomatoDrawHeight = 0; // Y-coordinate at which the tomatoes are drawn, indicating the upper bound of the game area. In this step it's just 0.
        //private int noOfTomatoes; // Tomatoes number that fit the screen's width
        //private tomato[] tomatoes; // An array of the tomatoes.

        //// NEW - ALL BELOW
        //private Rectangle messageRectangle; // the message's bounding rectangle.
        //private int messageHeight = 15; // the height of the messageRectangle.
        //private Font messageFont = null; // the font for the message to draw.
        //private SolidBrush messageBrush; // the font's color for the message.
        //private int level = 1; // current level

        //#endregion

        //#region "Application Start, UPDATED"

        //public Form1()
        //{
        //    InitializeComponent();

        //    cheeseRectangle = new Rectangle(0, 0, Resources.cheese.Width, Resources.cheese.Height);
        //    breadRectangle = new Rectangle((this.ClientSize.Width - Resources.bread.Width) / 2, this.ClientSize.Height / 2, Resources.bread.Width, Resources.bread.Height);

        //    MemoryStream bathitsoundmem = new MemoryStream(Resources.click);
        //    bathitsound = new SoundPlayer(bathitsoundmem);
        //    bathitsound.Load();
        //    bathitsoundmem.Close();

        //    MemoryStream tomatohitsoundmem = new MemoryStream(Resources.burp);
        //    tomatohitsound = new SoundPlayer(tomatohitsoundmem);
        //    tomatohitsound.Load();
        //    tomatohitsoundmem.Close();

        //    initializeTomatoes();
        //    placeTomatoes();

        //    // NEW
        //    messageFont = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Regular);
        //    messageBrush = new SolidBrush(Color.Red);
        //    messageRectangle = new Rectangle(0, this.ClientSize.Height - messageHeight, this.ClientSize.Width, messageHeight);

        //    this.timer1.Enabled = true;
        //}

        //#endregion

        //#region "Painting the Form, UPDATED"

        //private void Form1_Paint(object sender, PaintEventArgs e)
        //{
        //    if (backBuffer == null)
        //    {
        //        backBuffer = new Bitmap(this.ClientSize.Width, this.ClientSize.Height);
        //    }

        //    using (Graphics g = Graphics.FromImage(backBuffer))
        //    {
        //        g.Clear(Color.White);

        //        g.DrawImage(Resources.bread, breadRectangle.X, breadRectangle.Y);
        //        g.DrawImage(Resources.cheese, cheeseRectangle.X, cheeseRectangle.Y);

        //        // UPDATED - ALL BELOW
        //        g.DrawString(@"Level: " + level, messageFont, messageBrush, messageRectangle); // Draw current level
        //        bool gotTomato = false; // if there's at least one tomato visible
        //        for (int i = 0; i < tomatoes.Length; i++)
        //        {
        //            if (tomatoes[i].visible)
        //            {
        //                gotTomato = true;
        //                g.DrawImage(Resources.tomato, tomatoes[i].rectangle.X, tomatoes[i].rectangle.Y);
        //            }
        //        }
        //        if (!gotTomato)
        //        {
        //            newLevel();
        //        }

        //    }
        //    e.Graphics.DrawImage(backBuffer, 0, 0);
        //}

        //protected override void OnPaintBackground(PaintEventArgs e)
        //{
        //    // Don't allow the background to paint. 
        //}

        //#endregion

        //#region "updatePositions() and Timer"

        //private void updatePositions()
        //{

        //    if (goingRight)
        //        cheeseRectangle.X += speed;
        //    else
        //        cheeseRectangle.X -= speed;

        //    if ((cheeseRectangle.X + Resources.cheese.Width) >= this.Width)
        //        goingRight = false;
        //    if (cheeseRectangle.X <= 0)
        //        goingRight = true;

        //    if (goingDown)
        //        cheeseRectangle.Y += speed;
        //    else
        //        cheeseRectangle.Y -= speed;

        //    if ((cheeseRectangle.Y + Resources.cheese.Height) >= this.Height)
        //    {
        //        goingDown = false;
        //    }
        //    if (cheeseRectangle.Y <= 0)
        //    {
        //        goingDown = true;
        //    }

        //    if (keyArgs != null)
        //    {
        //        switch (keyArgs.KeyCode)
        //        {
        //            case Keys.Up:
        //                breadRectangle.Y -= speed + 1;
        //                break;
        //            case Keys.Down:
        //                breadRectangle.Y += speed + 1;
        //                break;
        //            case Keys.Left:
        //                breadRectangle.X -= speed + 1;
        //                break;
        //            case Keys.Right:
        //                breadRectangle.X += speed + 1;
        //                break;
        //        }
        //    }

        //    if (mouseArgs != null)
        //    {
        //        /* To move the bread with the mouse, we have two known facts: the mouse's point and the bread's current location. We'll use the following algebric representation to find where to move the bread: Imagine a circle of a radius equal to "speed", with the bread's center as its center. Imagine also the line connecting the bread's center and the mouse's point. The new location of the bread should be the intersection of the circle and the line (by choosing one of the two intersections). The following are based on the solved equations (by taking the center of the bread as the starting point O of the coordinates). */

        //        double x1 = breadRectangle.X + breadRectangle.Width / 2.0;
        //        double y1 = breadRectangle.Y + breadRectangle.Height / 2.0;
        //        double x2 = mouseArgs.X;
        //        double y2 = mouseArgs.Y;
        //        if (!((Math.Abs(x1 - x2) < 2.0) && (Math.Abs(y1 - y2) < 2.0)))
        //        {
        //            double newx, newy;
        //            newx = (speed + 1) * (x2 - x1) / Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
        //            newy = (y2 - y1) * newx / (x2 - x1);
        //            newx += x1;
        //            newy += y1;
        //            breadRectangle.X = (int)(newx - breadRectangle.Width / 2.0);
        //            breadRectangle.Y = (int)(newy - breadRectangle.Height / 2.0);
        //        }
        //    }

        //    // Dealing with collisions of cheese and bread.
        //    if (goingDown)
        //    {
        //        if (cheeseRectangle.IntersectsWith(breadRectangle))
        //        {
        //            bathitsound.Play();
        //            bool rightIn = breadRectangle.Contains(cheeseRectangle.Right, cheeseRectangle.Bottom);
        //            bool leftIn = breadRectangle.Contains(cheeseRectangle.Left, cheeseRectangle.Bottom);

        //            if (rightIn & leftIn)
        //            {
        //                goingDown = false;
        //            }
        //            else
        //            {
        //                goingDown = false;
        //                if (rightIn)
        //                {
        //                    goingRight = false;
        //                }
        //                if (leftIn)
        //                {
        //                    goingRight = true;
        //                }
        //            }
        //        }
        //    }
        //    // Dealing with collisions of cheese and tomatoes.
        //    else
        //    {
        //        for (int i = 0; i < tomatoes.Length; i++)
        //        {
        //            if (!tomatoes[i].visible)
        //            {
        //                continue; 
        //            }
        //            if (cheeseRectangle.IntersectsWith(tomatoes[i].rectangle))
        //            {
        //                tomatohitsound.Play();
        //                tomatoes[i].visible = false;
        //                goingDown = true;
        //                break; 
        //            }
        //        }
        //    }

        //}

        //private void timer1_Tick(object sender, EventArgs e)
        //{
        //    updatePositions();
        //    this.Invalidate();
        //}

        //#endregion

        //#region "Change Speed"

        //public void changeSpeed(int change)
        //{
        //    previousSpeed = speed;
        //    speed += change;
        //    if (speed > maxSpeed)
        //        speed = maxSpeed;
        //    if (speed < 0)
        //        speed = 0;
        //    if (speed == 0)
        //    {
        //        timer1.Enabled = false;
        //        menuItem1.Text = "Unpause";
        //    }
        //    else
        //    {
        //        timer1.Enabled = true;
        //        menuItem1.Text = "Pause";
        //    }
        //}

        //#endregion

        //#region "Menus"

        //private void menuItem3_Click(object sender, EventArgs e)
        //{
        //    changeSpeed(1);
        //}

        //private void menuItem4_Click(object sender, EventArgs e)
        //{
        //    changeSpeed(-1);
        //}

        //private void menuItem1_Click(object sender, EventArgs e)
        //{
        //    if (speed == 0)
        //    {
        //        changeSpeed(previousSpeed);
        //    }
        //    else
        //    {
        //        changeSpeed(speed * -1);
        //    }
        //}

        //private void menuItem6_Click(object sender, EventArgs e)
        //{
        //    this.Close();
        //    Application.Exit();
        //}

        //#endregion

        //#region "Form's key & mouse events"

        //// NEW
        //private void Form1_KeyDown(object sender, KeyEventArgs e)
        //{
        //    keyArgs = e;
        //}

        //// NEW
        //private void Form1_KeyUp(object sender, KeyEventArgs e)
        //{
        //    keyArgs = null;
        //}

        //// NEW
        //private void Form1_MouseMove(object sender, MouseEventArgs e)
        //{
        //    mouseArgs = e;
        //}

        //// NEW
        //private void Form1_MouseDown(object sender, MouseEventArgs e)
        //{
        //    mouseArgs = e;
        //}

        //// NEW
        //private void Form1_MouseUp(object sender, MouseEventArgs e)
        //{
        //    mouseArgs = null;
        //}


        //#endregion

        //#region "Tomatoes (initialization, placing)"

        //private void initializeTomatoes()
        //{
        //    noOfTomatoes = (this.ClientSize.Width - tomatoSpacing) / (Resources.tomato.Width + tomatoSpacing);
        //    tomatoes = new tomato[noOfTomatoes];

        //    int tomatoX = tomatoSpacing / 2;
        //    for (int i = 0; i < tomatoes.Length; i++)
        //    {
        //        tomatoes[i].rectangle =
        //           new Rectangle(tomatoX, tomatoDrawHeight, Resources.tomato.Width, Resources.tomato.Height);
        //        tomatoX = tomatoX + Resources.tomato.Width + tomatoSpacing;
        //    }
        //}

        //private void placeTomatoes()
        //{
        //    for (int i = 0; i < tomatoes.Length; i++)
        //    {
        //        tomatoes[i].rectangle.Y = tomatoDrawHeight;
        //        tomatoes[i].visible = true;
        //    }
        //}

        //#endregion

        //#region "Gameplay - New level, NEW"

        //// Called whenever all the tomatoes have been destroyed.
        //private void newLevel()
        //{
        //    // increase level
        //    level++;
        //    // re-place all tomatoes
        //    placeTomatoes();
        //    // speed things up
        //    if (speed < maxSpeed)
        //    {
        //        changeSpeed(1);
        //    }
        //}

        //#endregion

        #endregion

        #region "Run 9. Save/Load State."

        #region "Variables and Declarations, UPDATED"

        private Rectangle cheeseRectangle; // Position and bounding box for cheese.
        private Rectangle breadRectangle; // Position and bounding box for bread.

        private bool goingRight = true; // Whether the cheese is going right or left.
        private bool goingDown = true; // Whether the cheese is going down or up.
        private int speed = 3; // Speed of game
        private int maxSpeed = 7; // Max speed of the game
        private int previousSpeed; // used by the Pause/Unpause button.

        private Bitmap backBuffer = null; // Double Buffering

        private System.Windows.Forms.KeyEventArgs keyArgs = null; // Flag for which key the user holds
        private System.Windows.Forms.MouseEventArgs mouseArgs = null; // Flag, if the user touches the screen with the stylus.
        private SoundPlayer bathitsound; // Sound for the click.wav

        private SoundPlayer tomatohitsound; // Sound for the burp.wav
        struct tomato
        {
            public Rectangle rectangle; // The tomato's bounding rectangle
            public bool visible; // Whether the tomato has been hit or not
        }
        private int tomatoSpacing = 4; // Spacing between tomatoes.
        private int tomatoDrawHeight = 0; // Y-coordinate at which the tomatoes are drawn, indicating the upper bound of the game area. In this step it's just 0.
        private int noOfTomatoes; // Tomatoes number that fit the screen's width
        private tomato[] tomatoes; // An array of the tomatoes.

        private Rectangle messageRectangle; // the message's bounding rectangle.
        private int messageHeight = 15; // the height of the messageRectangle.
        private Font messageFont = null; // the font for the message to draw.
        private SolidBrush messageBrush; // the font's color for the message.
        private int level = 1; // current level

        // NEW
        private string applicationDirectory; // stores the file path of the application's working directory
        private string stateFileName = "GameState.bin"; // designates the filename of the binary file saving the game's state.

        #endregion

        #region "Application Start, UPDATED"

        public Form1()
        {
            InitializeComponent();

            cheeseRectangle = new Rectangle(0, 0, Resources.cheese.Width, Resources.cheese.Height);
            breadRectangle = new Rectangle((this.ClientSize.Width - Resources.bread.Width) / 2, this.ClientSize.Height / 2, Resources.bread.Width, Resources.bread.Height);

            MemoryStream bathitsoundmem = new MemoryStream(Resources.click);
            bathitsound = new SoundPlayer(bathitsoundmem);
            bathitsound.Load();
            bathitsoundmem.Close();

            MemoryStream tomatohitsoundmem = new MemoryStream(Resources.burp);
            tomatohitsound = new SoundPlayer(tomatohitsoundmem);
            tomatohitsound.Load();
            tomatohitsoundmem.Close();

            initializeTomatoes();
            placeTomatoes();

            messageFont = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Regular);
            messageBrush = new SolidBrush(Color.Red);
            messageRectangle = new Rectangle(0, this.ClientSize.Height - messageHeight, this.ClientSize.Width, messageHeight);

            // NEW - ALL BELOW

            // the following gets the application's working directory path
            applicationDirectory = new Uri(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)).LocalPath;
            if (!(applicationDirectory.EndsWith(@"/") || applicationDirectory.EndsWith(@"\")))
            {
                applicationDirectory += @"/"; // make sure we have a path separater on the end
            }
            loadState();

            this.timer1.Enabled = true;
        }

        #endregion

        #region "Painting the Form"

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (backBuffer == null)
            {
                backBuffer = new Bitmap(this.ClientSize.Width, this.ClientSize.Height);
            }

            using (Graphics g = Graphics.FromImage(backBuffer))
            {
                g.Clear(Color.White);

                g.DrawImage(Resources.bread, breadRectangle.X, breadRectangle.Y);
                g.DrawImage(Resources.cheese, cheeseRectangle.X, cheeseRectangle.Y);

                g.DrawString(@"Level: " + level, messageFont, messageBrush, messageRectangle); // Draw current level
                bool gotTomato = false; // if there's at least one tomato visible
                for (int i = 0; i < tomatoes.Length; i++)
                {
                    if (tomatoes[i].visible)
                    {
                        gotTomato = true;
                        g.DrawImage(Resources.tomato, tomatoes[i].rectangle.X, tomatoes[i].rectangle.Y);
                    }
                }
                if (!gotTomato)
                {
                    newLevel();
                }

            }
            e.Graphics.DrawImage(backBuffer, 0, 0);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            // Don't allow the background to paint. 
        }

        #endregion

        #region "updatePositions() and Timer"

        private void updatePositions()
        {

            if (goingRight)
                cheeseRectangle.X += speed;
            else
                cheeseRectangle.X -= speed;

            if ((cheeseRectangle.X + Resources.cheese.Width) >= this.Width)
                goingRight = false;
            if (cheeseRectangle.X <= 0)
                goingRight = true;

            if (goingDown)
                cheeseRectangle.Y += speed;
            else
                cheeseRectangle.Y -= speed;

            if ((cheeseRectangle.Y + Resources.cheese.Height) >= this.Height)
            {
                goingDown = false;
            }
            if (cheeseRectangle.Y <= 0)
            {
                goingDown = true;
            }

            if (keyArgs != null)
            {
                switch (keyArgs.KeyCode)
                {
                    case Keys.Up:
                        breadRectangle.Y -= speed + 1;
                        break;
                    case Keys.Down:
                        breadRectangle.Y += speed + 1;
                        break;
                    case Keys.Left:
                        breadRectangle.X -= speed + 1;
                        break;
                    case Keys.Right:
                        breadRectangle.X += speed + 1;
                        break;
                }
            }

            if (mouseArgs != null)
            {
                /* To move the bread with the mouse, we have two known facts: the mouse's point and the bread's current location. We'll use the following algebric representation to find where to move the bread: Imagine a circle of a radius equal to "speed", with the bread's center as its center. Imagine also the line connecting the bread's center and the mouse's point. The new location of the bread should be the intersection of the circle and the line (by choosing one of the two intersections). The following are based on the solved equations (by taking the center of the bread as the starting point O of the coordinates). */
                this.menuItem2.Text = "Down";
                double x1 = breadRectangle.X + breadRectangle.Width / 2.0;
                double y1 = breadRectangle.Y + breadRectangle.Height / 2.0;
                double x2 = mouseArgs.X;
                double y2 = mouseArgs.Y;
                if (!((Math.Abs(x1 - x2) < 2.0) && (Math.Abs(y1 - y2) < 2.0)))
                {
                    double newx, newy;
                    newx = (speed + 1) * (x2 - x1) / Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
                    newy = (y2 - y1) * newx / (x2 - x1);
                    newx += x1;
                    newy += y1;
                    breadRectangle.X = (int)(newx - breadRectangle.Width / 2.0);
                    breadRectangle.Y = (int)(newy - breadRectangle.Height / 2.0);
                }
            }
            else
            {
                this.menuItem2.Text = "Up";
            }

            // Dealing with collisions of cheese and bread.
            if (goingDown)
            {
                if (cheeseRectangle.IntersectsWith(breadRectangle))
                {
                    bathitsound.Play();
                    bool rightIn = breadRectangle.Contains(cheeseRectangle.Right, cheeseRectangle.Bottom);
                    bool leftIn = breadRectangle.Contains(cheeseRectangle.Left, cheeseRectangle.Bottom);

                    if (rightIn & leftIn)
                    {
                        goingDown = false;
                    }
                    else
                    {
                        goingDown = false;
                        if (rightIn)
                        {
                            goingRight = false;
                        }
                        if (leftIn)
                        {
                            goingRight = true;
                        }
                    }
                }
            }
            // Dealing with collisions of cheese and tomatoes.
            else
            {
                for (int i = 0; i < tomatoes.Length; i++)
                {
                    if (!tomatoes[i].visible)
                    {
                        continue;
                    }
                    if (cheeseRectangle.IntersectsWith(tomatoes[i].rectangle))
                    {
                        tomatohitsound.Play();
                        tomatoes[i].visible = false;
                        goingDown = true;
                        break;
                    }
                }
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            updatePositions();
            this.Invalidate();
        }

        #endregion

        #region "Change Speed"

        public void changeSpeed(int change)
        {
            previousSpeed = speed;
            speed += change;
            if (speed > maxSpeed)
                speed = maxSpeed;
            if (speed < 0)
                speed = 0;
            if (speed == 0)
            {
                timer1.Enabled = false;
                menuItem1.Text = "Unpause";
            }
            else
            {
                timer1.Enabled = true;
                menuItem1.Text = "Pause";
            }
        }

        #endregion

        #region "Menus"

        private void menuItem3_Click(object sender, EventArgs e)
        {
            changeSpeed(1);
        }

        private void menuItem4_Click(object sender, EventArgs e)
        {
            changeSpeed(-1);
        }

        private void menuItem1_Click(object sender, EventArgs e)
        {
            if (speed == 0)
            {
                changeSpeed(previousSpeed);
            }
            else
            {
                changeSpeed(speed * -1);
            }
        }

        private void menuItem6_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        #endregion

        #region "Form's key & mouse events UPDATED"

        // NEW
        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            saveState();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            keyArgs = e;
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            keyArgs = null;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            mouseArgs = e;
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseArgs = e;
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseArgs = null;
        }


        #endregion

        #region "Tomatoes (initialization, placing)"

        private void initializeTomatoes()
        {
            noOfTomatoes = (this.ClientSize.Width - tomatoSpacing) / (Resources.tomato.Width + tomatoSpacing);
            tomatoes = new tomato[noOfTomatoes];

            int tomatoX = tomatoSpacing / 2;
            for (int i = 0; i < tomatoes.Length; i++)
            {
                tomatoes[i].rectangle =
                   new Rectangle(tomatoX, tomatoDrawHeight, Resources.tomato.Width, Resources.tomato.Height);
                tomatoX = tomatoX + Resources.tomato.Width + tomatoSpacing;
            }
        }

        private void placeTomatoes()
        {
            for (int i = 0; i < tomatoes.Length; i++)
            {
                tomatoes[i].rectangle.Y = tomatoDrawHeight;
                tomatoes[i].visible = true;
            }
        }

        #endregion

        #region "Gameplay - New level"

        private void newLevel()
        {
            level++;
            placeTomatoes();
            if (speed < maxSpeed)
            {
                changeSpeed(1);
            }
        }

        #endregion

        #region "saveState and loadState, NEW"

        // NEW
        private bool saveState()
        {
            Stream stream = null;
            BinaryWriter writer = null;
            try
            {
                stream = File.Open(applicationDirectory + stateFileName, System.IO.FileMode.OpenOrCreate);
                writer = new BinaryWriter(stream);
                writer.Write(cheeseRectangle.X);
                writer.Write(cheeseRectangle.Y);
                writer.Write(breadRectangle.X);
                writer.Write(breadRectangle.Y);
                writer.Write(speed);
                writer.Write(goingDown);
                writer.Write(goingRight);
                foreach (tomato t in tomatoes)
                {
                    writer.Write(t.rectangle.X);
                    writer.Write(t.rectangle.Y);
                    writer.Write(t.visible);
                }
                writer.Write(tomatoDrawHeight);
                writer.Write(level);
            }
            catch
            {
                return false;
            }
            finally
            {
                try
                {
                    writer.Close();
                    stream.Close();
                }
                catch { }
            }
            return true;
        }

        // NEW
        private bool loadState()
        {
            if (!File.Exists(applicationDirectory + stateFileName))
            {
                return false;
            }
            Stream stream = null;
            BinaryReader reader = null;
            try
            {
                stream = File.OpenRead(applicationDirectory + stateFileName);
                reader = new BinaryReader(stream);

                cheeseRectangle.X = reader.ReadInt32();
                cheeseRectangle.Y = reader.ReadInt32();
                breadRectangle.X = reader.ReadInt32();
                breadRectangle.Y = reader.ReadInt32();
                speed = reader.ReadInt32();
                goingDown = reader.ReadBoolean();
                goingRight = reader.ReadBoolean();
                for (int i = 0; i < tomatoes.Length; i++)
                {
                    tomatoes[i].rectangle.X = reader.ReadInt32();
                    tomatoes[i].rectangle.Y = reader.ReadInt32();
                    tomatoes[i].visible = reader.ReadBoolean();
                }
                tomatoDrawHeight = reader.ReadInt32();
                level = reader.ReadInt32();

                reader.Close();
                stream.Close();
            }
            catch
            {
                return false;
            }
            finally
            {
                try
                {
                    if (reader != null) reader.Close();
                }
                catch { }
                try
                {
                    if (stream != null) stream.Close();
                }
                catch { }
            }
            return true;
        }

        #endregion

        #endregion

    }
}