﻿SendSkypeSms v0.0.1
===================

Sends a Short Messaging System message through Skype to a specified receiver. The SMS is not sent immediately when the program loads. A countdown timer starts and when the timer reaches zero, the SMS is sent. Optionally, a log is kept with the SMS messages sent in the past.

Options
=======

The program's options are defined in the SendSkypeSms.exe.config XML file and must be changed before executing the program. The following options are available:

SmsReceiver: The number to which the SMS is to be sent. Cannot be null.
SecondsBeforeSending: The number of seconds given to the countdown timer.
SmsMessage: The text to be sent in the SMS body.
SmsSender: The number which will be presented as the sender of the SMS. This number must be validated in Skype's SMS settings. If empty, Skype's display name is given.
WriteLog: True/False. Update log after each SMS sent?
LogFile: The log's filename. Default: Log.xml.

Requirements
============

Microsoft's .NET Framework 2.0 must be installed on your system.

Skype should be installed with the option to install "Extras Manager". It must be running when the program is executed. The skype user must be logged in. The first time this program tries to send a SMS, you must give it permission through Skype (in the future, this won't be needed again).

Contact
=======

kingherc@gmail.com