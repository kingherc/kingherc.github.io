﻿namespace SendSkypeSms
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmrSms = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.lblRemainingTime = new System.Windows.Forms.Label();
            this.tmrExit = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.lblSmsReceiver = new System.Windows.Forms.Label();
            this.lblSmsSender = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSms = new System.Windows.Forms.TextBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblSmsSent = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tmrSms
            // 
            this.tmrSms.Interval = 1000;
            this.tmrSms.Tick += new System.EventHandler(this.tmrSms_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Remaining time to send SMS:";
            // 
            // lblRemainingTime
            // 
            this.lblRemainingTime.AutoSize = true;
            this.lblRemainingTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.lblRemainingTime.ForeColor = System.Drawing.Color.Red;
            this.lblRemainingTime.Location = new System.Drawing.Point(164, 9);
            this.lblRemainingTime.Name = "lblRemainingTime";
            this.lblRemainingTime.Size = new System.Drawing.Size(66, 24);
            this.lblRemainingTime.TabIndex = 1;
            this.lblRemainingTime.Text = "label2";
            // 
            // tmrExit
            // 
            this.tmrExit.Interval = 3000;
            this.tmrExit.Tick += new System.EventHandler(this.tmrExit_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "SMS will be sent to:";
            // 
            // lblSmsReceiver
            // 
            this.lblSmsReceiver.AutoSize = true;
            this.lblSmsReceiver.Location = new System.Drawing.Point(129, 47);
            this.lblSmsReceiver.Name = "lblSmsReceiver";
            this.lblSmsReceiver.Size = new System.Drawing.Size(80, 13);
            this.lblSmsReceiver.TabIndex = 3;
            this.lblSmsReceiver.Text = "lblSmsReceiver";
            // 
            // lblSmsSender
            // 
            this.lblSmsSender.AutoSize = true;
            this.lblSmsSender.Location = new System.Drawing.Point(129, 70);
            this.lblSmsSender.Name = "lblSmsSender";
            this.lblSmsSender.Size = new System.Drawing.Size(71, 13);
            this.lblSmsSender.TabIndex = 5;
            this.lblSmsSender.Text = "lblSmsSender";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "SMS will be sent from:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "SMS that will be sent:";
            // 
            // txtSms
            // 
            this.txtSms.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSms.Location = new System.Drawing.Point(15, 108);
            this.txtSms.Multiline = true;
            this.txtSms.Name = "txtSms";
            this.txtSms.ReadOnly = true;
            this.txtSms.Size = new System.Drawing.Size(283, 112);
            this.txtSms.TabIndex = 7;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(161, 226);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(137, 31);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblSmsSent
            // 
            this.lblSmsSent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblSmsSent.AutoSize = true;
            this.lblSmsSent.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.lblSmsSent.ForeColor = System.Drawing.Color.Lime;
            this.lblSmsSent.Location = new System.Drawing.Point(12, 227);
            this.lblSmsSent.Name = "lblSmsSent";
            this.lblSmsSent.Size = new System.Drawing.Size(114, 24);
            this.lblSmsSent.TabIndex = 9;
            this.lblSmsSent.Text = "lblSmsSent";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(310, 269);
            this.Controls.Add(this.lblSmsSent);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.txtSms);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblSmsSender);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblSmsReceiver);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblRemainingTime);
            this.Controls.Add(this.label1);
            this.Name = "frmMain";
            this.Text = "Send Skype SMS";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer tmrSms;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblRemainingTime;
        private System.Windows.Forms.Timer tmrExit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblSmsReceiver;
        private System.Windows.Forms.Label lblSmsSender;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSms;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblSmsSent;
    }
}

