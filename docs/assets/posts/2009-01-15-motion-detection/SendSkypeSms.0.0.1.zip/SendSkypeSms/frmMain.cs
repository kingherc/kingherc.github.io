﻿/*
SendSkypeSms, a small application to send a custom Short Messaging System message through Skype
Copyright © 2009 Iraklis Psaroudakis

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace SendSkypeSms
{
    public partial class frmMain : Form
    {
        private int _remainingseconds = 10;
        public int RemainingSeconds
        {
            get
            {
                return _remainingseconds;
            }
            set
            {
                if (value >= 0)
                {
                    _remainingseconds = value;
                    lblRemainingTime.Text = new TimeSpan(0, 0, _remainingseconds).ToString();
                    if (_remainingseconds == 0)
                    {
                        tmrSms.Enabled = false;
                        SendSms();
                        lblSmsSent.Text = "SMS Sent!";
                        tmrExit.Enabled = true;
                    }
                }
            }
        }

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            this.Text = System.Reflection.Assembly.GetExecutingAssembly().FullName;
            RemainingSeconds = Properties.Settings.Default.SecondsBeforeSending;
            lblSmsReceiver.Text = Properties.Settings.Default.SmsReceiver;
            lblSmsSender.Text = Properties.Settings.Default.SmsSender;
            txtSms.Text = Properties.Settings.Default.SmsMessage;
            lblSmsSent.Text = "";
            tmrSms.Enabled = true;
        }

        private void tmrSms_Tick(object sender, EventArgs e)
        {
            RemainingSeconds--;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void tmrExit_Tick(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void SendSms()
        {
            SKYPE4COMLib.SkypeClass objSkype = new SKYPE4COMLib.SkypeClass();
            objSkype.SendSms(Properties.Settings.Default.SmsReceiver, Properties.Settings.Default.SmsMessage, Properties.Settings.Default.SmsSender);
            try
            {
                if (Properties.Settings.Default.WriteLog)
                {
                    XmlDocument xdoc = new XmlDocument();
                    xdoc.Load(Properties.Settings.Default.LogFile);
                    XmlElement xLog = (XmlElement)xdoc.GetElementsByTagName("Log").Item(0);
                    XmlElement xNewEntry = xdoc.CreateElement("Entry");
                    xNewEntry.SetAttribute("UTCtimestamp", DateTime.Now.ToUniversalTime().ToString());
                    xNewEntry.SetAttribute("SmsReceiver", Properties.Settings.Default.SmsReceiver);
                    xNewEntry.SetAttribute("SmsSender", Properties.Settings.Default.SmsSender);
                    xNewEntry.SetAttribute("SmsMessage", Properties.Settings.Default.SmsMessage);
                    xLog.AppendChild(xNewEntry);
                    xdoc.Save(Properties.Settings.Default.LogFile);
                }
            }
            catch (Exception ex)
            {
                ;
            }
        }
    }
}
