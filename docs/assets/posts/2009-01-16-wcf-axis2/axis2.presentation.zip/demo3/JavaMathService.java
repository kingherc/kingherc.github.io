import javax.xml.stream.XMLStreamException;
import org.apache.axiom.om.*;

public class JavaMathService {

	/*
	 * Ta XML requests tha exoun tin exis morfi:
		<axis:element>
			<axis:element>4</axis:element>
			<axis:element>5</axis:element>
		</axis:element>
	 * Ta XML responses tha exoun tin exis morfi:
      	<ns:AddResponse>
         	<ns:return>
            	<dps:AddResponse>
               		<dps:result>9</dps:result>
            	</dps:AddResponse>
        	</ns:return>
      	</ns:AddResponse>
	*/
	
    public OMElement Add(OMElement element) throws XMLStreamException {
        element.build();
        element.detach();

        OMElement firstchild = element.getFirstElement();
        Integer num1 = Integer.parseInt(firstchild.getText());
        OMElement secondchild = (OMElement) firstchild.getNextOMSibling().getNextOMSibling();
        Integer num2 = Integer.parseInt(secondchild.getText());
        
        Integer returntext = num1+num2;
        
        OMFactory fac = OMAbstractFactory.getOMFactory();
        OMNamespace omNs = fac.createOMNamespace("http://diktyakos.programmatismos.samples/xsd", "dps");
        OMElement method = fac.createOMElement("AddResponse", omNs);
        OMElement value = fac.createOMElement("result", omNs);
        value.addChild(fac.createOMText(value, returntext.toString()));
        method.addChild(value);
        return method;
    }

}
