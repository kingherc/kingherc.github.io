
public class JavaMathService implements IJavaMathService {
	
	public int Add(int a, int b) {
		return (a+b);
	}
	
	public int Subtract(int a, int b) {
		return (a-b);
	}
	
	public int Multiply(int a, int b) {
		return (a*b);
	}
	
	public double Divide(int a, int b) throws DivideByZeroException {
		if (b == 0) {
			throw new DivideByZeroException("Cannot divide by zero");
		} else {
			return (((double)a)/b);
		}
	}
	
}
