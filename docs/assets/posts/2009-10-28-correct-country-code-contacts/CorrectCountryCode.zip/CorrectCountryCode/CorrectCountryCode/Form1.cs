﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.WindowsMobile.PocketOutlook;

namespace CorrectCountryCode
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void menuItem1_Click(object sender, EventArgs e)
        {
            OutlookSession session = new OutlookSession();
            ContactCollection contacts = session.Contacts.Items;
            progressBar1.Minimum = 0;
            progressBar1.Maximum = contacts.Count;
            progressBar1.Value = 0;
            String countrycode = textBox2.Text;

            for (int i = 0; i < contacts.Count; i++)
            {
                Contact contact = contacts[i];

                contact.AssistantTelephoneNumber = correctNumber(contact.AssistantTelephoneNumber, countrycode);
                contact.Business2TelephoneNumber = correctNumber(contact.Business2TelephoneNumber, countrycode);
                contact.BusinessFaxNumber = correctNumber(contact.BusinessFaxNumber, countrycode);
                contact.BusinessTelephoneNumber = correctNumber(contact.BusinessTelephoneNumber, countrycode);
                contact.CarTelephoneNumber = correctNumber(contact.CarTelephoneNumber, countrycode);
                contact.CompanyTelephoneNumber = correctNumber(contact.CompanyTelephoneNumber, countrycode);
                contact.Home2TelephoneNumber = correctNumber(contact.Home2TelephoneNumber, countrycode);
                contact.HomeFaxNumber = correctNumber(contact.HomeFaxNumber, countrycode);
                contact.HomeTelephoneNumber = correctNumber(contact.HomeTelephoneNumber, countrycode);
                contact.MobileTelephoneNumber = correctNumber(contact.MobileTelephoneNumber, countrycode);

                contact.Update();
                progressBar1.Value += 1;
            }

            MessageBox.Show("Completed successfully!");
        }

        private String correctNumber(String number, String countrycode)
        {
            String trimmed = number.Trim();
            String nospaces = trimmed.Replace(" ", "");
            String returned = nospaces;

            if (nospaces.CompareTo("") == 0)
            {
                returned = "";
            }
            else if (nospaces.CompareTo("+" + countrycode) == 0)
            {
                returned = "";
            }
            else if (nospaces.StartsWith(countrycode))
            {
                returned = "+" + nospaces;
            }
            else if (nospaces.StartsWith("00" + countrycode))
            {
                returned = "+" + nospaces.Substring(2);
            }
            else if (!nospaces.StartsWith("+"))
            {
                returned = "+" + countrycode + nospaces;
            }

            return returned;
        }

        private void menuItem2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}