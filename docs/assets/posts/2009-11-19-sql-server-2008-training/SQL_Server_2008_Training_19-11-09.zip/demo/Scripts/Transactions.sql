-- Transactions

SELECT * FROM Posts

BEGIN TRAN YearUpdate

	UPDATE dbo.Posts
	SET CreatedOn = DATEADD(YEAR, 19, CreatedOn)
	WHERE YEAR(CreatedOn) = 1990

	SELECT * FROM Posts

ROLLBACK TRAN

SELECT * FROM Posts
