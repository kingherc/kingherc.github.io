-- Enable SQL CLR

USE MyWebsiteDB

EXEC sp_configure 'clr enabled', 1
go

RECONFIGURE
go

-- Add Visual Studio Project
-- and the "spGetBloggerByName"
-- stored procedure.

exec spGetBloggerByName 'kingherc'