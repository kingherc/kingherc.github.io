EXEC msdb.dbo.sp_send_dbmail
    @profile_name = 'Gmail',
    @recipients = 'kingherc@gmail.com',
    @query = 'EXEC	[MyWebsiteDB].[dbo].[spGetPostsPerDay]
		@date1 = NULL,
		@date2 = NULL;' ,
    @subject = 'Total posts today',
    @attach_query_result_as_file = 1 ;
