-- SPATIAL DATA

USE AdventureWorks2008

-- How to declare a geography region
-- This is a region inside the USA
DECLARE @region geography;
SET @region = geography::STGeomFromText('POLYGON((
                      -80.0 50.0, -90.0 50.0,
                      -90.0 25.0, -80.0 25.0,
                      -80.0 50.0))', 4326);
SELECT @region

-- Select all Stores that intersect with the region
SELECT a.[BusinessEntityID]
      ,a.[Name]
      ,c.[AddressLine1]
      ,c.[City]
      ,c.[SpatialLocation]
  FROM [Sales].[Store] a
  JOIN [Person].[BusinessEntityAddress] b ON
         a.[BusinessEntityID] = b.[BusinessEntityID]
  JOIN [Person].[Address] c ON
          b.[AddressID] = c.[AddressID]
  WHERE b.[AddressTypeID] = '3'
AND c.[SpatialLocation].STIntersects(@region) = 1

-- NEW DATE TIME FUNCTIONS

SET NOCOUNT ON
SELECT GETDATE() AS 'GETDATE() datetime'
SELECT GETUTCDATE() AS 'GETUTCDATE() datetime'
SELECT CONVERT(date, GETDATE()) AS 'GETDATE() date'
SELECT CONVERT(date, GETUTCDATE()) AS 'GETUTCDATE() date'
SELECT CONVERT(time, GETDATE()) AS 'GETDATE() time'
SELECT CONVERT(time, GETUTCDATE()) AS 'GETUTCDATE() time'
SELECT SYSDATETIME() AS 'SYSDATETIME() datetime2'
SELECT SYSUTCDATETIME() AS 'SYSUTCDATETIME() datetime2'
SELECT SYSDATETIMEOFFSET() AS 'SYSDATETIMEOFFSET() datetimeoffset'

-- TIME ZONES

DECLARE @DCTime datetimeoffset
DECLARE @SeattleTime datetimeoffset
DECLARE @TimeDiff int

SET @DCTime = '2008-08-08 09:27:00-05:00'  -- D.C. time is UTC -05:00
SET @SeattleTime = '2008-08-08 10:53:00-08:00'  -- Seattle time is UTC -08:00

SET @TimeDiff = DATEDIFF(minute, @DCTime, @SeattleTime)

SELECT @TimeDiff AS 'Difference in Minutes'