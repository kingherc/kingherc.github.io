-- Basic example

IF EXISTS (
  SELECT * 
    FROM INFORMATION_SCHEMA.ROUTINES 
   WHERE SPECIFIC_SCHEMA = N'dbo'
     AND SPECIFIC_NAME = N'spAddition' 
)
   DROP PROCEDURE dbo.spAddition
GO

CREATE PROCEDURE dbo.spAddition
	@p1 int = 0, 
	@p2 int = 0
AS
	SELECT (@p1 + @p2) as Addition
GO

-- Basic Example with Output parameters

IF EXISTS (
  SELECT * 
    FROM INFORMATION_SCHEMA.ROUTINES 
   WHERE SPECIFIC_SCHEMA = N'dbo'
     AND SPECIFIC_NAME = N'spAddition2' 
)
   DROP PROCEDURE dbo.spAddition2
GO

CREATE PROCEDURE dbo.spAddition2
	@p1 int = 0, 
	@p2 int  OUTPUT
AS
	SELECT @p2 = @p2 + @p1
GO

-- Execute basic example 2

DECLARE @p2_output int = 2

EXECUTE dbo.spAddition2 1, @p2_output OUTPUT

SELECT @p2_output
GO

-- Advanced Example

IF EXISTS (
  SELECT * 
    FROM INFORMATION_SCHEMA.ROUTINES 
   WHERE SPECIFIC_SCHEMA = N'dbo'
     AND SPECIFIC_NAME = N'spGetPostsPerDay' 
)
   DROP PROCEDURE dbo.spGetPostsPerDay
GO

CREATE PROCEDURE dbo.spGetPostsPerDay
	@date1 date = NULL, 
	@date2 date = NULL
AS

	IF (@date1 is NULL)
		BEGIN
			SET @date1 = (SELECT CONVERT(date, GETDATE()))
		END
	IF (@date2 is NULL)
		BEGIN
			SET @date2 = (SELECT CONVERT(date, DATEADD(day, 1, GETDATE())))
		END

	CREATE TABLE #dateposts (
		[date] date not null,
		postsnumber int not null
	)

	DECLARE @tempdate date
	SET @tempdate = @date1

	WHILE @tempdate < @date2
	BEGIN
	
		DECLARE @posts int = 0
	
		SELECT @posts = (
			SELECT COUNT(*) AS dateposts FROM Posts
			WHERE CONVERT(date, CreatedOn) = @tempdate
		)
		
		INSERT INTO #dateposts ([date], postsnumber) VALUES (@tempdate, @posts)
		
		SET @tempdate = DATEADD(day,1,@tempDate)
	END

	SELECT * FROM #dateposts

GO