﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;


public partial class StoredProcedures
{
    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void spGetBloggerByName(string name)
    {
        string sql = String.Format("SELECT * FROM Bloggers WHERE Name like '%' + '{0}' + '%'", name.Trim());

        SqlConnection connection = new SqlConnection("context connection=true");
        SqlCommand command = new SqlCommand(sql, connection);
        connection.Open();
        SqlDataReader reader = command.ExecuteReader();
        SqlContext.Pipe.Send("Starting bloggers query");
        SqlContext.Pipe.Send(reader);
        SqlContext.Pipe.Send("Bloggers query complete");
    }
};
