Team name: SimpleMind
=====================
 
Team members:
 
Name: Ismail Oukid
E-mail: ismail.oukid@gmail.com
Institution: TU Dresden
Degree: PhD student in Computer Science
PhD advisor: Wolfgang Lehner
 
Name: Ingo Mueller
E-mail: ingo.mueller@kit.edu
Institution: Karlsruhe Institute of Technology
Degree: PhD student in Computer Science
PhD advisor: Peter Sanders
 
Name: Iraklis Psaroudakis
E-mail: iraklis.psaroudakis@epfl.ch
Institution: École polytechnique fédérale de Lausanne
Degree: PhD student in Computer Science
PhD advisor: Anastasia Ailamaki
 
Third party code used:
======================
 
None, except C++ Boost libraries which are installed on the evaluation machine.
 
Brief description of program:
=============================
 
The program starts off by spawning a reader thread and a total of 7 worker threads (including the main thread).
 
The reader thread continuously reads from the testdriver, so that the read data is available to all worker threads.
 
The 7 worker threads are divided to:
- 5 main worker threads, doing transactions, flushes, validations, and forgets.
- 2 assistant worker threads, doing only validations.
 
Each relation is partitioned into 5 parts, so that the 5 main worker threads can insert data independently into these parts by partitioning on the primary key of the inserted or deleted rows.
Each RelationPartition has a map from primary key -> row pointer, which is the main storage representing the actual state of data.
It also has a history row store, which stores the pointers to modified rows of executed transactions.
The row store has a transaction index (a map from transaction IDs to row IDs in the row store).
The RelationPartition also features a column-store only for the primary key of modified rows.
The transaction index can also be used to point towards this column-store.
 
The 5 main worker threads continously read the incoming messages, executing the transactions immediately. Validations are stored.
 
As soon as a flush message occurs, the 5 main threads enter processFlush(), which constitutes the major part of our program's execution. During flush, the following things happen:
- For each relation, we merge the histories of each RelationPartition into a single RelationHistory structure. This includes updating the single row store with all modified rows (since the last flush), and the single transaction index (a map from transaction IDs to row IDs in the row store).
- Each RelationHistory also has a column-store, which we update at this point. Each column is represented by a single vector, that encapsulates the values of the corresponding row store of the previous step.
- Afterwards, we execute all the validations we stored since the last flush. The 2 assistant threads also take part here, as long as the reader thread is inactive (meaning that the testdriver is waiting for results). Each one of the 7 thread executes a single validation.
-- For each query of a validation, we first check if there is a primary key equality predicate. We either execute it with scanning the row store of the history or the column-store of the corresponding RelationPartition. Filtered results are the consecutively evaluated against remaining predicates.
-- If there is not a primary key predicate, we try to select the most selective equality predicate for scanning the history.  Filtered results are the consecutively evaluated against remaining predicates.
-- If there is no equality predicate, we just scan and evaluate the operator of the first predicate. Filtered results are the consecutively evaluated against remaining predicates.
- After all validations are done, we write out results.
- If a forget had happened since the last flush, we also deleted relevant rows and decrease the transaction indexes.
 
The above is the main loop of our program.
 
There are also several optimization, such as doing intermediate "virtual" flushes, SSE instructions for scans, min-max for each column as a shortcut while evaluating predicates, etc.
