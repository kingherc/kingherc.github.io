#!/bin/bash

DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
export OMP_NUM_THREADS=7
${DIR}/src/reference
