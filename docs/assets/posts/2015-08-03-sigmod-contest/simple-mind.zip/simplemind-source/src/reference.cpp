// SIGMOD Programming Contest 2015
// http://db.in.tum.de/sigmod15contest/
//
// Team name: SimpleMind
//
// Team members:
//
// Name: Ismail Oukid
// E-mail: ismail.oukid@gmail.com
// Institution: TU Dresden
// Degree: PhD student in Computer Science
// PhD advisor: Wolfgang Lehner
//
// Name: Ingo Mueller
// E-mail: ingo.mueller@kit.edu
// Institution: Karlsruhe Institute of Technology
// Degree: PhD student in Computer Science
// PhD advisor: Peter Sanders
//
// Name: Iraklis Psaroudakis
// E-mail: iraklis.psaroudakis@epfl.ch
// Institution: École polytechnique fédérale de Lausanne
// Degree: PhD student in Computer Science
// PhD advisor: Anastasia Ailamaki
//---------------------------------------------------------------------------
//
// Please see README.txt, our attached poster and presentation for an
// overview of our design and more details. Comments in the code
// reference design elements from the poster and the presentation.
//
//---------------------------------------------------------------------------
// This is free and unencumbered software released into the public domain.
//
// Anyone is free to copy, modify, publish, use, compile, sell, or
// distribute this software, either in source code form or as a compiled
// binary, for any purpose, commercial or non-commercial, and by any
// means.
//
// In jurisdictions that recognize copyright laws, the author or authors
// of this software dedicate any and all copyright interest in the
// software to the public domain. We make this dedication for the benefit
// of the public at large and to the detriment of our heirs and
// successors. We intend this dedication to be an overt act of
// relinquishment in perpetuity of all present and future rights to this
// software under copyright law.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
// IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
// ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.
//
// For more information, please refer to <http://unlicense.org/>
//---------------------------------------------------------------------------
#include <cassert>
#include <cstdint>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include <algorithm>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <stack>
#include <thread>
#include <vector>
#include <mutex>

#include <omp.h>
#include <emmintrin.h>
#include <smmintrin.h>
#include <sys/socket.h>

#include <boost/thread/condition_variable.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/container/flat_map.hpp>
#include <boost/thread.hpp>

// These are the additional helper validation threads that do validations only while
// the testdriver and the readstream threads are inactive.
#ifndef THREADSMINUS
#define THREADSMINUS 2
#endif

// To use VTune tasks:
// export LIBRARY_PATH=$LIBRARY_PATH:/opt/intel/vtune_amplifier_xe/lib64
// export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/intel/vtune_amplifier_xe/lib64
// export CPLUS_INCLUDE_PATH=$CPLUS_INCLUDE_PATH:/opt/intel/vtune_amplifier_xe/include
// Pick up the correct line for CXXFLAGS in the Makefile (that includes VTune)
// Compile
// Use VTune to run the program. In the analysis windows, check the
// checkbox "analyze user tasks".
#ifdef USE_VTUNE
#include "ittnotify.h"
__itt_domain* vtuneDomain;
__itt_string_handle* vtuneStringMsg;
__itt_string_handle* vtuneStringTx;
__itt_string_handle* vtuneStringFlushTmp;
__itt_string_handle* vtuneStringFlushResize;
__itt_string_handle* vtuneStringFlushCS;
__itt_string_handle* vtuneStringFlushVal;
__itt_string_handle* vtuneStringFlushClean;
#endif

#define ALWAYS_INLINE inline __attribute__((always_inline))
using namespace std;
using boost::container::flat_map;

//===========================================================================
// Code from "reference" implementation, given by the contest organizers
//===========================================================================

//---------------------------------------------------------------------------
// Wire protocol messages
//---------------------------------------------------------------------------
struct MessageHead {
   /// Message types
   enum Type : uint32_t { Done, DefineSchema, Transaction, ValidationQueries, Flush, Forget };
   /// Total message length, excluding this head
   uint32_t messageLen;
   /// The message type
   Type type;
};
//---------------------------------------------------------------------------
struct DefineSchema {
   /// Number of relations
   uint32_t relationCount;
   /// Column counts per relation, one count per relation. The first column is always the primary key
   uint32_t columnCounts[];
};
//---------------------------------------------------------------------------
struct Transaction {
   /// The transaction id. Monotonic increasing
   uint64_t transactionId;
   /// The operation counts
   uint32_t deleteCount,insertCount;
   /// A sequence of transaction operations. Deletes first, total deleteCount+insertCount operations
   char operations[];
};
//---------------------------------------------------------------------------
struct TransactionOperationDelete {
   /// The affected relation
   uint32_t relationId;
   /// The row count
   uint32_t rowCount;
   /// The deleted values, rowCount primary keyss
   uint64_t keys[];
};
//---------------------------------------------------------------------------
struct TransactionOperationInsert {
   /// The affected relation
   uint32_t relationId;
   /// The row count
   uint32_t rowCount;
   /// The inserted values, rowCount*relation[relationId].columnCount values
   uint64_t values[];
};
//---------------------------------------------------------------------------
struct ValidationQueries {
   enum Result : char { NoConflict = '0', Conflict = '1' };
   /// The validation id. Monotonic increasing
   uint64_t validationId;
   /// The transaction range
   uint64_t from,to;
   /// The query count
   uint32_t queryCount;
   /// The queries
   char queries[];
};
//---------------------------------------------------------------------------
struct Query {
   /// A column description
   struct Column {
      /// Support operations
      enum Op : uint32_t { Equal, NotEqual, Less, LessOrEqual, Greater, GreaterOrEqual };
      /// The column id
      uint32_t column;
      /// The operations
      Op op;
      /// The constant
      uint64_t value;
   };

   /// The relation
   uint32_t relationId;
   /// The number of bound columns
   uint32_t columnCount;
   /// The bindings
   Column columns[];
};
//---------------------------------------------------------------------------
struct Flush {
   /// All validations to this id (including) must be answered
   uint64_t validationId;
};
//---------------------------------------------------------------------------
struct Forget {
   /// Transactions older than that (including) will not be tested for
   uint64_t transactionId;
};

//===========================================================================
// End of code from "reference" implementation
//===========================================================================

// Lock-free linked list implementation
class FreeList
{
private:
    struct FreeListNode
    {
        uint64_t* _pointer;
        FreeListNode* _next;
    };

    FreeListNode* _head;

public:
    FreeList()
    : _head(NULL)
    {};

    void push(uint64_t* pointer)
    {
        FreeListNode* newNode = new FreeListNode();
        newNode->_pointer = pointer;
        while(true)
        {
            FreeListNode* currentHead = _head;
            if (currentHead)
            {
                newNode->_next = currentHead;
            }
            else
            {
                newNode->_next = NULL;
            }
            if (__sync_bool_compare_and_swap(&_head, currentHead, newNode))
            {
                break;
            }
        }
    }

    uint64_t* pull()
    {
        uint64_t* pointer = NULL;
        while(true)
        {
            FreeListNode* currentHead = _head;
            if (!currentHead)
            {
                break;
            }

            if (__sync_bool_compare_and_swap(&_head, currentHead, currentHead->_next))
            {
                pointer = currentHead->_pointer;
                delete currentHead;
                break;
            }
        }

        return pointer;
    }
};

typedef flat_map<uint32_t, uint32_t> TransactionIndex; // Used for the "history index"
static size_t numberOfPartitions = 0;
static size_t numberOfThreads = 0;
static size_t lastForgottenTxId = 0; // last received "forget" transaction id
static size_t lastReallyForgottenTxId = 0; // last cleaned transaction id (<= lastForgottenTxId)
constexpr size_t systemMemSize = 1ULL << 34;
//---------------------------------------------------------------------------
ALWAYS_INLINE uint64_t hashPrimaryKey( uint64_t key, uint64_t relationId )
{
    return ( key + relationId ) % numberOfPartitions;
}
struct RelationPartition
{
    typedef uint64_t* Column;
    typedef uint8_t*  ScanIndex;              // 8-bit fingerprint column

    map<uint64_t, uint64_t*> primaryKeyIndex;
    vector<uint64_t> dataRowStore;            // Physical storage
    FreeList freeList;                        // Free list of entries in dataRowStore
    TransactionIndex txIndex;                 // Maps TXs to historyRowStore entries
    vector<uint64_t*> historyRowStore;        // Points to dataRowStore entries
    vector< set<uint64_t> > distinctValues;   // Sampled distinct values per column

    vector<uint64_t> colMin;                  // Minimum value per column
    vector<uint64_t> colMax;                  // Maximum value per column
    Column primaryColumn;                     // Column with the primary key values
                                              // used to evaluate PK equality predicates
                                              // (can be done on a partition)
    ScanIndex primaryScanIndex;               // 8-bit fingerprint column on PK
    size_t sizeOfPrimaryColumn;
    uint32_t lastTx;                          // Last TX ID processed on this partition

    char padding[64];

    // Add history entry for an insertion or deletion
    void addHistoryEntry( const uint32_t txId, uint64_t* const row, const bool updateTxIndex );
};
struct Relation
{
    size_t numberOfColumns;               // Number of columns in the relation
    size_t relationId;
    vector<RelationPartition> partitions; // Partitions by PK hash
    uint32_t forgetFromRowId;             // Row id from which to forget
    uint32_t forgetToRowId;               // Row id until which to forget
    uint32_t lastMergedTx;                // Last merged transaction
};
static vector<Relation> relations;
//---------------------------------------------------------------------------
struct RelationHistory
{
    typedef uint64_t* Column;
    typedef uint8_t*  ScanIndex;

    size_t relationId;
    size_t numberOfRowsInRowStore;
    size_t numberOfRowsInColumnStore;   // Valid for columnStore columns and scanIndexes
    TransactionIndex  txIndex;          // Maps TXs to rowStore and columnStore entries
    uint64_t**        rowStore;         // Points to dataRowStore entries of partitions
    vector<Column>    columnStore;      // All history data kept in columns
    vector<ScanIndex> scanIndexes;      // 8-bit fingerprint column on all columns

    vector<uint64_t>  colMin;           // Minimum value per column
    vector<uint64_t> colMax;            // Maximum value per column
    uint32_t lastTx;                    // Last transaction merged in this relation history

    // Build column store of history data based on rowStore (part of the merge process)
    void buildColumnStore(const uint32_t numParts, const uint32_t part, const uint32_t sizeOfColumn);
};
static vector<RelationHistory> transactionHistory;
//---------------------------------------------------------------------------
static vector<char> queryResults; // Stores the results of the queries
static size_t valIDOffset = 0;    // Indicates how many queries were processed during the intermediate
                                  // flushed between two "flush" commands
//---------------------------------------------------------------------------
void inline RelationPartition::addHistoryEntry( const uint32_t txId, uint64_t* const row, const bool updateTxIndex )
{
    // If first change made by TX txId, update txIndex
    if( updateTxIndex )
        txIndex.emplace_hint( txIndex.cend(), txId, historyRowStore.size() );

    historyRowStore.push_back(row);
    lastTx = txId;
    primaryColumn[sizeOfPrimaryColumn] = row[1];
    primaryScanIndex[sizeOfPrimaryColumn] = static_cast<uint8_t>( row[1] );
    sizeOfPrimaryColumn++;

    // Update min and max of all columns
    for (size_t j = 0; j < colMax.size(); j++)
    {
        uint64_t val = row[j + 1];
        colMax[j] = max(colMax[j], val);
        colMin[j] = min(colMin[j], val);
    }
}
void inline RelationHistory::buildColumnStore(const uint32_t numParts, const uint32_t part, const uint32_t sizeOfColumn)
{
    uint32_t numCols = columnStore.size();

    // Compute the number of rows that need to be merged in the column store
    uint32_t numRows = numberOfRowsInRowStore - numberOfRowsInColumnStore;

    uint32_t begin_row = (part  ) * numRows / numParts;
    uint32_t end_row   = (part+1) * numRows / numParts;

    uint32_t colIdx = sizeOfColumn + begin_row;
    for ( uint32_t idx = numberOfRowsInColumnStore + begin_row; idx < numberOfRowsInColumnStore + end_row; idx++ )
    {
        uint64_t* rowStoreVal =  rowStore[idx];
        for( size_t i = 0; i < numCols; i++ )
        {
            uint64_t val = rowStoreVal[i+1];
            columnStore[i][colIdx] = val;
            scanIndexes[i][colIdx] = static_cast<uint8_t>( val );
        }
        colIdx++;
    }
}
// ===================================================================================
//                              Scan Routines
// ===================================================================================
// Scan routine that takes a column window and a predicate, and produces a hits vector
template<typename T, const Query::Column::Op op>
size_t Scan(const T* const data, const uint32_t from,
          const uint32_t to, const T queryValue, uint32_t* const hits )
{
    size_t hitsCount = 0;
    for( uint32_t i = from; i < to; i++ )
    {
        bool result;
        T tupleValue = data[i];
        switch (op) {
            case Query::Column::Equal:          result=(tupleValue==queryValue); break;
            case Query::Column::NotEqual:       result=(tupleValue!=queryValue); break;
            case Query::Column::Less:           result=(tupleValue< queryValue); break;
            case Query::Column::LessOrEqual:    result=(tupleValue<=queryValue); break;
            case Query::Column::Greater:        result=(tupleValue> queryValue); break;
            case Query::Column::GreaterOrEqual: result=(tupleValue>=queryValue); break;
        }
        if(result)
        {
            hits[hitsCount] = i;
            hitsCount++;
        }
    }
    return hitsCount;
}

// Specialized scan routine for 8-bit fingerprint columns using SIMD code (Intel SSE)
template<const Query::Column::Op op>
size_t ScanImpl( const uint8_t* const data, const uint32_t from,
               const uint32_t to, const uint8_t queryValue, uint32_t* const hits )
{
    uint32_t i = from;
    size_t idx = 0;
    // If there are less than 16 values to scan, use scalar scan
    // otherwise, use SIMD scan (16 values at a time)
    if( (to - from) >= 16 )
    {
        __m128i msk_cmp = _mm_set_epi8(queryValue, queryValue, queryValue, queryValue,
                queryValue, queryValue, queryValue, queryValue,
                queryValue, queryValue, queryValue, queryValue,
                queryValue, queryValue, queryValue, queryValue );
        for( ; i + 16 <= to; i += 16 )
        {
            __m128i result;
            __m128i tupleValues = _mm_loadu_si128(reinterpret_cast<const __m128i*>(data+i));
            switch( op )
            {
            case Query::Column::Equal:    result = _mm_cmpeq_epi8(tupleValues, msk_cmp); break;
            case Query::Column::NotEqual: result = _mm_xor_si128( _mm_cmpeq_epi8(tupleValues, msk_cmp),
                                                  _mm_set_epi32( 0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff ) ); break;
            default: assert(false); break;
            }
            int bitmask = _mm_movemask_epi8(result);
            if ( bitmask != 0 )
            {
                if ( (bitmask & 0xff) != 0)
                {
                    hits[idx] = i;
                    idx += bitmask & 0x1;
                    hits[idx] = i + 1;
                    idx += (bitmask >> 1) & 0x1;
                    hits[idx] = i + 2;
                    idx += (bitmask >> 2) & 0x1;
                    hits[idx] = i + 3;
                    idx += (bitmask >> 3) & 0x1;
                    hits[idx] = i + 4;
                    idx += (bitmask >> 4) & 0x1;
                    hits[idx] = i + 5;
                    idx += (bitmask >> 5) & 0x1;
                    hits[idx] = i + 6;
                    idx += (bitmask >> 6) & 0x1;
                    hits[idx] = i + 7;
                    idx += (bitmask >> 7) & 0x1;
                }
                if ( (bitmask & 0xff00) != 0)
                {
                    hits[idx] = i + 8;
                    idx += (bitmask >> 8) & 0x1;
                    hits[idx] = i + 9;
                    idx += (bitmask >> 9) & 0x1;
                    hits[idx] = i + 10;
                    idx += (bitmask >> 10) & 0x1;
                    hits[idx] = i + 11;
                    idx += (bitmask >> 11) & 0x1;
                    hits[idx] = i + 12;
                    idx += (bitmask >> 12) & 0x1;
                    hits[idx] = i + 13;
                    idx += (bitmask >> 13) & 0x1;
                    hits[idx] = i + 14;
                    idx += (bitmask >> 14) & 0x1;
                    hits[idx] = i + 15;
                    idx += (bitmask >> 15) & 0x1;
                }
            }
        }
    }
    for( ; i < to; i++ )
    {
        if( data[i] == queryValue )
        {
            hits[idx] = i;
            idx++;
        }
    }
    return idx;
}

// Specialization for 8-bit fingerprint columns
template<>
size_t Scan<uint8_t, Query::Column::Equal>(
        const uint8_t* const data, const uint32_t from,
        const uint32_t to, const uint8_t queryValue, uint32_t* const hits )
{
    return ScanImpl<Query::Column::Equal>( data, from, to, queryValue, hits );
}

// TODO: this is not used yet
template<>
size_t Scan<uint8_t, Query::Column::NotEqual>(
        const uint8_t* const data, const uint32_t from,
        const uint32_t to, const uint8_t queryValue, uint32_t* const hits )
{
    return ScanImpl<Query::Column::NotEqual>( data, from, to, queryValue, hits );
}

// Specialization of the scan for type uint64_t
// Takes into account min and max of the columns in evaluating the predicate
template<typename T>
size_t Scan(const Query::Column::Op op, const T* const data, const uint32_t from,
          const uint32_t to, const uint64_t queryValue, uint32_t* const hits, const uint64_t min, const uint64_t max )
{
    switch (op) {
        case Query::Column::Equal:
            {
                if( queryValue < min || queryValue > max ) return 0;
                return Scan<T, Query::Column::Equal>( data, from, to, queryValue, hits );
            }
            break;
        case Query::Column::NotEqual:
            {
                if( min == max && min == queryValue ) return 0;
                return Scan<T, Query::Column::NotEqual>( data, from, to, queryValue, hits );
            }
            break;
        case Query::Column::Less:
            {
                if( queryValue <= min ) return 0;
                return Scan<T, Query::Column::Less>( data, from, to, queryValue, hits );
            }
            break;
        case Query::Column::LessOrEqual:
            {
                if( queryValue < min ) return 0;
                return Scan<T, Query::Column::LessOrEqual>( data, from, to, queryValue, hits );
            }
            break;
        case Query::Column::Greater:
            {
                if( queryValue >= max ) return 0;
                return Scan<T, Query::Column::Greater>( data, from, to, queryValue, hits );
            }
            break;
        case Query::Column::GreaterOrEqual:
            {
                if( queryValue > max ) return 0;
                return Scan<T, Query::Column::GreaterOrEqual>( data, from, to, queryValue, hits );
            }
            break;
        default: assert(false);
    }
}

// Scan routine that takes a column window and a filter of positions, and produces a vector of hits
template<typename T, const Query::Column::Op op>
size_t Scan(const T* const data, const uint32_t* const filter, const size_t sizeOfFilter,
          const T queryValue, uint32_t* const hits )
{
    size_t hitsCount = 0;
    for( uint32_t filterPos = 0; filterPos < sizeOfFilter; filterPos++ )
    {
        bool result;
        const uint32_t i = filter[filterPos];
        T tupleValue = data[i];
        switch (op) {
            case Query::Column::Equal:          result=(tupleValue==queryValue); break;
            case Query::Column::NotEqual:       result=(tupleValue!=queryValue); break;
            case Query::Column::Less:           result=(tupleValue< queryValue); break;
            case Query::Column::LessOrEqual:    result=(tupleValue<=queryValue); break;
            case Query::Column::Greater:        result=(tupleValue> queryValue); break;
            case Query::Column::GreaterOrEqual: result=(tupleValue>=queryValue); break;
        }
        if(result)
        {
            hits[hitsCount] =  i;
            hitsCount++;
        }
    }
    return hitsCount;
}

// Specialization of the scan routine with filter for type uint64_t
// Takes into account min and max of the columns in evaluating the predicate
template<typename T>
size_t Scan(const Query::Column::Op op, const T* const data,
          const uint32_t* const filter, const size_t sizeOfFilter, const uint64_t queryValue, uint32_t* const hits, const uint64_t min, const uint64_t max )
{
    switch (op) {
        case Query::Column::Equal:
            {
                if( queryValue < min || queryValue > max ) return 0;
                return Scan<T, Query::Column::Equal>( data, filter, sizeOfFilter, queryValue, hits );
            }
            break;
        case Query::Column::NotEqual:
            {
                if( min == max && min == queryValue ) return 0;
                return Scan<T, Query::Column::NotEqual>( data, filter, sizeOfFilter, queryValue, hits );
            }
            break;
        case Query::Column::Less:
            {
                if( queryValue <= min ) return 0;
                return Scan<T, Query::Column::Less>( data, filter, sizeOfFilter, queryValue, hits );
            }
            break;
        case Query::Column::LessOrEqual:
            {
                if( queryValue < min ) return 0;
                return Scan<T, Query::Column::LessOrEqual>( data, filter, sizeOfFilter, queryValue, hits );
            }
            break;
        case Query::Column::Greater:
            {
                if( queryValue >= max ) return 0;
                return Scan<T, Query::Column::Greater>( data, filter, sizeOfFilter, queryValue, hits );
            }
            break;
        case Query::Column::GreaterOrEqual:
            {
                if( queryValue > max ) return 0;
                return Scan<T, Query::Column::GreaterOrEqual>( data, filter, sizeOfFilter, queryValue, hits );
            }
            break;
        default: assert(false);
    }
}
// ===================================================================================
//                          End of: Scan Routines
// ===================================================================================
//---------------------------------------------------------------------------
// Queue of validation jobs for worker threads
static vector<ValidationQueries*> validationQueue;
//---------------------------------------------------------------------------

// Define schema and initialize partitions and relation histories
static void processDefineSchema(const DefineSchema& d)
{
    relations.clear();
    transactionHistory.resize( d.relationCount );
    relations.resize( d.relationCount );
    for( size_t i = 0; i < d.relationCount; i++ )
    {
        // Initialize Relations
        auto& rel = relations[i];
        rel.numberOfColumns = d.columnCounts[i];
        rel.relationId = i;
        rel.lastMergedTx = 0;

        // Initialize RelationPartitions
        rel.partitions.resize( numberOfPartitions );
        for( size_t j = 0; j < numberOfPartitions; j++ )
        {
            auto& part = rel.partitions[j];
            part.dataRowStore.reserve( systemMemSize / sizeof(part.dataRowStore[0]) );
            part.historyRowStore.reserve( systemMemSize / sizeof(part.historyRowStore[0] ) );
            part.distinctValues.resize(rel.numberOfColumns);
            part.colMax.resize(rel.numberOfColumns);
            part.colMin.resize(rel.numberOfColumns);
            part.primaryColumn = reinterpret_cast<uint64_t*>( malloc( systemMemSize ) );
            part.primaryScanIndex = reinterpret_cast<uint8_t*>( malloc( systemMemSize ) );
            part.sizeOfPrimaryColumn = 0;
            part.txIndex.reserve( systemMemSize / sizeof(TransactionIndex::value_type) );
            part.lastTx = 0;
            for( size_t k = 0; k < relations[i].numberOfColumns; k++ )
            {
                part.colMax[k] = 0;
                part.colMin[k] = numeric_limits<uint64_t>::max();
            }
        }

        // Initialize RelationHistories
        auto &relationHistory = transactionHistory[i];
        relationHistory.columnStore.resize(rel.numberOfColumns);
        relationHistory.scanIndexes.resize(rel.numberOfColumns);
        relationHistory.colMax.resize(rel.numberOfColumns);
        relationHistory.colMin.resize(rel.numberOfColumns);
        relationHistory.relationId = i;
        relationHistory.numberOfRowsInRowStore = 0;
        relationHistory.numberOfRowsInColumnStore = 0;
        relationHistory.rowStore = reinterpret_cast<uint64_t**>( malloc( systemMemSize ) );
        relationHistory.txIndex.reserve( systemMemSize / sizeof(TransactionIndex::value_type) );
        relationHistory.lastTx = 0;
        for( size_t j = 0; j < relations[i].numberOfColumns; j++ )
        {
            relationHistory.columnStore[j] = reinterpret_cast<uint64_t*>( malloc( systemMemSize ) );
            relationHistory.scanIndexes[j] = reinterpret_cast<uint8_t*>(  malloc( systemMemSize ) );
            assert( relationHistory.columnStore[j] );
            assert( relationHistory.scanIndexes[j] );
            relationHistory.colMax[j] = 0;
            relationHistory.colMin[j] = numeric_limits<uint64_t>::max();
        }
    }
}
//---------------------------------------------------------------------------

static void processTransaction(const Transaction& t, const size_t partitionFilter )
{
#ifdef USE_VTUNE
    __itt_task_begin(vtuneDomain, __itt_null, __itt_null, vtuneStringTx);
#endif

    const char* reader=t.operations;

    // Delete all indicated tuples
    for (uint32_t index=0;index!=t.deleteCount;++index)
    {
        auto& o=*reinterpret_cast<const TransactionOperationDelete*>(reader);
        bool hasInserted = false; // indicates whether this TX has added a history
                                  // entry in the partition owned by the worker thread
        for (const uint64_t* key=o.keys,*keyLimit=key+o.rowCount;key!=keyLimit;++key)
        {
            // process delete operation only if the corresponding partition is owned
            // by the worker thread, if not, continue
            if( hashPrimaryKey( *key, o.relationId ) != partitionFilter ) continue;

            auto& partition = relations[o.relationId].partitions[ partitionFilter ];
            auto& primaryKeyIndex = partition.primaryKeyIndex;

            // Delete PK and add history entry if PK to delete is found in the relation partition
            auto iter = primaryKeyIndex.find(*key);
            uint64_t*& val = iter->second;
            if (iter != primaryKeyIndex.end() && val) {
                partition.addHistoryEntry( t.transactionId, val, !hasInserted );
                hasInserted = true;
                val = NULL;
            }
        }
        reader+=sizeof(TransactionOperationDelete)+(sizeof(uint64_t)*o.rowCount);
    }

    // Insert new tuples
    for (uint32_t index=0;index!=t.insertCount;++index)
    {
        auto& o=*reinterpret_cast<const TransactionOperationInsert*>(reader);
        bool hasInserted = false;   // indicates whether this TX has added a history
                                    // entry in the partition owned by the worker thread
        auto& rel  = relations[o.relationId];
        auto& part = rel.partitions[partitionFilter];
        auto& dataRowStore = part.dataRowStore;
        auto& freeList     = part.freeList;
        for (const uint64_t* values=o.values,*valuesLimit=values+(o.rowCount*rel.numberOfColumns);values!=valuesLimit;values+=rel.numberOfColumns)
        {
            const uint64_t key = values[0];
            // process inserts operation only if the corresponding partition is owned
            // by the worker thread, if not, continue
            if( hashPrimaryKey( key, o.relationId ) != partitionFilter ) continue;

            // Find slot for new tuples in the list of free (i.e. deleted) row slots
            uint64_t* tuple = freeList.pull();
            if (!tuple)
            {
                tuple = dataRowStore.data() + dataRowStore.size();
                dataRowStore.resize( dataRowStore.size() + 1 + rel.numberOfColumns );
            }

            // Assign value to new tuples
            tuple[0] = 2;  // reference counter (1 for partition, 1 for history)

            // Sampling of distinct values: keep one in a hundred values to keep
            // an estimate of distinct values per column
            if (part.historyRowStore.size() % 100 == 0)
            {
                // Construction of new tuple value by value to allow
                // updating the distinct values set
                for (uint32_t c = 0; c < rel.numberOfColumns; c++)
                {
                    uint64_t val = *(values + c);
                    tuple[c + 1] = val;
                    part.distinctValues[c].insert( val );
                }
            }
            else
            {
                // Bulk-construction of new tuple of "values"
                copy(values, values + rel.numberOfColumns, tuple + 1);
            }

            // Add new tuple to partition and history
            part.primaryKeyIndex[key] = tuple;
            part.addHistoryEntry( t.transactionId, tuple, !hasInserted );
            hasInserted = true;
        }
        reader+=sizeof(TransactionOperationInsert)+(sizeof(uint64_t)*o.rowCount*rel.numberOfColumns);
    }

#ifdef USE_VTUNE
    __itt_task_end(vtuneDomain);
#endif
}
//---------------------------------------------------------------------------

// Evaluate one predicate on a single row
size_t ALWAYS_INLINE EvaluatePredicatesOnRow( const Query::Column* const colBegin, const Query::Column* const colEnd,
        const uint64_t* const row )
{
    for( auto c = colBegin; c != colEnd; ++c )
    {
        bool result = false;
        uint64_t tupleValue = row[c->column + 1];
        switch (c->op)
        {
        case Query::Column::Equal:          result=(tupleValue==c->value); break;
        case Query::Column::NotEqual:       result=(tupleValue!=c->value); break;
        case Query::Column::Less:           result=(tupleValue< c->value); break;
        case Query::Column::LessOrEqual:    result=(tupleValue<=c->value); break;
        case Query::Column::Greater:        result=(tupleValue> c->value); break;
        case Query::Column::GreaterOrEqual: result=(tupleValue>=c->value); break;
        }
        if (!result)
        {
            // No match found
            return 0;
        }
    }
    // Match found
    return 1;
}

// Evaluate predicates on a set of rows indicated by a filter
size_t ALWAYS_INLINE EvaluateSelectRowWise(
        const Query::Column* const colBegin, const Query::Column* const colEnd,
        const RelationPartition& partition,
        uint32_t* filter, size_t filterSize )
{
    // Empty set of predicates
    if( colBegin == colEnd ) return filterSize;

    // Evaluate all predicates on one row at a time
    for ( size_t pos = 0; pos < filterSize; pos++)
    {
        bool result = false;
        uint64_t* row = partition.historyRowStore[filter[pos]];
        for( auto c = colBegin; c != colEnd; ++c )
        {
            uint64_t tupleValue = row[c->column + 1];
            switch (c->op)
            {
            case Query::Column::Equal:          result=(tupleValue==c->value); break;
            case Query::Column::NotEqual:       result=(tupleValue!=c->value); break;
            case Query::Column::Less:           result=(tupleValue< c->value); break;
            case Query::Column::LessOrEqual:    result=(tupleValue<=c->value); break;
            case Query::Column::Greater:        result=(tupleValue> c->value); break;
            case Query::Column::GreaterOrEqual: result=(tupleValue>=c->value); break;
            }
            if (!result)
            {
                break;
            }
        }
        if (result)
        {
            return 1;
        }
    }
    // Match found
    return 0;
}

// Evaluate predicates on a window (i.e. from, to) of rows
size_t ALWAYS_INLINE EvaluateSelectRowWise(
        const Query::Column* const colBegin, const Query::Column* const colEnd,
        uint64_t** const rows,
        uint32_t from, uint32_t to )
{
    // Empty set of predicates
    if( colBegin == colEnd ) return (to - from);

    // Evaluate all predicates on one row at a time
    for ( size_t pos = from; pos < to; pos++)
    {
        bool result = false;
        uint64_t* row = rows[pos];
        for( auto c = colBegin; c != colEnd; ++c )
        {
            uint64_t tupleValue = row[c->column + 1];
            switch (c->op)
            {
            case Query::Column::Equal:          result=(tupleValue==c->value); break;
            case Query::Column::NotEqual:       result=(tupleValue!=c->value); break;
            case Query::Column::Less:           result=(tupleValue< c->value); break;
            case Query::Column::LessOrEqual:    result=(tupleValue<=c->value); break;
            case Query::Column::Greater:        result=(tupleValue> c->value); break;
            case Query::Column::GreaterOrEqual: result=(tupleValue>=c->value); break;
            }
            if (!result)
            {
                break;
            }
        }
        if (result)
        {
            return 1;
        }
    }
    // Match found
    return 0;
}

// Evaluate predicates on a set of rows indicated by a filter
size_t ALWAYS_INLINE EvaluateSelect(
        const Query::Column* const colBegin, const Query::Column* const colEnd,
        const RelationHistory& relationHistory,
        uint32_t* filter, size_t filterSize, uint32_t* hits )
{
    // Predicates are evaluated one column at a time and a filter of hits
    // is propagated to the next predicate
    for( auto c = colBegin; c != colEnd; ++c )
    {
        if( filterSize == 0 ) return 0;
        if( filterSize == 1 )
        {
            uint32_t pos = filter[0];
            return EvaluatePredicatesOnRow( c, colEnd, relationHistory.rowStore[pos] );
        }
        else
        {
            uint64_t min = relationHistory.colMin[c->column];
            uint64_t max = relationHistory.colMax[c->column];
            filterSize = Scan( c->op, relationHistory.columnStore[c->column], filter, filterSize, c->value, hits, min, max );
            swap(filter, hits);
        }
    }
    return filterSize;
}

static bool volatile isValidationPhase = false; // True if worker threads are in the validation phase
                                                // (i.e. processing a flush or an intermediate flush)

// Process one validation (that includes several queries, each including several predicates)
static void processValidationQueries(const ValidationQueries& v)
{
    // infinite buffers for hits and filter arrays
    thread_local uint32_t* hits   = reinterpret_cast<uint32_t*>( malloc(systemMemSize) );
    thread_local uint32_t* filter = reinterpret_cast<uint32_t*>( malloc(systemMemSize) );
    const char* reader=v.queries;
    for (unsigned index=0;index!=v.queryCount;++index) {
        auto& q=*reinterpret_cast<const Query*>(reader);
        reader+=sizeof(Query)+(sizeof(Query::Column)*q.columnCount);
        const auto& distinctColumns = relations[q.relationId].partitions[0].distinctValues;

        // Fast path for equality predicate on primary column
        bool foundPrimaryEquality = false;
        const Query::Column* pColumn = nullptr;
        size_t filterSize = 0;

        // Scan the predicates of the query looking in order for:
        // 1. Equality predicate on PK
        // 2. Equality predicate on a non-PK column
        for (auto c=q.columns,cLimit=q.columns+q.columnCount;c!=cLimit;++c)
        {
            if( c->op == Query::Column::Equal )
            {
                if (pColumn == nullptr || distinctColumns[c->column].size() > distinctColumns[pColumn->column].size())
                {
                    pColumn = c;
                }
                if( c->column == 0 )
                {
                    // Equality predicate on primary key found

                    foundPrimaryEquality = true;

                    auto& partition = relations[q.relationId].partitions[ hashPrimaryKey( c->value, q.relationId ) ];
                    // Translate the TX IDs range into a row Ids range
                    const auto from_it = partition.txIndex.lower_bound(v.from);
                    const auto to_it   = partition.txIndex.upper_bound(v.to);
                    const uint32_t from = from_it == partition.txIndex.end() ? partition.sizeOfPrimaryColumn : from_it->second;
                    const uint32_t to   = to_it   == partition.txIndex.end() ? partition.sizeOfPrimaryColumn : to_it->second;
                    // Short path for narrow rowId windows
                    if( to - from <= 2)
                    {
                        filterSize = EvaluateSelectRowWise( q.columns, q.columns+q.columnCount, partition.historyRowStore.data(), from, to );
                    }
                    else
                    {
                        bool firstColumnDone = false;
                        // Execute first a 8-bit fingerprint scan to filter out most of the values
                        filterSize = Scan<uint8_t>( c->op, partition.primaryScanIndex, from, to, c->value, hits ,
                                partition.colMin[c->column], partition.colMax[c->column] );
                        // The hits array of the previous scan becomes the filter array for the next one
                        swap(hits, filter);

                        // If there are > 2 hits, execute a scan on full values to filter further
                        if( filterSize  > 2 )
                        {
                            filterSize = Scan( c->op, partition.primaryColumn, filter, filterSize, c->value, hits,
                                    partition.colMin[c->column], partition.colMax[c->column] );
                            swap(hits, filter);
                            firstColumnDone = c == q.columns;
                        }
                        // Evaluate the rest of the predicates row wise since equality on PK yields only a handful hits at max.
                        filterSize = EvaluateSelectRowWise( q.columns + firstColumnDone, q.columns+q.columnCount, partition, filter, filterSize );
                    }
                    break;
                }
            }
        }

        // Fast path for equality predicate on other columns
        // The same order of operations as for equality on PK applies
        if( !foundPrimaryEquality && pColumn != nullptr )
        {
            const auto& relationHistory = transactionHistory[q.relationId];
            if( v.from > relationHistory.lastTx ) continue;
            const auto from_it = relationHistory.txIndex.lower_bound(v.from);
            const auto to_it   = relationHistory.txIndex.upper_bound(v.to);
            const uint32_t from = from_it == relationHistory.txIndex.end() ? relationHistory.numberOfRowsInColumnStore : from_it->second;
            const uint32_t to   = to_it   == relationHistory.txIndex.end() ? relationHistory.numberOfRowsInColumnStore : to_it->second;
            if( to - from <= 10)
            {
                filterSize = EvaluateSelectRowWise( q.columns, q.columns+q.columnCount, relationHistory.rowStore, from, to );
            }
            else
            {
                filterSize = Scan<uint8_t>( pColumn->op, relationHistory.scanIndexes[pColumn->column], from, to, pColumn->value, hits,
                        relationHistory.colMin[pColumn->column], relationHistory.colMax[pColumn->column] );
                swap(hits, filter);
                filterSize = EvaluateSelect( q.columns, q.columns+q.columnCount, relationHistory, filter, filterSize, hits );
            }
        }
        // No equality predicate found
        else if( !foundPrimaryEquality )
        {
            const auto& relationHistory = transactionHistory[q.relationId];
            if( v.from > relationHistory.lastTx ) continue;
            const auto from_it = relationHistory.txIndex.lower_bound(v.from);
            const auto to_it   = relationHistory.txIndex.upper_bound(v.to);
            const uint32_t from = from_it == relationHistory.txIndex.end() ? relationHistory.numberOfRowsInColumnStore : from_it->second;
            const uint32_t to   = to_it   == relationHistory.txIndex.end() ? relationHistory.numberOfRowsInColumnStore : to_it->second;

            // This test seems to be somewhat costly and not often beneficial,
            // so it is not done at the first level
            if( q.columnCount == 0 )
            {
                // q.columnCount == 0 represents a 'SELECT *', which is only
                // a conflict, if there is at least one transaction having
                // modified the table, i.e., between from and to.
                // If no transaction modified it, we need to check the other queries.
                if( from == to ) continue;
                queryResults[v.validationId-valIDOffset] = ValidationQueries::Conflict;
                return;
            }

            bool oneColumnDone   = false;
            bool firstColumnDone = false;

            // "Fast path" for range predicates
            // We avoid starting with inequality predicates because
            // the hits array represents usually > 90% of the data
            // Search for predicates other than inequality
            for (auto c=q.columns,cLimit=q.columns+q.columnCount;c!=cLimit;++c)
            {
                if ( c->op != Query::Column::NotEqual )
                {
                    filterSize = Scan( c->op, relationHistory.columnStore[c->column], from, to, c->value, hits,
                                        relationHistory.colMin[c->column], relationHistory.colMax[c->column] );
                    oneColumnDone = true;
                    if( c == q.columns ) firstColumnDone = true;
                    break;
                }
            }
            // In the worst case, just scan the first column
            if (!oneColumnDone)
            {
                filterSize = Scan( q.columns->op, relationHistory.columnStore[q.columns->column], from, to, q.columns->value, hits,
                                        relationHistory.colMin[q.columns->column], relationHistory.colMax[q.columns->column] );
                firstColumnDone = true;
            }

            // Remaining columns
            swap(hits, filter);
            filterSize = EvaluateSelect( q.columns + firstColumnDone, q.columns+q.columnCount, relationHistory, filter, filterSize, hits );
        }
        if( filterSize != 0 )
        {
            // A conflict was found
            queryResults[v.validationId-valIDOffset] = ValidationQueries::Conflict;
            return;
        }
    }
}
//---------------------------------------------------------------------------
static bool volatile flushOccured = false; // if a flush message occurred
static bool volatile isReaderActive = true; // whether the reader thread is working
static boost::barrier* tempBarrier = NULL; // barrier for the helper validation threads
static boost::barrier* largeBarrier = NULL; // barrier for all (main + helper) validation threads
static boost::barrier* smallBarrier = NULL; // barrier for main validation threads
static mutex* exitLock = NULL; // to make exit() safe across threads
static uint64_t columnStoreCounter = 0; // counter for building the column-store during processFlush()
static uint64_t validationCounter = 0; // counter for doing validations during processFlush()

// Processes a flush
// The parameter shows if it is a real flush or a virtual intermediate flush.
// Mind that the "main" validation threads do all phases of processFlush
// (including the "merge", "building the column-store", "validations", and "forget" phases),
// while the "helper" validation threads do only the "validations" phase.
static void processFlush(const bool intermediate = false)
{
    // Synchronize main validation threads
    smallBarrier->wait();

    // Initialization
    size_t numIterations = relations.size() * numberOfPartitions;
    if (omp_get_thread_num() == 0) // only the master thread executes this
    {
        columnStoreCounter = 0;
        validationCounter = 0;
    }

#ifdef USE_VTUNE
    __itt_task_begin(vtuneDomain, __itt_null, __itt_null, vtuneStringFlushTmp);
#endif

    // Merging phase
    // For each relation, merge the history of each partition into
    // a single row-store history.

	// Parallelize per relation
    size_t mergeStep = numberOfPartitions;
    for( size_t i = omp_get_thread_num(); i < relations.size(); i+=mergeStep )
    {
        auto& rel = relations[i];
        auto& relationHistory = transactionHistory[i];

        // Build temporary index of new transactions, save iterators to txIndex partitions
        vector<TransactionIndex::iterator> txIterators;
        vector<TransactionIndex::iterator> txEndIterators;
        TransactionIndex newTxIndex;
        for( size_t j = 0; j < numberOfPartitions; j++ )
        {
            auto &part = rel.partitions[j];
            const auto it_from = part.txIndex.upper_bound( rel.lastMergedTx );
            txIterators.push_back( it_from );
            txEndIterators.push_back( part.txIndex.end() );
            newTxIndex.insert( it_from, part.txIndex.end() );
            relationHistory.lastTx = max(relationHistory.lastTx, part.lastTx);

            for( size_t k = 0; k < relationHistory.colMax.size(); k++)
            {
				// Fix max/min for all the relation
                relationHistory.colMax[k] = max(relationHistory.colMax[k], part.colMax[k]);
                relationHistory.colMin[k] = min(relationHistory.colMin[k], part.colMin[k]);
            }
        }

        // Insert temporary index into txIndex, updating rowStore accordingly
        for( auto& tx : newTxIndex )
        {
		    // Insert to single transaction index
            auto it = relationHistory.txIndex.insert( tx );
            if( it.second )
            {
                it.first->second = relationHistory.numberOfRowsInRowStore;
            }
            for( size_t j = 0; j < numberOfPartitions; j++ )
            {
                if( txIterators[j] == txEndIterators[j] ) continue;
                if( txIterators[j]->first != tx.first ) continue;

                auto &part = rel.partitions[j];

                const auto newTx = txIterators[j]++;
                const size_t from = newTx->second;
                const size_t to   = txIterators[j] == txEndIterators[j] ? part.historyRowStore.size() : txIterators[j]->second;

                // Append to row-store
                for( size_t idx = from; idx < to; idx++ )
                {
                    uint64_t* const row = part.historyRowStore[ idx ];
                    relationHistory.rowStore[relationHistory.numberOfRowsInRowStore++] = row;
                }
            }
        }
        const auto last = relationHistory.txIndex.rbegin();
        if ( last != relationHistory.txIndex.rend() )
        {
            rel.lastMergedTx = last->first;
        }
    }
#ifdef USE_VTUNE
    __itt_task_end(vtuneDomain);
#endif

    // Synchronize main validation threads
    smallBarrier->wait();

#ifdef USE_VTUNE
    __itt_task_begin(vtuneDomain, __itt_null, __itt_null, vtuneStringFlushCS);
#endif

    // Building the column-store phase

    while(true)
    {
        uint64_t value = columnStoreCounter;
        if (value >= numIterations)
        {
            break;
        }
        
        // Parallelize per partition
        if (__sync_bool_compare_and_swap(&columnStoreCounter, value, value+1))
        {
            uint32_t relId = value / numberOfPartitions;
            auto& relationHistory = transactionHistory[relId];
            uint64_t partid = value - (relId * numberOfPartitions);
            // Transfer row-store history to column-store
            relationHistory.buildColumnStore( numberOfPartitions, partid, relationHistory.numberOfRowsInColumnStore );
        }
    }

#ifdef USE_VTUNE
    __itt_task_end(vtuneDomain);
#endif

    // Synchronize main validation threads
    smallBarrier->wait();

    if (omp_get_thread_num() == 0)
    {
        for (uint32_t relId=0; relId < relations.size(); relId++)
        {
            auto& relationHistory = transactionHistory[relId];
            relationHistory.numberOfRowsInColumnStore = relationHistory.numberOfRowsInRowStore;
        }
        // Resize query results
        queryResults.resize(validationQueue.size(), ValidationQueries::NoConflict);
    }

    // Synchronize main validation threads
    smallBarrier->wait();

#ifdef USE_VTUNE
    __itt_task_begin(vtuneDomain, __itt_null, __itt_null, vtuneStringFlushVal);
#endif

    // Validations phase
    // Parallelize per validation

    uint64_t maxValidations = validationQueue.size();

    while(true)
    {
        // If the reader is not active, the helper validation threads will help
        // and we need to trigger them as well.
        if ((omp_get_thread_num() == 0) && !isReaderActive && !isValidationPhase)
        {
            isValidationPhase = true;
            // Signal the barrier for the helper validation threads
            tempBarrier->wait();
        }
    
        uint64_t value = validationCounter;
        if (value >= maxValidations)
        {
            break;
        }
        if (__sync_bool_compare_and_swap(&validationCounter, value, value+1))
        {
            processValidationQueries( *(validationQueue[value]) );
        }
    }

#ifdef USE_VTUNE
    __itt_task_end(vtuneDomain);
#endif

    // Synchronize main validation threads
    smallBarrier->wait();
    
    // If the helper validation threades helped, we need to synchronize all threads
    if( isValidationPhase )
    {
        // Synchronize all validation threads
        largeBarrier->wait();

        if( omp_get_thread_num() == 0 )
        {
            isValidationPhase = false;
        }
    }

    if (omp_get_thread_num() == 0)
    {
        valIDOffset += validationQueue.size();
        validationQueue.clear();

        // Signal flush at the latest moment possible = just before the result is written
        if (!intermediate) flushOccured = true;

        cout.write( queryResults.data(), queryResults.size() );
        cout.flush();
        queryResults.clear();
    }

#ifdef USE_VTUNE
    __itt_task_begin(vtuneDomain, __itt_null, __itt_null, vtuneStringFlushClean);
#endif

    // Forget phase
    // For each transaction in the forgotten transaction range, 
    // and for each referenced relation, we decrease the usage counter of 
    // referenced rows. If the counter of a row reaches 0, we can mark the row as 
    // free and available for re-usage.

    // Parallelize per relation
    for (size_t relationId = 0; relationId < relations.size(); relationId++)
    {
        size_t partNum = omp_get_thread_num();
        auto &part = relations[relationId].partitions[partNum];
        auto from_it = part.txIndex.lower_bound(lastReallyForgottenTxId + 1);
        auto to_it   = part.txIndex.upper_bound(lastForgottenTxId);

        part.txIndex.erase(from_it, to_it); // delete unnecessary transaction ranges from each partition
    }

    if (!intermediate)
    {

        // Parallelize per relation. Find row ranges in the history to "forget".
        for( size_t relationId = omp_get_thread_num(); relationId < relations.size(); relationId += numberOfPartitions )
        {
            auto& relationHistory = transactionHistory[relationId];
            auto& rel = relations[relationId];

            size_t firstTxToReallyForget = lastReallyForgottenTxId + 1;
            size_t lastTxToReallyForget  = lastForgottenTxId;

            if (lastTxToReallyForget >= firstTxToReallyForget) // safety check
            {
                auto from_it = relationHistory.txIndex.lower_bound(firstTxToReallyForget);
                auto to_it   = relationHistory.txIndex.upper_bound(lastTxToReallyForget);

                // Mark row range to use later on
                rel.forgetFromRowId = from_it == relationHistory.txIndex.end() ? relationHistory.numberOfRowsInColumnStore : from_it->second;
                rel.forgetToRowId   = to_it   == relationHistory.txIndex.end() ? relationHistory.numberOfRowsInColumnStore : to_it->second;

                relationHistory.txIndex.erase(from_it, to_it); // delete unnecessary transaction ranges
            }
        }

        // Synchronize main validation threads
        smallBarrier->wait();

        if (omp_get_thread_num() == 0)
        {
            lastReallyForgottenTxId = lastForgottenTxId;
        }

        // Really forget rows, partition by primary key
        for (size_t relationId = 0; relationId < relations.size(); relationId++)
        {
            size_t myRelationId = (relationId + omp_get_thread_num()) % relations.size();
            auto& relationHistory = transactionHistory[myRelationId];
            auto& rel = relations[myRelationId];

            uint32_t& from = rel.forgetFromRowId;
            uint32_t& to = rel.forgetToRowId;
            const uint32_t numRows = (to >= from) ? (to - from) : 0;
            // Parallelize per partition
            const uint32_t fromPart = ((size_t)omp_get_thread_num()) * numRows / numberOfPartitions;
            const uint32_t toPart = ((size_t)omp_get_thread_num() + 1) * numRows / numberOfPartitions;

            for (size_t r = fromPart; r < toPart; r++)
            {
                uint64_t*& tuple = relationHistory.rowStore[r];
                if (tuple)
                {
                    for(;;)
                    {
                        uint64_t oldvalue = tuple[0]; // Get usage counter of row
                        if (oldvalue > 0)
                        {
                            // Decrease usage counter of row
                            if (__sync_bool_compare_and_swap(tuple, oldvalue, oldvalue-1))
                            {
                                if (oldvalue == 1)
                                {
                                    // Push it in the free list of the partition from which the tuple was originally allocated
                                    rel.partitions[ hashPrimaryKey( tuple[1], myRelationId ) ].freeList.push(tuple);
                                }
                                break;
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                    tuple = NULL;
                }
            }
        }
    }

    if (!intermediate)
    {
        // Synchronize main validation threads
        smallBarrier->wait();
    }

#ifdef USE_VTUNE
    __itt_task_end(vtuneDomain);
#endif

}
//---------------------------------------------------------------------------
static void processForget(const Forget& f)
{
    if (omp_get_thread_num() == 0)
    {
        lastForgottenTxId = f.transactionId;
    }
}
//---------------------------------------------------------------------------
static const size_t inputStreamBufferSize = 1 << 14;
static size_t volatile inputStreamPos = 0;
static char* volatile inputStream;
// If READER_BUSY_WAIT is set, the reader thread uses a non-blocking mode for receiving a stream from the test driver.
#define READER_BUSY_WAIT

// Reader thread
void readInputStream()
{
#ifdef USE_VTUNE
    __itt_thread_set_name("readstream");
#endif

    inputStream = reinterpret_cast<char*>( malloc(systemMemSize) );
    if( !inputStream ) throw std::bad_alloc();
    ssize_t s;
#ifdef READER_BUSY_WAIT
    // While receiving the stream, be in non-blocking mode. Only after while of not receiving anything get into blocking mode.
    uint64_t counter = 0;
    while( (s = recv( STDIN_FILENO, inputStream + inputStreamPos, inputStreamBufferSize, isReaderActive ? MSG_DONTWAIT : 0 ) ) != 0 )
    {
        if( s < 0 )
        {
            if( errno == EAGAIN || errno == EWOULDBLOCK )
            {
                counter++;
                if (counter > 1000) // Now enter blocking mode and mark myself as not active (so that the "helper" validation threads can operate)
                {
                    isReaderActive = false;
                }
                continue;
            }
            else
            {
                assert( false );
            }
        }
#else  // READER_BUSY_WAIT
     while( (s = recv( STDIN_FILENO, inputStream + inputStreamPos, inputStreamBufferSize, 0 )) > 0 )
     {
#endif  // READER_BUSY_WAIT

        counter = 0;
        isReaderActive = true;

        // Handle flush
        if( flushOccured )
        {
            // The first call to recv after the flush occurred is done with the
            // old value of inputStreamPos, which should be 0 after the flush,
            // so we copy the data from this call to recv to the beginning of
            // the input buffer before proceeding.
            memcpy( inputStream + 0, inputStream + inputStreamPos, s );
            inputStreamPos = 0;
            flushOccured = false;
        }
        inputStreamPos += s;
    }
    while ( !flushOccured );
    flushOccured = false;
}

// Version of reader that reads from a file
const char* inputFileName;
void readInputFile()
{
#ifdef USE_VTUNE
    __itt_thread_set_name("readfile");
#endif

    std::ifstream ifs( inputFileName, ios::in | ios::binary );
    if( !ifs )
    {
        cerr << "read error" << endl;
        abort();
    }

    inputStream = reinterpret_cast<char*>( malloc(systemMemSize) );
    if( !inputStream ) throw std::bad_alloc();

    while( true )
    {
        // Read length and process input
        int32_t len;
        ifs.read( (char*)&len, sizeof(int32_t) );
        if( ifs.eof() ) break;

        // Read messages (they always end with Flush or Done)
        ifs.read(inputStream, len);
        inputStreamPos = len;

        // Wait for flush and handle it
        while( !flushOccured );
        inputStreamPos = 0;
        flushOccured = false;

        // Skip result reference data
        ifs.read( (char*)&len, sizeof(int32_t) );
        ifs.seekg( len, ios_base::cur );
    }
}
//---------------------------------------------------------------------------
int main( int argc, char** argv )
{
    // Start reader thread
    thread reader;
    if( argc == 2 )
    {
        // Handle input from file
        inputFileName = argv[1];
        reader = thread( readInputFile );
    }
    else
    {
        // Handle input from stdin
        reader = thread( readInputStream );
    }

#ifdef USE_VTUNE
    {
        vtuneDomain = __itt_domain_create("SimpleMinds");
        vtuneStringMsg = __itt_string_handle_create("Msg");
        vtuneStringTx = __itt_string_handle_create("Tx");
        vtuneStringFlushTmp = __itt_string_handle_create("FlTmp");
        vtuneStringFlushResize = __itt_string_handle_create("FlResize");
        vtuneStringFlushCS = __itt_string_handle_create("FlCS");
        vtuneStringFlushVal = __itt_string_handle_create("FlVal");
        vtuneStringFlushClean = __itt_string_handle_create("FlClean");
    }
#endif

    volatile bool didSchema = false;

    // Processing threads
    #pragma omp parallel
    {
#ifdef USE_VTUNE
        char threadName[255];
        sprintf(threadName, "omp%d", omp_get_thread_num());
        __itt_thread_set_name(threadName);
#endif

        #pragma omp single
        {
            numberOfThreads = omp_get_num_threads();
            numberOfPartitions = numberOfThreads - THREADSMINUS;
            largeBarrier = new boost::barrier(numberOfThreads);
            smallBarrier = new boost::barrier(numberOfPartitions);
            tempBarrier = new boost::barrier(THREADSMINUS + 1);
            exitLock = new mutex();
        }

        size_t bytesRead = 0;
        size_t intermediateFlushThreshold = 1 << 22; // Threshold of bytes that trigger an intermediate virtual flush
        size_t inputStreamRead = 0;
        while (true)
        {
            size_t threadNum = (size_t) omp_get_thread_num();
            if (threadNum >= numberOfPartitions) // helper validation thread
            {
                while (true)
                {
                    tempBarrier->wait();

                    // While active, the helper validation thread
                    // just does validations. Nothing else.
                    
                    const uint64_t maxValidations = validationQueue.size();
                    while(true)
                    {
                        uint64_t idx = validationCounter;
                        if (idx >= maxValidations) break;
                        if (__sync_bool_compare_and_swap(&validationCounter, idx, idx+1))
                        {
                            processValidationQueries( *(validationQueue[idx]) );
                        }
                    }

                    largeBarrier->wait();
                }
                continue;
            }

            if (bytesRead >= intermediateFlushThreshold)
            {
                // Intermediate flushes are good to build/merge histories,
                // while transactions are being received and transactions can afterwards be
                // processed without waiting for them.
                processFlush(true);
                bytesRead = 0;
                intermediateFlushThreshold *= 2;
            }
            // Wait until we can read the message head
            while( inputStreamRead + sizeof(MessageHead) > inputStreamPos );

            // Retrieve the message
            const MessageHead &head = *reinterpret_cast<MessageHead*>( inputStream + inputStreamRead );
            inputStreamRead += sizeof(MessageHead);
            bytesRead += sizeof(MessageHead);
            // Wait until we can read the message body
            while( inputStreamRead + head.messageLen > inputStreamPos );

            // And interpret it
            switch (head.type) {
                case MessageHead::Done:
                    {
                        std::lock_guard<std::mutex> lock(*exitLock);
                        exit(0);
                    }
                    break;
                case MessageHead::DefineSchema:
                    if (omp_get_thread_num() == 0)
                    {
                        processDefineSchema( *reinterpret_cast<DefineSchema*>( inputStream + inputStreamRead ) );
                        didSchema = true;
                    }
                    else
                    {
                        while(!didSchema);
                    }
                    break;
                case MessageHead::Transaction:
                    {
                        processTransaction( *reinterpret_cast<Transaction*>( inputStream + inputStreamRead ), threadNum );
                    }
                    break;
                case MessageHead::ValidationQueries:
                    if (omp_get_thread_num() == 0)
                    {
                        validationQueue.push_back(reinterpret_cast<ValidationQueries*>( inputStream + inputStreamRead ));
                    }
                    break;
                case MessageHead::Flush:
                {
                    // Reset input pointer and remember how much was left
                    const uint32_t remain = inputStreamPos - (inputStreamRead + head.messageLen);
                    inputStreamRead = 0;
                    bytesRead = 0;
                    intermediateFlushThreshold = 1 << 22;

                    // Process flush (this triggers new data to be sent)
                    processFlush();

                    // If the flush message was not the last message, we assume that
                    // it is followed by a Done and exit the program
                    if ( remain != 0 )
                    {
                        std::lock_guard<std::mutex> lock(*exitLock);
                        inputStreamRead += head.messageLen;
                        assert( reinterpret_cast<MessageHead*>( inputStream + inputStreamRead )->type == MessageHead::Done );
                        exit(0);
                    }

                    // Wait for flush to be handled by reader thread
                    while( flushOccured );

                    // Restart main loop
                    continue;
                }
                break;
                case MessageHead::Forget: processForget( *reinterpret_cast<Forget*>( inputStream + inputStreamRead ) ); break;
                default: cerr << "malformed message" << endl; abort(); // crude error handling, should never happen
            }
            inputStreamRead += head.messageLen;
            bytesRead += head.messageLen;
        }
    }
}
//---------------------------------------------------------------------------
