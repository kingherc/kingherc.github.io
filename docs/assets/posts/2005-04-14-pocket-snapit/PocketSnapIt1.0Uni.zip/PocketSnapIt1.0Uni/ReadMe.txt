Pocket SnapIt 1.0
by Kingherc
(Original universal distribution package)
=========================================

The real ReadMe file for this program is the file ReadMe.htm in the folder Pocket SnapIt which can be viewed with any browser off-line.

The licence for this program can be found in the text file Licence.txt in the folder Pocket SnapIt.

The Gnu General Public Licence can be found in the text file GPL.txt in the folder Pocket SnapIt.

The executable program and folder is Pocket SnapIt. It works on any .NET Compact Framework Device (PCs, Smartphones and Pocket PCs).

More information or contact at http://www34.brinkster.com/kingherc/.

31/1/07: The website's address changed from http://www34.brinkster.com/kingherc/ to http://kherc.brinkster.net/.