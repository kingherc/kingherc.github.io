'Pocket SnapIt
'Copyright (C) 2004,2005 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

'In addition, as a special exception, Iraklis Psaroudakis gives permission to link the code of this program with the XrossOne Mobile GDI+ library (or with modified versions of XrossOne Mobile GDI+ that use the same license as XrossOne Mobile GDI+), and distribute linked combinations including the two. You must obey the GNU General Public License in all respects for all of the code used other than XrossOne Mobile GDI+. If you modify this file, you may extend this exception to your version of the file, but you are not obligated to do so. If you do not wish to do so, delete this exception statement from your version.

'VBC Compiler Command Arguments:
'"C:\WINDOWS\Microsoft.NET\Framework\v1.1.4322\vbc.exe" /out:"C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket SnapIt\Pocket SnapIt.exe" /win32icon:"C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket SnapIt\PocketSnapIt.ico" /target:winexe /r:"C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket SnapIt\XrossOne.Drawing.dll" /r:System.Windows.Forms.dll,System.dll,System.Drawing.dll,Microsoft.VisualBasic.dll,System.Xml.dll /imports:System.Text,System.IO,System.Drawing,System.Drawing.Imaging,System.Runtime.InteropServices,System.Xml /main:PSI.Main /netcf /sdkpath:"C:\Program Files\Microsoft .NET Compact Framework 1.0 SP2\CompactFrameworkSDK" /res:"C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket SnapIt\Main.resources" /recurse:"C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket SnapIt\*.vb"

'CabWizSP (used to make setup .cab file for smartphones):
'"C:\Program Files\Windows CE Tools\wce420\SMARTPHONE 2003\Tools\CabWizSp.exe" "C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket SnapIt\Install.inf" /err "C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket SnapIt\InstallError.txt"

'CabWiz (used to make setup .cab file for pocket pcs):
'"C:\Program Files\Windows CE Tools\wce420\POCKET PC 2003\Tools\CabWiz.exe" "C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket SnapIt\Install.inf" /err "C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket SnapIt\InstallErrorPPC.txt"

Imports System
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Resources
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.IO
Imports PSI.cAPI.Tools
Imports PSI.cAPI
Imports XrossOne.Drawing
Imports PSI.Tools
Imports PSI.Tools.cTools

Namespace PSI

    Public Class Main
        Inherits System.Windows.Forms.Form

#Region "Variables & Controls"

        Public Shared ReadOnly WorkingSize As Size = Screen.PrimaryScreen.WorkingArea.Size 'The Working Size of the screen/form for the device.
        Public Shared ReadOnly ScreenSize As Size = Screen.PrimaryScreen.Bounds.Size 'The size of the primary screen.
        Public Shared ReadOnly WorkingDir As String = CType(New Uri(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)), Uri).LocalPath 'The directory where the application is running.
        Public Shared TitleFont As Font
        Public Shared UsualFont As Font
        Public Const MyOptionsFile As String = "Options.xml"
        Public Const MyName As String = "Pocket SnapIt"
        Public Const MyVersion As String = "1.0"
        Public Const MyWebsite As String = "http://www34.brinkster.com/kingherc/"

        Private QuickExecution As Boolean = False
        Private ClosedOnce As Boolean = False
        Private myhWnd As IntPtr
        Public Shared hResources As New Hashtable

        Private ops As Options
        Public ReadOnly Property CurrentOptions() As Options
            Get
                Return ops
            End Get
        End Property

        Friend WithEvents mnMain As New MainMenu
        Friend WithEvents mnAction As New MenuItem
        Friend WithEvents mnMenu As New MenuItem
        Friend WithEvents mnExit As New MenuItem
        Friend WithEvents mnHelp As New MenuItem
        Friend WithEvents mnAbout As New MenuItem
        Friend WithEvents mnLicence As New MenuItem
        Friend WithEvents mnOptions As New MenuItem

        Friend WithEvents tmrListen As New Timer
        Friend WithEvents tmrConsecutive As New Timer
        Friend WithEvents tmrShow As New Timer

        Friend pbIcon As New PictureBox
        Friend pbPSI As New PictureBox

        Friend lblModeTlt As New Label
        Friend lblMode As New Label
        Friend lblIntervalTlt As New Label
        Friend lblInterval As New Label
        Friend lblSnapBtnTlt As New Label
        Friend lblSnapBtn As New Label
        Friend lblSoundTlt As New Label
        Friend lblSound As New Label
        Friend lblImmTlt As New Label
        Friend lblImm As New Label
        Friend lblSaveTlt As New Label
        Friend txtSave As New TextBox

#End Region

#Region "Main"

        Shared Sub Main(ByVal CmdArgs() As String)
            Dim ops As New Options
            ops.LoadDefaults()

            If File.Exists(WorkingDir & "\" & MyOptionsFile) Then
                ops = New Options(WorkingDir & "\" & MyOptionsFile)
            End If

            If CmdArgs.Length > 0 Then
                ops.LoadDefaults()
                Dim i As Integer
                For i = 0 To CmdArgs.Length - 1
                    Dim m As String = CmdArgs(i)
                    If Not m.IndexOf("-?") = -1 Then
                        MessageBox.Show("Usage of command arguments: -[command]:[example value] (explanation)" & vbCrLf & "-m1 (mode 1) -m2 (mode 2) -con (consecutive snaps) -int:100 (100 milliseconds consecutive timer interval) -frx:1 (fixed region's x) -fry:1 (y) -frw (width) -frh (height) -sd:""C:/"" (storage directory) -sp:""Snap Shot"" (file prefix) -sn:3 (filename min digits) -ps (play capture sound) -snapbtn:40 (virtual key value -search msdn- of the snapshot button) -listen (starts listening for snapshot button immediately) -snapim (starts capture process immediately)" & vbCrLf & "e.g. ""Pocket SnapIt.exe"" -m1 -sd:""C:/"" -sp:""Snap Shot"" -sn:3 -ps -snapbtn:40 -snapim")
                    End If
                    If Not m.IndexOf("-m1") = -1 Then
                        ops.Mode = 1
                    End If
                    If Not m.IndexOf("-m2") = -1 Then
                        ops.Mode = 2
                    End If
                    If Not m.IndexOf("-con") = -1 Then
                        ops.Consecutive = True
                    End If
                    If Not m.IndexOf("-int:") = -1 Then
                        ops.ConsecutiveInterval = m.Substring(5)
                    End If
                    If Not m.IndexOf("-frx:") = -1 Then
                        ops.FixedRegion.X = m.Substring(5)
                    End If
                    If Not m.IndexOf("-fry:") = -1 Then
                        ops.FixedRegion.Y = m.Substring(5)
                    End If
                    If Not m.IndexOf("-frw:") = -1 Then
                        ops.FixedRegion.Width = m.Substring(5)
                    End If
                    If Not m.IndexOf("-frh:") = -1 Then
                        ops.FixedRegion.Height = m.Substring(5)
                    End If
                    If Not m.IndexOf("-sd:") = -1 Then
                        ops.StoreDirectory = m.Substring(4)
                    End If
                    If Not m.IndexOf("-sp:") = -1 Then
                        ops.StorePrefix = m.Substring(4)
                    End If
                    If Not m.IndexOf("-sn:") = -1 Then
                        ops.StoreDigits = m.Substring(4)
                    End If
                    If Not m.IndexOf("-ps") = -1 Then
                        ops.DoPlaySound = True
                    End If
                    If Not m.IndexOf("-snapbtn:") = -1 Then
                        ops.SnapButton = m.Substring(9)
                    End If
                    If Not m.IndexOf("-listen") = -1 Then
                        ops.StartImmediately = True
                    End If
                    If Not m.IndexOf("-snapim") = -1 Then
                        ops.SnapImmediately = True
                    End If
                Next
            End If

            If Not ops.IsValid Then
                cTools.Options.ThowInvalidError
                ops.LoadDefaults()
            End If

            Application.Run(New Main(ops))
        End Sub

#End Region

#Region "Initialization"

        Private Sub LoadUpResources()
            Dim iStream As Stream = System.Reflection.Assembly.GetExecutingAssembly.GetManifestResourceStream(System.Reflection.Assembly.GetExecutingAssembly.GetManifestResourceNames(0))
            Dim rr As New System.Resources.ResourceReader(iStream)
            Dim id As IDictionaryEnumerator = rr.GetEnumerator()
            While id.MoveNext()
                hResources.Add(id.Key, id.Value)
            End While
        End Sub

        Sub New(ByVal opsExt As cTools.Options)
            MyBase.New()

            Me.ops = opsExt
            Init()

            If ops.SnapImmediately Then
                QuickExecution = True
                mnAction_Click(Me, EventArgs.Empty)
                StartCapture()
            ElseIf ops.StartImmediately Then
                QuickExecution = True
                mnAction_Click(Me, EventArgs.Empty)
                HideMe()
            End If
        End Sub

        Private Sub Init()
            LoadUpResources()

            'Customizations
            TitleFont = New Font(FontFamily.GenericSansSerif, 12, FontStyle.Bold)
            UsualFont = New Font(FontFamily.GenericSansSerif, 10, FontStyle.Regular)
            If IsPC() Then
                Me.ClientSize = New Size(225, 275)
                UsualFont = New Font(FontFamily.GenericSansSerif, 8, FontStyle.Regular)
            ElseIf IsPocketPC() Then
                TitleFont = New Font(FontFamily.GenericSansSerif, 16, FontStyle.Bold)
            ElseIf IsSmartphone() Then

            Else
                Me.ClientSize = New Size(225, 275)
            End If
            Me.FormBorderStyle = FormBorderStyle.FixedSingle
            Me.MaximizeBox = False

            'Controls

            mnExit.Text = "E&xit"
            mnAbout.Text = "&About"
            mnLicence.Text = "&Licence"
            mnHelp.Text = "&Help"
            mnAction.Text = "&Start"
            mnMenu.Text = "&Menu"
            mnOptions.Text = "&Options"
            mnMenu.MenuItems.Add(mnOptions)
            Dim mnSep As New MenuItem
            mnSep.Text = "-"
            mnMenu.MenuItems.Add(mnSep)
            mnMenu.MenuItems.Add(mnLicence)
            mnMenu.MenuItems.Add(mnAbout)
            mnMenu.MenuItems.Add(mnHelp)
            Dim mnSep2 As New MenuItem
            mnSep2.Text = "-"
            mnMenu.MenuItems.Add(mnSep2)
            mnMenu.MenuItems.Add(mnExit)
            mnMain.MenuItems.Add(mnAction)
            mnMain.MenuItems.Add(mnMenu)

            pbIcon.Image = hResources("icoApp")
            pbIcon.Size = pbIcon.Image.Size
            Me.Controls.Add(pbIcon)

            pbPSI.Image = hResources("PocketSnapIt")
            pbPSI.Size = pbPSI.Image.Size
            Me.Controls.Add(pbPSI)

            Dim ffcolor As Color = SystemColors.WindowText
            If ffcolor.ToArgb = Me.BackColor.ToArgb Then
            	ffcolor = Color.FromArgb(255 - Me.BackColor.R, 255 - Me.BackColor.G, 255 - Me.BackColor.B)
            End If

            lblMode.Font = UsualFont
            lblMode.ForeColor = ffcolor
            lblMode.TextAlign = ContentAlignment.TopRight
            Me.Controls.Add(lblMode)
            lblModeTlt.Font = UsualFont
            lblModeTlt.Text = "Mode:"
            lblModeTlt.ForeColor = ffcolor
            Me.Controls.Add(lblModeTlt)

            lblInterval.Font = UsualFont
            lblInterval.ForeColor = ffcolor
            lblInterval.TextAlign = ContentAlignment.TopRight
            Me.Controls.Add(lblInterval)
            lblIntervalTlt.Font = UsualFont
            lblIntervalTlt.Text = "Interval:"
            lblIntervalTlt.ForeColor = ffcolor
            Me.Controls.Add(lblIntervalTlt)

            lblSnapBtn.Font = UsualFont
            lblSnapBtn.ForeColor = ffcolor
            lblSnapBtn.TextAlign = ContentAlignment.TopRight
            Me.Controls.Add(lblSnapBtn)
            lblSnapBtnTlt.Font = UsualFont
            lblSnapBtnTlt.Text = "SnapButton:"
            lblSnapBtnTlt.ForeColor = ffcolor
            Me.Controls.Add(lblSnapBtnTlt)

            lblSound.Font = UsualFont
            lblSound.ForeColor = ffcolor
            lblSound.TextAlign = ContentAlignment.TopRight
            Me.Controls.Add(lblSound)
            lblSoundTlt.Font = UsualFont
            lblSoundTlt.Text = "Sound:"
            lblSoundTlt.ForeColor = ffcolor
            Me.Controls.Add(lblSoundTlt)

            lblImm.Font = UsualFont
            lblImm.ForeColor = ffcolor
            lblImm.TextAlign = ContentAlignment.TopRight
            Me.Controls.Add(lblImm)
            lblImmTlt.Font = UsualFont
            lblImmTlt.Text = "Immediately:"
            lblImmTlt.ForeColor = ffcolor
            Me.Controls.Add(lblImmTlt)

            txtSave.Font = UsualFont
            txtSave.ReadOnly = True
            Me.Controls.Add(txtSave)
            lblSaveTlt.Font = UsualFont
            lblSaveTlt.Text = "Save next at:"
            lblSaveTlt.ForeColor = ffcolor
            Me.Controls.Add(lblSaveTlt)

            tmrShow.Interval = 1500
            tmrShow.Enabled = False

            Me.Text = MyName & " " & MyVersion.ToString
            Me.Menu = mnMain
        End Sub

#End Region

#Region "Application Routines"

        Private Sub Main_Resize(ByVal s As Object, ByVal e As EventArgs) Handles MyBase.Resize
            pbIcon.Location = New Point(ClientSize.Width - pbIcon.Width - 3, 3)
            pbPSI.Location = New Point((pbIcon.Left - 3) / 2 - pbPSI.Width / 2, (pbIcon.Top + pbIcon.Height / 2) - pbPSI.Height / 2)
        End Sub

        Private Sub Main_Load(ByVal s As Object, ByVal e As EventArgs) Handles MyBase.Load
            DescriptionOps()
        End Sub

        Private Sub Main_Activated(ByVal s As Object, ByVal e As EventArgs) Handles MyBase.Activated
'            If (QuickExecution Or tmrListen.Enabled) And Not ClosedOnce Then
'                HideMe()
'                ClosedOnce = True
'            End If
			If myhWnd.ToInt32 = 0 Then
				myhWnd = Win.GetActiveWindow
			End If
            If QuickExecution And Not ClosedOnce Then
                HideMe()
                ClosedOnce = True
            End If
        End Sub

#End Region

#Region "Capture Process"

        Private Sub HideMe()
            Me.Hide()
            Me.SendToBack()
        End Sub

        Private Sub ShowMe()
            Me.Show()
            Me.BringToFront()
            Win.SetForegroundWindow(myhWnd)
        End Sub

        Public Sub StartCapture()
            If ops.Consecutive Then
                cTools.PlayExclamationSound()
                tmrConsecutive.Interval = ops.ConsecutiveInterval
                tmrConsecutive.Enabled = True
            Else
                SnapIt()
            End If
        End Sub

        Private Sub tmrConsecutive_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrConsecutive.Tick
            SnapIt()
        End Sub

        Private Sub SnapIt()
            Dim hdc As IntPtr = Win.GetDC(Nothing), bmpx As BitmapX, r As Rectangle
            If ops.Mode = 1 Then
                r = New Rectangle(0, 0, ScreenSize.Width, ScreenSize.Height)
            ElseIf ops.Mode = 2 Then
                r = ops.FixedRegion
            End If
            bmpx = cTools.GetScreenshot(hdc, r)
            If ops.DoPlaySound Then
                cTools.PlayNotificationSound()
            End If
            If Not Directory.Exists(ops.StoreDirectory) Then
                Directory.CreateDirectory(ops.StoreDirectory)
            End If
            Dim fs As New FileStream(returnNextFilename, FileMode.Create)
            bmpx.Save(fs)
            fs.Close()
            DescriptionOps()
        End Sub

        Private Sub tmrListen_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrListen.Tick
            If Not Win.GetAsyncKeyState(ops.SnapButton) = 0 Then
                If Not tmrShow.Enabled Then
                    tmrShow.Enabled = True
                End If
                If tmrConsecutive.Enabled Then
                    cTools.PlayExclamationSound()
                    tmrConsecutive.Enabled = False
                Else
                    StartCapture()
                End If
            End If
        End Sub

        Private Sub mnAction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAction.Click
            If Not tmrListen.Enabled Then
                tmrListen.Interval = 150
                tmrListen.Enabled = True
                mnAction.Text = "Stop"
                'HideMe()
            Else
                tmrListen.Enabled = False
                If tmrConsecutive.Enabled Then
                    tmrConsecutive.Enabled = False
                End If
                mnAction.Text = "Start"
            End If
        End Sub

        Private Function returnNextFilename() As String
            Dim fi As Integer = 1, flname As String = ""
            Do
                Dim istr As String = fi
                If istr.Length < ops.StoreDigits Then
                    Do
                        istr = 0 & istr
                    Loop Until istr.Length >= ops.StoreDigits
                End If
                Dim strfilename As String = ops.StorePrefix & istr
                If Not File.Exists(ops.StoreDirectory & "\" & strfilename & ".bmp") Then
                    flname = ops.StoreDirectory & "\" & strfilename & ".bmp"
                    Exit Do
                Else
                    fi += 1
                End If
            Loop
            Return flname
        End Function

#End Region

#Region "Miscellanious"

        Private Sub tmrShow_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrShow.Tick
            If Not Win.GetAsyncKeyState(ops.SnapButton) = 0 Then
                ClosedOnce = True
                ShowMe()
            End If
            tmrShow.Enabled = False
        End Sub

        Private Sub mnOptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnOptions.Click
            Dim fo As New fOptions(Me, ops)
            If fo.ShowDialog = DialogResult.OK Then
                ops = fo.SelectedOptions
                DescriptionOps()
            End If
        End Sub

        Private Sub Main_Closed(ByVal s As Object, ByVal e As EventArgs) Handles MyBase.Closed
            If Not QuickExecution Then
                ops.ToXml.Save(WorkingDir & "\Options.xml")
            End If
        End Sub

        Private Sub mnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnExit.Click
            Me.Close()
            Application.Exit()
        End Sub

        Private Sub DescriptionOps()
            Dim g As Graphics = Graphics.FromImage(New Bitmap(10, 10))

            lblModeTlt.Location = New Point(3, pbIcon.Bottom + 2)
            lblModeTlt.Size = g.MeasureString(lblModeTlt.Text, lblModeTlt.Font).ToSize
            lblMode.Location = New Point(lblModeTlt.Right + 3, lblModeTlt.Top)
            lblMode.Size = New Size(ClientSize.Width - 2 - lblMode.Left, lblModeTlt.Height)

            If ops.Mode = 1 Then
                lblMode.Text = "Full-screen"
            ElseIf ops.Mode = 2 Then
                lblMode.Text = "Region (" & ops.FixedRegion.X & "," & ops.FixedRegion.Y & "," & ops.FixedRegion.Width & "," & ops.FixedRegion.Height & ")"
            End If

            If ops.Consecutive Then
                lblIntervalTlt.Visible = True
                lblInterval.Visible = True
                lblIntervalTlt.Location = New Point(lblModeTlt.Left, lblModeTlt.Bottom + 2)
                lblIntervalTlt.Size = g.MeasureString(lblIntervalTlt.Text, lblIntervalTlt.Font).ToSize
                lblInterval.Location = New Point(lblIntervalTlt.Right + 3, lblIntervalTlt.Top)
                lblInterval.Size = New Size(ClientSize.Width - 2 - lblInterval.Left, lblIntervalTlt.Height)

                lblInterval.Text = ops.ConsecutiveInterval & " ms"

                lblSnapBtnTlt.Location = New Point(lblModeTlt.Left, lblIntervalTlt.Bottom + 2)
            Else
                lblIntervalTlt.Visible = False
                lblInterval.Visible = False
                lblSnapBtnTlt.Location = New Point(lblModeTlt.Left, lblModeTlt.Bottom + 2)
            End If

            lblSnapBtnTlt.Size = g.MeasureString(lblSnapBtnTlt.Text, lblSnapBtnTlt.Font).ToSize
            lblSnapBtn.Location = New Point(lblSnapBtnTlt.Right + 3, lblSnapBtnTlt.Top)
            lblSnapBtn.Size = New Size(ClientSize.Width - 2 - lblSnapBtn.Left, lblSnapBtnTlt.Height)

            Dim b As String
            If ops.SnapButton = Win.VirtualKey.VK_SNAPSHOT Or ops.SnapButton = Win.VirtualKey.SP_SHARP Or ops.SnapButton = Win.VirtualKey.PPC_VOLUMEUP Or ops.SnapButton = Win.VirtualKey.VK_DOWN Then
                If ops.SnapButton = Win.VirtualKey.VK_SNAPSHOT Then
                    b = "PrintScreen (" & Win.VirtualKey.VK_SNAPSHOT & ")"
                ElseIf ops.SnapButton = Win.VirtualKey.SP_SHARP Then
                    b = "# (" & Win.VirtualKey.SP_SHARP & ")"
                ElseIf ops.SnapButton = Win.VirtualKey.PPC_VOLUMEUP Then
                    b = "Volume-Up (" & Win.VirtualKey.PPC_VOLUMEUP & ")"
                ElseIf ops.SnapButton = Win.VirtualKey.VK_DOWN Then
                    b = "Down (" & Win.VirtualKey.VK_DOWN & ")"
                End If
            Else
                b = "(" & ops.SnapButton & ")"
            End If
            lblSnapBtn.Text = b

            lblSoundTlt.Location = New Point(lblModeTlt.Left, lblSnapBtnTlt.Bottom + 2)
            lblSoundTlt.Size = g.MeasureString(lblSoundTlt.Text, lblSoundTlt.Font).ToSize
            lblSound.Location = New Point(lblSoundTlt.Right + 3, lblSoundTlt.Top)
            lblSound.Size = New Size(ClientSize.Width - 2 - lblSound.Left, lblSoundTlt.Height)

            If ops.DoPlaySound Then
                lblSound.Text = "On"
                'lblSound.ForeColor = Color.Green
            Else
                lblSound.Text = "Off"
                'lblSound.ForeColor = Color.Red
            End If

            lblImmTlt.Location = New Point(lblModeTlt.Left, lblSoundTlt.Bottom + 2)
            lblImmTlt.Size = g.MeasureString(lblImmTlt.Text, lblImmTlt.Font).ToSize
            lblImm.Location = New Point(lblImmTlt.Right + 3, lblImmTlt.Top)
            lblImm.Size = New Size(ClientSize.Width - 2 - lblImm.Left, lblImmTlt.Height)

            If ops.StartImmediately Or ops.SnapImmediately Then
                lblImm.Visible = True
                lblImmTlt.Visible = True

                If ops.StartImmediately And ops.SnapImmediately Then
                    lblImm.Text = "Start/Listen && Snap"
                Else
                    If ops.StartImmediately Then
                        lblImm.Text = "Start/Listen"
                    ElseIf ops.SnapImmediately Then
                        lblImm.Text = "Snap"
                    End If
                End If

                lblSaveTlt.Location = New Point(lblModeTlt.Left, lblImmTlt.Bottom + 2)
            Else
                lblImm.Visible = False
                lblImmTlt.Visible = False

                lblSaveTlt.Location = New Point(lblModeTlt.Left, lblSoundTlt.Bottom + 2)
            End If

            lblSaveTlt.Size = New Size(lblSound.Right - lblSoundTlt.Left, g.MeasureString(lblSaveTlt.Text, lblSaveTlt.Font).ToSize.Height)
            txtSave.Location = New Point(lblModeTlt.Left, lblSaveTlt.Bottom + 2)
            txtSave.Width = ClientSize.Width - 2 - txtSave.Left

            txtSave.Text = """" & returnNextFilename() & """"

            g = Nothing
        End Sub

        Private Sub mnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnHelp.Click
            cTools.ShowHelp(Me, "General Help", "*Note: The ReadMe file of the program can be found in the directory of the program (usually Program Files\Pocket SnapIt) and contains more help." & vbcrlf & vbcrlf & "With this program, you are able to take screenshots of the screen of your PC or your device. You can either take single screenshots, or consecutive screenshots. The screenshots can be full-screen or of a fixed region of the screen. The screenshots are stored in .bmp uncompressed format in a directory. You can also choose a filename prefix." & vbCrLf & vbCrLf & "Here's how the program works: Upon pressing Start, the program hides itself and 'listens' for the capture button. When you press the capture button, you can either take a single screenshot or start the capture process for automatically taking screenshots (you can define this in the options). In the second case, you can stop the process by clicking again the capture button." & vbCrLf & "To stop listening for the button, click Stop." & vbcrlf & "If you hide the program window, you can reshow it by pressing the capture button for more than 1.5 seconds." & vbCrLf & vbCrLf & "If you wish to change the current options, click Menu > Options. Each screen will help its own help which you can read for more info.")
        End Sub

        Private Sub mnLicence_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnLicence.Click
            cTools.ShowHelp(Me, "Licence", "Pocket SnapIt" & vbcrlf & "Copyright (C) 2004,2005 Iraklis Psaroudakis" & vbCrLf & vbCrLf & "This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version." & vbCrLf & vbCrLf & "This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details." & vbCrLf & vbCrLf & "You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA" & vbCrLf & vbCrLf & "In addition, as a special exception, Iraklis Psaroudakis gives permission to link the code of this program with the XrossOne Mobile GDI+ library (or with modified versions of XrossOne Mobile GDI+ that use the same license as XrossOne Mobile GDI+), and distribute linked combinations including the two. You must obey the GNU General Public License in all respects for all of the code used other than XrossOne Mobile GDI+. If you modify this file, you may extend this exception to your version of the file, but you are not obligated to do so. If you do not wish to do so, delete this exception statement from your version.")
        End Sub

        Private Sub mnAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAbout.Click
            System.Windows.Forms.MessageBox.Show(MyName & " " & MyVersion & vbCrLf & "by Kingherc" & vbCrLf & MyWebsite & vbCrLf & vbCrLf & "This program uses XrossOne Mobile GDI+ library. Icons used are free and originate from Lokas Software (via www.EggHeadCafe.com)." & vbCrLf & vbCrLf & "This application is under the GNU GPL licence. See licence for more info.", "About", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1)
        End Sub

#End Region

    End Class
End Namespace
