'Pocket SnapIt
'Copyright (C) 2004,2005 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

'In addition, as a special exception, Iraklis Psaroudakis gives permission to link the code of this program with the XrossOne Mobile GDI+ library (or with modified versions of XrossOne Mobile GDI+ that use the same license as XrossOne Mobile GDI+), and distribute linked combinations including the two. You must obey the GNU General Public License in all respects for all of the code used other than XrossOne Mobile GDI+. If you modify this file, you may extend this exception to your version of the file, but you are not obligated to do so. If you do not wish to do so, delete this exception statement from your version.

Imports System.Text
Imports System.IO
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.ValueType
Imports System.Windows.Forms
Imports System
Imports System.Drawing
Imports PSI.cAPI.Tools
Imports PSI.cAPI
Imports XrossOne.Drawing
Imports System.Uri
Imports PSI.Main
Imports System.Xml

Namespace PSI.Tools

    Public Class cTools

        Public Shared Function GetScreenshot(ByVal hdc As IntPtr, ByVal r As Rectangle) As BitmapX
            Dim dc As IntPtr = Gdi.CreateCompatibleDC(hdc)
            Dim bmp As IntPtr = Gdi.CreateCompatibleBitmap(hdc, r.Width, r.Height)
            Dim hold As IntPtr = Gdi.SelectObject(dc, bmp)
            Gdi.BitBlt(dc, 0, 0, r.Width, r.Height, hdc, r.X, r.Y, Gdi.Rop.SRCCOPY)
            Gdi.SelectObject(dc, hold)
            Gdi.DeleteDC(dc)
            Dim bmpx As New BitmapX(r.Width, r.Height)
            bmpx.FromHBitmap(bmp)
            Gdi.DeleteObject(bmp)
            Return bmpx
        End Function

        Public Shared Sub PlayExclamationSound()
            Win.PlaySound("SystemExclamation", Nothing, Win.SoundMode.SND_ALIAS)
        End Sub

        Public Shared Sub PlayNotificationSound()
            Win.PlaySound("SystemNotification", Nothing, Win.SoundMode.SND_ALIAS)
        End Sub

        Public Shared Sub ShowHelp(ByVal parent As Form, ByVal helpTitle As String, ByVal helpMsg As String)
            Dim nh As New fHelp(parent, helpTitle, helpMsg)
            nh.ShowDialog()
        End Sub

        Public Shared Function GetInput(ByVal parent As Form, Optional ByVal helpMsg As String = "", Optional ByVal predefinedInput As String = "Enter input here") As String
            Dim fi As New fInput(parent, helpMsg, predefinedInput)
            If fi.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Return fi.InputText
            Else
                Return ""
            End If
        End Function

#Region "Options"

        Public Structure Options
            Public Mode As Integer '1=FullScreen, 2=FixedRegion
            Public Consecutive As Boolean 'If the program is to take consecutive snapshots
            Public ConsecutiveInterval As Integer 'The interval for the consecutive snapshots in milliseconds
            Public FixedRegion As Rectangle 'The rectangle of the fixed region for mode 2
            Public StoreDirectory As String 'The target storing directory of the snapshots
            Public StorePrefix As String 'The prefix of each snapshot file
            Public StoreDigits As Integer 'The least number of digits to be added to the end of the snapshot filename
            Public DoPlaySound As Boolean 'Whether to play a system sound at each snapshot
            Public SnapButton As Integer 'The virtual_key of the button to watch for initiating the capture process

            Public StartImmediately As Boolean 'Special for command line execution. The program hidden, starts immediately listening for the snapbutton with the defined options.
            Public SnapImmediately As Boolean 'Special for command line execution. The program hidden, starts immediately the capture process (without waiting for the snapbutton) with the defined options.

            'Routines related to Options manipulation:

            Private Sub LoadXmlDoc(ByVal xdoc As XmlDocument)
                Dim xOps As XmlElement = xdoc.Item("Options")
                Try
                    Me.Mode = GetOpVal(xOps, "Mode", "No")
                    Me.Consecutive = GetOpVal(xOps, "Consecutive", "Is")
                    Me.ConsecutiveInterval = GetOpVal(xOps, "ConsecutiveInterval", "No")
                    Me.StoreDirectory = GetOpVal(xOps, "StoreDirectory", "Path")
                    Me.StorePrefix = GetOpVal(xOps, "StorePrefix", "Txt")
                    Me.StoreDigits = GetOpVal(xOps, "StoreDigits", "No")
                    Me.DoPlaySound = GetOpVal(xOps, "PlaySound", "Do")
                    Me.SnapButton = GetOpVal(xOps, "SnapButton", "Vk")
                    Me.StartImmediately = GetOpVal(xOps, "StartImmediately", "Is")
                    Me.SnapImmediately = GetOpVal(xOps, "SnapImmediately", "Is")
                    Me.FixedRegion = New Rectangle(GetOpVal(xOps, "FixedRegion", "X"), GetOpVal(xOps, "FixedRegion", "Y"), GetOpVal(xOps, "FixedRegion", "Width"), GetOpVal(xOps, "FixedRegion", "Height"))
                Catch
                    ThowInvalidError
                    LoadDefaults()
                End Try
                If Not Me.IsValid Then
                    ThowInvalidError
                    LoadDefaults()
                End If
            End Sub

            Public Sub New(ByVal xmlfile As String)
                Try
                    Dim xdoc As New XmlDocument
                    xdoc.Load(xmlfile)
                    LoadXmlDoc(xdoc)
                Catch ex As Exception
                    ThowInvalidError
                    LoadDefaults()
                End Try
            End Sub

            Public Sub New(ByVal xdoc As XmlDocument)
                LoadXmlDoc(xdoc)
            End Sub

            Public Function IsValid(Optional ByRef errormsg As String = "") As Boolean
                Dim t As Boolean = True
                If (Not (Me.Mode = 1 Or Me.Mode = 2)) Then
                    t = False
                    errormsg &= vbCrLf & "Please select a mode."
                End If
                If Me.ConsecutiveInterval <= 0 Then
                    t = False
                    errormsg &= vbCrLf & "Please enter a positive consecutive snapshots interval value."
                End If
                If Me.Mode = 2 And Me.FixedRegion.IsEmpty Then
                    t = False
                    errormsg &= vbCrLf & "Please select a fixed region."
                End If
                If FixedRegion.X < 0 Or FixedRegion.Y < 0 Or FixedRegion.Right > Screen.PrimaryScreen.Bounds.Width Or FixedRegion.Bottom > Screen.PrimaryScreen.Bounds.Height Then
                    t = False
                    errormsg &= vbCrLf & "Please select a fixed region that is in the bounds of the screen."
                End If
                Dim i As Integer, bb As Boolean = False
                For i = 0 To Path.InvalidPathChars.Length - 1
                    If Not StorePrefix.IndexOf(Path.InvalidPathChars(i)) = -1 Then
                        t = False
                        bb = True
                    End If
                Next
                If bb Then
                    errormsg &= vbCrLf & "The file prefix contains invalid characters."
                End If
                If Not StoreDigits > 0 Then
                    t = False
                    errormsg &= vbCrLf & "Please enter a positive file digits value."
                End If
                Return t
            End Function

            Public Function ToXml() As XmlDocument
                If Me.IsValid Then
                    Dim doc As New XmlDocument
                    Dim comm As XmlComment = doc.CreateComment(Main.MyName & " " & Main.MyVersion & " " & "options xml file. More information about the program at " & Main.MyWebsite & ".")
                    doc.AppendChild(comm)
                    Dim xOps As XmlElement = doc.CreateElement("Options")
                    doc.AppendChild(xOps)

                    OptionsElement(xOps, "Mode", "No", Me.Mode)
                    OptionsElement(xOps, "Consecutive", "Is", Me.Consecutive)
                    OptionsElement(xOps, "ConsecutiveInterval", "No", Me.ConsecutiveInterval)
                    OptionsElement(xOps, "StoreDirectory", "Path", Me.StoreDirectory)
                    OptionsElement(xOps, "StorePrefix", "Txt", Me.StorePrefix)
                    OptionsElement(xOps, "StoreDigits", "No", Me.StoreDigits)
                    OptionsElement(xOps, "PlaySound", "Do", Me.DoPlaySound)
                    OptionsElement(xOps, "SnapButton", "Vk", Me.SnapButton)
                    OptionsElement(xOps, "StartImmediately", "Is", Me.StartImmediately)
                    OptionsElement(xOps, "SnapImmediately", "Is", Me.SnapImmediately)

                    'FixedRegion option
                    Dim nElRect As XmlElement = doc.CreateElement("FixedRegion")
                    Dim nAtX As XmlAttribute = doc.CreateAttribute("X"), nAtY As XmlAttribute = doc.CreateAttribute("Y"), nAtWid As XmlAttribute = doc.CreateAttribute("Width"), nAtHei As XmlAttribute = doc.CreateAttribute("Height")
                    nAtX.Value = Me.FixedRegion.X
                    nAtY.Value = Me.FixedRegion.Y
                    nAtWid.Value = Me.FixedRegion.Width
                    nAtHei.Value = Me.FixedRegion.Height
                    nElRect.Attributes.Append(nAtX)
                    nElRect.Attributes.Append(nAtY)
                    nElRect.Attributes.Append(nAtWid)
                    nElRect.Attributes.Append(nAtHei)
                    xOps.AppendChild(nElRect)

                    Return doc
                Else
                    ThowInvalidError
                    LoadDefaults()
                End If
            End Function

            Public Sub LoadDefaults()
                Me.Mode = 1
                Me.Consecutive = False
                Me.ConsecutiveInterval = 2000
                Me.FixedRegion = New Rectangle(0, 0, Main.ScreenSize.Width, Main.ScreenSize.Height)
                Me.StoreDirectory = Win.SHGetSpecialFolderPath(Win.CSIDL.CSIDL_PERSONAL)
                Me.StorePrefix = "Snap"
                Me.StoreDigits = 3
                Me.DoPlaySound = True
                If IsPC() Then
                    Me.SnapButton = Win.VirtualKey.VK_SNAPSHOT
                ElseIf IsSmartphone() Then
                    Me.SnapButton = Win.VirtualKey.SP_SHARP
                ElseIf IsPocketPC() Then
                    Me.SnapButton = Win.VirtualKey.PPC_VOLUMEUP
                Else
                    Me.SnapButton = Win.VirtualKey.VK_DOWN 'In case of an unrecognisable device
                End If
            End Sub
            
            Public Shared Sub ThowInvalidError
            	MessageBox.Show("The options values are invalid. Defaults will be loaded.", "Error - " & Main.MyName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1)
            End Sub

        End Structure

        Private Shared Function GetOpVal(ByVal xOps As XmlElement, ByVal name As String, ByVal attributeName As String) As String
            Return CType(xOps.Item(name), XmlElement).GetAttribute(attributeName)
        End Function

        Private Shared Function OptionsElement(ByRef xOps As XmlElement, ByVal name As String, ByVal valueName As String, ByVal value As String) As XmlElement
            Dim nEl As XmlElement = xOps.OwnerDocument.CreateElement(name)
            Dim nAt As XmlAttribute = xOps.OwnerDocument.CreateAttribute(valueName)
            nAt.Value = value
            nEl.Attributes.Append(nAt)
            xOps.AppendChild(nEl)
        End Function

#End Region

#Region "Miscellanious"

        Public Shared Function GetMax(ByVal numbers() As Integer) As Integer
            Dim i As Integer
            Dim mx As Double = numbers(0)
            For i = 1 To numbers.Length - 1
                If numbers(i) > mx Then
                    mx = numbers(i)
                End If
            Next
            Return mx
        End Function

        Public Shared Function GetMin(ByVal numbers() As Integer) As Integer
            Dim i As Integer
            Dim mx As Double = numbers(0)
            For i = 1 To numbers.Length - 1
                If numbers(i) < mx Then
                    mx = numbers(i)
                End If
            Next
            Return mx
        End Function

#End Region

    End Class

End Namespace
