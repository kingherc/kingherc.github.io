'Pocket SnapIt
'Copyright (C) 2004,2005 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

'In addition, as a special exception, Iraklis Psaroudakis gives permission to link the code of this program with the XrossOne Mobile GDI+ library (or with modified versions of XrossOne Mobile GDI+ that use the same license as XrossOne Mobile GDI+), and distribute linked combinations including the two. You must obey the GNU General Public License in all respects for all of the code used other than XrossOne Mobile GDI+. If you modify this file, you may extend this exception to your version of the file, but you are not obligated to do so. If you do not wish to do so, delete this exception statement from your version.

Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.Windows.Forms
Imports PSI.cAPI.Tools
Imports PSI
Imports PSI.cAPI
Imports PSI.Tools
Imports System

Namespace PSI
	
	
Public Class fExplorer
    Inherits System.Windows.Forms.Form

    Private fParent As Form

    Private DirPath As String 'Can be Root, MyDocuments, Temp or a usual directory path like 'C:\'.
    Private WhatToReturn As String = "Dir"
    Private AllowOtherDirs As Boolean = True

    Public ReadOnly Property SelectedPath() As String
        Get
            Return CStr(tvExplorer.SelectedNode.Tag).Substring(4)
        End Get
    End Property

    Private ReadOnly Property SelectedType() As String
        Get
            Return CStr(tvExplorer.SelectedNode.Tag).Substring(0, 3)
        End Get
    End Property

    Public Sub New(ByVal parent As Form, Optional ByVal dir As String = "MyDocuments")
        MyBase.New()
        DirPath = dir
        fParent = parent
        Init()
    End Sub

    Friend WithEvents MainMenu As New System.Windows.Forms.MainMenu
    Friend WithEvents mnDone As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMenu As New System.Windows.Forms.MenuItem
    Friend WithEvents mnHelp As New system.Windows.Forms.MenuItem
    Friend WithEvents mnCancel As New System.Windows.Forms.MenuItem
    Friend WithEvents tvExplorer As New System.Windows.Forms.TreeView
    Friend WithEvents ilIcons As New System.Windows.Forms.ImageList
    Friend WithEvents mnSeperator2 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnLoadDirs As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDirRoot As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDirMyDocs As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDirCurrent As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDirTemp As New System.Windows.Forms.MenuItem

    Sub Init()
        If IsPC() Then
            Me.ClientSize = fParent.ClientSize
        End If
        Me.Location = fParent.Location

        MainMenu.MenuItems.Add(mnDone)
        MainMenu.MenuItems.Add(mnMenu)

        mnDone.Text = "Done"

        mnMenu.MenuItems.Add(mnLoadDirs)
        mnMenu.MenuItems.Add(mnSeperator2)
        mnMenu.MenuItems.Add(mnHelp)
        mnMenu.MenuItems.Add(mnCancel)
        mnMenu.Text = "Menu"

        mnLoadDirs.Text = "Load Directory"

        mnLoadDirs.MenuItems.Add(mnDirRoot)
        mnLoadDirs.MenuItems.Add(mnDirMyDocs)
        mnLoadDirs.MenuItems.Add(mnDirCurrent)
        mnLoadDirs.MenuItems.Add(mnDirTemp)

        mnDirRoot.Text = "Device Root"
        mnDirMyDocs.Text = "My Documents"
        mnDirCurrent.Text = "Current App Directory"
        mnDirTemp.Text = "Temporary Folder"

        mnSeperator2.Text = "-"
        mnHelp.Text = "&Help"
        mnCancel.Text = "Cancel"
        tvExplorer.ImageList = ilIcons
        tvExplorer.Location = New System.Drawing.Point(-1, -1)
        tvExplorer.SelectedImageIndex = 1
        tvExplorer.Size = New System.Drawing.Size(ClientSize.Width + 2, ClientSize.Height + 2)
        ilIcons.ImageSize = New System.Drawing.Size(16, 14)
        ilIcons.Images.Add(CType(Main.hResources("FolderClosed"), System.Drawing.Image))
        ilIcons.Images.Add(CType(Main.hResources("FolderOpened"), System.Drawing.Image))
        ilIcons.Images.Add(CType(Main.hResources("File"), System.Drawing.Image))
        'Create Error Image Bitmap
        Dim ErrorBmp As New Bitmap(ilIcons.ImageSize.Width, ilIcons.ImageSize.Height)
        Dim g As Graphics = Graphics.FromImage(ErrorBmp)
        g.FillRectangle(New SolidBrush(Color.White), 0, 0, ErrorBmp.Width, ErrorBmp.Height)
        g.DrawLine(New Pen(Color.Red), CInt(ErrorBmp.Width / 2 - 3), CInt(ErrorBmp.Height / 2 - 3), CInt(ErrorBmp.Width / 2 + 3), CInt(ErrorBmp.Height / 2 + 3))
        g.DrawLine(New Pen(Color.Red), CInt(ErrorBmp.Width / 2 - 3), CInt(ErrorBmp.Height / 2 + 3), CInt(ErrorBmp.Width / 2 + 3), CInt(ErrorBmp.Height / 2 - 3))
        g = Nothing
        'End Create Error Image Bitmap
        ilIcons.Images.Add(ErrorBmp)
        ErrorBmp = Nothing

        Me.Controls.Add(tvExplorer)
        Me.Menu = MainMenu
        Me.Text = "Directory Explorer"
    End Sub

    Private Sub frmExplorer_Resize(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        tvExplorer.Width = Me.ClientSize.Width + 2
        tvExplorer.Height = Me.ClientSize.Height + 2
    End Sub

    Private Sub mnDirTemp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDirTemp.Click
        MakeDirPathTempPath(False)
        LoadDir(DirPath)
    End Sub
    
    Private Sub mnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnHelp.Click
		PSI.Tools.cTools.ShowHelp(Me, "Directory Explorer", "Through this window you can choose a directory. The directory you choose must exist. If not, you need to create it through the file explorer of your device. In this window, you are presented with a 'treeview' of the My Documents folder. Clicking the plus or minus signs makes it possible to show and hide folders. When you find the folder you want to choose, click/select it and then click Done." & vbcrlf & vbcrlf & "To change the first directory shown in the treeview, use Menu > Load Directory buttons. By clicking one of them loads that directory in the upper place of the treeview.")
    End Sub

    Private Sub mnDirCurrent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDirCurrent.Click
        MakeDirPathRunningPath(False)
        LoadDir(DirPath)
    End Sub

    Private Sub mnDirMyDocs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDirMyDocs.Click
        DirPath = Win.SHGetSpecialFolderPath(Win.CSIDL.CSIDL_PERSONAL)
        LoadDir(DirPath)
    End Sub

    Private Sub mnDirRoot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDirRoot.Click
        DirPath = "\"
        LoadDir(DirPath)
    End Sub

    Private Sub mnDone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDone.Click
        Try
            If WhatToReturn = SelectedType Then
                If SelectedPath = "\\" Or tvExplorer.SelectedNode.Text = ":Device Root:" Then
                    MessageBox.Show("You cannot select Device Root.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                Else
                    Me.DialogResult = DialogResult.OK
                End If
            Else
                Select Case SelectedType
                    Case "Err"
                        System.Windows.Forms.MessageBox.Show("You selected an error message. Select a folder.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                End Select
            End If
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show("Please select a folder.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
        End Try
    End Sub

    Private Sub mnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCancel.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

    Private Sub frmExplorer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        tvExplorer.Bounds = New Rectangle(-1, -1, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width + 2, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height + 2)
        Select Case DirPath
            Case "MyDocuments"
                DirPath = Win.SHGetSpecialFolderPath(Win.CSIDL.CSIDL_PERSONAL)
            Case "Root"
                DirPath = "\"
            Case "Current"
                MakeDirPathRunningPath(False)
        End Select
        Dim DoesDirExists As Boolean = Directory.Exists(DirPath)
        If IsWCE() Then
            Try
                Dim TempPDirs() As String = Directory.GetDirectories(DirPath)
                DoesDirExists = True
                TempPDirs = Nothing
            Catch ex As Exception

            End Try
        End If
        If Not DoesDirExists Then
            Select Case System.Windows.Forms.MessageBox.Show("The given directory was not found. The directory will now be changed to the current application's running directory. Would you rather change it to System's temporary directory?", "Directory Error", System.Windows.Forms.MessageBoxButtons.YesNo, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                Case DialogResult.Yes
                    MakeDirPathTempPath(False)
                Case DialogResult.No
                    MakeDirPathRunningPath(False)
            End Select
        End If
        LoadDir(DirPath)
        tvExplorer.SelectedNode = tvExplorer.Nodes(0)
        mnLoadDirs.Enabled = AllowOtherDirs
        frmExplorer_Resize(Me, EventArgs.Empty)
    End Sub

    Sub MakeDirPathRunningPath(Optional ByVal ShowMessage As Boolean = False)
        If ShowMessage Then
            System.Windows.Forms.MessageBox.Show("The starting folder of the search will be changed to the executing application path because there was an error while querying the given directory.", "Info", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
        End If
        DirPath = CType(New Uri(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)), Uri).LocalPath
    End Sub

    Sub MakeDirPathTempPath(Optional ByVal ShowMessage As Boolean = False)
        If ShowMessage Then
            System.Windows.Forms.MessageBox.Show("The starting folder of the search will be changed to System's temporary directory because there was an error while querying the given directory.", "Info", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
        End If
        DirPath = Path.GetTempPath
    End Sub

    Sub LoadDir(ByVal DirStr As String)
        If DirStr.LastIndexOf("\") = DirStr.Length - 1 Then
            If Not DirStr = "\" Then
                DirStr = DirStr.Remove(DirStr.LastIndexOf("\"), 1)
            End If
        End If
        tvExplorer.Nodes.Clear()
        Try
            Dim ParentNode As New TreeNode(DirStr.Substring(DirStr.LastIndexOf("\") + 1))
            If DirStr = "\" Then
                ParentNode.Text = ":Device Root:"
            End If
            ParentNode.Tag = "Dir:" & DirStr & "\"
            Dim Dirs() As String
            Try
                Dirs = Directory.GetDirectories(DirStr)
            Catch ex As Exception

            End Try
            Dim i
            If Dirs.Length > 0 Then
                For i = 0 To (Dirs.Length - 1)
                    Dim nt As New System.Windows.Forms.TreeNode(Dirs(i).Substring(Dirs(i).LastIndexOf("\") + 1))
                    nt.Tag = "Dir:" & Dirs(i) & "\"
                    ParentNode.Nodes.Add(nt)
                    nt = Nothing
                Next
            End If
            If ParentNode.Nodes.Count = 0 Then
                MessageBox.Show("Error2")
                Dim ErrNt As New System.Windows.Forms.TreeNode("No Directories or Read Error")
                ErrNt.Tag = "Err:" & ErrNt.Text
                ErrNt.ImageIndex = 3
                ErrNt.SelectedImageIndex = 3
                ParentNode.Nodes.Add(ErrNt)
                ErrNt = Nothing
            End If
            Dirs = Nothing
            i = Nothing
            tvExplorer.Nodes.Add(ParentNode)
        Catch ex As Exception

        End Try
        If tvExplorer.Nodes.Count = 0 Then
            Dim ErrNt As New System.Windows.Forms.TreeNode("No Directories or Read Error")
            ErrNt.Tag = "Err:" & ErrNt.Text
            ErrNt.ImageIndex = 3
            ErrNt.SelectedImageIndex = 3
            tvExplorer.Nodes.Add(ErrNt)
            ErrNt = Nothing
        End If
    End Sub

    Sub PopulateDirs(ByRef tNode As System.Windows.Forms.TreeNode)
        Dim Dirs As String()
        Dirs = Directory.GetDirectories(CStr(tNode.Tag).Substring(4))
        Dim i
        For i = 0 To (Dirs.Length - 1)
            Dim nt As New System.Windows.Forms.TreeNode(Dirs(i).Substring(Dirs(i).LastIndexOf("\") + 1))
            nt.Tag = "Dir:" & Dirs(i) & "\"
            tNode.Nodes.Add(nt)
            nt = Nothing
        Next
        Dirs = Nothing
        i = Nothing
    End Sub

    Private Sub tvExplorer_BeforeExpand(ByVal sender As Object, ByVal e As TreeViewCancelEventArgs) Handles tvExplorer.BeforeExpand
        Dim nt As TreeNode
        For Each nt In e.Node.Nodes
            If CStr(nt.Tag).Substring(0, 3) = "Dir" Then
                Try
                    PopulateDirs(nt)
                Catch ex As Exception
                    Dim ErrNt As New System.Windows.Forms.TreeNode("Read/Access Error")
                    ErrNt.Tag = "Err:" & ErrNt.Text
                    ErrNt.ImageIndex = 3
                    ErrNt.SelectedImageIndex = 3
                    nt.Nodes.Add(ErrNt)
                    ErrNt = Nothing
                End Try
            End If
        Next
    End Sub

End Class

	
End Namespace

