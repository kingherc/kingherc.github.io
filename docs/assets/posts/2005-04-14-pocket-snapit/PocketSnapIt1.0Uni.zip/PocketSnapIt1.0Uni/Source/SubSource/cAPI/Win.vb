'Pocket SnapIt
'Copyright (C) 2004,2005 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

'In addition, as a special exception, Iraklis Psaroudakis gives permission to link the code of this program with the XrossOne Mobile GDI+ library (or with modified versions of XrossOne Mobile GDI+ that use the same license as XrossOne Mobile GDI+), and distribute linked combinations including the two. You must obey the GNU General Public License in all respects for all of the code used other than XrossOne Mobile GDI+. If you modify this file, you may extend this exception to your version of the file, but you are not obligated to do so. If you do not wish to do so, delete this exception statement from your version.

Imports System.Text
Imports System.IO
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.ValueType
Imports System.Windows.Forms
Imports System
Imports System.Drawing
Imports PSI.cAPI.InnerAPI
Imports PSI.cAPI.Tools

Namespace PSI.cAPI

    Public Class Win

        Private Shared PlatformName As String = ""
        Private Shared DoubleClickTm As Integer = 0

        Public Shared Function GetPlatformName() As String
            Try
                If PlatformName = "" Then
                    If Environment.OSVersion.Platform = PlatformID.WinCE Then
                        Dim buffer(29) As Byte
                        Dim rc As String = ""
                        InnerAPICalls.SystemParametersInfo(257, buffer.Length, buffer, 0)
                        rc = Encoding.Unicode.GetString(buffer, 0, buffer.Length)
                        PlatformName = "WindowsCE" & rc
                        Return PlatformName
                    Else
                        Select Case Environment.OSVersion.Platform
                            Case PlatformID.Win32NT
                                PlatformName = "WindowsPCNT"
                                Return PlatformName
                            Case PlatformID.Win32S
                                PlatformName = "WindowsPCS16For32Bit"
                                Return PlatformName
                            Case Else
                                PlatformName = "WindowsPC"
                                Return PlatformName
                        End Select
                    End If
                Else
                    Return PlatformName
                End If
            Catch ex As Exception
                Return "SmartPhone"
            End Try
        End Function

        Public Shared Function GetDoubleClickTime() As Integer
            If DoubleClickTm = 0 Then
                If IsPC() Then
                    DoubleClickTm = InnerAPICalls.GetWindowsDoubleClickTime()
                    Return DoubleClickTm
                Else
                    DoubleClickTm = InnerAPICalls.GetDoubleClickTime()
                    Return DoubleClickTm
                End If
            Else
                Return DoubleClickTm
            End If
        End Function

        Public Shared Function SHGetSpecialFolderPath(Optional ByVal iCSIDL As CSIDL = CSIDL.CSIDL_PERSONAL) As String
            Try
                Dim buffer(InnerAPICalls.MAX_PATH) As Byte
                Dim rc As String = ""
                If Not IsPC() Then
                    InnerAPICalls.SHGetSpecialFolderPath(Nothing, buffer, iCSIDL, 0)
                Else
                    InnerAPICalls.SHGetSpecialFolderPathWindows(Nothing, buffer, iCSIDL, 0)
                End If
                If Not LCase(GetPlatformName).IndexOf(LCase("WindowsPC")) = -1 Then
                    rc = Encoding.ASCII.GetString(buffer, 0, buffer.Length)
                Else
                    rc = Encoding.Unicode.GetString(buffer, 0, buffer.Length)
                End If
                'Remove illegal characters
                Dim ii
                For ii = 0 To Path.InvalidPathChars.Length - 1
                    rc = rc.Replace(Path.InvalidPathChars(ii), "")
                Next
                ii = Nothing
                Return rc
            Catch ex As Exception
                Return "Error"
            End Try
        End Function

        Public Enum CSIDL As Integer
            CSIDL_FAVORITES = &H6
            CSIDL_FONTS = &H14
            CSIDL_PERSONAL = &H5
            CSIDL_PROGRAM_FILES = &H26
            CSIDL_PROGRAMS = &H2
            CSIDL_STARTUP = &H7
            CSIDL_WINDOWS = &H24
        End Enum

        Public Shared Function GetDC(ByVal hwnd As IntPtr) As IntPtr
            If IsPC() Then
                Return InnerAPICalls.GetDCWindows(hwnd)
            Else
                Return InnerAPICalls.GetDC(hwnd)
            End If
        End Function

        Public Shared Function ReleaseDC(ByVal hwnd As IntPtr, ByVal hdc As IntPtr) As Integer
            If IsPC() Then
                Return InnerAPICalls.ReleaseDCWindows(hwnd, hdc)
            Else
                Return InnerAPICalls.ReleaseDC(hwnd, hdc)
            End If
        End Function

        Public Shared Function GetActiveWindow() As IntPtr
            If IsPC() Then
                Return InnerAPICalls.GetActiveWindowWindows()
            Else
                Return InnerAPICalls.GetActiveWindow()
            End If
        End Function

        Public Shared Function GetModuleHandle(ByVal lpModuleName As String) As IntPtr
            If IsPC() Then
                Return InnerAPICalls.GetModuleHandleWindows(lpModuleName)
            Else
                Return InnerAPICalls.GetModuleHandle(lpModuleName)
            End If
        End Function

        Public Shared Function GetLastError() As IntPtr
            If IsPC() Then
                Return InnerAPICalls.GetLastErrorWindows
            Else
                Return InnerAPICalls.GetLastError
            End If
        End Function

        Public Shared Function PlaySound(ByVal pszSound As String, ByVal hmod As IntPtr, ByVal fdwSound As SoundMode) As Boolean
            If IsPC() Then
                Return InnerAPICalls.PlaySoundWindows(pszSound, hmod, fdwSound)
            Else
                Return InnerAPICalls.PlaySound(pszSound, hmod, fdwSound)
            End If
        End Function

        Public Enum SoundMode As Integer
            SND_ALIAS = &H10000
            SND_FILENAME = &H20000
            SND_RESOURCE = &H40004
            SND_SYNC = &H0
            SND_ASYNC = &H1
            SND_NODEFAULT = &H2
            SND_MEMORY = &H4
            SND_LOOP = &H8
            SND_NOSTOP = &H10
            SND_NOWAIT = &H2000
        End Enum

        Public Shared Function GetAsyncKeyState(ByVal vKey As Integer) As Short
            If IsPC() Then
                Return InnerAPICalls.GetAsyncKeyStateWindows(vKey)
            Else
                Return InnerAPICalls.GetAsyncKeyState(vKey)
            End If
        End Function

        Public Enum VirtualKey As Integer
            'Various useful Keys
            VK_LBUTTON = &H1
            VK_RBUTTON = &H2
            VK_BACK = &H8 'Only SP and PC
            VK_RETURN = &HD
            VK_LEFT = &H25
            VK_UP = &H26
            VK_RIGHT = &H27
            VK_DOWN = &H28

            'Possible PC Snapshot Keys
            VK_SNAPSHOT = &H2C
            VK_F9 = &H78
            VK_SCROLL = &H91

            'Possible PocketPC Snapshot Keys
            PPC_RECORD = 121
            PPC_VOLUMEUP = 38
            PPC_VOLUMEDOWN = 40
            PPC_SHARP = 51
            PPC_ASTERISK = 56

            'Possible SmartPhone Snapshot Keys
            SP_ASTERISK = 119
            SP_SHARP = 120
            SP_ZERO = 48
        End Enum
        
        Public Shared Function SetForegroundWindow(ByVal hWnd As IntPtr) As Integer
        	If IsPC Then
        		return InnerAPICalls.SetForegroundWindowWindows(hWnd)
        	Else
        		return InnerAPICalls.SetForegroundWindow(hWnd)
        	End If
        End Function

    End Class

End Namespace
