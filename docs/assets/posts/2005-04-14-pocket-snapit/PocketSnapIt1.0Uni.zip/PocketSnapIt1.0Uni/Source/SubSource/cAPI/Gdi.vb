'Pocket SnapIt
'Copyright (C) 2004,2005 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

'In addition, as a special exception, Iraklis Psaroudakis gives permission to link the code of this program with the XrossOne Mobile GDI+ library (or with modified versions of XrossOne Mobile GDI+ that use the same license as XrossOne Mobile GDI+), and distribute linked combinations including the two. You must obey the GNU General Public License in all respects for all of the code used other than XrossOne Mobile GDI+. If you modify this file, you may extend this exception to your version of the file, but you are not obligated to do so. If you do not wish to do so, delete this exception statement from your version.

Imports System.Text
Imports System.IO
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.ValueType
Imports System.Windows.Forms
Imports System
Imports System.Drawing
Imports PSI.cAPI.InnerAPI
Imports PSI.cAPI.Tools

Namespace PSI.cAPI

    Public Class Gdi

        Public Shared Function CreateCompatibleDC(ByVal hdc As IntPtr) As IntPtr
            If IsPC() Then
                Return InnerAPICalls.CreateCompatibleDCWindows(hdc)
            Else
                Return InnerAPICalls.CreateCompatibleDC(hdc)
            End If
        End Function

        Public Shared Function DeleteDC(ByVal hdc As IntPtr) As Integer
            If IsPC() Then
                Return InnerAPICalls.DeleteDCWindows(hdc)
            Else
                Return InnerAPICalls.DeleteDC(hdc)
            End If
        End Function

        Public Shared Function CreateCompatibleBitmap(ByVal hdc As IntPtr, ByVal nWidth As Integer, ByVal nHeight As Integer) As IntPtr
            If IsPC() Then
                Return InnerAPICalls.CreateCompatibleBitmapWindows(hdc, nWidth, nHeight)
            Else
                Return InnerAPICalls.CreateCompatibleBitmap(hdc, nWidth, nHeight)
            End If
        End Function

        Public Shared Function SelectObject(ByVal hdc As IntPtr, ByVal hgdiobj As IntPtr) As IntPtr
            If IsPC() Then
                Return InnerAPICalls.SelectObjectWindows(hdc, hgdiobj)
            Else
                Return InnerAPICalls.SelectObject(hdc, hgdiobj)
            End If
        End Function

        Public Shared Function DeleteObject(ByVal hObject As IntPtr) As Integer
            If IsPC() Then
                Return InnerAPICalls.DeleteObjectWindows(hObject)
            Else
                Return InnerAPICalls.DeleteObject(hObject)
            End If
        End Function

        Public Shared Function BitBlt(ByVal hdcDest As IntPtr, ByVal nXDest As Integer, ByVal nYDest As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal hdcSrc As IntPtr, ByVal nXSrc As Integer, ByVal nYSrc As Integer, Optional ByVal dwRop As Rop = Rop.SRCCOPY) As Integer
            If IsPC() Then
                Return InnerAPICalls.BitBltWindows(hdcDest, nXDest, nYDest, nWidth, nHeight, hdcSrc, nXSrc, nYSrc, dwRop)
            Else
                Return InnerAPICalls.BitBlt(hdcDest, nXDest, nYDest, nWidth, nHeight, hdcSrc, nXSrc, nYSrc, dwRop)
            End If
        End Function

        Public Enum Rop As Integer
            BLACKNESS = &H42
            DSTINVERT = &H550009
            MERGECOPY = &HC000CA
            MERGEPAINT = &HBB0226
            NOTSRCCOPY = &H330008
            NOTSRCERASE = &H1100A6
            PATCOPY = &HF00021
            PATINVERT = &H5A0049
            PATPAINT = &HFB0A09
            SRCAND = &H8800C6
            SRCCOPY = &HCC0020
            SRCERASE = &H440328
            SRCINVERT = &H660046
            SRCPAINT = &HEE0086
            WHITENESS = &HFF0062
        End Enum

    End Class

End Namespace