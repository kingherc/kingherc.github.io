'Pocket SnapIt
'Copyright (C) 2004,2005 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

'In addition, as a special exception, Iraklis Psaroudakis gives permission to link the code of this program with the XrossOne Mobile GDI+ library (or with modified versions of XrossOne Mobile GDI+ that use the same license as XrossOne Mobile GDI+), and distribute linked combinations including the two. You must obey the GNU General Public License in all respects for all of the code used other than XrossOne Mobile GDI+. If you modify this file, you may extend this exception to your version of the file, but you are not obligated to do so. If you do not wish to do so, delete this exception statement from your version.

Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports System.Drawing
Imports XrossOne.Drawing
Imports PSI.cAPI.Tools
Imports PSI.Tools.cTools

Namespace PSI

    Public Class fInput
        Inherits System.Windows.Forms.Form

#Region "Variables & Controls"

        Public Property InputText() As String
            Get
                Return txtInput.Text
            End Get
            Set(ByVal Value As String)
                txtInput.Text = Value
            End Set
        End Property

        Public Property InputHelp() As String
            Get
                Return txtHelp.Text
            End Get
            Set(ByVal Value As String)
                txtHelp.Text = Value
                If Value = "" Then
                    txtHelp.Visible = False
                    lblHelp.Visible = False
                Else
                    txtHelp.Visible = True
                    lblHelp.Visible = True
                End If
            End Set
        End Property

        Private fParent As Form

        Friend WithEvents mnMain As New MainMenu
        Friend WithEvents mnAction As New MenuItem

        Friend txtHelp As New TextBox
        Friend txtInput As New TextBox
        Friend lblInput As New Label
        Friend lblHelp As New Label

#End Region

#Region "Initialization"

        Sub New(ByVal parent As Form, Optional ByVal helpMsg As String = "", Optional ByVal predefinedText As String = "Enter input here")
            MyBase.New()
            fParent = parent
            Init()
            InputHelp = helpMsg
            InputText = predefinedText
        End Sub

        Private Sub Init()
            If IsPC() Then
                Me.ClientSize = fParent.ClientSize
            End If
            Me.Location = fParent.Location
            Me.FormBorderStyle = FormBorderStyle.Sizable

            lblInput.Font = Main.UsualFont
            lblInput.Text = "Enter input:"
            Me.Controls.Add(lblInput)

            lblHelp.Font = Main.UsualFont
            lblHelp.Text = "Help:"
            Me.Controls.Add(lblHelp)

            mnAction.Text = "&Done"
            mnMain.MenuItems.Add(mnAction)

            txtInput.Text = "Enter input"
            Me.Controls.Add(txtInput)

            txtHelp.Font = Main.UsualFont
            txtHelp.Text = "Undefined help text"
            txtHelp.ReadOnly = True
            txtHelp.Multiline = True
            txtHelp.WordWrap = True
            txtHelp.ScrollBars = ScrollBars.Vertical
            Me.Controls.Add(txtHelp)

            Me.Text = "Input"
            Me.Menu = mnMain
        End Sub

#End Region

        Private Sub Main_Load(ByVal s As Object, ByVal e As EventArgs) Handles MyBase.Load

        End Sub

        Private Sub Main_Resize(ByVal s As Object, ByVal e As EventArgs) Handles MyBase.Resize
            lblInput.Location = New Point(5, 5)
            lblInput.Width = ClientSize.Width - lblInput.Left - 5
            lblInput.Height = 18

            txtInput.Location = New Point(lblInput.Left, lblInput.Bottom + 2)
            txtInput.Width = lblInput.Width

            lblHelp.Location = New Point(lblInput.Left, txtInput.Bottom + 5)
            lblHelp.Width = lblInput.Width
            lblHelp.Height = lblInput.Height

            txtHelp.Location = New Point(lblInput.Left, lblHelp.Bottom + 2)
            txtHelp.Size = New Size(txtInput.Width, ClientSize.Height - txtHelp.Top - 5)
        End Sub

        Private Sub mnAction_Click(ByVal s As Object, ByVal e As EventArgs) Handles mnAction.Click
            Me.DialogResult = DialogResult.OK
        End Sub

    End Class
End Namespace
