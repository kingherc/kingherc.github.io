'Pocket SnapIt
'Copyright (C) 2004,2005 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

'In addition, as a special exception, Iraklis Psaroudakis gives permission to link the code of this program with the XrossOne Mobile GDI+ library (or with modified versions of XrossOne Mobile GDI+ that use the same license as XrossOne Mobile GDI+), and distribute linked combinations including the two. You must obey the GNU General Public License in all respects for all of the code used other than XrossOne Mobile GDI+. If you modify this file, you may extend this exception to your version of the file, but you are not obligated to do so. If you do not wish to do so, delete this exception statement from your version.

Imports System
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports XrossOne.Drawing
Imports PSI.cAPI.Tools
Imports PSI.Tools.cTools

Namespace PSI

    Public Class SelectFR
        Inherits System.Windows.Forms.Form

#Region "Variables & Controls"

        Public ReadOnly Property SelectedRectangle() As Rectangle
            Get
                If Not p1.IsEmpty And Not p2.IsEmpty Then
                    If Not (p1.X = p2.X Or p1.Y = p2.Y) Then
                        Return New Rectangle(GetMin(New Integer(1) {p1.X, p2.X}), GetMin(New Integer(1) {p1.Y, p2.Y}), Math.Abs(p1.X - p2.X), Math.Abs(p1.Y - p2.Y))
                    End If
                End If
            End Get
        End Property

        Private bmpx As BitmapX
        Private fParent As Form

        Private bmpcur As BitmapX
        Private loci As Point
        Private stpi As Integer = 25
        Private p1 As Point
        Private p2 As Point

        Private Property stp() As Integer
            Get
                Return stpi
            End Get
            Set(ByVal Value As Integer)
                If Value <= 0 Then
                    Exit Property
                End If
                stpi = Value
                mnStep.Text = "Step: " & Value
            End Set
        End Property

        Private Property loc() As Point
            Get
                Return loci
            End Get
            Set(ByVal Value As Point)
                If Value.X >= pbImage.Width Or Value.Y >= pbImage.Height Or Value.X < 0 Or Value.Y < 0 Then
                    Exit Property
                End If
                loci = Value
                RefreshImage()
            End Set
        End Property

        Friend WithEvents mnMain As New MainMenu
        Friend WithEvents mnAction As New MenuItem
        Friend WithEvents mnMenu As New MenuItem
        Friend WithEvents mnCancel As New MenuItem
        Friend WithEvents mnStep As New MenuItem
        Friend WithEvents mnReset As New MenuItem
        Friend WithEvents mnHelp As New MenuItem

        Friend WithEvents pbImage As New PictureBox

#End Region

#Region "Initialization"

        Sub New(ByVal myParent As Form, ByVal image As BitmapX)
            MyBase.New()
            bmpx = image
            fParent = myParent
            Init()
        End Sub

        Private Sub Init()
            If IsPC() Then
                Me.ClientSize = fParent.ClientSize
                stp = 40
            ElseIf IsSmartphone() Then
                stp = 16
            ElseIf IsPocketPC() Then
                stp = 23
            End If
            Me.Location = fParent.Location
            Me.FormBorderStyle = FormBorderStyle.Sizable

            bmpcur = New BitmapX(5, 5) 'Cursor
            bmpcur.Clear(Color.Black)
            bmpcur.SetPixel(1, 1, Color.White)
            bmpcur.SetPixel(2, 1, Color.White)
            bmpcur.SetPixel(3, 1, Color.White)
            bmpcur.SetPixel(1, 2, Color.White)
            bmpcur.SetPixel(3, 2, Color.White)
            bmpcur.SetPixel(1, 3, Color.White)
            bmpcur.SetPixel(2, 3, Color.White)
            bmpcur.SetPixel(3, 3, Color.White)

            mnCancel.Text = "&Cancel"
            mnAction.Text = "&Done"
            mnAction.Enabled = False
            mnMenu.Text = "&Menu"
            mnStep.Enabled = False
            mnReset.Text = "&Reset"
            mnHelp.Text = "&Help"
            mnMenu.MenuItems.Add(mnStep)
            Dim nSep1 As New MenuItem
            nSep1.Text = "-"
            mnMenu.MenuItems.Add(nSep1)
            mnMenu.MenuItems.Add(mnReset)
            mnMenu.MenuItems.Add(mnHelp)
            mnMenu.MenuItems.Add(mnCancel)
            mnMain.MenuItems.Add(mnAction)
            mnMain.MenuItems.Add(mnMenu)

            pbImage.Image = bmpx.ToBitmap
            pbImage.Size = pbImage.Image.Size
            pbImage.Location = New Point(0, 0)
            Me.Controls.Add(pbImage)

            loc = New Point(pbImage.Width / 2, pbImage.Height / 2)

            Me.Text = "Select Fixed Region"
            Me.Menu = mnMain
        End Sub

#End Region

#Region "Form routines"

        Private Sub Main_Load(ByVal s As Object, ByVal e As EventArgs) Handles MyBase.Load
			Me.Focus
        End Sub
        
        Private Sub Main_LostFocus(ByVal s As Object, ByVal e As EventArgs) Handles MyBase.LostFocus
			Me.Focus
        End Sub

        Private Sub Main_Resize(ByVal s As Object, ByVal e As EventArgs) Handles MyBase.Resize
            pbImage.Location = New Point((Me.Width - pbImage.Width) / 2, (Me.Height - pbImage.Height) / 2)
        End Sub

        Private Sub RefreshImage()
            Dim gx As New GraphicsX(bmpx.Width, bmpx.Height)
            gx.Clear(Color.Black)
            gx.ResetTransform()
            gx.DrawImage(bmpx, New Point(0, 0))

            If Not p1.IsEmpty Then
                Dim r As Rectangle
                If Not p2.IsEmpty Then
                    r = SelectedRectangle
                Else
                    r = New Rectangle(GetMin(New Integer(1) {p1.X, loc.X}), GetMin(New Integer(1) {p1.Y, loc.Y}), Math.Abs(p1.X - loc.X), Math.Abs(p1.Y - loc.Y))
                End If
                If Not r.IsEmpty Then
                    gx.FillRectangle(New SolidBrushX(Utils.FromArgb(175, Color.FromArgb(230, 240, 255))), r)
                    gx.DrawRectangle(New PenX(Color.Blue, 0.3), r)
                End If
            End If

            gx.DrawImage(bmpcur, New Point(loc.X - bmpcur.Width / 2, loc.Y - bmpcur.Height / 2))
            pbImage.Image = gx.ToBitmapX.ToBitmap
            gx = Nothing

            Main_Resize(Me, EventArgs.Empty)
            If pbImage.Width > ClientSize.Width Then
                Dim xi As Integer = loc.X - Math.Abs(pbImage.Left)
                If xi < 0 Then
                    pbImage.Left += Math.Abs(xi)
                End If
                If xi > ClientSize.Width Then
                    pbImage.Location = New Point(pbImage.Left - xi + ClientSize.Width, pbImage.Top)
                End If
            End If
            If pbImage.Height > ClientSize.Height Then
                Dim yi As Integer = loc.Y - Math.Abs(pbImage.Top)
                If yi < 0 Then
                    pbImage.Top += Math.Abs(yi)
                End If
                If yi > ClientSize.Height Then
                    pbImage.Location = New Point(pbImage.Left, pbImage.Top - yi + ClientSize.Height)
                End If
            End If
        End Sub

#Region "Keys"

        Private Sub Main_KeyDown(ByVal s As Object, ByVal e As KeyEventArgs) Handles MyBase.KeyDown
            Select Case e.KeyCode
                Case Keys.Up
                    loc = New Point(loc.X, loc.Y - stp)
                Case Keys.Right
                    loc = New Point(loc.X + stp, loc.Y)
                Case Keys.Down
                    loc = New Point(loc.X, loc.Y + stp)
                Case Keys.Left
                    loc = New Point(loc.X - stp, loc.Y)
                Case Keys.D1
                    stp -= 1
                Case Keys.D2
                    stp += 1
                Case Keys.Return
                    If p1.IsEmpty Then
                        p1 = New Point(loc.X, loc.Y)
                    ElseIf p2.IsEmpty Then
                        p2 = New Point(loc.X, loc.Y)
                        mnAction.Enabled = True
                    End If
            End Select
        End Sub

#End Region

#End Region

#Region "Miscellanious"

        Private Sub pbImage_MouseDown(ByVal s As Object, ByVal e As MouseEventArgs) Handles pbImage.MouseDown
            loc = New Point(e.X, e.Y)
        End Sub

        Private Sub mnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnReset.Click
            p1 = Point.Empty
            p2 = Point.Empty
            mnAction.Enabled = False
            loc = New Point(pbImage.Width / 2, pbImage.Height / 2)
        End Sub

        Private Sub mnAction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAction.Click
            If Not SelectedRectangle.IsEmpty Then
                Me.DialogResult = DialogResult.OK
            Else
                System.Windows.Forms.MessageBox.Show("The specified rectangle is not valid. Please select a valid region.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1)
            End If
        End Sub

        Private Sub mnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCancel.Click
            Me.DialogResult = DialogResult.Cancel
        End Sub

        Private Sub mnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnHelp.Click
            PSI.Tools.cTools.ShowHelp(Me, "Fixed Region", "In this window, you are able to select the fixed region's rectangle you wish to capture. When the window appears, you are shown a full-screen screenshot with a small cursor in the middle. You can use the navigation keys to move the cursor around. To decrease or increase the step-speed of the cursor, use the keys 1 or 2. You can see the current step in the menu." & vbCrLf & vbCrLf & "When you have moved the cursor to one of the corners of the region, hit the action/enter button. Then move the cursor to the other corner. You can dynamically see the selected region. When you have moved the cursor to the other corner, hit the action/enter button to select the current rectangle. Then click Done to finish." & vbCrLf & vbCrLf & "If you want to reset the selecting process, click Menu > Reset. If you want to cancel the process, click Menu > Cancel.")
        End Sub

#End Region

    End Class
End Namespace
