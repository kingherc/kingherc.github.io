'Pocket SnapIt
'Copyright (C) 2004,2005 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

'In addition, as a special exception, Iraklis Psaroudakis gives permission to link the code of this program with the XrossOne Mobile GDI+ library (or with modified versions of XrossOne Mobile GDI+ that use the same license as XrossOne Mobile GDI+), and distribute linked combinations including the two. You must obey the GNU General Public License in all respects for all of the code used other than XrossOne Mobile GDI+. If you modify this file, you may extend this exception to your version of the file, but you are not obligated to do so. If you do not wish to do so, delete this exception statement from your version.

Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports System.Drawing
Imports XrossOne.Drawing
Imports PSI.cAPI.Tools
Imports PSI.Tools.cTools

Namespace PSI

    Public Class fHelp
        Inherits System.Windows.Forms.Form

#Region "Variables & Controls"

        Private fParent As Form

        Friend WithEvents mnMain As New MainMenu
        Friend WithEvents mnAction As New MenuItem

        Friend pbIcon As New PictureBox
        Friend lblTitle As New Label
        Friend txtHelp As New TextBox

#End Region

#Region "Initialization"

        Sub New(ByVal parent As Form, ByVal helpTitle As String, ByVal helpMsg As String)
            MyBase.New()
            fParent = parent
            Init()
            lblTitle.Text = helpTitle
            txtHelp.Text = helpMsg
        End Sub

        Private Sub Init()
            If IsPC() Then
                Me.ClientSize = fParent.ClientSize
            End If
            Me.Location = fParent.Location
            Me.FormBorderStyle = FormBorderStyle.Sizable

            mnAction.Text = "&OK"
            mnMain.MenuItems.Add(mnAction)

            pbIcon.Image = Main.hResources.Item("icoHelp")
            pbIcon.Size = pbIcon.Image.Size
            Me.Controls.Add(pbIcon)

            lblTitle.Font = Main.TitleFont
            lblTitle.Text = "Help"
            lblTitle.TextAlign = ContentAlignment.TopLeft
            Me.Controls.Add(lblTitle)

            txtHelp.Font = Main.UsualFont
            txtHelp.Text = "Undefined help text"
            txtHelp.ReadOnly = True
            txtHelp.Multiline = True
            txtHelp.WordWrap = True
            txtHelp.ScrollBars = ScrollBars.Vertical
            Me.Controls.Add(txtHelp)

            Me.Text = "Help"
            Me.Menu = mnMain
            If IsPC() Then
                Me.BackColor = SystemColors.Control
            Else
                Me.BackColor = Color.White
            End If
        End Sub

#End Region

        Private Sub Main_Load(ByVal s As Object, ByVal e As EventArgs) Handles MyBase.Load

        End Sub

        Private Sub Main_Resize(ByVal s As Object, ByVal e As EventArgs) Handles MyBase.Resize
            pbIcon.Location = New Point(ClientSize.Width - pbIcon.Width - 5, 5)
            lblTitle.Location = New Point(5, 5)
            lblTitle.Size = New Size(pbIcon.Left - lblTitle.Left, pbIcon.Height)
            'txtHelp.Location = New Point(lblTitle.Left, lblTitle.Bottom + 5)
            'txtHelp.Size = New Size(pbIcon.Right - txtHelp.Left, ClientSize.Height - 5 - txtHelp.Top)
            txtHelp.Location = New Point(-1, lblTitle.Bottom + 5)
            txtHelp.Size = New Size(ClientSize.Width + 2, ClientSize.Height - txtHelp.Top + 1)
        End Sub

        Private Sub mnAction_Click(ByVal s As Object, ByVal e As EventArgs) Handles mnAction.Click
            Me.DialogResult = DialogResult.OK
        End Sub

    End Class
End Namespace
