'Pocket SnapIt
'Copyright (C) 2004,2005 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

'In addition, as a special exception, Iraklis Psaroudakis gives permission to link the code of this program with the XrossOne Mobile GDI+ library (or with modified versions of XrossOne Mobile GDI+ that use the same license as XrossOne Mobile GDI+), and distribute linked combinations including the two. You must obey the GNU General Public License in all respects for all of the code used other than XrossOne Mobile GDI+. If you modify this file, you may extend this exception to your version of the file, but you are not obligated to do so. If you do not wish to do so, delete this exception statement from your version.

Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports System.Drawing
Imports XrossOne.Drawing
Imports PSI.cAPI.Tools
Imports PSI.Tools.cTools
Imports PSI.cAPI

Namespace PSI

    Public Class fOptions
        Inherits System.Windows.Forms.Form

#Region "Variables & Controls"

        Private fParent As Form
        Private ops As New Options

        Public ReadOnly Property SelectedOptions() As Options
            Get
                Return ops
            End Get
        End Property

        Friend WithEvents mnMain As New MainMenu
        Friend WithEvents mnAction As New MenuItem
        Friend WithEvents mnMenu As New MenuItem
        Friend WithEvents mnHelp As New MenuItem
        Friend WithEvents mnCancel As New MenuItem
        Friend WithEvents mnSelectFR As New MenuItem
        Friend WithEvents mnOptions As New MenuItem
        Friend WithEvents mnGeneral As New MenuItem
        Friend WithEvents mnConsecutive As New MenuItem
        Friend WithEvents mnStore As New MenuItem
        Friend WithEvents mnStoreDir As New MenuItem
        Friend WithEvents mnCapture As New MenuItem
        Friend WithEvents mnSnapBtn As New MenuItem
        Friend WithEvents mnMisc As New MenuItem

        'General
        Friend WithEvents pnlGeneral As New Panel
        Friend WithEvents icoGeneral As New PictureBox
        Friend WithEvents lblGeneral As New Label
        Friend WithEvents rbtMode1 As New CheckBox
        Friend WithEvents rbtMode2 As New CheckBox
        Friend WithEvents lblFR As New Label

        'Consecutive Snaps
        Friend WithEvents pnlConsecutive As New Panel
        Friend WithEvents icoConsecutive As New PictureBox
        Friend WithEvents lblConsecutive As New Label
        Friend WithEvents rbtConsecutive As New CheckBox
        Friend WithEvents txtInterval As New TextBox
        Friend WithEvents lblInterval As New Label

        'Store Options
        Friend WithEvents pnlStore As New Panel
        Friend WithEvents icoStore As New PictureBox
        Friend WithEvents lblStore As New Label
        Friend WithEvents lblStoreDir As New Label
        Friend WithEvents txtStoreDir As New TextBox
        Friend WithEvents lblStorePre As New Label
        Friend WithEvents txtStorePre As New TextBox
        Friend WithEvents lblStoreDigits As New Label
        Friend WithEvents txtStoreDigits As New TextBox

        'Capture Options
        Friend WithEvents pnlCapture As New Panel
        Friend WithEvents icoCapture As New PictureBox
        Friend WithEvents lblCapture As New Label
        Friend WithEvents rbtCaptureSnd As New CheckBox
        Friend WithEvents lblSnapBtn As New Label
        Friend WithEvents txtSnapBtn As New TextBox

        'Miscellanious
        Friend WithEvents pnlMisc As New Panel
        Friend WithEvents icoMisc As New PictureBox
        Friend WithEvents lblMisc As New Label
        Friend WithEvents lblMisc2 As New Label
        Friend WithEvents rbtMiscListen As New CheckBox
        Friend WithEvents rbtMiscSnap As New CheckBox

#End Region

#Region "Initialization"

        Sub New(ByVal parent As Form)
            MyBase.New()
            fParent = parent
            ops.LoadDefaults()
            Init()
        End Sub
        
        Sub New(ByVal parent As Form, ByVal ops2Load As Options)
            MyBase.New()
            fParent = parent
            ops = ops2Load
            Init()
        End Sub

        Private Sub Init()
            If IsPC() Then
                Me.ClientSize = fParent.ClientSize
            End If
            Me.Location = fParent.Location
            Me.FormBorderStyle = FormBorderStyle.Sizable

            mnAction.Text = "&Done"
            mnMain.MenuItems.Add(mnAction)
            mnMenu.Text = "&Menu"
            mnMain.MenuItems.Add(mnMenu)

            mnOptions.Text = "Options"
            mnMenu.MenuItems.Add(mnOptions)
            Dim sep2 As New MenuItem
            sep2.Text = "-"
            mnMenu.MenuItems.Add(sep2)
            mnSelectFR.Text = "Select Fixed Region..."
            mnSelectFR.Enabled = False
            mnMenu.MenuItems.Add(mnSelectFR)
            mnSnapBtn.Text = "Select Capture Button..."
            mnMenu.MenuItems.Add(mnSnapBtn)
            mnStoreDir.Text = "Select Store Directory..."
            mnMenu.MenuItems.Add(mnStoreDir)
            Dim sep1 As New MenuItem
            sep1.Text = "-"
            mnMenu.MenuItems.Add(sep1)
            mnHelp.Text = "&Help"
            mnMenu.MenuItems.Add(mnHelp)
            mnCancel.Text = "&Cancel"
            mnMenu.MenuItems.Add(mnCancel)

            mnGeneral.Text = "General"
            mnOptions.MenuItems.Add(mnGeneral)
            mnConsecutive.Text = "Consecutive Snaps"
            mnOptions.MenuItems.Add(mnConsecutive)
            mnStore.Text = "Save Options"
            mnOptions.MenuItems.Add(mnStore)
            mnCapture.Text = "Capture Options"
            mnOptions.MenuItems.Add(mnCapture)
            mnMisc.Text = "Miscellanious"
            mnOptions.MenuItems.Add(mnMisc)

            'General
            Me.Controls.Add(pnlGeneral)
            icoGeneral.Image = Main.hResources("icoOptions")
            icoGeneral.Size = icoGeneral.Image.Size
            pnlGeneral.Controls.Add(icoGeneral)
            lblGeneral.Font = Main.TitleFont
            lblGeneral.Text = "General"
            lblGeneral.ForeColor = Color.Blue
            pnlGeneral.Controls.Add(lblGeneral)
            rbtMode1.AutoCheck = False
            rbtMode1.Font = Main.UsualFont
            rbtMode1.Text = "Mode 1: Full-screen"
            pnlGeneral.Controls.Add(rbtMode1)
            rbtMode2.AutoCheck = False
            rbtMode2.Font = Main.UsualFont
            rbtMode2.Text = "Mode 2: Fixed Region"
            pnlGeneral.Controls.Add(rbtMode2)
            lblFR.Visible = False
            lblFR.ForeColor = Color.DarkGray
            pnlGeneral.Controls.Add(lblFR)

            'Consecutive Snaps
            Me.Controls.Add(pnlConsecutive)
            icoConsecutive.Image = Main.hResources("icoConsecutiveOps")
            icoConsecutive.Size = icoConsecutive.Image.Size
            pnlConsecutive.Controls.Add(icoConsecutive)
            lblConsecutive.Font = Main.TitleFont
            lblConsecutive.Text = "Consecutive Snaps"
            lblConsecutive.ForeColor = Color.Blue
            pnlConsecutive.Controls.Add(lblConsecutive)
            rbtConsecutive.AutoCheck = False
            rbtConsecutive.Font = Main.UsualFont
            rbtConsecutive.Text = "Enable consecutive snapshots"
            pnlConsecutive.Controls.Add(rbtConsecutive)
            pnlConsecutive.Controls.Add(txtInterval)
            pnlConsecutive.Controls.Add(lblInterval)
            lblInterval.Font = Main.UsualFont
            lblInterval.Text = "Interval (ms):"

            'Store Options
            Me.Controls.Add(pnlStore)
            txtStoreDir.ReadOnly = True
            pnlStore.Controls.Add(txtStoreDir)
            pnlStore.Controls.Add(txtStorePre)
            pnlStore.Controls.Add(txtStoreDigits)
            icoStore.Image = Main.hResources("icoStoreOps")
            icoStore.Size = icoStore.Image.Size
            pnlStore.Controls.Add(icoStore)
            lblStore.Font = Main.TitleFont
            lblStore.Text = "Save Options"
            lblStore.ForeColor = Color.Blue
            pnlStore.Controls.Add(lblStore)
            lblStoreDir.Font = Main.UsualFont
            lblStoreDir.Text = "Save file in this directory:"
            pnlStore.Controls.Add(lblStoreDir)
            lblStorePre.Font = Main.UsualFont
            lblStorePre.Text = "File prefix:"
            pnlStore.Controls.Add(lblStorePre)
            lblStoreDigits.Font = Main.UsualFont
            lblStoreDigits.Text = "Minimum digits in the name:"
            pnlStore.Controls.Add(lblStoreDigits)

            'Capture Options
            Me.Controls.Add(pnlCapture)
            icoCapture.Image = Main.hResources("icoCaptureOps")
            icoCapture.Size = icoCapture.Image.Size
            pnlCapture.Controls.Add(icoCapture)
            lblCapture.Font = Main.TitleFont
            lblCapture.Text = "Capture Options"
            lblCapture.ForeColor = Color.Blue
            pnlCapture.Controls.Add(lblCapture)
            rbtCaptureSnd.AutoCheck = False
            rbtCaptureSnd.Font = Main.UsualFont
            rbtCaptureSnd.Text = "Sound at each capture"
            pnlCapture.Controls.Add(rbtCaptureSnd)
            lblSnapBtn.Font = Main.UsualFont
            lblSnapBtn.Text = "Capture/Snap Button:"
            pnlCapture.Controls.Add(lblSnapBtn)
            txtSnapBtn.ReadOnly = True
            pnlCapture.Controls.Add(txtSnapBtn)

            'Miscellanious
            Me.Controls.Add(pnlMisc)
            icoMisc.Image = Main.hResources("icoMiscOps")
            icoMisc.Size = icoMisc.Image.Size
            pnlMisc.Controls.Add(icoMisc)
            lblMisc.Font = Main.TitleFont
            lblMisc.Text = "Miscellanious"
            lblMisc.ForeColor = Color.Blue
            pnlMisc.Controls.Add(lblMisc)
            lblMisc2.Font = Main.UsualFont
            lblMisc2.Text = "Upon program startup:"
            pnlMisc.Controls.Add(lblMisc2)
            rbtMiscListen.AutoCheck = False
            rbtMiscListen.Font = Main.UsualFont
            rbtMiscListen.Text = "Start listening"
            pnlMisc.Controls.Add(rbtMiscListen)
            rbtMiscSnap.AutoCheck = False
            rbtMiscSnap.Font = Main.UsualFont
            rbtMiscSnap.Text = "Start capturing"
            pnlMisc.Controls.Add(rbtMiscSnap)

            Me.Text = "Options"
            Me.Menu = mnMain
        End Sub

#End Region

#Region "General"

        Private Sub mnGeneral_Click(ByVal s As Object, ByVal e As EventArgs) Handles mnGeneral.Click
            ClearPanels()
            mnGeneral.Checked = True
            pnlGeneral.Visible = True
            pnlGeneral.Focus()
        End Sub

        Private Sub pnlGeneral_Resize(ByVal s As Object, ByVal e As EventArgs) Handles pnlGeneral.Resize
            icoGeneral.Location = New Point(pnlGeneral.Width - icoGeneral.Width - 3, 3)
            lblGeneral.Location = New Point(3, icoGeneral.Top)
            lblGeneral.Width = icoGeneral.Left - lblGeneral.Left
            lblGeneral.Height = icoGeneral.Height

            rbtMode1.Location = New Point(lblGeneral.Left, lblGeneral.Bottom + 10)
            rbtMode1.Width = icoGeneral.Right - lblGeneral.Left

            rbtMode2.Location = New Point(rbtMode1.Left, rbtMode1.Bottom + 2)
            rbtMode2.Width = rbtMode1.Width

            lblFR.Width = rbtMode2.Width
            lblFR.Location = New Point(rbtMode2.Left, rbtMode2.Bottom + 2)
        End Sub

        Private Sub rbtMode1_Click(ByVal s As Object, ByVal e As EventArgs) Handles rbtMode1.Click
            ops.Mode = 1
            LoadOptions()
        End Sub

        Private Sub rbtMode2_Click(ByVal s As Object, ByVal e As EventArgs) Handles rbtMode2.Click
            ops.Mode = 2
            LoadOptions()
        End Sub

        Private Sub mnSelectFR_Click(ByVal s As Object, ByVal e As EventArgs) Handles mnSelectFR.Click
            Dim hdc As IntPtr = Win.GetDC(Nothing)
            Dim bmpx As BitmapX = PSI.Tools.cTools.GetScreenshot(hdc, New Rectangle(0, 0, Main.ScreenSize.Width, Main.ScreenSize.Height))
            Dim fi As New SelectFR(Me, bmpx)
            If fi.ShowDialog = DialogResult.OK Then
                ops.FixedRegion = fi.SelectedRectangle
                LoadOptions()
            End If
        End Sub

#End Region

#Region "Consecutive"

        Private Sub mnConsecutive_Click(ByVal s As Object, ByVal e As EventArgs) Handles mnConsecutive.Click
            ClearPanels()
            mnConsecutive.Checked = True
            pnlConsecutive.Visible = True
            pnlConsecutive.Focus()
        End Sub

        Private Sub pnlConsecutive_Resize(ByVal s As Object, ByVal e As EventArgs) Handles pnlConsecutive.Resize
            icoConsecutive.Location = New Point(pnlConsecutive.Width - icoConsecutive.Width - 3, 3)
            lblConsecutive.Location = New Point(3, icoConsecutive.Top)
            lblConsecutive.Width = icoConsecutive.Left - lblConsecutive.Left
            lblConsecutive.Height = icoConsecutive.Height

            rbtConsecutive.Location = New Point(lblConsecutive.Left, lblConsecutive.Bottom + 10)
            rbtConsecutive.Width = icoConsecutive.Right - lblConsecutive.Left

            txtInterval.Width = rbtConsecutive.Width / 2
            txtInterval.Location = New Point(icoConsecutive.Right - txtInterval.Width, rbtConsecutive.Bottom + 2)

            lblInterval.Width = txtInterval.Width
            lblInterval.Location = New Point(rbtConsecutive.Left, txtInterval.Top)
        End Sub

        Private Sub rbtConsecutive_Click(ByVal s As Object, ByVal e As EventArgs) Handles rbtConsecutive.Click
            If ops.Consecutive Then
                ops.Consecutive = False
            Else
                ops.Consecutive = True
            End If
            LoadOptions()
        End Sub

        Private Sub txtInterval_Click(ByVal s As Object, ByVal e As EventArgs) Handles txtInterval.TextChanged
            If IsNumeric(txtInterval.Text) Then
                ops.ConsecutiveInterval = Math.Abs(CInt(txtInterval.Text))
            End If
            LoadOptions()
        End Sub

#End Region

#Region "Store"

        Private Sub mnStore_Click(ByVal s As Object, ByVal e As EventArgs) Handles mnStore.Click
            ClearPanels()
            mnStore.Checked = True
            pnlStore.Visible = True
            pnlStore.Focus()
        End Sub

        Private Sub pnlStore_Resize(ByVal s As Object, ByVal e As EventArgs) Handles pnlStore.Resize
            icoStore.Location = New Point(pnlStore.Width - icoStore.Width - 3, 3)
            lblStore.Location = New Point(3, icoStore.Top)
            lblStore.Width = icoStore.Left - lblStore.Left
            lblStore.Height = icoStore.Height

            lblStoreDir.Width = icoStore.Right - lblStore.Left
            lblStoreDir.Location = New Point(lblStore.Left, lblStore.Bottom + 10)

            txtStoreDir.Width = lblStoreDir.Width
            If Not IsSmartphone() Then
                txtStoreDir.Location = New Point(lblStoreDir.Left, lblStoreDir.Bottom + 1)
            Else
                txtStoreDir.Location = New Point(lblStoreDir.Left, lblStoreDir.Bottom - 2)
            End If

            lblStorePre.Width = txtStoreDir.Width
            lblStorePre.Location = New Point(txtStoreDir.Left, txtStoreDir.Bottom + 3)

            txtStorePre.Width = lblStorePre.Width
            If Not IsSmartphone() Then
                txtStorePre.Location = New Point(lblStorePre.Left, lblStorePre.Bottom + 1)
            Else
                txtStorePre.Location = New Point(lblStorePre.Left, lblStorePre.Bottom - 2)
            End If

            lblStoreDigits.Width = txtStorePre.Width
            lblStoreDigits.Location = New Point(txtStorePre.Left, txtStorePre.Bottom + 3)

            txtStoreDigits.Width = lblStoreDigits.Width
            If Not IsSmartphone() Then
                txtStoreDigits.Location = New Point(lblStoreDigits.Left, lblStoreDigits.Bottom + 1)
            Else
                txtStoreDigits.Location = New Point(lblStoreDigits.Left, lblStoreDigits.Bottom - 2)
            End If
        End Sub

        Private Sub mnStoreDir_Click(ByVal s As Object, ByVal e As EventArgs) Handles mnStoreDir.Click
            Dim fi As New fExplorer(Me)
            If fi.ShowDialog = DialogResult.OK Then
                Dim sfi As String = fi.SelectedPath
                If sfi.Substring(sfi.Length - 1) = "\" Or sfi.Substring(sfi.Length - 1) = "/" Then
                    sfi = sfi.Substring(0, sfi.Length - 1)
                End If
                ops.StoreDirectory = sfi
            End If
            LoadOptions()
        End Sub

        Private Sub txtStorePre_Click(ByVal s As Object, ByVal e As EventArgs) Handles txtStorePre.TextChanged
            ops.StorePrefix = txtStorePre.Text
            LoadOptions()
        End Sub

        Private Sub txtStoreDigits_Click(ByVal s As Object, ByVal e As EventArgs) Handles txtStoreDigits.TextChanged
            If IsNumeric(txtStoreDigits.Text) Then
                ops.StoreDigits = Math.Abs(CInt(txtStoreDigits.Text))
            End If
            LoadOptions()
        End Sub

#End Region

#Region "Capture"

        Private GetSnapKey As Boolean = False

        Private Sub mnCapture_Click(ByVal s As Object, ByVal e As EventArgs) Handles mnCapture.Click
            ClearPanels()
            mnCapture.Checked = True
            pnlCapture.Visible = True
            mnSnapBtn.Enabled = True
            pnlCapture.Focus()
        End Sub

        Private Sub pnlCapture_Resize(ByVal s As Object, ByVal e As EventArgs) Handles pnlCapture.Resize
            icoCapture.Location = New Point(pnlCapture.Width - icoCapture.Width - 3, 3)
            lblCapture.Location = New Point(3, icoCapture.Top)
            lblCapture.Width = icoCapture.Left - lblCapture.Left
            lblCapture.Height = icoCapture.Height

            rbtCaptureSnd.Width = icoCapture.Right - lblCapture.Left
            rbtCaptureSnd.Location = New Point(lblCapture.Left, lblCapture.Bottom + 10)

            lblSnapBtn.Width = rbtCaptureSnd.Width
            lblSnapBtn.Location = New Point(rbtCaptureSnd.Left, rbtCaptureSnd.Bottom + 2)

            txtSnapBtn.Width = lblSnapBtn.Width
            txtSnapBtn.Location = New Point(lblSnapBtn.Left, lblSnapBtn.Bottom + 1)
        End Sub

        Private Sub rbtCaptureSnd_Click(ByVal s As Object, ByVal e As EventArgs) Handles rbtCaptureSnd.Click
            If ops.DoPlaySound Then
                ops.DoPlaySound = False
            Else
                ops.DoPlaySound = True
            End If
            LoadOptions()
        End Sub

        Private Sub mnSnapBtn_Click(ByVal s As Object, ByVal e As EventArgs) Handles mnSnapBtn.Click
            System.Windows.Forms.MessageBox.Show("After this messagebox, press the key you want to use as the capture/snap button.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1)
            GetSnapKey = True
            pnlCapture.Focus()
            If IsSmartphone() Then
                txtSnapBtn.Focus()
            End If
        End Sub

        Private Sub pnlCapture_KeyDown(ByVal s As Object, ByVal e As KeyEventArgs) Handles pnlCapture.KeyDown
            If GetSnapKey Then
                ops.SnapButton = e.KeyCode
                GetSnapKey = False
                LoadOptions()
            End If
        End Sub

        Private Sub txtSnapBtn_KeyDown(ByVal s As Object, ByVal e As KeyEventArgs) Handles txtSnapBtn.KeyDown
            If GetSnapKey Then
                pnlCapture_KeyDown(s, e)
            End If
        End Sub

        Private Sub rbtCaptureSnd_KeyDown(ByVal s As Object, ByVal e As KeyEventArgs) Handles rbtCaptureSnd.KeyDown
            If GetSnapKey Then
                pnlCapture_KeyDown(s, e)
            End If
        End Sub

#End Region

#Region "Miscellanious"

        Private Sub mnMisc_Click(ByVal s As Object, ByVal e As EventArgs) Handles mnMisc.Click
            ClearPanels()
            mnMisc.Checked = True
            pnlMisc.Visible = True
            pnlMisc.Focus()
        End Sub

        Private Sub pnlMisc_Resize(ByVal s As Object, ByVal e As EventArgs) Handles pnlMisc.Resize
            icoMisc.Location = New Point(pnlMisc.Width - icoMisc.Width - 3, 3)
            lblMisc.Location = New Point(3, icoMisc.Top)
            lblMisc.Width = icoMisc.Left - lblMisc.Left
            lblMisc.Height = icoMisc.Height

            lblMisc2.Width = icoMisc.Right - lblMisc.Left
            lblMisc2.Location = New Point(lblMisc.Left, lblMisc.Bottom + 10)

            rbtMiscListen.Width = lblMisc2.Width
            rbtMiscListen.Location = New Point(lblMisc2.Left, lblMisc2.Bottom + 1)

            rbtMiscSnap.Width = rbtMiscListen.Width
            rbtMiscSnap.Location = New Point(rbtMiscListen.Left, rbtMiscListen.Bottom + 2)
        End Sub

        Private Sub rbtMiscListen_Click(ByVal s As Object, ByVal e As EventArgs) Handles rbtMiscListen.Click
            If ops.StartImmediately Then
                ops.StartImmediately = False
            Else
                ops.StartImmediately = True
            End If
            LoadOptions()
        End Sub

        Private Sub rbtMiscSnap_Click(ByVal s As Object, ByVal e As EventArgs) Handles rbtMiscSnap.Click
            If ops.SnapImmediately Then
                ops.SnapImmediately = False
            Else
                ops.SnapImmediately = True
            End If
            LoadOptions()
        End Sub

#End Region

#Region "Form's and miscellanious"

        Private Sub Main_Load(ByVal s As Object, ByVal e As EventArgs) Handles MyBase.Load
            LoadOptions()
            mnGeneral_Click(Me, EventArgs.Empty)
        End Sub

        Private Sub Main_Resize(ByVal s As Object, ByVal e As EventArgs) Handles MyBase.Resize
            pnlGeneral.Location = New Point(0, 0)
            pnlGeneral.Size = ClientSize
            pnlConsecutive.Location = New Point(0, 0)
            pnlConsecutive.Size = ClientSize
            pnlStore.Location = New Point(0, 0)
            pnlStore.Size = ClientSize
            pnlCapture.Location = New Point(0, 0)
            pnlCapture.Size = ClientSize
            pnlMisc.Location = New Point(0, 0)
            pnlMisc.Size = ClientSize
        End Sub

        Private Sub mnAction_Click(ByVal s As Object, ByVal e As EventArgs) Handles mnAction.Click
            Dim errormsg As String = ""
            If ops.IsValid(errormsg) Then
                Me.DialogResult = DialogResult.OK
            Else
                System.Windows.Forms.MessageBox.Show("The options provided are not valid." & vbCrLf & errormsg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1)
            End If
        End Sub

        Private Sub mnCancel_Click(ByVal s As Object, ByVal e As EventArgs) Handles mnCancel.Click
            Me.DialogResult = DialogResult.Cancel
        End Sub

        Private Sub mnHelp_Click(ByVal s As Object, ByVal e As EventArgs) Handles mnHelp.Click
            PSI.Tools.cTools.ShowHelp(Me, "Options", "In this window, you are able to select the options of the capture process. The options are divided in several categories you can choose from Menu > Options. If you ever wish to cancel your modifications, click Menu > Cancel." & vbCrLf & vbCrLf & "General:" & vbCrLf & "In this category, you choose the capture mode for each screenshot. If you wish a full-screen one, choose Mode 1. If you wish a screenshot of a fixed region of the screen, choose Mode 2. If you choose Mode 2, you can see the coordinates of the fixed region under the checkbox. You can change those by clicking Menu > Select Fixed Region." & vbCrLf & vbCrLf & "Consecutive Snaps:" & vbCrLf & "If you wish the program to take automatically screenshots, check the checkbox. You can also define the interval in milliseconds, in the following textbox." & vbCrLf & vbCrLf & "Save Options:" & vbCrLf & "In the first textbox, you can see the directory where the screenshots will be saved. To change it, click Menu > Select Store directory. The name of the screenshot will be consisted of a prefix and of some digits. To change how many digits must appear (at least) in the name, fill the digits textbox with the desired number. For example, choosing a prefix of 'Snap' and 2 digits would result in a series of screenshots: 'Snap01.bmp, Snap02.bmp etc'." & vbCrLf & vbCrLf & "Capture Options:" & vbCrLf & "To enable sound at each screenshot, check the first checkbox. To change the capture button, click Menu > Select Capture Button. The capture button is not shown with its name, but with a key code." & vbCrLf & vbCrLf & "Miscellanious:" & vbCrLf & "If you wish the program to start listening for the capture key automatically upon startup, check the first checkbox. In this way, when you start the program, it hides itself, and you can then click the capture key to start the capture process/take a screenshot. If you also wish the program to automatically do this without having to click the capture key to start the capture process, check also the second checkbox. If you check any of these checkboxes, it would also be a good idea to enable the screenshot sound so that you can keep track of the screenshot(s).")
        End Sub

        Private Sub ClearPanels()
            mnGeneral.Checked = False
            pnlGeneral.Visible = False
            mnConsecutive.Checked = False
            pnlConsecutive.Visible = False
            mnStore.Checked = False
            pnlStore.Visible = False
            mnCapture.Checked = False
            pnlCapture.Visible = False
            mnSnapBtn.Enabled = False
            mnMisc.Checked = False
            pnlMisc.Visible = False
        End Sub

        Private Sub LoadOptions()
            If ops.Mode = 1 Then
                rbtMode1.Checked = True
                rbtMode2.Checked = False
                mnSelectFR.Enabled = False
                lblFR.Visible = False
            End If
            If ops.Mode = 2 Then
                rbtMode2.Checked = True
                rbtMode1.Checked = False
                mnSelectFR.Enabled = True
                lblFR.Visible = True
            End If
            lblFR.Text = ops.FixedRegion.X & ", " & ops.FixedRegion.Y & ", " & ops.FixedRegion.Width & ", " & ops.FixedRegion.Height

            If ops.Consecutive Then
                rbtConsecutive.Checked = True
                txtInterval.Enabled = True
            Else
                rbtConsecutive.Checked = False
                txtInterval.Enabled = False
            End If
            txtInterval.Text = ops.ConsecutiveInterval

            txtStoreDir.Text = ops.StoreDirectory
            txtStorePre.Text = ops.StorePrefix
            txtStoreDigits.Text = ops.StoreDigits

            If ops.DoPlaySound Then
                rbtCaptureSnd.Checked = True
            Else
                rbtCaptureSnd.Checked = False
            End If

            txtSnapBtn.Text = ops.SnapButton

            If ops.StartImmediately Then
                rbtMiscListen.Checked = True
            Else
                rbtMiscListen.Checked = False
            End If
            If ops.SnapImmediately Then
                rbtMiscSnap.Checked = True
            Else
                rbtMiscSnap.Checked = False
            End If
        End Sub

#End Region

    End Class
End Namespace
