'Pocket SnapIt
'Copyright (C) 2004,2005 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

'In addition, as a special exception, Iraklis Psaroudakis gives permission to link the code of this program with the XrossOne Mobile GDI+ library (or with modified versions of XrossOne Mobile GDI+ that use the same license as XrossOne Mobile GDI+), and distribute linked combinations including the two. You must obey the GNU General Public License in all respects for all of the code used other than XrossOne Mobile GDI+. If you modify this file, you may extend this exception to your version of the file, but you are not obligated to do so. If you do not wish to do so, delete this exception statement from your version.

Imports System.Text
Imports System.IO
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.ValueType
Imports System.Windows.Forms
Imports System
Imports System.Drawing
Imports PSI.cAPI.Tools

Namespace PSI.cAPI.InnerAPI

    Public Class InnerAPICalls

#Region "Windows"

        Public Structure RECT
            Dim left As Integer
            Dim top As Integer
            Dim right As Integer
            Dim bottom As Integer
        End Structure

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
    Public Shared Function GetWindowRect(ByVal hWnd As IntPtr, ByRef lpRect As RECT) As Integer
        End Function

        <System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint:="GetWindowRect")> _
Public Shared Function GetWindowRectWindows(ByVal hWnd As IntPtr, ByRef lpRect As RECT) As Integer
        End Function

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
    Public Shared Function GetDC(ByVal hWnd As IntPtr) As IntPtr
        End Function

        <System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint:="GetDC")> _
Public Shared Function GetDCWindows(ByVal hWnd As IntPtr) As IntPtr
        End Function

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function ReleaseDC(ByVal hWnd As IntPtr, ByVal hDC As IntPtr) As Integer
        End Function

        <System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint:="ReleaseDC")> _
Public Shared Function ReleaseDCWindows(ByVal hWnd As IntPtr, ByVal hDC As IntPtr) As Integer
        End Function

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
    Public Shared Function GetActiveWindow() As IntPtr
        End Function

        <System.Runtime.InteropServices.DllImport("User32.dll", EntryPoint:="GetActiveWindow")> _
Public Shared Function GetActiveWindowWindows() As IntPtr
        End Function

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function GetModuleHandle(ByVal lpModuleName As String) As IntPtr
        End Function

        <System.Runtime.InteropServices.DllImport("Kernel32.dll", EntryPoint:="GetModuleHandle")> _
Public Shared Function GetModuleHandleWindows(ByVal lpModuleName As String) As IntPtr
        End Function

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function PlaySound(ByVal pszSound As String, ByVal hmod As IntPtr, ByVal fdwSound As Integer) As Boolean
        End Function

        <System.Runtime.InteropServices.DllImport("Winmm.dll", EntryPoint:="PlaySound")> _
Public Shared Function PlaySoundWindows(ByVal pszSound As String, ByVal hmod As IntPtr, ByVal fdwSound As Integer) As Boolean
        End Function

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function GetAsyncKeyState(ByVal vKey As Integer) As Short
        End Function

        <System.Runtime.InteropServices.DllImport("User32.dll", EntryPoint:="GetAsyncKeyState")> _
Public Shared Function GetAsyncKeyStateWindows(ByVal vKey As Integer) As Short
        End Function
        
        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function SetForegroundWindow(ByVal hWnd As IntPtr) As Integer
        End Function

        <System.Runtime.InteropServices.DllImport("User32.dll", EntryPoint:="SetForegroundWindow")> _
Public Shared Function SetForegroundWindowWindows(ByVal hWnd As IntPtr) As Integer
        End Function

#Region "Resources"

        '        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
        'Public Shared Function LoadImage(ByVal hInstance As IntPtr, ByVal lpszName As String, ByVal uType As Integer, ByVal cxDesired As Integer, ByVal cyDesired As Integer, ByVal fuLoad As Integer) As IntPtr
        '        End Function

        '        <System.Runtime.InteropServices.DllImport("User32.dll", EntryPoint:="LoadImage")> _
        'Public Shared Function LoadImageWindows(ByVal hInstance As IntPtr, ByVal lpszName As String, ByVal uType As Integer, ByVal cxDesired As Integer, ByVal cyDesired As Integer, ByVal fuLoad As Integer) As IntPtr
        '        End Function

        '        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
        'Public Shared Function FindResource(ByVal hModule As IntPtr, ByVal lpName As String, ByVal lpType As String) As IntPtr
        '        End Function

        '        <System.Runtime.InteropServices.DllImport("Kernel32.dll", EntryPoint:="FindResource")> _
        'Public Shared Function FindResourceWindows(ByVal hModule As IntPtr, ByVal lpName As String, ByVal lpType As String) As IntPtr
        '        End Function

        '        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
        'Public Shared Function LoadBitmap(ByVal hInstance As IntPtr, ByVal lpBitmapName As String) As IntPtr
        '        End Function

        '        <System.Runtime.InteropServices.DllImport("User32.dll", EntryPoint:="LoadBitmap")> _
        'Public Shared Function LoadBitmapWindows(ByVal hInstance As IntPtr, ByVal lpBitmapName As String) As IntPtr
        '        End Function

#End Region

#Region "GetPlatformName & DoubleClickTime"

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
    Public Shared Function GetDoubleClickTime() As Integer
        End Function

        <System.Runtime.InteropServices.DllImport("User32.dll", EntryPoint:="GetDoubleClickTime")> _
    Public Shared Function GetWindowsDoubleClickTime() As Integer
        End Function

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
        Public Shared Function SystemParametersInfo(ByVal uiAction As Integer, ByVal uiParam As Integer, ByVal pvParam As Byte(), ByVal fWinIni As Integer) As Integer
        End Function

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
    Public Shared Function GetLastError() As IntPtr
        End Function

        <System.Runtime.InteropServices.DllImport("Kernel32.dll", EntryPoint:="GetLastError")> _
    Public Shared Function GetLastErrorWindows() As IntPtr
        End Function

#End Region

#Region "GetSpecialFolder"

        Public Const MAX_PATH As Integer = 260

        <System.Runtime.InteropServices.DllImport("coredll.dll")> _
        Public Shared Function SHGetSpecialFolderPath(ByVal hwndOwner As IntPtr, ByVal lpszPath As Byte(), ByVal nFolder As Integer, ByVal fCreate As Integer) As Boolean
        End Function

        <System.Runtime.InteropServices.DllImport("shell32.dll", EntryPoint:="SHGetSpecialFolderPath")> _
    Public Shared Function SHGetSpecialFolderPathWindows(ByVal hwndOwner As IntPtr, ByVal lpszPath As Byte(), ByVal nFolder As Integer, ByVal fCreate As Integer) As Boolean
        End Function

#End Region

#End Region

#Region "GDI"

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function CreateCompatibleDC(ByVal hdc As IntPtr) As IntPtr
        End Function

        <System.Runtime.InteropServices.DllImport("gdi32.dll", EntryPoint:="CreateCompatibleDC")> _
Public Shared Function CreateCompatibleDCWindows(ByVal hdc As IntPtr) As IntPtr
        End Function

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function DeleteDC(ByVal hdc As IntPtr) As Integer
        End Function

        <System.Runtime.InteropServices.DllImport("gdi32.dll", EntryPoint:="DeleteDC")> _
Public Shared Function DeleteDCWindows(ByVal hdc As IntPtr) As Integer
        End Function

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function CreateCompatibleBitmap(ByVal hdc As IntPtr, ByVal nWidth As Integer, ByVal nHeight As Integer) As IntPtr
        End Function

        <System.Runtime.InteropServices.DllImport("gdi32.dll", EntryPoint:="CreateCompatibleBitmap")> _
Public Shared Function CreateCompatibleBitmapWindows(ByVal hdc As IntPtr, ByVal nWidth As Integer, ByVal nHeight As Integer) As IntPtr
        End Function

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function SelectObject(ByVal hdc As IntPtr, ByVal hgdiobj As IntPtr) As IntPtr
        End Function

        <System.Runtime.InteropServices.DllImport("gdi32.dll", EntryPoint:="SelectObject")> _
Public Shared Function SelectObjectWindows(ByVal hdc As IntPtr, ByVal hgdiobj As IntPtr) As IntPtr
        End Function

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function DeleteObject(ByVal hObject As IntPtr) As Integer
        End Function

        <System.Runtime.InteropServices.DllImport("gdi32.dll", EntryPoint:="DeleteObject")> _
Public Shared Function DeleteObjectWindows(ByVal hObject As IntPtr) As Integer
        End Function

        <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function BitBlt(ByVal hdcDest As IntPtr, ByVal nXDest As Integer, ByVal nYDest As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal hdcSrc As IntPtr, ByVal nXSrc As Integer, ByVal nYSrc As Integer, ByVal dwRop As Integer) As Integer
        End Function

        <System.Runtime.InteropServices.DllImport("gdi32.dll", EntryPoint:="BitBlt")> _
Public Shared Function BitBltWindows(ByVal hdcDest As IntPtr, ByVal nXDest As Integer, ByVal nYDest As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal hdcSrc As IntPtr, ByVal nXSrc As Integer, ByVal nYSrc As Integer, ByVal dwRop As Integer) As Integer
        End Function

#End Region

    End Class

End Namespace
