'Pocket Image Editor
'Copyright (C) 2004 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection

Public Class SaveImageBMP

    'This class creates a .bmp file from its structure. Because I have not made a profound search in bmp's file structure, I have used the most hassle-free values and no compression (that is 24-bit which required no color table). If anyone can ameliorate this (I mean adding a compression or saving to another type), please do!

    Public Structure BITMAPINFOHEADER 'Contains info about the bitmap. This is written after BITMAPFILEHEADER.

        Public biSize As Int32 '40
        Public biWidth As Integer
        Public biHeight As Integer
        Public biPlanes As Short '1
        Public biBitCount As Short '16 or 24 usually. better 24 for now
        Public biCompression As Int32 '0
        Public biSizeImage As Int32
        Public biXPelsPerMeter As Integer '0
        Public biYPelsPerMeter As Integer '0
        Public biClrUsed As Int32 '0
        Public biClrImportant As Int32 '0

    End Structure

    Public Structure BITMAPFILEHEADER 'Contains info about the file.

        Public bfType As Int16 '19778
        Public bfSize As Int32
        Public bfReserved1 As Short '0
        Public bfReserved2 As Short '0
        Public bfOffBits As Int32 '54

    End Structure

    Public Shared Sub SaveImageToFile(ByVal img As Image, ByVal strPath As String)
        Dim bw As BinaryWriter
        Dim ms As MemoryStream
        Dim fs As FileStream
        Dim infoHdr As New BITMAPINFOHEADER
        Dim fileHdr As New BITMAPFILEHEADER
        Dim bmp As New Bitmap(img)

        'Modifying infoHdr
        infoHdr.biSize = 40
        infoHdr.biWidth = img.Width
        infoHdr.biHeight = img.Height
        infoHdr.biPlanes = 1
        infoHdr.biBitCount = 24
        infoHdr.biCompression = 0
        infoHdr.biSizeImage = 0
        infoHdr.biXPelsPerMeter = 0
        infoHdr.biYPelsPerMeter = 0
        infoHdr.biClrUsed = 0
        infoHdr.biClrImportant = 0
        'Modifying fileHdr
        fileHdr.bfType = 19778
        fileHdr.bfReserved1 = 0
        fileHdr.bfReserved2 = 0
        fileHdr.bfOffBits = 54
        fileHdr.bfSize = 0 'This will be changed later.
        'Special Operation for fileHdr.bfSize for 32-bit scan lines in order to find out bfSize.
        Dim bitsPerLine As Integer = infoHdr.biWidth * infoHdr.biBitCount
        Dim bitsOff As Integer = Decimal.op_Modulus(bitsPerLine, 32)
        Dim totalBitsPerLine As Integer = bitsPerLine + bitsOff
        fileHdr.bfSize = (totalBitsPerLine * infoHdr.biHeight) + fileHdr.bfOffBits

        'End of All preparation procedures. Right on to writing the BMP file which must be processed from bottom-left pixel to upper-right pixel. BGR format!

        'Open a memory stream, then a binary and finally a file stream.

        Dim bytes(fileHdr.bfSize) As Byte 'This holds the data for the file
        ms = New MemoryStream(bytes)
        bw = New BinaryWriter(ms)
        bw.Write(fileHdr.bfType) 'Here is where the strctures are used.
        bw.Write(fileHdr.bfSize)
        bw.Write(fileHdr.bfReserved1)
        bw.Write(fileHdr.bfReserved2)
        bw.Write(fileHdr.bfOffBits)

        bw.Write(infoHdr.biSize)
        bw.Write(infoHdr.biWidth)
        bw.Write(infoHdr.biHeight)
        bw.Write(infoHdr.biPlanes)
        bw.Write(infoHdr.biBitCount)
        bw.Write(infoHdr.biCompression)
        bw.Write(infoHdr.biSizeImage)
        bw.Write(infoHdr.biXPelsPerMeter)
        bw.Write(infoHdr.biYPelsPerMeter)
        bw.Write(infoHdr.biClrUsed)
        bw.Write(infoHdr.biClrImportant)

        'Now Write Each scan line with pixel info!

        Dim w As Integer, h As Integer, i As Integer

        For h = img.Height - 1 To 0 Step -1 'For every pixel in height
            For w = 0 To img.Width - 1 'For every pixel in width

                'Write Bytes for each intensity of the three basic colors in BGR (blue-green-red) format for each pixel.

                Dim color As Color = bmp.GetPixel(w, h)
                Dim red As System.Int32 = CByte(color.R)
                Dim green As System.Int32 = CByte(color.G)
                Dim blue As System.Int32 = CByte(color.B)

                bw.Write(CByte(blue)) 'Write Blue intensity
                bw.Write(CByte(green)) 'Write Green intensity
                bw.Write(CByte(red)) 'Write Red intensity

            Next
        Next

        fs = File.Create(strPath) 'Create a file to write the bmp bytes

        fs.Write(bytes, 0, CType(fileHdr.bfSize, Integer))

        'Closing Sub
        fs.Close()
        bw.Close()
        ms.Close()
        ms = Nothing
        bytes = Nothing
        bw = Nothing
        w = Nothing
        h = Nothing
        i = Nothing
        fs = Nothing
        totalBitsPerLine = Nothing
        bitsOff = Nothing
        bitsPerLine = Nothing
        bmp = Nothing
        fileHdr = Nothing
        infoHdr = Nothing

    End Sub


End Class

