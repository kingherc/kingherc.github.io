    'Pocket Image Editor
    'Copyright (C) 2004 Iraklis Psaroudakis

    'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
    'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

    'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.Windows.Forms

Public Class InputDialog
    Inherits System.Windows.Forms.Form

    Public RequiredType As TypeCode = TypeCode.String 'Still working on it... Avoid using this.
    Public RequireType As Boolean = True
    Dim WorkingSize As Size

    Public Property AssignedValue() As String
        Get
            Return txtField.Text
        End Get
        Set(ByVal Value As String)
            txtField.Text = Value
        End Set
    End Property
    Public Property Description() As String
        Get
            Return lblDescription.Text
        End Get
        Set(ByVal Value As String)
            lblDescription.Text = Value
        End Set
    End Property

    Public Sub New()
        MyBase.New()
        Init()
    End Sub

    Friend WithEvents MainMenu As New System.Windows.Forms.MainMenu
    Friend WithEvents mnDone As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMenu As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCancel As New System.Windows.Forms.MenuItem
    Friend WithEvents lblEnterValue As New System.Windows.Forms.Label
    Friend WithEvents txtField As New System.Windows.Forms.TextBox
    Friend WithEvents lblPreDescription As New System.Windows.Forms.Label
    Friend WithEvents lblDescription As New System.Windows.Forms.TextBox
    Friend WithEvents SmartphoneBoxPanel As New System.Windows.Forms.Panel

    Sub Init()
        If Not LCase(frmMain.PlatformType).IndexOf(LCase("WindowsPC")) = -1 Then
            WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        Else
            WorkingSize = New Size(System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height)
            'WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        End If

        MainMenu.MenuItems.Add(mnDone)
        MainMenu.MenuItems.Add(mnMenu)

        mnDone.Text = "Done"

        mnMenu.MenuItems.Add(mnCancel)
        mnMenu.Text = "Menu"

        mnCancel.Text = "Cancel"

        lblEnterValue.Font = frmMain.LabelFont
        lblEnterValue.Size = New System.Drawing.Size(176, 22)
        lblEnterValue.Text = "Enter required value:"

        txtField.Location = New System.Drawing.Point(2, 22)
        txtField.Size = New System.Drawing.Size(WorkingSize.Width - 2, 30)
        txtField.Text = ""

        lblPreDescription.Font = frmMain.LabelFont
        lblPreDescription.Location = New System.Drawing.Point(2, 52)
        lblPreDescription.Size = New System.Drawing.Size(172, 16)
        lblPreDescription.Text = "Description:"

        lblDescription.Font = frmMain.LabelFont
        lblDescription.Location = New System.Drawing.Point(3, 72)
        lblDescription.Size = New System.Drawing.Size(WorkingSize.Width - 5, WorkingSize.Height - 2 - lblDescription.Top)
        lblDescription.MultiLine = True
        lblDescription.ReadOnly = True
        lblDescription.WordWrap = True
        lblDescription.Scrollbars = ScrollBars.Vertical
        lblDescription.Text = "None."

        SmartphoneBoxPanel.Size = frmMain.SmartphonePanelsSize
        SmartphoneBoxPanel.Location = New Point(WorkingSize.Width / 2 - SmartphoneBoxPanel.Width / 2, 0)

        SmartphoneBoxPanel.Controls.Add(lblDescription)
        SmartphoneBoxPanel.Controls.Add(lblPreDescription)
        SmartphoneBoxPanel.Controls.Add(txtField)
        SmartphoneBoxPanel.Controls.Add(lblEnterValue)
        Me.Controls.Add(SmartphoneBoxPanel)
        Me.Menu = MainMenu
        Me.Text = "Input Dialog"
        Me.WindowState = System.Windows.Forms.FormWindowState.Normal

    End Sub

    Private Sub frmExplorer_Resize(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        If Me.ClientSize.Width >= frmMain.SmartphonePanelsSize.Width And Me.ClientSize.Height >= frmMain.SmartphonePanelsSize.Height Then
            WorkingSize = Me.ClientSize
            SmartphoneBoxPanel.Size = Me.ClientSize
            SmartphoneBoxPanel.Location = New Point(WorkingSize.Width / 2 - SmartphoneBoxPanel.Width / 2, (WorkingSize.Height - SmartphoneBoxPanel.Height) / 2)
            lblDescription.Size = New System.Drawing.Size(WorkingSize.Width - 5, WorkingSize.Height - 2 - lblDescription.Top)
            txtField.Width = Me.ClientSize.Width - 4
        Else
            If Not Me.ClientSize.Width >= frmMain.SmartphonePanelsSize.Width Then
                Me.ClientSize = New Size(frmMain.SmartphonePanelsSize.Width, Me.ClientSize.Height)
            End If
            If Not Me.ClientSize.Height >= frmMain.SmartphonePanelsSize.Height Then
                Me.ClientSize = New Size(Me.ClientSize.Width, frmMain.SmartphonePanelsSize.Height)
            End If
        End If
    End Sub

    Private Sub mnDone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDone.Click
        If (txtField.Text).GetTypeCode = RequiredType Then
            Me.DialogResult = DialogResult.OK
        Else
            System.Windows.Forms.MessageBox.Show("The value you entered is not of the required type. Please enter another value." & vbCrLf & "Type Required: " & RequiredType, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
        End If
    End Sub

    Private Sub mnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCancel.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

End Class

