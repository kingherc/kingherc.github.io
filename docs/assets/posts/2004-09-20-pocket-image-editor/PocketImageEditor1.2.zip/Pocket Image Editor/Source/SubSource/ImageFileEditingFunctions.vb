'Pocket Image Editor
'Copyright (C) 2004 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection

Public Class ImageEditingFunctions

    Public Shared Function GetNegativeColorsImage(ByVal Image2Edit As Image, ByVal EditArea As Rectangle) As Image
        'Returns an image with the negative colors.
        Dim edBit As Bitmap = Image2Edit
        Dim ed2Bit As Bitmap = Image2Edit
        Dim i As Integer = 1
        Dim r As Integer = 1
        For i = EditArea.Y To (EditArea.Height - 1 + EditArea.Y)
            For r = EditArea.X To (EditArea.Width - 1 + EditArea.X)
                Dim prColor As Color = ed2Bit.GetPixel(r, i)
                Dim neColor As Color = Color.FromArgb(255 - prColor.R, 255 - prColor.G, 255 - prColor.B)
                edBit.SetPixel(r, i, neColor)
                prColor = Nothing
                neColor = Nothing
            Next
        Next
        Return edBit

        edBit = Nothing
        ed2Bit = Nothing
        i = Nothing
        r = Nothing
    End Function

    Public Shared Function GetLightnessAdjusted(ByVal Image2Edit As Image, ByVal LightnessInteger As Integer, ByVal EditArea As Rectangle) As Image
        'Returns an image with the negative colors.
        Dim edBit As Bitmap = Image2Edit
        Dim ed2Bit As Bitmap = Image2Edit
        Dim i As Integer = 1
        Dim r As Integer = 1
        For i = EditArea.Y To (EditArea.Height - 1 + EditArea.Y)
            For r = EditArea.X To (EditArea.Width - 1 + EditArea.X)
                Dim prColor As Color = ed2Bit.GetPixel(r, i)
                Dim neColor As Color
                If LightnessInteger > 0 Then
                    neColor = Color.FromArgb(Math.Min(prColor.R + LightnessInteger, 255), Math.Min(prColor.G + LightnessInteger, 255), Math.Min(prColor.B + LightnessInteger, 255))
                Else
                    neColor = Color.FromArgb(Math.Max(prColor.R + LightnessInteger, 0), Math.Max(prColor.G + LightnessInteger, 0), Math.Max(prColor.B + LightnessInteger, 0))
                End If
                edBit.SetPixel(r, i, neColor)
                prColor = Nothing
                neColor = Nothing
            Next
        Next
        Return edBit

        edBit = Nothing
        ed2Bit = Nothing
        i = Nothing
        r = Nothing
    End Function

    Public Shared Function GetFlippedImage(ByVal Image2Edit As Image, ByVal IsHorizontal As Boolean, ByVal EditArea As Rectangle) As Image
        'Returns an image flipped horizontally (true) or vertically (false).
        Dim edBit As New Bitmap(Image2Edit)
        Dim ed2Bit As Bitmap = Image2Edit
        Dim i As Integer = 1
        Dim r As Integer = 1
        For i = EditArea.Y To (EditArea.Height - 1 + EditArea.Y)
            For r = EditArea.X To (EditArea.Width - 1 + EditArea.X)
                Dim nColor As Color = Color.FromArgb(0, 0, 0)
                If IsHorizontal Then
                    nColor = ed2Bit.GetPixel(EditArea.Right - (r - EditArea.X) - 1, i)
                Else
                    nColor = ed2Bit.GetPixel(r, EditArea.Bottom - (i - EditArea.Y) - 1)
                End If
                edBit.SetPixel(r, i, nColor)
                nColor = Nothing
            Next
        Next
        Return edBit

        edBit = Nothing
        ed2Bit = Nothing
        i = Nothing
        r = Nothing
    End Function

    Public Shared Function pDrawLine(ByVal Image2Edit As Image, ByVal LineCommands As Hashtable) As Image
        Dim g As Graphics = Graphics.FromImage(Image2Edit)
        Dim i As Integer
        Dim isEvenNumber As Boolean = True
        Dim IsHorizontal As Boolean = False
        Dim IsVertical As Boolean = False
        Dim IsNotHOrV As Boolean = False

        If LineCommands("X1") = LineCommands("X2") Then
            IsVertical = True
        End If
        If LineCommands("Y1") = LineCommands("Y2") Then
            IsHorizontal = True
        End If
        If IsHorizontal = False And IsVertical = False Then
            IsNotHOrV = True
        End If

        If LineCommands("Width") = 1 Then
            g.DrawLine(New Pen(LineCommands("Color")), LineCommands("X1"), LineCommands("Y1"), LineCommands("X2"), LineCommands("Y2"))
        Else
            g.DrawLine(New Pen(LineCommands("Color")), LineCommands("X1"), LineCommands("Y1"), LineCommands("X2"), LineCommands("Y2"))
            For i = 2 To LineCommands("Width")
                If isEvenNumber Then
                    'g.DrawLine(New Pen(LineCommands("Color")), LineCommands("X1"), LineCommands("Y1"), LineCommands("X2"), LineCommands("Y2"))

                    If IsHorizontal Then
                        g.DrawLine(New Pen(LineCommands("Color")), LineCommands("X1"), LineCommands("Y1") - CInt(CStr(i / 2).Substring(0, 1)), LineCommands("X2"), LineCommands("Y2") - CInt(CStr(i / 2).Substring(0, 1)))
                    ElseIf IsVertical Then
                        g.DrawLine(New Pen(LineCommands("Color")), LineCommands("X1") - CInt(CStr(i / 2).Substring(0, 1)), LineCommands("Y1"), LineCommands("X2") - CInt(CStr(i / 2).Substring(0, 1)), LineCommands("Y2"))
                    End If
                    If IsNotHOrV Then
                        g.DrawLine(New Pen(LineCommands("Color")), LineCommands("X1") - CInt(CStr(i / 2).Substring(0, 1)), LineCommands("Y1"), LineCommands("X2") - CInt(CStr(i / 2).Substring(0, 1)), LineCommands("Y2"))
                    End If

                    isEvenNumber = False
                Else

                    If IsHorizontal Then
                        g.DrawLine(New Pen(LineCommands("Color")), LineCommands("X1"), LineCommands("Y1") + CInt(CStr(i / 2).Substring(0, 1)), LineCommands("X2"), LineCommands("Y2") + CInt(CStr(i / 2).Substring(0, 1)))
                    ElseIf IsVertical Then
                        g.DrawLine(New Pen(LineCommands("Color")), LineCommands("X1") + CInt(CStr(i / 2).Substring(0, 1)), LineCommands("Y1"), LineCommands("X2") + CInt(CStr(i / 2).Substring(0, 1)), LineCommands("Y2"))
                    End If
                    If IsNotHOrV Then
                        g.DrawLine(New Pen(LineCommands("Color")), LineCommands("X1") + CInt(CStr(i / 2).Substring(0, 1)), LineCommands("Y1"), LineCommands("X2") + CInt(CStr(i / 2).Substring(0, 1)), LineCommands("Y2"))
                    End If

                    isEvenNumber = True
                End If
            Next
        End If

        Return Image2Edit

        isEvenNumber = Nothing
        IsHorizontal = Nothing
        IsVertical = Nothing
        IsNotHOrV = Nothing
        i = Nothing
        g = Nothing
    End Function

    Public Shared Function pReplaceColorSelection(ByVal Image2Edit As Image, ByVal rC As Rectangle, ByVal ColorFill As Color, ByVal ColorReplace As Color) As Image
        Dim edBit As Bitmap = Image2Edit
        Dim i As Integer = 1
        Dim r As Integer = 1
        For i = rC.X To rC.Right
            For r = rC.Y To rC.Bottom
                If edBit.GetPixel(i, r).ToArgb() = ColorReplace.ToArgb() Then
                    edBit.SetPixel(i, r, ColorFill)
                End If
            Next
        Next
        Return edBit
        i = Nothing
        r = Nothing
        edBit = Nothing
    End Function

    Public Shared Function pDrawString(ByVal Image2Edit As Image, ByVal t As Hashtable) As Image
        Dim nFontStyle As FontStyle
        Dim nPoint As Point = t("Point")
        Dim nrc As Rectangle = t("Rectangle")
        If t("Bold") Then 'If Bold
            If t("Italic") Then 'If Bold and italic
                If t("Underline") Then 'If Bold and underline and italic
                    nFontStyle = FontStyle.Bold And FontStyle.Italic And FontStyle.Underline
                Else 'If bold and italic
                    nFontStyle = FontStyle.Bold And FontStyle.Italic
                End If
            Else
                If t("Underline") Then 'If Bold and underline
                    nFontStyle = FontStyle.Bold And FontStyle.Underline
                Else 'If only bold after all
                    nFontStyle = FontStyle.Bold
                End If
            End If
        Else 'If not bold
            If t("Italic") Then 'If Italic
                If t("Underline") Then 'If Italic and underline
                    nFontStyle = FontStyle.Italic And FontStyle.Underline
                Else 'If Only italic
                    nFontStyle = FontStyle.Italic
                End If
            Else 'If not bold or italic
                If t("Underline") Then
                    nFontStyle = FontStyle.Underline
                Else
                    nFontStyle = FontStyle.Regular
                End If
            End If
        End If
        '---------
        Dim nFontFamily As FontFamily
        Dim nFont As Font
        Select Case t("Font")
            Case 0
                nFontFamily = FontFamily.GenericMonospace
                nFont = New Font(nFontFamily, t("Size"), nFontStyle)
            Case 1
                nFontFamily = FontFamily.GenericSansSerif
                nFont = New Font(nFontFamily, t("Size"), nFontStyle)
            Case 2
                nFontFamily = FontFamily.GenericSerif
                nFont = New Font(nFontFamily, t("Size"), nFontStyle)
            Case 3
                nFont = New Font(CStr(t("FontString")), t("Size"), nFontStyle)
        End Select
        '---------
        Dim tempbit As Bitmap = New Bitmap(Image2Edit)
        Dim g As Graphics = Graphics.FromImage(tempbit)

        If t("UseRectangle") Then
            g.DrawString(t("Text"), nFont, New SolidBrush(t("Color")), New RectangleF(nrc.X, nrc.Y, nrc.Width, nrc.Height))
        Else
            g.DrawString(t("Text"), nFont, New SolidBrush(t("Color")), nPoint.X, nPoint.Y)
        End If

        Return tempbit
        tempbit = Nothing
        g = Nothing
        nFont = Nothing
        nFontFamily = Nothing
        nPoint = Nothing
        nFontStyle = Nothing
        nrc = Nothing
    End Function

    Public Shared Function GetBlackWhite(ByVal Image2Edit As Image, ByVal EditArea As Rectangle) As Image
        'Returns an image with the negative colors.
        Dim edBit As Bitmap = Image2Edit
        Dim ed2Bit As Bitmap = Image2Edit
        Dim i As Integer = 1
        Dim r As Integer = 1
        For i = EditArea.Y To (EditArea.Height - 1 + EditArea.Y)
            For r = EditArea.X To (EditArea.Width - 1 + EditArea.X)
                Dim prColor As Color = ed2Bit.GetPixel(r, i)
                Dim BWint As Integer = (CInt(prColor.R) + CInt(prColor.G) + CInt(prColor.B)) / 3
                If BWint > 255 Then
                    BWint = 255
                End If
                If BWint < 0 Then
                    BWint = 0
                End If
                edBit.SetPixel(r, i, Color.FromArgb(BWint, BWint, BWint))
                prColor = Nothing
                BWint = Nothing
            Next
        Next
        Return edBit

        edBit = Nothing
        ed2Bit = Nothing
        i = Nothing
        r = Nothing
    End Function

    Public Shared Function DrawRectangle(ByVal Image2Edit As Image, ByVal rc As Rectangle, ByVal Attr As Hashtable) As Image
        Dim g As Graphics = Graphics.FromImage(Image2Edit)
        Dim i As Integer
        Dim isAlternateNumber As Boolean = True

        If Attr("hasShadow") Then
            For i = 1 To Attr("ShadowLevels")
                g.DrawRectangle(New Pen(Attr("ShadowColor")), rc.X - i - (Attr("Border") / 2), rc.Y - i - (Attr("Border") / 2), rc.Width + (Attr("Border") / 2), rc.Height + (Attr("Border") / 2))
            Next
        End If

        If Attr("isFill") Then
            g.FillRectangle(New SolidBrush(Attr("FillColor")), rc)
        End If

        If Attr("Border") = 1 Then
            g.DrawRectangle(New Pen(Attr("BorderColor")), rc)
        Else
            g.DrawRectangle(New Pen(Attr("BorderColor")), rc)
            For i = 1 To Attr("Border")
                If isAlternateNumber Then
                    g.DrawRectangle(New Pen(Attr("BorderColor")), rc.X - CInt(CStr(i / 2).Substring(0, 1)), rc.Y - CInt(CStr(i / 2).Substring(0, 1)), rc.Width, rc.Height)
                    isAlternateNumber = False
                Else
                    g.DrawRectangle(New Pen(Attr("BorderColor")), rc.X + CInt(CStr(i / 2).Substring(0, 1)), rc.Y + CInt(CStr(i / 2).Substring(0, 1)), rc.Width, rc.Height)
                    isAlternateNumber = True
                End If
            Next
        End If

        g = Nothing
        Return Image2Edit
    End Function

    Public Shared Function DrawPolygon(ByVal Image2Edit As Image, ByVal pp As Point(), ByVal Attr As Hashtable) As Image
        Dim g As Graphics = Graphics.FromImage(Image2Edit)
        Dim i As Integer
        Dim isAlternateNumber As Boolean = True

        If Attr("hasShadow") Then
            For i = 1 To Attr("ShadowLevels")
                'There's a problem with the shadow. I dunno what.
                g.DrawPolygon(New Pen(Attr("ShadowColor")), ModifyPointArray(pp, 0, i + (Attr("Border") / 2) - 2))
                g.DrawPolygon(New Pen(Attr("ShadowColor")), ModifyPointArray(pp, i + (Attr("Border") / 2) - 2, 0))
            Next
        End If

        If Attr("isFill") Then
            g.FillPolygon(New SolidBrush(Attr("FillColor")), pp)
        End If

        If Attr("Border") = 1 Then
            g.DrawPolygon(New Pen(Attr("BorderColor")), pp)
        Else
            g.DrawPolygon(New Pen(Attr("BorderColor")), pp)
            For i = 1 To Attr("Border")
                If isAlternateNumber Then
                    g.DrawPolygon(New Pen(Attr("BorderColor")), ModifyPointArray(pp, 0, CInt(CStr(i / 2).Substring(0, 1))))
                    g.DrawPolygon(New Pen(Attr("BorderColor")), ModifyPointArray(pp, CInt(CStr(i / 2).Substring(0, 1)), 0))
                    isAlternateNumber = False
                Else
                    g.DrawPolygon(New Pen(Attr("BorderColor")), ModifyPointArray(pp, 0, -CInt(CStr(i / 2).Substring(0, 1))))
                    g.DrawPolygon(New Pen(Attr("BorderColor")), ModifyPointArray(pp, -CInt(CStr(i / 2).Substring(0, 1)), 0))
                    isAlternateNumber = True
                End If
            Next
        End If

        g = Nothing
        Return Image2Edit
    End Function

    Shared Function ModifyPointArray(ByVal pp As Point(), ByVal Int2SubtractX As Integer, ByVal Int2SubtractY As Integer) As Point()
        Dim ii As Integer
        Dim sP(pp.Length - 1) As Point
        For ii = 0 To (pp.Length - 1)
            sP.SetValue(New Point(pp(ii).X - Int2SubtractX, pp(ii).Y - Int2SubtractY), CInt(ii))
        Next
        Return sP
        sP = Nothing
        ii = Nothing
    End Function

    Public Shared Function DrawEllipse(ByVal Image2Edit As Image, ByVal rc As Rectangle, ByVal Attr As Hashtable) As Image
        Dim g As Graphics = Graphics.FromImage(Image2Edit)
        Dim i As Integer
        Dim isAlternateNumber As Boolean = True

        If Attr("hasShadow") Then
            For i = 1 To Attr("ShadowLevels")
                g.DrawEllipse(New Pen(Attr("ShadowColor")), rc.X - i - (Attr("Border") / 2), rc.Y - i - (Attr("Border") / 2), rc.Width + (Attr("Border") / 2), rc.Height + (Attr("Border") / 2))
                g.DrawEllipse(New Pen(Attr("ShadowColor")), rc.X - i - (Attr("Border") / 2), rc.Y - (Attr("Border") / 2), rc.Width + (Attr("Border") / 2), rc.Height + (Attr("Border") / 2))
                g.DrawEllipse(New Pen(Attr("ShadowColor")), rc.X - (Attr("Border") / 2), rc.Y - i - (Attr("Border") / 2), rc.Width + (Attr("Border") / 2), rc.Height + (Attr("Border") / 2))
                g.DrawEllipse(New Pen(Attr("ShadowColor")), rc.X - Attr("ShadowLevels") - (Attr("Border") / 2), rc.Y - i - (Attr("Border") / 2), rc.Width + (Attr("Border") / 2), rc.Height + (Attr("Border") / 2))
                g.DrawEllipse(New Pen(Attr("ShadowColor")), rc.X - i - (Attr("Border") / 2), rc.Y - Attr("ShadowLevels") - (Attr("Border") / 2), rc.Width + (Attr("Border") / 2), rc.Height + (Attr("Border") / 2))
            Next
        End If

        If Attr("isFill") Then
            g.FillEllipse(New SolidBrush(Attr("FillColor")), rc)
        End If

        If Attr("Border") = 1 Then
            g.DrawEllipse(New Pen(Attr("BorderColor")), rc)
        Else
            g.DrawEllipse(New Pen(Attr("BorderColor")), rc)
            For i = 1 To Attr("Border")
                If isAlternateNumber Then
                    g.DrawEllipse(New Pen(Attr("BorderColor")), rc.X - CInt(CStr(i / 2).Substring(0, 1)), rc.Y - CInt(CStr(i / 2).Substring(0, 1)), rc.Width, rc.Height)
                    g.DrawEllipse(New Pen(Attr("BorderColor")), rc.X, rc.Y - CInt(CStr(i / 2).Substring(0, 1)), rc.Width, rc.Height)
                    g.DrawEllipse(New Pen(Attr("BorderColor")), rc.X - CInt(CStr(i / 2).Substring(0, 1)), rc.Y, rc.Width, rc.Height)
                    isAlternateNumber = False
                Else
                    g.DrawEllipse(New Pen(Attr("BorderColor")), rc.X + CInt(CStr(i / 2).Substring(0, 1)), rc.Y + CInt(CStr(i / 2).Substring(0, 1)), rc.Width, rc.Height)
                    g.DrawEllipse(New Pen(Attr("BorderColor")), rc.X, rc.Y + CInt(CStr(i / 2).Substring(0, 1)), rc.Width, rc.Height)
                    g.DrawEllipse(New Pen(Attr("BorderColor")), rc.X + CInt(CStr(i / 2).Substring(0, 1)), rc.Y, rc.Width, rc.Height)
                    isAlternateNumber = True
                End If
            Next
        End If

        g = Nothing
        Return Image2Edit
    End Function

End Class

Public Class FileFunctions

    Shared Function ReadTxt(ByVal TxtPath As String, Optional ByVal DoNotUseMapPath As Boolean = False) As String
        Dim Wt2Return As String
        Dim str2Validate As String
        If Not DoNotUseMapPath Then
            str2Validate = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase) & "\" & TxtPath
        Else
            str2Validate = TxtPath
        End If
        If File.Exists(str2Validate) Then
            Dim objStreamReader As StreamReader
            Dim strInput As String
            objStreamReader = File.OpenText(str2Validate)
            Wt2Return = objStreamReader.ReadToEnd()
            objStreamReader.Close()
            objStreamReader = Nothing
            strInput = Nothing
        Else
            Wt2Return = str2Validate
        End If
        Return Wt2Return
    End Function

    Shared Function Write2Txt(ByVal TxtPath As String, ByVal Wt2Write As String, Optional ByVal ReplaceIt As Boolean = True, Optional ByVal DoNotUseMapPath As Boolean = False) As Boolean
        If Not DoNotUseMapPath Then
            TxtPath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase) & "\" & TxtPath
        End If
        If File.Exists(TxtPath) Then
            Dim objStreamWriter As StreamWriter
            If Not ReplaceIt Then
                objStreamWriter = File.AppendText(TxtPath)
            Else
                objStreamWriter = File.CreateText(TxtPath)
            End If
            objStreamWriter.WriteLine(Wt2Write)
            objStreamWriter.Close()
            Return True
        Else
            If ReplaceIt Then
                Dim objStreamWriter As StreamWriter
                objStreamWriter = File.CreateText(TxtPath)
                objStreamWriter.WriteLine(Wt2Write)
                objStreamWriter.Close()
            End If
            Return False
        End If
    End Function

End Class

