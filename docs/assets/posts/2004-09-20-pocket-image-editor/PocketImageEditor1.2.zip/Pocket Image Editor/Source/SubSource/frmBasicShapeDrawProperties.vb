'Pocket Image Editor
'Copyright (C) 2004 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection

Public Class frmBasicShapeDrawProperties
    Inherits System.Windows.Forms.Form


    Dim WorkingSize As Size
    Public ImageEdited As Image
    Public Property BorderWidth() As Integer
        Get
            Return lblBorderWidth.Text
        End Get
        Set(ByVal Value As Integer)
            If IsNumeric(Value) Then
                lblBorderWidth.Text = Value
            End If
        End Set
    End Property
    Public Property BorderColor() As Color
        Get
            Return pnlBorderColor.BackColor
        End Get
        Set(ByVal Value As Color)
            pnlBorderColor.BackColor = Value
        End Set
    End Property
    Public Property isFill() As Boolean
        Get
            Return chkFill.Checked
        End Get
        Set(ByVal Value As Boolean)
            chkFill.Checked = Value
        End Set
    End Property
    Public Property FillColor() As Color
        Get
            Return pnlFillColor.BackColor
        End Get
        Set(ByVal Value As Color)
            pnlFillColor.BackColor = Value
        End Set
    End Property
    Public Property isTransparent() As Boolean
        Get
            Return chkTransparent.Checked
        End Get
        Set(ByVal Value As Boolean)
            chkTransparent.Checked = Value
        End Set
    End Property
    Public Property TranspPercent() As Integer
        Get
            Return txtTransparencyPercentage.Text
        End Get
        Set(ByVal Value As Integer)
            txtTransparencyPercentage.Text = Value
        End Set
    End Property
    Public Property hasShadow() As Boolean
        Get
            Return chkShadow.Checked
        End Get
        Set(ByVal Value As Boolean)
            chkShadow.Checked = Value
        End Set
    End Property
    Public Property ShadowLevels() As Integer
        Get
            Return txtShadowLevels.Text
        End Get
        Set(ByVal Value As Integer)
            txtShadowLevels.Text = Value
        End Set
    End Property
    Public Property ShadowColor() As Color
        Get
            Return pnlShadowColor.BackColor
        End Get
        Set(ByVal Value As Color)
            pnlShadowColor.BackColor = Value
        End Set
    End Property

    Public Sub New()
        MyBase.New()
        Init()
    End Sub

    Friend WithEvents MainMenu As New System.Windows.Forms.MainMenu
    Friend WithEvents mnDone As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMenu As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCancel As New System.Windows.Forms.MenuItem
    Friend WithEvents lblBorderWidth As New System.Windows.Forms.Label
    Friend WithEvents lblPreBorderWidth As New System.Windows.Forms.Label
    Friend WithEvents lblBorderColor As New System.Windows.Forms.Label
    Friend WithEvents pnlBorderColorBg As New System.Windows.Forms.Panel
    Friend WithEvents chkFill As New System.Windows.Forms.CheckBox
    Friend WithEvents lblFillColor As New System.Windows.Forms.Label
    Friend WithEvents pnlFillColorBg As New System.Windows.Forms.Panel
    Friend WithEvents mnBorderWidth As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnBorderColor As New System.Windows.Forms.MenuItem
    Friend WithEvents mnFillColor As New System.Windows.Forms.MenuItem
    Friend WithEvents chkShadow As New System.Windows.Forms.CheckBox
    Friend WithEvents lblShadowLvs As New System.Windows.Forms.Label
    Friend WithEvents txtShadowLevels As New System.Windows.Forms.TextBox
    Friend WithEvents pnlBorderColor As New System.Windows.Forms.Panel
    Friend WithEvents pnlFillColor As New System.Windows.Forms.Panel
    Friend WithEvents lblShadowColor As New System.Windows.Forms.Label
    Friend WithEvents pnlShadowColor As New System.Windows.Forms.Panel
    Friend WithEvents pnlShadowColorBg As New System.Windows.Forms.Panel
    Friend WithEvents mnShadowColor As New System.Windows.Forms.MenuItem
    Friend WithEvents mnHelp As New System.Windows.Forms.MenuItem
    Friend WithEvents txtTransparencyPercentage As New System.Windows.Forms.TextBox
    Friend WithEvents chkTransparent As New System.Windows.Forms.CheckBox
    Friend WithEvents lblTranspPercent As New System.Windows.Forms.Label
    Friend WithEvents SmartphoneBoxPanel As New System.Windows.Forms.Panel

    Sub Init()
        If Not LCase(frmMain.PlatformType).IndexOf(LCase("WindowsPC")) = -1 Then
            WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        Else
            WorkingSize = New Size(System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height)
            'WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        End If

        MainMenu.MenuItems.Add(mnDone)
        MainMenu.MenuItems.Add(mnMenu)

        mnDone.Text = "Done"

        mnMenu.MenuItems.Add(mnBorderWidth)
        mnMenu.MenuItems.Add(mnBorderColor)
        mnMenu.MenuItems.Add(mnFillColor)
        mnMenu.MenuItems.Add(mnShadowColor)
        mnMenu.MenuItems.Add(mnSeperator1)
        mnMenu.MenuItems.Add(mnCancel)
        mnMenu.MenuItems.Add(mnHelp)
        mnMenu.Text = "Menu"

        mnBorderWidth.Text = "Choose Border Width..."

        mnBorderColor.Text = "Choose Border Color..."

        mnFillColor.Text = "Choose Fill Color..."

        mnShadowColor.Text = "Choose Shadow Color..."

        mnSeperator1.Text = "-"

        mnCancel.Text = "Cancel"

        mnHelp.Text = "Help"

        lblPreBorderWidth.Font = frmMain.LabelFont
        lblPreBorderWidth.Location = New System.Drawing.Point(2, 2)
        lblPreBorderWidth.Size = New System.Drawing.Size(174, 18)
        lblPreBorderWidth.Text = "Border Width (px):"

        lblBorderWidth.Location = New System.Drawing.Point(124, 2)
        lblBorderWidth.Size = New System.Drawing.Size(26, 18)
        lblBorderWidth.Text = "1"

        lblBorderColor.Font = frmMain.LabelFont
        lblBorderColor.Location = New System.Drawing.Point(2, 20)
        lblBorderColor.Size = New System.Drawing.Size(96, 18)
        lblBorderColor.Text = "Border Color:"

        pnlBorderColor.Location = New System.Drawing.Point(100, 22)
        pnlBorderColor.Size = New System.Drawing.Size(14, 14)

        pnlBorderColorBg.BackColor = System.Drawing.Color.Black
        pnlBorderColorBg.Location = New System.Drawing.Point(99, 21)
        pnlBorderColorBg.Size = New System.Drawing.Size(16, 16)

        chkFill.Font = frmMain.LabelFont
        chkFill.Location = New System.Drawing.Point(4, 38)
        chkFill.Size = New System.Drawing.Size(94, 18)
        chkFill.Text = "Fill"

        pnlFillColor.Location = New System.Drawing.Point(100, 56)
        pnlFillColor.Size = New System.Drawing.Size(14, 14)

        lblFillColor.Font = frmMain.LabelFont
        lblFillColor.Location = New System.Drawing.Point(2, 54)
        lblFillColor.Size = New System.Drawing.Size(96, 22)
        lblFillColor.Text = "Fill Color:"

        pnlFillColorBg.BackColor = System.Drawing.Color.Black
        pnlFillColorBg.Location = New System.Drawing.Point(99, 55)
        pnlFillColorBg.Size = New System.Drawing.Size(16, 16)

        chkShadow.Font = frmMain.LabelFont
        chkShadow.Location = New System.Drawing.Point(4, 76)
        chkShadow.Size = New System.Drawing.Size(94, 18)
        chkShadow.Text = "Shadow"

        txtShadowLevels.Enabled = False
        txtShadowLevels.Location = New System.Drawing.Point(122, 92)
        txtShadowLevels.Size = New System.Drawing.Size(48, 30)
        txtShadowLevels.Text = "3"

        lblShadowLvs.Font = frmMain.LabelFont
        lblShadowLvs.Location = New System.Drawing.Point(8, 94)
        lblShadowLvs.Size = New System.Drawing.Size(152, 22)
        lblShadowLvs.Text = "Shadow Levels:"

        lblShadowColor.Font = frmMain.LabelFont
        lblShadowColor.Location = New System.Drawing.Point(8, 116)
        lblShadowColor.Size = New System.Drawing.Size(152, 22)
        lblShadowColor.Text = "Shadow Color:"

        pnlShadowColor.BackColor = System.Drawing.Color.Black
        pnlShadowColor.Location = New System.Drawing.Point(120, 118)
        pnlShadowColor.Size = New System.Drawing.Size(14, 14)

        pnlShadowColorBg.BackColor = System.Drawing.Color.Black
        pnlShadowColorBg.Location = New System.Drawing.Point(119, 117)
        pnlShadowColorBg.Size = New System.Drawing.Size(16, 16)

        txtTransparencyPercentage.Enabled = False
        txtTransparencyPercentage.Font = frmMain.LabelFont
        txtTransparencyPercentage.Location = New System.Drawing.Point(122, 152)
        txtTransparencyPercentage.Size = New System.Drawing.Size(48, 30)
        txtTransparencyPercentage.Text = "50"
        txtTransparencyPercentage.Visible = False

        chkTransparent.Font = frmMain.LabelFont
        chkTransparent.Location = New System.Drawing.Point(4, 136)
        chkTransparent.Size = New System.Drawing.Size(94, 18)
        chkTransparent.Text = "Transparent"
        chkTransparent.Visible = False

        lblTranspPercent.Font = frmMain.LabelFont
        lblTranspPercent.Location = New System.Drawing.Point(32, 154)
        lblTranspPercent.Size = New System.Drawing.Size(152, 22)
        lblTranspPercent.Text = "Percentage:"
        lblTranspPercent.Visible = False

        SmartphoneBoxPanel.Size = frmMain.SmartphonePanelsSize
        SmartphoneBoxPanel.Location = New Point(WorkingSize.Width / 2 - SmartphoneBoxPanel.Width / 2, 0)

        SmartphoneBoxPanel.Controls.Add(txtTransparencyPercentage)
        SmartphoneBoxPanel.Controls.Add(lblTranspPercent)
        SmartphoneBoxPanel.Controls.Add(chkTransparent)
        SmartphoneBoxPanel.Controls.Add(pnlShadowColor)
        SmartphoneBoxPanel.Controls.Add(pnlShadowColorBg)
        SmartphoneBoxPanel.Controls.Add(lblShadowColor)
        SmartphoneBoxPanel.Controls.Add(txtShadowLevels)
        SmartphoneBoxPanel.Controls.Add(lblShadowLvs)
        SmartphoneBoxPanel.Controls.Add(pnlFillColor)
        SmartphoneBoxPanel.Controls.Add(pnlFillColorBg)
        SmartphoneBoxPanel.Controls.Add(chkFill)
        SmartphoneBoxPanel.Controls.Add(pnlBorderColor)
        SmartphoneBoxPanel.Controls.Add(lblBorderWidth)
        SmartphoneBoxPanel.Controls.Add(pnlBorderColorBg)
        SmartphoneBoxPanel.Controls.Add(lblBorderColor)
        SmartphoneBoxPanel.Controls.Add(lblFillColor)
        SmartphoneBoxPanel.Controls.Add(chkShadow)
        SmartphoneBoxPanel.Controls.Add(lblPreBorderWidth)
        Me.Controls.Add(SmartphoneBoxPanel)
        Me.Menu = MainMenu
        Me.Text = "Shape Properties"
        Me.MaximizeBox = False
        Me.WindowState = System.Windows.Forms.FormWindowState.Normal
        Me.FormBorderStyle = FormBorderStyle.FixedSingle

    End Sub



    Private Sub mnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnHelp.Click 'Help
        System.Windows.Forms.MessageBox.Show("This window helps you choose some properties for the shape you're about to draw. Firstly, you can choose a border width & color. Border width is in pixels and 0 would mean no border. If you want to fill the shape, you can check the appropriate checkbox and also you can choose a fill color. If you want to make the shape have a shadow, check the appropriate checkbox and type the levels you want the shadow to have. Levels means the number of layers of pixels.", "Help", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1)
    End Sub

    Private Sub mnDone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDone.Click
        Me.DialogResult = DialogResult.OK
    End Sub

    Private Sub mnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCancel.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

    Private Sub mnBorderWidth_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnBorderWidth.Click 'BorderWidth
        Dim nBW As New frmGetBorderWidth
        If nBW.ShowDialog = DialogResult.OK Then
            BorderWidth = nBW.SelectedWidth
        End If
        nBW = Nothing
    End Sub

    Private Sub mnBorderColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnBorderColor.Click 'BorderColor
        Dim nBC As New frmColorPicker
        nBC.ImageForPick = ImageEdited
        If nBC.ShowDialog = DialogResult.OK Then
            BorderColor = nBC.SelectedColor
        End If
        nBC = Nothing
    End Sub

    Private Sub mnFillColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnFillColor.Click 'FillColor
        Dim nBC As New frmColorPicker
        nBC.ImageForPick = ImageEdited
        If nBC.ShowDialog = DialogResult.OK Then
            FillColor = nBC.SelectedColor
        End If
        nBC = Nothing
    End Sub

    Private Sub mnShadowColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnShadowColor.Click 'ShadowColor
        Dim nBC As New frmColorPicker
        nBC.ImageForPick = ImageEdited
        If nBC.ShowDialog = DialogResult.OK Then
            ShadowColor = nBC.SelectedColor
        End If
        nBC = Nothing
    End Sub


    Private Sub lblBorderWidth_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblBorderWidth.Click
        mnBorderWidth_Click(Me, EventArgs.Empty)
    End Sub

    Private Sub pnlBorderColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnlBorderColor.Click
        mnBorderColor_Click(Me, EventArgs.Empty)
    End Sub

    Private Sub pnlFillColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnlFillColor.Click
        mnFillColor_Click(Me, EventArgs.Empty)
    End Sub

    Private Sub pnlShadowColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnlShadowColor.Click
        mnShadowColor_Click(Me, EventArgs.Empty)
    End Sub

    Private Sub chkTransparent_CheckStateChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If chkTransparent.Checked Then
            txtTransparencyPercentage.Enabled = True
        Else
            txtTransparencyPercentage.Enabled = False
        End If
    End Sub

    Private Sub chkShadow_CheckStateChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShadow.CheckStateChanged
        If chkShadow.Checked Then
            txtShadowLevels.Enabled = True
        Else
            txtShadowLevels.Enabled = False
        End If
    End Sub

    Private Sub txtTransparencyPercentage_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If IsNumeric(txtTransparencyPercentage.Text) Then
            If Not txtTransparencyPercentage.Text >= 0 And Not txtTransparencyPercentage.Text <= 100 Then
                System.Windows.Forms.MessageBox.Show("Percentage should be between 0 and 100.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            End If
        Else
            System.Windows.Forms.MessageBox.Show("Percentage must be an integer.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
        End If
    End Sub

End Class

