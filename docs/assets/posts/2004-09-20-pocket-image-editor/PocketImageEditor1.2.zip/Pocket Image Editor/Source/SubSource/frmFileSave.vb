    'Pocket Image Editor
    'Copyright (C) 2004 Iraklis Psaroudakis

    'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
    'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

    'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.Windows.Forms

Public Class frmFileSave
    Inherits System.Windows.Forms.Form

    Dim WorkingSize As Size
    Public Property DirectorySelected() As String
        Get
            If txtDirectory.Text.LastIndexOf("\") = txtDirectory.Text.Length - 1 Then
                Return txtDirectory.Text
            Else
                Return txtDirectory.Text & "\"
            End If
        End Get
        Set(ByVal Value As String)
            If Value.LastIndexOf("\") = Value.Length - 1 Then
                txtDirectory.Text = Value
            Else
                txtDirectory.Text = Value & "\"
            End If
        End Set
    End Property

    Public Property FilenameSelected() As String
        Get
            Return Replace(txtFilename.Text, "\", "")
        End Get
        Set(ByVal Value As String)
            txtFilename.Text = Replace(Value, "\", "")
        End Set
    End Property

    Public Property FullFilePath() As String
        Get
            Return DirectorySelected & FilenameSelected
        End Get
        Set(ByVal Value As String)
            DirectorySelected = Value
            FilenameSelected = Value
        End Set
    End Property

    Public Sub New()
        MyBase.New()
        Init()
    End Sub

    Friend WithEvents MainMenu As New System.Windows.Forms.MainMenu
    Friend WithEvents mnDone As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMenu As New System.Windows.Forms.MenuItem
    Friend WithEvents mnChooseDirectory As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCancel As New System.Windows.Forms.MenuItem
    Friend WithEvents lblDirExpl As New System.Windows.Forms.Label
    Friend WithEvents txtDirectory As New System.Windows.Forms.TextBox
    Friend WithEvents lblFileExpl As New System.Windows.Forms.Label
    Friend WithEvents mnReplaceFile As New System.Windows.Forms.MenuItem
    Friend WithEvents mnHelp As New System.Windows.Forms.MenuItem
    Friend WithEvents txtFilename As New System.Windows.Forms.TextBox
    Friend WithEvents SmartphoneBoxPanel As New System.Windows.Forms.Panel

    Sub Init()
        If Not LCase(APICalls.GetPlatformName).IndexOf(LCase("WindowsPC")) = -1 Then
            WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        Else
            WorkingSize = New Size(System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height)
            'WorkingSize = frmfrmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        End If

        MainMenu.MenuItems.Add(mnDone)
        MainMenu.MenuItems.Add(mnMenu)

        mnDone.Text = "Done"

        mnMenu.MenuItems.Add(mnChooseDirectory)
        mnMenu.MenuItems.Add(mnReplaceFile)
        mnMenu.MenuItems.Add(mnHelp)
        mnMenu.MenuItems.Add(mnCancel)
        mnMenu.Text = "Menu"

        mnChooseDirectory.Text = "Choose directory"

        mnReplaceFile.Text = "Replace existing file"

        mnHelp.Text = "Help"

        mnCancel.Text = "Cancel"

        lblDirExpl.Font = frmMain.LabelFont
        lblDirExpl.Location = New System.Drawing.Point(2, 2)
        lblDirExpl.Size = New System.Drawing.Size(174, 38)
        lblDirExpl.Text = "This is the directory where the file will be saved at:"

        txtDirectory.Location = New System.Drawing.Point(4, 40)
        'txtDirectory.ReadOnly = True
        txtDirectory.Size = New System.Drawing.Size(170, 30)
        ResetDirText()

        lblFileExpl.Font = frmMain.LabelFont
        lblFileExpl.Location = New System.Drawing.Point(2, 72)
        lblFileExpl.Size = New System.Drawing.Size(172, 36)
        lblFileExpl.Text = "This is the name of the file that will be created:"

        txtFilename.Location = New System.Drawing.Point(4, 106)
        txtFilename.Size = New System.Drawing.Size(170, 30)
        txtFilename.Text = "None.bmp"

        SmartphoneBoxPanel.Size = frmMain.SmartphonePanelsSize
        SmartphoneBoxPanel.Location = New Point(WorkingSize.Width / 2 - SmartphoneBoxPanel.Width / 2, 0)

        SmartphoneBoxPanel.Controls.Add(txtFilename)
        SmartphoneBoxPanel.Controls.Add(lblFileExpl)
        SmartphoneBoxPanel.Controls.Add(txtDirectory)
        SmartphoneBoxPanel.Controls.Add(lblDirExpl)
        Me.Controls.Add(SmartphoneBoxPanel)
        Me.Menu = MainMenu
        Me.Text = "Destination file..."
        Me.WindowState = System.Windows.Forms.FormWindowState.Normal

    End Sub

    Private Sub frmFileSave_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        If Not Width > frmMain.SmartphonePanelsSize.Width Then
            Width = frmMain.SmartphonePanelsSize.Width
            SmartphoneBoxPanel.Width = frmMain.SmartphonePanelsSize.Width
        Else 'Widths changes
            SmartphoneBoxPanel.Width = ClientSize.Width
            txtFilename.Width = Width - 17
            txtDirectory.Width = Width - 17
        End If
        If Not Height > frmMain.SmartphonePanelsSize.Height Then
            SmartphoneBoxPanel.Height = frmMain.SmartphonePanelsSize.Height
            Height = frmMain.SmartphonePanelsSize.Height
        Else 'Heights changes
            SmartphoneBoxPanel.Height = ClientSize.Height
        End If
    End Sub

    Sub ResetDirText()
        If Not LCase(APICalls.GetPlatformName).IndexOf(LCase("WindowsPC")) = -1 Then
            DirectorySelected = "C:\"
        Else
            If Not LCase(APICalls.GetPlatformName).IndexOf(LCase("PocketPC")) = -1 Then
                DirectorySelected = APICalls.GetSpecialFolder(APICalls.CSIDL_PERSONAL)
            Else
                DirectorySelected = APICalls.GetSpecialFolder(APICalls.CSIDL_PERSONAL)
            End If
        End If
        txtDirectory_LostFocus(Me, EventArgs.Empty)
    End Sub

    Sub ResetDirTexttoTemp()
        DirectorySelected = Path.GetTempPath
    End Sub

    Private Sub txtDirectory_LostFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDirectory.LostFocus
        DirectorySelected = txtDirectory.Text
        Dim DoesDirExists As Boolean = Directory.Exists(DirectorySelected)
        If Not LCase(APICalls.GetPlatformName).IndexOf(LCase("WindowsCE")) = -1 Then
            Try
                Dim TempPDirs() As String = Directory.GetDirectories(DirectorySelected)
                DoesDirExists = True
            Catch ex As Exception

            End Try
        End If
        If Not DoesDirExists Then
            System.Windows.Forms.MessageBox.Show("The directory you entered has not been found. Please re-enter an existing directory. The directory will now be changed to System's temporary directory.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            ResetDirTexttoTemp()
        End If
    End Sub

    Private Sub mnDone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDone.Click
        Try
            Path.GetFullPath(FullFilePath)
            Me.DialogResult = DialogResult.OK
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show("The filename you entered was not properly typed. Check again the destination directory and filename. Also, check that the directory does not end with an '\' and that the filename does not begin with an '\'. If the problem persists, it is recommended to use the Menu options for file replacing and directory finding.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
        End Try
    End Sub

    Private Sub mnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCancel.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

    Private Sub mnChooseDirectory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnChooseDirectory.Click
        Dim mOpenImg As New frmExplorer
        mOpenImg.WhatToReturn = "Dir"
        mOpenImg.ShowFiles = False
        If mOpenImg.ShowDialog = DialogResult.OK Then
            DirectorySelected = mOpenImg.SelectedPath()
        End If
    End Sub

    Private Sub mnReplaceFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnReplaceFile.Click
        Dim mOpenImg As New frmExplorer
        mOpenImg.WhatToReturn = "Fil"
        If mOpenImg.ShowDialog = DialogResult.OK Then
            DirectorySelected = mOpenImg.SelectedPath.Substring(0, mOpenImg.SelectedPath.LastIndexOf("\"))
            FilenameSelected = mOpenImg.SelectedPath.Substring(mOpenImg.SelectedPath.LastIndexOf("\") + 1)
        End If
    End Sub

    Private Sub mnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnHelp.Click ' Help
        System.Windows.Forms.MessageBox.Show("The destination folder of the file to be created/replaced is shown in the first textbox. It's not editable. To change the destination folder click Menu > Choose Directory. The file's name is shown in the second textbox along with its extension. An extra choice is avalaible: Menu > Replace Existing File. This allows you to select a file so that it is replaced automatically. When finished, click Done.", "Help", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1)
    End Sub

End Class

