    'Pocket Image Editor
    'Copyright (C) 2004 Iraklis Psaroudakis

    'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
    'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

    'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.Windows.Forms

Public Class frmGetPoints
    Inherits System.Windows.Forms.Form

    Dim CursorStep As Integer = 7
    Dim i As Integer
    Dim CurrentPoint As Integer = 1
    Dim frmWidth As Integer '170
    Dim frmHeight As Integer
    Dim LocX As Integer 'X location of cursor on the image
    Dim LocY As Integer 'Y location of cursor on the image
    Dim hResources As New Hashtable
    Dim WorkingSize As Size

    Public Image2Show As Image
    Dim OriginalImageBackup As Image
    Public NumPoints As Integer
    Public PointsSelected() As Point
    Public AllowCustomNumber As Boolean = False

    Public Sub New()
        MyBase.New()
        Init()
    End Sub

    Public WithEvents MainMenu As New System.Windows.Forms.MainMenu
    Friend WithEvents lblLocCur As New System.Windows.Forms.Label
    Friend WithEvents pCursor As New System.Windows.Forms.PictureBox
    Friend WithEvents HScroll As New System.Windows.Forms.HScrollBar
    Friend WithEvents VScroll As New System.Windows.Forms.VScrollBar
    Friend WithEvents pBgImg As New System.Windows.Forms.PictureBox
    Friend WithEvents mnMenu As New System.Windows.Forms.MenuItem
    Friend WithEvents mnAction As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCancel As New System.Windows.Forms.MenuItem
    Friend WithEvents mnHelp As New System.Windows.Forms.MenuItem
    Friend WithEvents lblWhatPoint As New System.Windows.Forms.Label
    Friend WithEvents mnConnectPoints As New System.Windows.Forms.MenuItem
    Friend WithEvents ppImage As New System.Windows.Forms.PictureBox
    Friend WithEvents mnPointNumbers As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCirclePoint As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnReset As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSeperator2 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnAssignCurrentPoint As New System.Windows.Forms.MenuItem
    Friend WithEvents pOriginal As New System.Windows.Forms.PictureBox
    Friend WithEvents mnShowAssigned As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSetCurrentPoint As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSetNumber As New System.Windows.Forms.MenuItem
    Friend WithEvents tmrDoubleClickOnImage As New System.Windows.Forms.Timer

    Private Sub LoadUpResources
        Dim iStream As Stream = System.Reflection.Assembly.GetExecutingAssembly.GetManifestResourceStream(System.Reflection.Assembly.GetExecutingAssembly.GetManifestResourceNames(0))
        Dim rr As New System.Resources.ResourceReader(iStream)
        Dim id As IDictionaryEnumerator = rr.GetEnumerator()
        While id.MoveNext()
            hResources.Add(id.key, id.Value)
        End While
    End Sub

    Sub Init()
        If Not LCase(frmMain.PlatformType).IndexOf(LCase("WindowsPC")) = -1 Then
            WorkingSize = frmMain.WorkingSize
            Me.ClientSize = WorkingSize
        Else
            WorkingSize = New Size(System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height)
            Me.ClientSize = WorkingSize
        End If
        LoadUpResources()

        MainMenu.MenuItems.Add(mnAction)
        MainMenu.MenuItems.Add(mnMenu)

        mnAction.Text = "Done"

        mnMenu.MenuItems.Add(mnConnectPoints)
        mnMenu.MenuItems.Add(mnPointNumbers)
        mnMenu.MenuItems.Add(mnCirclePoint)
        mnMenu.MenuItems.Add(mnSeperator1)
        mnMenu.MenuItems.Add(mnReset)
        mnMenu.MenuItems.Add(mnSetCurrentPoint)
        mnMenu.MenuItems.Add(mnAssignCurrentPoint)
        mnMenu.MenuItems.Add(mnSetNumber)
        mnMenu.MenuItems.Add(mnShowAssigned)
        mnMenu.MenuItems.Add(mnSeperator2)
        mnMenu.MenuItems.Add(mnCancel)
        mnMenu.MenuItems.Add(mnHelp)
        mnMenu.Text = "Menu"

        mnConnectPoints.Checked = True
        mnConnectPoints.Text = "Connect Points"

        mnPointNumbers.Checked = True
        mnPointNumbers.Text = "Show Point Numbers"

        mnCirclePoint.Checked = True
        mnCirclePoint.Text = "Circle Point Style"

        mnSeperator1.Text = "-"

        mnReset.Text = "Reset Point Editing"

        mnSetCurrentPoint.Text = "Set Current Point..."

        mnAssignCurrentPoint.Text = "Assign Current Point..."

        mnSetNumber.Enabled = False
        mnSetNumber.Text = "Set Number of Points..."

        mnShowAssigned.Text = "Show Assigned Values"

        mnSeperator2.Text = "-"

        mnCancel.Text = "Cancel"

        mnHelp.Text = "Help"

        ppImage.Location = New System.Drawing.Point(28, 26)
        ppImage.Size = New System.Drawing.Size(120, 120)
        ppImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage

        pCursor.Image = CType(hResources("Cursor1"), System.Drawing.Image)
        pCursor.Location = New System.Drawing.Point(86, 82)
        pCursor.Size = New System.Drawing.Size(5, 5)

        VScroll.Maximum = 90
        VScroll.Size = New System.Drawing.Size(7, WorkingSize.Height)
        VScroll.Location = New System.Drawing.Point(WorkingSize.Width - VScroll.Width, 0)

        HScroll.Maximum = 90
        HScroll.Size = New System.Drawing.Size(WorkingSize.Width - VScroll.Width, 7)
        HScroll.Location = New System.Drawing.Point(0, WorkingSize.Height - HScroll.Height)

        pBgImg.Image = CType(hResources("GrayBackground"), System.Drawing.Image)
        pBgImg.Location = New System.Drawing.Point(0, 0)
        pBgImg.Size = New System.Drawing.Size(WorkingSize.Width, WorkingSize.Height)
        'Process for tiling Background Image
        If pBgImg.Image.Width < pBgImg.Width Then
            Dim TimesToTile As Integer = CInt(pBgImg.Width / pBgImg.Image.Width) + 1
            Dim NewImage As New Bitmap(pBgImg.Image.Width * TimesToTile, pBgImg.Image.Height)
            Dim g As Graphics = Graphics.FromImage(NewImage)
            Dim i As Integer
            For i = 0 To (TimesToTile - 1)
                g.DrawImage(pBgImg.Image, pBgImg.Image.Width * i, 0)
            Next
            i = Nothing
            TimesToTile = Nothing
            g = Nothing
            pBgImg.Image = New Bitmap(NewImage)
            NewImage = Nothing
        End If
        If pBgImg.Image.Height < pBgImg.Height Then
            Dim TimesToTile As Integer = CInt(pBgImg.Height / pBgImg.Image.Height) + 1
            Dim NewImage As New Bitmap(pBgImg.Image.Width, pBgImg.Image.Height * TimesToTile)
            Dim g As Graphics = Graphics.FromImage(NewImage)
            Dim i As Integer
            For i = 0 To (TimesToTile - 1)
                g.DrawImage(pBgImg.Image, 0, pBgImg.Image.Height * i)
            Next
            i = Nothing
            TimesToTile = Nothing
            g = Nothing
            pBgImg.Image = New Bitmap(NewImage)
            NewImage = Nothing
        End If
        'End Tiling background image

        lblLocCur.Font = frmMain.LabelFont
        lblLocCur.Size = New System.Drawing.Size(WorkingSize.Width - VScroll.Width, 18)
        lblLocCur.Location = New System.Drawing.Point(0, WorkingSize.Height - HScroll.Height - lblLocCur.Height)
        lblLocCur.Text = "X: 0, Y: 0, Step: 7"

        lblWhatPoint.Font = frmMain.LabelFont
        If Not LCase(frmMain.PlatformType).IndexOf(LCase("PocketPC")) = -1 Then
            lblWhatPoint.Font = New System.Drawing.Font("Nina", 8.0!, System.Drawing.FontStyle.Bold)
        End If
        lblWhatPoint.ForeColor = System.Drawing.Color.FromArgb(192, 0, 0)
        lblWhatPoint.Size = New System.Drawing.Size(58, 12)
        lblWhatPoint.Location = New System.Drawing.Point(WorkingSize.Width - VScroll.Width - lblWhatPoint.Width, WorkingSize.Height - lblWhatPoint.Height - HScroll.Height)
        If Not LCase(frmMain.PlatformType).IndexOf(LCase("WindowsPC")) = -1 Or Not LCase(frmMain.PlatformType).IndexOf(LCase("PocketPC")) = -1 Then
            lblWhatPoint.Top -= 5
        End If
        lblWhatPoint.Text = "Point 1"
        lblWhatPoint.TextAlign = System.Drawing.ContentAlignment.TopRight

        pOriginal.Location = New System.Drawing.Point(6, 146)
        pOriginal.Size = New System.Drawing.Size(12, 10)
        pOriginal.Visible = False

        tmrDoubleClickOnImage.Enabled = False
        tmrDoubleClickOnImage.Interval = APICalls.DoubleClickTime()

        Me.BackColor = System.Drawing.Color.Gainsboro
        Me.Controls.Add(pOriginal)
        Me.Controls.Add(lblWhatPoint)
        Me.Controls.Add(VScroll)
        Me.Controls.Add(HScroll)
        Me.Controls.Add(pCursor)
        Me.Controls.Add(lblLocCur)
        Me.Controls.Add(ppImage)
        Me.Controls.Add(pBgImg)
        Me.Menu = MainMenu
        Me.Text = "Point Selection"
        Me.MaximizeBox = False
        Me.WindowState = System.Windows.Forms.FormWindowState.Normal
        Me.FormBorderStyle = FormBorderStyle.FixedSingle

    End Sub

    Private Sub mnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnHelp.Click 'Help
        System.Windows.Forms.MessageBox.Show("This dialog helps you choose points for different purposes (defining a line for example). It consists of the image, a cursor, it's location's coordinates. You can move the cursor with the nav keys and you can click the action button to define the point and move on to defining the following point. The current point always shows up on the bottom. When you finish selecting points, a text message Complete! will appear and you can click the action button again to complete the point selection process. Through the menu though you can do the following stuff:" & vbCrLf & "Change the point style: The first three checks provide means to alter the appearance of points selected." & vbCrLf & "Reset Point Editing: If you changed your mind and want to select the points from the beginning, click this one." & vbCrLf & "Set Current Point: If you want to roll back to a previous point to select or you want to go to a next one, you can do it with this. Just provide the number of the point you want to edit. Selecting points will continue from the point you select." & vbCrLf & "Assign Current Point: If you do not want to select apoint with the cursor but you want to select it providing its coordinates, you can do it with this." & vbCrLf & "Set Number Of Points (if available): Useful when you define a polygon for example. You can set the number of points you want to select." & vbCrLf & "Show Assigned Values: To see the coordinates of each point you have selected so far." & vbCrLf & "Press Done when finished.", "Help", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1)
    End Sub

    Private Sub mnSetCurrentPoint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSetCurrentPoint.Click
        Dim nInput As New InputDialog
        nInput.AssignedValue = 1
        nInput.Description = "Give a number to show the point where you want to start editing points. Entering " & CStr(NumPoints + 1) & " will complete point editing. Keep in mind that all unassigned points have a value of (-100, -100), that is out of the image. Avoid skipping them."
        If nInput.ShowDialog = DialogResult.OK Then
            Try
                If CInt(nInput.AssignedValue) <= NumPoints And nInput.AssignedValue > 0 Then
                    CurrentPoint = nInput.AssignedValue
                    lblWhatPoint.Text = "Point " & nInput.AssignedValue & "/" & NumPoints
                    mnAction.Enabled = False
                Else
                    System.Windows.Forms.MessageBox.Show("The number you entered is out of range (min is 1 and max is " & NumPoints & "). Please enter another value.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                End If
            Catch ex As Exception
                System.Windows.Forms.MessageBox.Show("The value you entered is not a number-integer. Please enter another value.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            End Try
        End If
        nInput = Nothing
    End Sub

    Private Sub mnShowAssigned_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnShowAssigned.Click
        Dim i As Integer
        Dim str2Show As String = "Assigned Points:"
        For i = 1 To NumPoints
            str2Show += vbCrLf & i & ") " & PointsSelected(i - 1).X & ", " & PointsSelected(i - 1).Y
        Next
        System.Windows.Forms.MessageBox.Show(str2Show, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1)
        i = Nothing
        str2Show = Nothing
    End Sub

    Private Sub mnAction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAction.Click
        Me.DialogResult = DialogResult.OK
    End Sub

    Private Sub mnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCancel.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

    Private Sub mnConnectPoints_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnConnectPoints.Click
        If mnConnectPoints.Checked Then
            mnConnectPoints.Checked = False
        Else
            mnConnectPoints.Checked = True
        End If
    End Sub

    Private Sub mnPointNumbers_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnPointNumbers.Click
        If mnPointNumbers.Checked Then
            mnPointNumbers.Checked = False
        Else
            mnPointNumbers.Checked = True
        End If
    End Sub

    Private Sub mnCirclePoint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCirclePoint.Click
        If mnCirclePoint.Checked Then
            mnCirclePoint.Checked = False
        Else
            mnCirclePoint.Checked = True
        End If
    End Sub

    Private Sub mnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnReset.Click
        ResetPoints()
    End Sub

    Private Sub mnAssignCurrentPoint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAssignCurrentPoint.Click
        Dim Dinput As New InputDialog
        Dinput.AssignedValue = "0, 0"
        Dinput.Description = "Enter the coordinates of the point you want. Please be sure that they are not out of bounds of the image (" & Image2Show.Width & "x" & Image2Show.Height & "). Acceptable format is 'X, Y'."
        If Dinput.ShowDialog = DialogResult.OK Then
            Try
                Dim co As New Point((Dinput.AssignedValue).Substring(0, (Dinput.AssignedValue).IndexOf(",")), (Dinput.AssignedValue).Substring((Dinput.AssignedValue).IndexOf(",") + 1))
                ActionClicked(co.X, co.Y)
            Catch ex As Exception
                System.Windows.Forms.MessageBox.Show("There was an error while processing the coordinates you gave:" & vbCrLf & Dinput.AssignedValue & vbCrLf & "Please ensure that they are of format 'X, Y' and enter the coordinates again.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            End Try
        End If
    End Sub

    Private Sub mnSetNumber_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSetNumber.Click 'Set Number Points
        Dim nn As New InputDialog
        nn.AssignedValue = 5
        nn.Description = "Choose the number of points you'll like to define. All currently defined ones will be deleted. You'll need to re-define them."
        If nn.ShowDialog = DialogResult.OK Then
            NumPoints = CInt(nn.AssignedValue)
            ResetPoints()
        End If
        nn = Nothing
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        pOriginal.Image = New Bitmap(Image2Show)
        frmHeight = lblLocCur.Top
        frmWidth = WorkingSize.Width - VScroll.Width
        ppImage.Image = Image2Show
        ppImage.Size = Image2Show.Size
        CenterImage()
        CenterCursor()

        ResetPoints()
        mnSetNumber.Enabled = AllowCustomNumber
    End Sub

    Private Sub frmMain_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown

        MoveCursor(e.KeyValue) 'For left-right-up-down keys
        Select Case e.KeyValue
            Case 13 'action 'Draw Pixel
                ActionClicked(LocX - 1, LocY - 1)
            Case 49 '1
                CursorStep -= 1 'Reduce Cursor Step
                If CursorStep <= 0 Then
                    CursorStep += 1
                End If
                UpdateLocCur()
            Case 50 '2
                CursorStep += 1 'Enlarge Cursor step
                If CursorStep >= ((frmWidth / 2) + 1) Or CursorStep >= ((frmHeight / 2) + 1) Then
                    CursorStep -= 1
                End If
                UpdateLocCur()
            Case 51 '3
                If pCursor.Visible = True Then 'Toggle Cursor visibility
                    pCursor.Visible = False
                Else
                    pCursor.Visible = True
                End If
            Case 52 '4

            Case 53 '5 

            Case 54 '6

            Case 55 '7

            Case 56 '8

            Case 57 '9

            Case 119 '*

            Case 48 '0

            Case 120 '#

            Case 65 'PCs: A
                frmMain_KeyDown(Me, New KeyEventArgs(37))
            Case 87 'PCs: W
                frmMain_KeyDown(Me, New KeyEventArgs(38))
            Case 68 'PCs: D
                frmMain_KeyDown(Me, New KeyEventArgs(39))
            Case 83 'PCs: S
                frmMain_KeyDown(Me, New KeyEventArgs(40))
            Case 32 'PCs: Space
                frmMain_KeyDown(Me, New KeyEventArgs(13))
            Case 84 'PCs: T
                frmMain_KeyDown(Me, New KeyEventArgs(49))
            Case 89 'PCs: Y
                frmMain_KeyDown(Me, New KeyEventArgs(50))
            Case 85 'PCs: U
                frmMain_KeyDown(Me, New KeyEventArgs(51))
            Case 71 'PCs: G
                frmMain_KeyDown(Me, New KeyEventArgs(52))
            Case 72 'PCs: H
                frmMain_KeyDown(Me, New KeyEventArgs(53))
            Case 74 'PCs: J
                frmMain_KeyDown(Me, New KeyEventArgs(54))
            Case 66 'PCs: B
                frmMain_KeyDown(Me, New KeyEventArgs(55))
            Case 78 'PCs: N
                frmMain_KeyDown(Me, New KeyEventArgs(56))
            Case 77 'PCs: M
                frmMain_KeyDown(Me, New KeyEventArgs(57))
            Case 73 'PCs: I
                frmMain_KeyDown(Me, New KeyEventArgs(119))
            Case 75 'PCs: K
                frmMain_KeyDown(Me, New KeyEventArgs(120))
            Case 188 'PCs: ,
                frmMain_KeyDown(Me, New KeyEventArgs(48))
        End Select
    End Sub

    Private Sub CursorMoved()
        'When the Cursor is moved, this function must always be called after the movement.
        'If Picture's Width is <= the max allowed
        If ppImage.Width <= frmWidth And (pCursor.Left + (pCursor.Width - 1) / 2) < ppImage.Left Then
            pCursor.Left += CursorStep
        End If
        If ppImage.Width <= frmWidth And (pCursor.Left + 1 + (pCursor.Width - 1) / 2) > (ppImage.Left + ppImage.Width) Then
            pCursor.Left -= CursorStep
        End If
        'If Picture's Height is <= the max allowed
        If ppImage.Height <= frmHeight And (pCursor.Top + (pCursor.Height - 1) / 2) < ppImage.Top Then
            pCursor.Top += CursorStep
        End If
        If ppImage.Height <= frmHeight And (pCursor.Top + 1 + (pCursor.Height - 1) / 2) > (ppImage.Top + ppImage.Height) Then
            pCursor.Top -= CursorStep
        End If
        'If Picture's Width is > the max allowed
        If ppImage.Width > frmWidth And (pCursor.Left - 1 + (pCursor.Width - 1) / 2) < 0 Then
            pCursor.Left = 0 - (pCursor.Width - 1) / 2 + 1
            ppImage.Left += CursorStep
            If ppImage.Left > 1 Then
                ppImage.Left = 1
            End If
        End If
        If ppImage.Width > frmWidth And (pCursor.Left + 1 + (pCursor.Width - 1) / 2) > frmWidth Then
            pCursor.Left = frmWidth - pCursor.Width + (pCursor.Width - 1) / 2
            ppImage.Left -= CursorStep
            If (ppImage.Left + ppImage.Width) < frmWidth Then
                ppImage.Left += (frmWidth - ppImage.Right)
            End If
        End If
        'If Picture's Height is > the max allowed
        If ppImage.Height > frmHeight And (pCursor.Top + (pCursor.Height - 1) / 2) < 0 Then
            pCursor.Top = 0 - (pCursor.Height - 1) / 2
            ppImage.Top += CursorStep
            If ppImage.Top > 0 Then
                ppImage.Top = 0
            End If
        End If
        If ppImage.Height > frmHeight And (pCursor.Top + 1 + (pCursor.Height - 1) / 2) > frmHeight Then
            pCursor.Top = frmHeight - pCursor.Height + (pCursor.Height - 1) / 2
            ppImage.Top -= CursorStep
            If (ppImage.Top + ppImage.Height) < frmHeight Then
                ppImage.Top += (frmHeight - ppImage.Bottom)
            End If
        End If

        UpdateLocCur() 'Update Coordinates
    End Sub

    Private Sub CenterCursor()
        'This functions centers the cursor related to the size of the form that the image can have.
        'Dim dmCenterTop, dmCenterLeft
        'dmCenterTop = frmHeight / 2
        'dmCenterLeft = frmWidth / 2
        'If Not CStr(dmCenterTop).IndexOf(".") = -1 Then
        'pCursor.Top = Mid(dmCenterTop, 0, CStr(dmCenterTop).IndexOf("."))
        'Else
        '    pCursor.Top = dmCenterTop
        'End If
        'If Not CStr(dmCenterLeft).IndexOf(".") = -1 Then
        'pCursor.Left = Mid(dmCenterLeft, 0, CStr(dmCenterLeft).IndexOf("."))
        'Else
        '    pCursor.Left = dmCenterLeft
        'End If
        'dmCenterTop = Nothing
        'dmCenterLeft = Nothing
        'CursorMoved()
        'This functions centers the cursor related to the size of the form that the image can have.
        pCursor.Top = CInt(frmHeight / 2)
        pCursor.Left = CInt(frmWidth / 2)
        CursorMoved()
    End Sub

    Private Sub UpdateLocCur() 'Update Coordinates in the label
        Dim CurAddWid As Integer = ((pCursor.Width - 1) / 2) + 1
        Dim CurAddHei As Integer = ((pCursor.Height - 1) / 2) + 1

        LocX = ((0 - ppImage.Left) + pCursor.Left) + CurAddWid
        LocY = ((0 - ppImage.Top) + pCursor.Top) + CurAddHei

        lblLocCur.Text = "X: " & LocX & ", Y: " & LocY & ", Step: " & CursorStep
        CurAddWid = Nothing
        CurAddHei = Nothing

        UpdateScrollbars()
    End Sub

    Private Sub UpdateScrollbars()
        Try
            HScroll.Minimum = 1
            HScroll.Maximum = ppImage.Image.Width + 9
            HScroll.Value = LocX
            VScroll.Minimum = 1
            VScroll.Maximum = ppImage.Image.Height + 9
            VScroll.Value = LocY
        Catch

        End Try
    End Sub

    Private Sub HScroll_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HScroll.ValueChanged
        UpdateScrollbars()
    End Sub

    Private Sub VScroll_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VScroll.ValueChanged
        UpdateScrollbars()
    End Sub

    Private Sub ppImage_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ppImage.MouseDown
        MoveCursor(e.X, e.Y)
        If tmrDoubleClickOnImage.Enabled Then
            frmMain_KeyDown(Me, New KeyEventArgs(13))
        Else
            tmrDoubleClickOnImage.Enabled = True
        End If
    End Sub

    Private Sub pCursor_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pCursor.MouseDown
        ppImage_MouseDown(Me, New MouseEventArgs(MouseButtons.Left, 1, LocX - 1, LocY - 1, 0))
    End Sub

    Private Sub tmrDoubleClickOnImage_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrDoubleClickOnImage.Tick
        tmrDoubleClickOnImage.enabled = False
    End Sub

    Private Sub MoveCursor(ByVal nkey As Integer)
        'Moves the cursor left,right,up,down when a key is pressed.
        Select Case nkey
            Case 38 'up
                pCursor.Top = pCursor.Top - CursorStep
                CursorMoved()
            Case 39 'right
                pCursor.Left = pCursor.Left + CursorStep
                CursorMoved()
            Case 40 'down
                pCursor.Top = pCursor.Top + CursorStep
                CursorMoved()
            Case 37 'left
                pCursor.Left = pCursor.Left - CursorStep
                CursorMoved()
        End Select
    End Sub

    Private Sub CenterImage()
        'Centers the image related to the size of the form that the image can have.
        ppImage.Left = (frmWidth - ppImage.Width) / 2
        ppImage.Top = (frmHeight - ppImage.Height) / 2
    End Sub

    Private Sub ActionClicked(ByVal pX As Integer, ByVal pY As Integer)
        If Not CurrentPoint > NumPoints Then
            PointsSelected.SetValue(New Point(pX, pY), CurrentPoint - 1)
            PointAdded()
            CurrentPoint += 1
            If CurrentPoint > NumPoints Then
                lblWhatPoint.Text = "Complete!"
                mnAction.Enabled = True
            Else
                lblWhatPoint.Text = "Point " & CurrentPoint & "/" & NumPoints
                mnAction.Enabled = False
            End If
        Else
            Me.DialogResult = DialogResult.OK
        End If
    End Sub

    Private Sub PointAdded()
        Dim g As Graphics = Graphics.FromImage(Image2Show)
        'For i = 0 To (NumPoints - 1)
        'If mnConnectPoints.Checked Then
        'If i < (NumPoints - 1) And Not i = 0 Then
        'g.DrawLine(New Pen(Color.Black), PointsSelected(i - 1).X, PointsSelected(i - 1).Y, PointsSelected(i).X, PointsSelected(i).Y)
        'End If
        'If i = (NumPoints - 1) Then
        'g.DrawLine(New Pen(Color.Black), PointsSelected(0).X, PointsSelected(0).Y, PointsSelected(i).X, PointsSelected(i).Y)
        'End If
        'End If
        'Dim pointRect As New Rectangle(PointsSelected(i).X - 2, PointsSelected(i).Y - 2, 4, 4)
        'g.FillEllipse(New SolidBrush(Color.DimGray), pointRect)
        'g.DrawEllipse(New Pen(Color.White), pointRect)
        'g.DrawString(CStr(i + 1), New Font(FontFamily.GenericSerif, 10, FontStyle.Regular), New SolidBrush(Color.Gray), pointRect.X - 4, pointRect.Y)
        'Next

        If mnConnectPoints.Checked Then
            If (CurrentPoint - 1) <= (NumPoints - 1) And Not (CurrentPoint - 1) = 0 Then
                g.DrawLine(New Pen(Color.Black), PointsSelected((CurrentPoint - 1) - 1).X, PointsSelected((CurrentPoint - 1) - 1).Y, PointsSelected((CurrentPoint - 1)).X, PointsSelected((CurrentPoint - 1)).Y)
            End If
            If (CurrentPoint - 1) = (NumPoints - 1) Then
                g.DrawLine(New Pen(Color.Black), PointsSelected(0).X, PointsSelected(0).Y, PointsSelected((CurrentPoint - 1)).X, PointsSelected((CurrentPoint - 1)).Y)
            End If
        End If
        Dim pointRect As New Rectangle(PointsSelected((CurrentPoint - 1)).X - 2, PointsSelected((CurrentPoint - 1)).Y - 2, 4, 4)
        g.DrawRectangle(New Pen(Color.Black), pointRect.X + 1, pointRect.Y + 1, 3, 3)
        If mnCirclePoint.Checked Then
            g.FillEllipse(New SolidBrush(Color.DimGray), pointRect)
            g.DrawEllipse(New Pen(Color.White), pointRect)
        End If
        If mnPointNumbers.Checked Then
            Dim Font2Use As Font = New Font(FontFamily.GenericSansSerif, 7, FontStyle.Regular)
            Dim MoreSpace As Integer = 0
            If Not LCase(frmMain.PlatformType).IndexOf(LCase("WindowsPC")) = -1 Then
                Font2Use = New Font(FontFamily.GenericSansSerif, 6, FontStyle.Regular)
                MoreSpace = 2
            End If
            g.DrawString(CStr((CurrentPoint - 1) + 1), Font2Use, New SolidBrush(Color.Black), pointRect.X - 8 - MoreSpace, pointRect.Y - 2)
            g.DrawString(CStr((CurrentPoint - 1) + 1), Font2Use, New SolidBrush(Color.White), pointRect.X - 7 - MoreSpace, pointRect.Y - 3)
            MoreSpace = Nothing
            Font2Use = Nothing
        End If

        ppImage.Image = Image2Show
        g = Nothing
    End Sub

    Private Sub ResetPoints()
        'Returns point modifying to original position
        CurrentPoint = 1

        Dim pptmp(NumPoints) As Point
        PointsSelected = pptmp
        For i = 0 To (NumPoints - 1)
            PointsSelected.SetValue(New Point(-100, -100), i)
        Next

        Image2Show = New Bitmap(pOriginal.Image)
        ppImage.Image = New Bitmap(Image2Show)
        CenterImage()
        CenterCursor()

        lblWhatPoint.Text = "Point 1" & "/" & NumPoints
        mnAction.Enabled = False

        'Dim g As Graphics = Graphics.FromImage(ppImage.Image)
        'g.DrawImage(New Bitmap(pOriginal.Image), 0, 0)
    End Sub

    Sub MoveCursor(ByVal LocX As Integer, ByVal LocY As Integer) 'For use within the current bounds of the image shown in the working area
        'If LocX > ppImage.Image.Width Or 
        'pCursor.Left = ppImage.Left
        If ppImage.Left < 0 Then 'If Image is larger that screen and image's left side is out of the screen.
            If LocX < 0 Then 'If the request Left location is out of bounds too
                ppImage.Left += (Math.Abs(ppImage.Left) - LocX)
                pCursor.Left = 0
            Else
                pCursor.Left = LocX - Math.Abs(ppImage.Left)
            End If
        Else
            If ppImage.Right > frmWidth Then 'If Image is larger than screen and image's right side is out of bounds
                If LocX > frmWidth Then 'If the request X location is out of bounds too
                    ppImage.Left -= (Math.Abs(ppImage.Right) - LocX)
                    pCursor.Left = frmWidth - 1
                Else
                    pCursor.Left = LocX
                End If
            Else
                pCursor.Left = ppImage.Left + LocX
            End If
        End If
        If ppImage.Top < 0 Then 'If Image is larger that screen and image's top side is out of the screen.
            If LocY < 0 Then 'If the request Y location is out of bounds too
                ppImage.Top += (Math.Abs(ppImage.Top) - LocY)
                pCursor.Top = 0
            Else
                pCursor.Top = LocY - Math.Abs(ppImage.Top)
            End If
        Else
            If ppImage.Bottom > frmHeight Then 'If Image is larger than screen and image's bottom side is out of bounds
                If LocY > frmHeight Then 'If the request Y location is out of bounds too
                    ppImage.Top -= (Math.Abs(ppImage.Bottom) - LocY)
                    pCursor.Top = frmHeight - 1
                Else
                    pCursor.Top = LocY
                End If
            Else
                pCursor.Top = ppImage.Top + LocY
            End If
        End If
        pCursor.Left -= (pCursor.Width - 1) / 2
        pCursor.Top -= (pCursor.Height - 1) / 2
        CursorMoved()
    End Sub

End Class

