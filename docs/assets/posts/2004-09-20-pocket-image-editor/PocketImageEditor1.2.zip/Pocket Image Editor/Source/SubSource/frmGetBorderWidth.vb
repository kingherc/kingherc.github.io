    'Pocket Image Editor
    'Copyright (C) 2004 Iraklis Psaroudakis

    'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
    'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

    'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection

Public Class frmGetBorderWidth
    Inherits System.Windows.Forms.Form

    Dim WorkingSize As Size
    Public MaxWidth As Integer = 15
    Dim hResources As New Hashtable
    Public Property SelectedWidth() As Integer
        Get
            Return txtWidth.Text
        End Get
        Set(ByVal Value As Integer)
            txtWidth.Text = Value
        End Set
    End Property

    Public Sub New()
        MyBase.New()
        Init()
    End Sub

    Friend WithEvents MainMenu As New System.Windows.Forms.MainMenu
    Friend WithEvents mnDone As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMenu As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCancel As New System.Windows.Forms.MenuItem
    Friend WithEvents lblWidth As New System.Windows.Forms.Label
    Friend WithEvents txtWidth As New System.Windows.Forms.TextBox
    Friend WithEvents lblPixels As New System.Windows.Forms.Label
    Friend WithEvents pbBorderExamples As New System.Windows.Forms.PictureBox
    Friend WithEvents SmartphoneBoxPanel As New System.Windows.Forms.Panel

    Private Sub LoadUpResources
        Dim iStream As Stream = System.Reflection.Assembly.GetExecutingAssembly.GetManifestResourceStream(System.Reflection.Assembly.GetExecutingAssembly.GetManifestResourceNames(0))
        Dim rr As New System.Resources.ResourceReader(iStream)
        Dim id As IDictionaryEnumerator = rr.GetEnumerator()
        While id.MoveNext()
            hResources.Add(id.key, id.Value)
        End While
    End Sub

    Sub Init()
        If Not LCase(frmMain.PlatformType).IndexOf(LCase("WindowsPC")) = -1 Then
            WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        Else
            WorkingSize = New Size(System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height)
            'WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        End If
        LoadUpResources()

        MainMenu.MenuItems.Add(mnDone)
        MainMenu.MenuItems.Add(mnMenu)

        mnDone.Text = "Done"

        mnMenu.MenuItems.Add(mnCancel)
        mnMenu.Text = "Menu"

        mnCancel.Text = "Cancel"

        lblWidth.Font = frmMain.LabelFont
        lblWidth.Location = New System.Drawing.Point(2, 10)
        lblWidth.Size = New System.Drawing.Size(38, 22)
        lblWidth.Text = "Width:"

        txtWidth.Location = New System.Drawing.Point(38, 6)
        txtWidth.MaxLength = 5
        txtWidth.Size = New System.Drawing.Size(96, 30)
        txtWidth.Text = "1"

        lblPixels.Font = frmMain.LabelFont
        lblPixels.Location = New System.Drawing.Point(136, 10)
        lblPixels.Size = New System.Drawing.Size(40, 22)
        lblPixels.Text = "pixels"

        pbBorderExamples.Image = CType(hResources("BorderWidthImg"), System.Drawing.Image)
        pbBorderExamples.Location = New System.Drawing.Point(6, 48)
        pbBorderExamples.Size = New System.Drawing.Size(166, 120)

        SmartphoneBoxPanel.Size = New Size(176, 180)
        SmartphoneBoxPanel.Location = New Point(WorkingSize.Width / 2 - SmartphoneBoxPanel.Width / 2, 0)

        SmartphoneBoxPanel.Controls.Add(pbBorderExamples)
        SmartphoneBoxPanel.Controls.Add(lblPixels)
        SmartphoneBoxPanel.Controls.Add(txtWidth)
        SmartphoneBoxPanel.Controls.Add(lblWidth)
        Me.Controls.Add(SmartphoneBoxPanel)
        Me.Menu = MainMenu
        Me.Text = "Set Border Width"
        Me.MaximizeBox = False
        Me.WindowState = System.Windows.Forms.FormWindowState.Normal
        Me.FormBorderStyle = FormBorderStyle.FixedSingle

    End Sub

    Private Sub mnDone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDone.Click
        Try
            If IsNumeric(txtWidth.Text) Then
                If CInt(txtWidth.Text) <= MaxWidth Then
                    Me.DialogResult = DialogResult.OK
                Else
                    System.Windows.Forms.MessageBox.Show("The value you entered is greater than the maximum allowed (" & MaxWidth & "). Please enter another number.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                End If
            Else
                System.Windows.Forms.MessageBox.Show("The value you entered is not a number. Please, enter an accepted number.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            End If
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show("The value you entered is not a number. Please, enter an accepted number.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
        End Try
    End Sub

    Private Sub mnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCancel.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

End Class

