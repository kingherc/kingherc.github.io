    'Pocket Image Editor
    'Copyright (C) 2004 Iraklis Psaroudakis

    'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
    'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

    'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.Windows.Forms

Public Class frmGenerateText
    Inherits System.Windows.Forms.Form

    Dim WorkingSize As Size
    Dim pUseRectangle As Boolean = False
    Public Rectangle2Use As Rectangle
    Public pPoint As Point = Point.Empty
    Public Image2Show As Image
    Public FontString As String = "Nina"

    Public Property UseRectangle() As Boolean
        Get
            Return pUseRectangle
        End Get
        Set(ByVal Value As Boolean)
            pUseRectangle = Value
            If Value Then
                pPoint = Point.Empty
                mnPoint.Enabled = False
            Else
                mnPoint.Enabled = True
            End If
        End Set
    End Property
    Public Property TextCommands() As Hashtable
        Get
            Dim nHash As New Hashtable
            nHash.Add("UseRectangle", UseRectangle)
            nHash.Add("Color", pnlColor.BackColor)
            nHash.Add("Text", txtText.Text)
            nHash.Add("Size", txtSize.Text)
            nHash.Add("Italic", chkItalic.Checked)
            nHash.Add("Bold", chkBold.Checked)
            nHash.Add("Underline", chkUnderline.Checked)
            nHash.Add("Font", cbFont.SelectedIndex)
            nHash.Add("FontString", FontString)
            If UseRectangle Then
                nHash.Add("Rectangle", Rectangle2Use)
            Else
                nHash.Add("Point", pPoint)
            End If
            Return nHash
        End Get
        Set(ByVal Value As Hashtable)
            UseRectangle = Value("UseRectangle")
            txtText.Text = Value("Text")
            txtSize.Text = Value("Size")
            pnlColor.BackColor = Value("Color")
            chkItalic.Checked = Value("Italic")
            chkBold.Checked = Value("Bold")
            FontString = Value("FontString")
            chkUnderline.Checked = Value("Underline")
            If Value("UseRectangle") Then
                Rectangle2Use = Value("Rectangle")
            Else
                pPoint = Value("Point")
            End If
            cbFont.SelectedIndex = Value("Font")
        End Set
    End Property

    Public Sub New()
        MyBase.New()
        Init()
    End Sub

    Friend WithEvents MainMenu As New System.Windows.Forms.MainMenu
    Friend WithEvents mnDone As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMenu As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCancel As New System.Windows.Forms.MenuItem
    Friend WithEvents lblText As New System.Windows.Forms.Label
    Friend WithEvents txtText As New System.Windows.Forms.TextBox
    Friend WithEvents lblSize As New System.Windows.Forms.Label
    Friend WithEvents txtSize As New System.Windows.Forms.TextBox
    Friend WithEvents chkItalic As New System.Windows.Forms.CheckBox
    Friend WithEvents chkBold As New System.Windows.Forms.CheckBox
    Friend WithEvents chkUnderline As New System.Windows.Forms.CheckBox
    Friend WithEvents lblFont As New System.Windows.Forms.Label
    Friend WithEvents cbFont As New System.Windows.Forms.ComboBox
    Friend WithEvents mnPoint As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents lblColor As New System.Windows.Forms.Label
    Friend WithEvents pnlColor As New System.Windows.Forms.Panel
    Friend WithEvents pnlColorBg As New System.Windows.Forms.Panel
    Friend WithEvents mnColor As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCustomFont As New System.Windows.Forms.MenuItem
    Friend WithEvents mnHelp As New System.Windows.Forms.MenuItem
    Friend WithEvents SmartphoneBoxPanel As New System.Windows.Forms.Panel

    Sub Init()
        If Not LCase(frmMain.PlatformType).IndexOf(LCase("WindowsPC")) = -1 Then
            WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        Else
            WorkingSize = New Size(System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height)
            'WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        End If

        MainMenu.MenuItems.Add(mnDone)
        MainMenu.MenuItems.Add(mnMenu)

        mnDone.Text = "Done"

        mnMenu.MenuItems.Add(mnPoint)
        mnMenu.MenuItems.Add(mnCustomFont)
        mnMenu.MenuItems.Add(mnColor)
        mnMenu.MenuItems.Add(mnSeperator1)
        mnMenu.MenuItems.Add(mnHelp)
        mnMenu.MenuItems.Add(mnCancel)
        mnMenu.Text = "Menu"

        mnPoint.Text = "Define upper-left point..."

        mnCustomFont.Text = "Enter user-defined Font..."

        mnColor.Text = "Choose Color..."

        mnSeperator1.Text = "-"

        mnCancel.Text = "Cancel"

        lblText.Location = New System.Drawing.Point(4, 6)
        lblText.Size = New System.Drawing.Size(42, 22)
        lblText.Text = "Text:"

        txtText.Location = New System.Drawing.Point(42, 2)
        txtText.Size = New System.Drawing.Size(132, 30)
        txtText.Text = "Hello!"

        lblSize.Location = New System.Drawing.Point(4, 36)
        lblSize.Size = New System.Drawing.Size(152, 22)
        lblSize.Text = "Size (em):"

        txtSize.Location = New System.Drawing.Point(72, 34)
        txtSize.Size = New System.Drawing.Size(102, 30)
        txtSize.Text = "8"

        chkItalic.Font = frmMain.LabelFont
        chkItalic.Location = New System.Drawing.Point(4, 68)
        chkItalic.Size = New System.Drawing.Size(50, 20)
        chkItalic.Text = "Italic"

        chkBold.Font = frmMain.LabelFont
        chkBold.Location = New System.Drawing.Point(56, 68)
        chkBold.Size = New System.Drawing.Size(56, 20)
        chkBold.Text = "Bold"

        chkUnderline.Font = frmMain.LabelFont
        chkUnderline.Location = New System.Drawing.Point(112, 68)
        chkUnderline.Size = New System.Drawing.Size(62, 20)
        chkUnderline.Text = "Underline"

        lblFont.Location = New System.Drawing.Point(4, 94)
        lblFont.Size = New System.Drawing.Size(152, 22)
        lblFont.Text = "Font:"

        cbFont.Items.Add("Monospace")
        cbFont.Items.Add("SansSerif")
        cbFont.Items.Add("Serif")
        cbFont.Items.Add("User-Defined")
        cbFont.Location = New System.Drawing.Point(42, 90)
        cbFont.Size = New System.Drawing.Size(132, 30)

        lblColor.Location = New System.Drawing.Point(4, 124)
        lblColor.Size = New System.Drawing.Size(170, 22)
        lblColor.Text = "Color:"

        pnlColor.Location = New System.Drawing.Point(56, 128)
        pnlColor.Size = New System.Drawing.Size(14, 14)

        pnlColorBg.BackColor = System.Drawing.Color.Black
        pnlColorBg.Location = New System.Drawing.Point(55, 127)
        pnlColorBg.Size = New System.Drawing.Size(16, 16)

        mnHelp.Text = "Help"

        SmartphoneBoxPanel.Size = frmMain.SmartphonePanelsSize
        SmartphoneBoxPanel.Location = New Point(WorkingSize.Width / 2 - SmartphoneBoxPanel.Width / 2, 0)

        SmartphoneBoxPanel.Controls.Add(pnlColor)
        SmartphoneBoxPanel.Controls.Add(cbFont)
        SmartphoneBoxPanel.Controls.Add(lblFont)
        SmartphoneBoxPanel.Controls.Add(chkUnderline)
        SmartphoneBoxPanel.Controls.Add(chkBold)
        SmartphoneBoxPanel.Controls.Add(chkItalic)
        SmartphoneBoxPanel.Controls.Add(txtSize)
        SmartphoneBoxPanel.Controls.Add(lblSize)
        SmartphoneBoxPanel.Controls.Add(txtText)
        SmartphoneBoxPanel.Controls.Add(lblText)
        SmartphoneBoxPanel.Controls.Add(pnlColorBg)
        SmartphoneBoxPanel.Controls.Add(lblColor)
        Me.Controls.Add(SmartphoneBoxPanel)
        Me.Menu = MainMenu
        Me.Text = "Draw: Text"
        Me.MaximizeBox = False
        Me.WindowState = System.Windows.Forms.FormWindowState.Normal
        Me.FormBorderStyle = FormBorderStyle.FixedSingle

    End Sub

    Private Sub cbFont_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbFont.TextChanged
        If Not cbFont.Items.Contains(cbFont.Text) Then
            cbFont.SelectedIndex = 0
        End If
    End Sub

    Private Sub mnDone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDone.Click
        If Not pPoint.IsEmpty Then
            If IsNumeric(txtSize.Text) Then
                Me.DialogResult = DialogResult.OK
            Else
                System.Windows.Forms.MessageBox.Show("The size must be a number!", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            End If
        Else
            If UseRectangle Then
                If IsNumeric(txtSize.Text) Then
                    Me.DialogResult = DialogResult.OK
                Else
                    System.Windows.Forms.MessageBox.Show("The size must be a number!", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                End If
            Else
                System.Windows.Forms.MessageBox.Show("You have not defined the upper-left point of the text to be drawn. Use the menu to define it.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            End If
        End If
    End Sub

    Private Sub mnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCancel.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

    Private Sub frmGenerateText_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cbFont.SelectedIndex = 0
    End Sub


    Private Sub mnPoint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnPoint.Click
        Dim nGetPoint As New frmGetPoints
        nGetPoint.Image2Show = Image2Show
        nGetPoint.NumPoints = 1
        If nGetPoint.ShowDialog = DialogResult.OK Then
            pPoint = nGetPoint.PointsSelected(0)
        End If
    End Sub

    Private Sub mnColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnColor.Click
        Dim nGetColor As New frmColorPicker
        nGetColor.ImageForPick = Image2Show
        If nGetColor.ShowDialog = DialogResult.OK Then
            pnlColor.BackColor = nGetColor.SelectedColor
        End If
    End Sub

    Private Sub mnCustomFont_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCustomFont.Click
        Dim nIn As New InputDialog
        nIn.AssignedValue = FontString
        nIn.Description = "Enter the name of the font you want to use. Please be sure that it exists. It will only be used if you choose 'User-Defined' from the fonts list box."
        If nIn.ShowDialog = DialogResult.OK Then
            FontString = nIn.AssignedValue
        End If
    End Sub

    Private Sub mnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnHelp.Click ' Help
        System.Windows.Forms.MessageBox.Show("Enter the text you want to draw in the first textbox. Enter the size integer in the second textbox. Choose the characteristics of the text, bold, italic, underline if you want by checking the appropriate checkboxes (due to a problem, multiple characteristics may not work in some cases). Choose the font you want from the dropdown list. If you choose UserDefined, then you need to click Menu > Choose User Defined Font... to supply the font's name you want to use. The color to be used can be changed by Menu > Choose Color..." & vbCrLf & vbCrLf & "If you used a selection for drawing the text, you don't need to do anything else, just press Done. If you didn't use a selection, you must lastly provide a point for the upper-left corner of the text to be drawn on the image. To do that click Menu > Define Upper-Left Point... Then press Done.", "Help", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1)
    End Sub

End Class

