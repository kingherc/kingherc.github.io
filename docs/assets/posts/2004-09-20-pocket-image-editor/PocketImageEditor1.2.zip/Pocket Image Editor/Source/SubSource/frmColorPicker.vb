    'Pocket Image Editor
    'Copyright (C) 2004 Iraklis Psaroudakis

    'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
    'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

    'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection

Public Class frmColorPicker
    Inherits System.Windows.Forms.Form

    Public Key4ColorPressed As Boolean = False
    Public CurStep As Integer = 7
    Dim ImageForPickT As Bitmap
    Dim hResources As New Hashtable
    Dim WorkingSize As Size

    Public Property SelectedColor() As Color
        Get
            Return pChosenColor.BackColor
        End Get
        Set(ByVal Value As Color)
            pChosenColor.BackColor = Value
            txtR.Text = Value.R
            txtG.Text = Value.G
            txtB.Text = Value.B
        End Set
    End Property
    Public Property ImageForPick() As Bitmap
        Get
            Return ImageForPickT
        End Get
        Set(ByVal Value As Bitmap)
            ImageForPickT = Value
            mnPickImage.Enabled = True
        End Set
    End Property

    Public Sub New()
        MyBase.New()
        Init()
    End Sub

    Friend WithEvents MainMenu As New System.Windows.Forms.MainMenu
    Friend WithEvents mnDone As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMenu As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCancel As New System.Windows.Forms.MenuItem
    Friend WithEvents txtR As New System.Windows.Forms.TextBox
    Friend WithEvents txtG As New System.Windows.Forms.TextBox
    Friend WithEvents txtB As New System.Windows.Forms.TextBox
    Friend WithEvents pnlPickedColorBg As New System.Windows.Forms.Panel
    Friend WithEvents pChosenColor As New System.Windows.Forms.Panel
    Friend WithEvents mnHelp As New System.Windows.Forms.MenuItem
    Friend WithEvents mnPredef As New System.Windows.Forms.MenuItem
    Friend WithEvents pCur As New System.Windows.Forms.PictureBox
    Friend WithEvents pColors As New System.Windows.Forms.PictureBox
    Friend WithEvents txtHex As New System.Windows.Forms.TextBox
    Friend WithEvents mnHex As New System.Windows.Forms.MenuItem
    Friend WithEvents lblHex As New System.Windows.Forms.Label
    Friend WithEvents lblR As New System.Windows.Forms.Label
    Friend WithEvents lblG As New System.Windows.Forms.Label
    Friend WithEvents lblB As New System.Windows.Forms.Label
    Friend WithEvents mnPickImage As New System.Windows.Forms.MenuItem
    Friend WithEvents SmartphoneBoxPanel As New System.Windows.Forms.Panel

    Private Sub LoadUpResources
        Dim iStream As Stream = System.Reflection.Assembly.GetExecutingAssembly.GetManifestResourceStream(System.Reflection.Assembly.GetExecutingAssembly.GetManifestResourceNames(0))
        Dim rr As New System.Resources.ResourceReader(iStream)
        Dim id As IDictionaryEnumerator = rr.GetEnumerator()
        While id.MoveNext()
            hResources.Add(id.key, id.Value)
        End While
    End Sub

    Sub Init()
        If Not LCase(frmMain.PlatformType).IndexOf(LCase("WindowsPC")) = -1 Then
            WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        Else
            WorkingSize = New Size(System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height)
            'WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        End If

        LoadUpResources()

        MainMenu.MenuItems.Add(mnDone)
        MainMenu.MenuItems.Add(mnMenu)

        mnDone.Text = "Done"

        mnMenu.MenuItems.Add(mnPredef)
        mnMenu.MenuItems.Add(mnHex)
        mnMenu.MenuItems.Add(mnPickImage)
        mnMenu.MenuItems.Add(mnHelp)
        mnMenu.MenuItems.Add(mnCancel)
        mnMenu.Text = "Menu"

        mnPredef.Text = "Choose Predefined"

        mnHex.Text = "Hex / Html to RGB"

        mnHelp.Text = "Help"

        mnCancel.Text = "Cancel"

        txtR.Location = New System.Drawing.Point(20, 146)
        txtR.Size = New System.Drawing.Size(30, 30)
        txtR.Text = "255"

        lblR.Location = New System.Drawing.Point(2, 148)
        lblR.Size = New System.Drawing.Size(38, 22)
        lblR.Text = "R:"

        txtG.Location = New System.Drawing.Point(71, 146)
        txtG.Size = New System.Drawing.Size(30, 30)
        txtG.Text = "255"

        lblG.Location = New System.Drawing.Point(53, 148)
        lblG.Size = New System.Drawing.Size(31, 22)
        lblG.Text = "G:"

        txtB.Location = New System.Drawing.Point(121, 146)
        txtB.Size = New System.Drawing.Size(30, 30)
        txtB.Text = "255"

        lblB.Location = New System.Drawing.Point(103, 148)
        lblB.Size = New System.Drawing.Size(35, 22)
        lblB.Text = "B:"

        pChosenColor.BackColor = System.Drawing.Color.White
        pChosenColor.Location = New System.Drawing.Point(156, 154)
        pChosenColor.Size = New System.Drawing.Size(14, 14)

        pnlPickedColorBg.BackColor = System.Drawing.Color.Black
        pnlPickedColorBg.Location = New System.Drawing.Point(155, 153)
        pnlPickedColorBg.Size = New System.Drawing.Size(16, 16)

        pColors.Image = CType(hResources("Pallette"), System.Drawing.Image)
        pColors.Location = New System.Drawing.Point(6, 5)
        pColors.Size = New System.Drawing.Size(165, 135)
        pColors.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage

        pCur.Image = CType(hResources("Cursor1"), System.Drawing.Image)
        pCur.Location = New System.Drawing.Point(76, 60)
        pCur.Size = New System.Drawing.Size(5, 5)

        lblHex.Location = New System.Drawing.Point(7, 149)
        lblHex.Size = New System.Drawing.Size(33, 23)
        lblHex.Text = "Hex:"
        lblHex.Visible = False

        txtHex.Enabled = False
        txtHex.Location = New System.Drawing.Point(43, 146)
        txtHex.Size = New System.Drawing.Size(105, 30)
        txtHex.Text = "#000000"
        txtHex.Visible = False

        mnPickImage.Enabled = False
        mnPickImage.Text = "Pick from image..."

        SmartphoneBoxPanel.Size = frmMain.SmartphonePanelsSize
        SmartphoneBoxPanel.Location = New Point(WorkingSize.Width / 2 - SmartphoneBoxPanel.Width / 2, 0)

        SmartphoneBoxPanel.Controls.Add(lblHex)
        SmartphoneBoxPanel.Controls.Add(txtHex)
        SmartphoneBoxPanel.Controls.Add(pCur)
        SmartphoneBoxPanel.Controls.Add(pColors)
        SmartphoneBoxPanel.Controls.Add(pChosenColor)
        SmartphoneBoxPanel.Controls.Add(txtB)
        SmartphoneBoxPanel.Controls.Add(txtG)
        SmartphoneBoxPanel.Controls.Add(txtR)
        SmartphoneBoxPanel.Controls.Add(lblB)
        SmartphoneBoxPanel.Controls.Add(lblG)
        SmartphoneBoxPanel.Controls.Add(lblR)
        SmartphoneBoxPanel.Controls.Add(pnlPickedColorBg)
        Me.Controls.Add(SmartphoneBoxPanel)
        Me.Menu = MainMenu
        Me.Text = "Color Picker"
        Me.MaximizeBox = False
        Me.WindowState = System.Windows.Forms.FormWindowState.Normal
        Me.FormBorderStyle = FormBorderStyle.FixedSingle

    End Sub

    Private Sub pColors_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pColors.MouseDown
        pCur.Left = pColors.Left + e.X - ((pCur.Width - 1) / 2)
        pCur.Top = pColors.Top + e.Y - ((pCur.Height - 1) / 2)
        CurMoved()
    End Sub

    Private Sub mnPickImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnPickImage.Click
        Dim nPick As New frmGetPoints
        nPick.Image2Show = ImageForPick
        nPick.NumPoints = 1
        If nPick.ShowDialog = DialogResult.OK Then
            SelectedColor = ImageForPick.GetPixel(nPick.PointsSelected(0).X, nPick.PointsSelected(0).Y)
        End If
    End Sub

    Private Sub mnHex_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnHex.Click
        If mnHex.Checked Then
            lblHex.Visible = False
            txtHex.Enabled = False
            txtHex.Visible = False
            lblR.Visible = True
            lblG.Visible = True
            lblB.Visible = True
            txtR.Visible = True
            txtG.Visible = True
            txtB.Visible = True
            txtR.Enabled = True
            txtG.Enabled = True
            txtB.Enabled = True
            mnPredef.Enabled = True
            txtR.Focus()
            mnHex.Checked = False
        Else
            lblHex.Visible = True
            txtHex.Enabled = True
            txtHex.Visible = True
            lblR.Visible = False
            lblG.Visible = False
            lblB.Visible = False
            txtR.Visible = False
            txtG.Visible = False
            txtB.Visible = False
            txtR.Enabled = False
            txtG.Enabled = False
            txtB.Enabled = False
            mnPredef.Enabled = False
            txtHex.Focus()
            mnHex.Checked = True
        End If
    End Sub

    Private Sub mnPredef_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnPredef.Click
        If Not mnPredef.Checked Then
            txtR.Enabled = False
            txtG.Enabled = False
            txtB.Enabled = False
            mnPredef.Checked = True
            mnHex.Enabled = False
        Else
            txtR.Enabled = True
            txtG.Enabled = True
            txtB.Enabled = True
            txtR.Focus()
            mnPredef.Checked = False
            mnHex.Enabled = True
        End If
    End Sub

    Private Sub mnDone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDone.Click
        Me.DialogResult = DialogResult.OK
    End Sub

    Private Sub mnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCancel.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

    Private Sub mnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnHelp.Click
        System.Windows.Forms.MessageBox.Show("--- Choosing Colors ---" & vbCrLf & vbCrLf & "There are 3 ways to choose a color. Just keep in mind that the final color selected upon clicking Done will be the one showed in the square at the bottom-right of the System.Windows.Forms.Screen." & vbCrLf & "1) Create your RGB color (If you don't know about RGB, read the relevant section of this messagebox): Fill the textboxes with your desired values (0-256)." & vbCrLf & "2) Choose a predefined color: Click Menu->Choose Predefined Colors. Then navigate with the navkeys to find the color you want with the help of the cursor. Pressing key 1 will decrease the cursor speed. Pressing key 2 will increase it. Pressing 3 will toggle visibility of the cursor. When finished, click done or Menu->Choose Predefined Colors." & vbCrLf & "3) Hex to RGB color: If you are familiar with hex/html colors, click Menu->Hex / Html to RGB. Fill the textbox with the hex color (7 characters with #). When finished click Menu->Hex / Html to RGB or Done." & vbCrLf & vbCrLf & "--- RGB & Hex---" & vbCrLf & vbCrLf & "A color is made up from three basic colors: Red, Green, Blue. According to the intensity of each basic color, you can mix them up to make various colors. The intensity in mathematics (referring to the mostly used RGB system in computers) is between 0 and 256. For example, for black: Red = 0, Green = 0, Blue = 0 (because black is the absence of all colors. For clear green: Red = 0, Green = 256, Blue = 0. For Yellow: Red = 256, Green = 256, Blue = 0." & vbCrLf & vbCrLf & "Hex Colors is another way of representing RGB colors in one phrase, rather than using three intensities of the basic colors seperate and they are used in web development. Hex colors consist of 6 characters. Each 2 characters define the intensity of the basic red, green, blue colors but in hexademical format. So for black we would have #000000, for white #FFFFFF, for yellow #FFFF00.", "Help", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1)
    End Sub

    Private Sub txtHex_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtHex.TextChanged
        If txtHex.Text.Length = 7 Then
            Dim cColor As Color = Hex2Rgb(txtHex.Text)
            txtR.Text = cColor.R
            txtG.Text = cColor.G
            txtB.Text = cColor.B
        End If
    End Sub

    Private Sub frmColorPicker_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Select Case e.KeyValue
            Case 13 'action

            Case 49 '1
                CurStep -= 1 'Reduce Cursor Step
                If CurStep <= 0 Then
                    CurStep += 1
                End If
            Case 50 '2
                CurStep += 1 'Enlarge Cursor step
                If CurStep >= 50 Then
                    CurStep -= 1
                End If
            Case 51 '3
                If pCur.Visible = True Then 'Toggle Cursor visibility
                    pCur.Visible = False
                Else
                    pCur.Visible = True
                End If
            Case 38 'UP
                pCur.Top -= CurStep
                CurMoved()
            Case 37 'LEFT
                pCur.Left -= CurStep
                CurMoved()
            Case 39 'RIGHT
                pCur.Left += CurStep
                CurMoved()
            Case 40 'DOWN
                pCur.Top += CurStep
                CurMoved()
        End Select
    End Sub

    Private Sub ColorPicker_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mnPredef_Click(Me, EventArgs.Empty)
    End Sub


    Private Sub txtR_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtR.TextChanged
        ShowColor()
    End Sub

    Private Sub txtG_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtG.TextChanged
        ShowColor()
    End Sub

    Private Sub txtB_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtB.TextChanged
        ShowColor()
    End Sub

    Private Sub txtR_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtR.KeyDown
        Key4ColorPressed = True
    End Sub

    Private Sub txtG_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtG.KeyDown
        Key4ColorPressed = True
    End Sub

    Private Sub txtB_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtB.KeyDown
        Key4ColorPressed = True
    End Sub

    Private Sub frmColorPicker_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Deactivate
        Key4ColorPressed = False
    End Sub

    Sub CurMoved()
        If pCur.Top < pColors.Top Then
            pCur.Top += CurStep
        End If
        If pCur.Top >= pColors.Bottom Then
            pCur.Top -= CurStep
        End If
        If pCur.Left < pColors.Left Then
            pCur.Left += CurStep
        End If
        If pCur.Left >= pColors.Right Then
            pCur.Left -= CurStep
        End If
        Try
            Dim nbit As Bitmap = New Bitmap(pColors.Image)
            Dim X As Integer = pCur.Left - pColors.Left + ((pCur.Width - 1) / 2)
            Dim Y As Integer = pCur.Top - pColors.Top + ((pCur.Height - 1) / 2)
            Dim selColor As Color = nbit.GetPixel(X - 1, Y - 1)
            txtR.Text = selColor.R
            txtG.Text = selColor.G
            txtB.Text = selColor.B
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show("An Error occurred while moving the cursor. Try not to move the cursor out of the bounds of the Colors image." & vbCrLf & "" & vbCrLf & "Error: '" & ex.Message & "'", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
        End Try
    End Sub

    Sub ShowColor()
        Try
            pChosenColor.BackColor = Color.FromArgb(txtR.Text, txtG.Text, txtB.Text)
        Catch ex As Exception
            If Key4ColorPressed Then
                System.Windows.Forms.MessageBox.Show("RGB (Red, Green, Blue) values must be numeric and between 0 and 255!", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            End If
        End Try
    End Sub

    Function Hex2Rgb(ByVal HexStr As String) As Color
        HexStr = HexStr.Replace("#", "")
        Dim rred As Integer
        Dim ggreen As Integer
        Dim bblue As Integer
        rred = CInt(DemVal(HexStr.Substring(0, 1)) * 16 + DemVal(HexStr.Substring(1, 1)))
        ggreen = CInt(DemVal(HexStr.Substring(2, 1)) * 16 + DemVal(HexStr.Substring(3, 1)))
        bblue = CInt(DemVal(HexStr.Substring(4, 1)) * 16 + DemVal(HexStr.Substring(5, 1)))
        Return Color.FromArgb(rred, ggreen, bblue)
        'Disposing
        rred = Nothing
        ggreen = Nothing
        bblue = Nothing
    End Function

    Function DemVal(ByVal HexChar As String) As Integer
        Select Case LCase(HexChar)
            Case "a"
                Return 10
            Case "b"
                Return 11
            Case "c"
                Return 12
            Case "d"
                Return 13
            Case "e"
                Return 14
            Case "f"
                Return 15
            Case Else
                If Char.IsNumber(HexChar) Then
                    Return CInt(HexChar)
                Else
                    System.Windows.Forms.MessageBox.Show("Hex colors constitute of 7 characters. The first must be the '#' character. The following must be numeric or 'a', 'b', 'c', 'd', 'e', 'f'.", "Non hex color!", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                    Return 10
                End If
        End Select
    End Function

    Public Function GetChosenColor() As Color
        Return pChosenColor.BackColor
    End Function

End Class

