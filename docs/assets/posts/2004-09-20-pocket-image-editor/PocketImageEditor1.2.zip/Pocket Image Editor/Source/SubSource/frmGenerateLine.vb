    'Pocket Image Editor
    'Copyright (C) 2004 Iraklis Psaroudakis

    'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
    'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

    'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection

Public Class frmGenerateLine
    Inherits System.Windows.Forms.Form

    Dim sPoint1 As Point = New Point(-100, -100)
    Dim sPoint2 As Point = New Point(-100, -100)
    Dim WorkingSize As Size

    Public ImageEdited As New Bitmap(100, 100)
    Public Property Point1() As Point
        Get
            Return sPoint1
        End Get
        Set(ByVal Value As Point)
            sPoint1 = Value
            lblPoint1.Text = "(" & Value.X & ", " & Value.Y & ")"
        End Set
    End Property
    Public Property Point2() As Point
        Get
            Return sPoint2
        End Get
        Set(ByVal Value As Point)
            sPoint2 = Value
            lblPoint2.Text = "(" & Value.X & ", " & Value.Y & ")"
        End Set
    End Property
    Public Property ChosenColor() As Color
        Get
            Return pnlColor.BackColor
        End Get
        Set(ByVal Value As Color)
            pnlColor.BackColor = Value
        End Set
    End Property
    Public Property ChosenWidth() As Integer
        Get
            Return lblBorderWidth.Text
        End Get
        Set(ByVal Value As Integer)
            lblBorderWidth.Text = Value
        End Set
    End Property

    Public Property LineCommands() As Hashtable
        'This hashtable contains all required values for drawing a line.
        Get
            Dim nHash As New Hashtable
            nHash.Add("Color", ChosenColor)
            nHash.Add("Width", ChosenWidth)
            nHash.Add("X1", Point1.X)
            nHash.Add("Y1", Point1.Y)
            nHash.Add("X2", Point2.X)
            nHash.Add("Y2", Point2.Y)
            Return nHash
        End Get
        Set(ByVal Value As Hashtable)
            ChosenColor = Value("Color")
            ChosenWidth = Value("Width")
            Point1 = New Point(Value("X1"), Value("Y1"))
            Point2 = New Point(Value("X2"), Value("Y2"))
        End Set
    End Property

    Public Sub New()
        MyBase.New()
        Init()
    End Sub

    Friend WithEvents mnDone As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMenu As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCancel As New System.Windows.Forms.MenuItem
    Friend WithEvents mMenu As New System.Windows.Forms.MainMenu
    Friend WithEvents lblWidth As New System.Windows.Forms.Label
    Friend WithEvents lblBorderWidth As New System.Windows.Forms.Label
    Friend WithEvents lblColor As New System.Windows.Forms.Label
    Friend WithEvents pnlColorBg As New System.Windows.Forms.Panel
    Friend WithEvents pnlColor As New System.Windows.Forms.Panel
    Friend WithEvents lblPrePoint1 As New System.Windows.Forms.Label
    Friend WithEvents lblPoint1 As New System.Windows.Forms.Label
    Friend WithEvents lblPrePoint2 As New System.Windows.Forms.Label
    Friend WithEvents lblPoint2 As New System.Windows.Forms.Label
    Friend WithEvents mnWidth As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnColor As New System.Windows.Forms.MenuItem
    Friend WithEvents mnPoints As New System.Windows.Forms.MenuItem
    Friend WithEvents mnHelp As New System.Windows.Forms.MenuItem
    Friend WithEvents SmartphoneBoxPanel As New System.Windows.Forms.Panel

    Sub Init
        If Not LCase(frmMain.PlatformType).IndexOf(LCase("WindowsPC")) = -1 Then
            WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        Else
            WorkingSize = New Size(System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height)
            'WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        End If

        mMenu.MenuItems.Add(mnDone)
        mMenu.MenuItems.Add(mnMenu)

        mnDone.Text = "Done"

        mnMenu.MenuItems.Add(mnWidth)
        mnMenu.MenuItems.Add(mnColor)
        mnMenu.MenuItems.Add(mnPoints)
        mnMenu.MenuItems.Add(mnSeperator1)
        mnMenu.MenuItems.Add(mnCancel)
        mnMenu.MenuItems.Add(mnHelp)
        mnMenu.Text = "Menu"

        mnWidth.Text = "Choose Width..."

        mnColor.Text = "Choose Color..."

        mnPoints.Text = "Choose Points..."

        mnSeperator1.Text = "-"

        mnCancel.Text = "Cancel"

        mnHelp.Text = "Help"

        lblWidth.Location = New System.Drawing.Point(2, 2)
        lblWidth.Size = New System.Drawing.Size(126, 18)
        lblWidth.Text = "Line width (px):"

        lblBorderWidth.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(64, Byte), CType(0, Byte))
        lblBorderWidth.Location = New System.Drawing.Point(114, 2)
        lblBorderWidth.Size = New System.Drawing.Size(48, 18)
        lblBorderWidth.Text = "1"

        lblColor.Location = New System.Drawing.Point(2, 22)
        lblColor.Size = New System.Drawing.Size(174, 22)
        lblColor.Text = "Color:"

        pnlColor.Location = New System.Drawing.Point(63, 25)
        pnlColor.Size = New System.Drawing.Size(14, 14)

        pnlColorBg.BackColor = System.Drawing.Color.Black
        pnlColorBg.Location = New System.Drawing.Point(62, 24)
        pnlColorBg.Size = New System.Drawing.Size(16, 16)

        lblPrePoint1.Location = New System.Drawing.Point(2, 44)
        lblPrePoint1.Size = New System.Drawing.Size(152, 22)
        lblPrePoint1.Text = "Point 1:"

        lblPoint1.Location = New System.Drawing.Point(56, 44)
        lblPoint1.Size = New System.Drawing.Size(88, 22)
        lblPoint1.Text = "(-100, -100)"

        lblPoint2.Location = New System.Drawing.Point(56, 66)
        lblPoint2.Size = New System.Drawing.Size(152, 22)
        lblPoint2.Text = "(-100, -100)"

        lblPrePoint2.Location = New System.Drawing.Point(2, 66)
        lblPrePoint2.Size = New System.Drawing.Size(152, 22)
        lblPrePoint2.Text = "Point 2:"

        SmartphoneBoxPanel.Size = frmMain.SmartphonePanelsSize
        SmartphoneBoxPanel.Location = New Point(WorkingSize.Width / 2 - SmartphoneBoxPanel.Width / 2, 0)

        SmartphoneBoxPanel.Controls.Add(lblPoint2)
        SmartphoneBoxPanel.Controls.Add(lblPrePoint2)
        SmartphoneBoxPanel.Controls.Add(lblPoint1)
        SmartphoneBoxPanel.Controls.Add(lblPrePoint1)
        SmartphoneBoxPanel.Controls.Add(pnlColor)
        SmartphoneBoxPanel.Controls.Add(pnlColorBg)
        SmartphoneBoxPanel.Controls.Add(lblColor)
        SmartphoneBoxPanel.Controls.Add(lblBorderWidth)
        SmartphoneBoxPanel.Controls.Add(lblWidth)
        Me.Controls.Add(SmartphoneBoxPanel)
        Me.Menu = mMenu
        Me.Text = "Draw: Line"
        Me.MaximizeBox = False
        Me.WindowState = System.Windows.Forms.FormWindowState.Normal
        Me.FormBorderStyle = FormBorderStyle.FixedSingle

    End Sub

    Private Sub pnlColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnlColor.Click
        mnColor_Click(Me, EventArgs.Empty)
    End Sub

    Private Sub mnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnHelp.Click 'Help
        System.Windows.Forms.MessageBox.Show("A line is defined by two points (start & finish). You can choose its border width, its color and its two points by using the Menu.", "Help", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1)
    End Sub

    Private Sub mnDone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDone.Click
        Me.DialogResult = DialogResult.OK
    End Sub

    Private Sub mnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCancel.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

    Private Sub mnWidth_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnWidth.Click
        Dim nGetWidth As New frmGetBorderWidth
        If nGetWidth.ShowDialog = DialogResult.OK Then
            ChosenWidth = nGetWidth.SelectedWidth
        End If
    End Sub

    Private Sub mnColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnColor.Click
        Dim nGetColor As New frmColorPicker
        nGetColor.ImageForPick = ImageEdited
        If nGetColor.ShowDialog = DialogResult.OK Then
            ChosenColor = nGetColor.SelectedColor
        End If
    End Sub

    Private Sub mnPoints_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnPoints.Click
        Dim nGetPoints As New frmGetPoints
        nGetPoints.NumPoints = 2
        nGetPoints.Image2Show = ImageEdited
        If nGetPoints.ShowDialog = DialogResult.OK Then
            Point1 = nGetPoints.PointsSelected(0)
            Point2 = nGetPoints.PointsSelected(1)
        End If
    End Sub

End Class

