'Pocket Image Editor
'Copyright (C) 2004 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System
Imports System.Resources

Public Class WriteResources
    
    Public Shared Sub Main()

        Dim writer As New System.Resources.ResourceWriter("Main.resources")

        ' Adds resources to the resource writer.
        writer.AddResource("GrayBackground", New System.Drawing.Bitmap("Images\Background.jpg"))
        writer.AddResource("BorderWidthImg", New System.Drawing.Bitmap("Images\BorderWidthExamples.gif"))
        writer.AddResource("Cursor1", new System.Drawing.Bitmap("Images\Cursor.bmp"))
        writer.AddResource("Cursor2", new System.Drawing.Bitmap("Images\Cursor2.bmp"))
        writer.AddResource("Cursor3", new System.Drawing.Bitmap("Images\Cursor3.bmp"))
        writer.AddResource("Cursor4", new System.Drawing.Bitmap("Images\Cursor4.bmp"))
        writer.AddResource("FileIcon", new System.Drawing.Bitmap("Images\File.gif"))
        writer.AddResource("FolderClosed", new System.Drawing.Bitmap("Images\FolderClosed.gif"))
        writer.AddResource("FolderOpened", new System.Drawing.Bitmap("Images\FolderOpened.gif"))
        writer.AddResource("IntroImage", new System.Drawing.Bitmap("Images\IntroImg.jpg"))
        writer.AddResource("Pallette", new System.Drawing.Bitmap("Images\Pallette.jpg"))
        writer.AddResource("Pencil_Accelarated", new System.Drawing.Bitmap("Images\Pencil_Accelarated.gif"))
        writer.AddResource("Pencil_AccelaratedWrite", new System.Drawing.Bitmap("Images\Pencil_AccelaratedWrite.gif"))
        writer.AddResource("Pencil_Plain", new System.Drawing.Bitmap("Images\Pencil_Plain.gif"))
        writer.AddResource("Pencil_Write", new System.Drawing.Bitmap("Images\Pencil_Write.gif"))
        writer.AddResource("ProgramIcon16", New System.Drawing.Icon("Images\ProgramIcon16.ico"))
        writer.AddResource("MouseClickEvents", New System.Drawing.Bitmap("Images\MouseClickEvents.gif"))
        writer.AddResource("Zoom", New System.Drawing.Bitmap("Images\Zoom.gif"))
        writer.AddResource("UnZoom", New System.Drawing.Bitmap("Images\UnZoom.gif"))

        ' Writes the resources to the file or stream, and closes it.
        writer.Close()


    End Sub
End Class

