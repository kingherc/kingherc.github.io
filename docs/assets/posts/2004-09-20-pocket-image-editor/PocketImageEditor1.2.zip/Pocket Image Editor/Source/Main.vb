'Pocket Image Editor
'Copyright (C) 2004 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Resources
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports System.Reflection

<Assembly: AssemblyTitle("Pocket Image Editor")> 
<Assembly: AssemblyDescription("A compact Pocket Image Editor for .NET Compact Framework devices. For basic draw and image editing.")> 
<Assembly: AssemblyCompany("None")> 
<Assembly: AssemblyProduct("Pocket Image Editor")> 
<Assembly: AssemblyCopyright("2004 Iraklis Psaroudakis")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: AssemblyVersion("1.2.0")> 

Public Class frmMain
    Inherits System.Windows.Forms.Form



    Public Shared strRegKey As String = "HKEY_CURRENT_USER\Software\Pocket Image Editor"
    Dim CursorStep As Integer = 7
    Public frmWidth As Integer '170
    Public frmHeight As Integer
    Public LocX As Integer 'X location of cursor on the image
    Public LocY As Integer 'Y location of cursor on the image
    Dim pUndoImage As Image
    Dim Paint1Color As Color
    Dim PaintSize As Size
    Dim FloatingCursorT As Boolean = False
    Dim navKeyLastPressed As Integer = 38
    Dim isEditSession As Boolean = False
    Dim EditPoint1 As Point = Point.Empty
    Dim EditPoint2 As Point = Point.Empty
    Dim EditRectangle As New Rectangle
    Dim PreEditImageBackup As Image
    Dim CopiedImage As Image
    Dim isZoom As Boolean = False
    Dim ZoomPixels As Integer = 20
    Dim CursorsPreviousLocation As Point
    Dim hResources As New Hashtable
    Dim pPaintSizeFirstMiddlePoint As Point
    Public Shared PlatformType As String
    Public Shared WorkingSize As Size
    Public Shared SmartphonePanelsSize As Size = New Size(176, 180)
    Public Shared LabelFont As Font
    Public Shared DefaultExplorerDir As String = "CurrentDir"

    Private Property FloatingCursor() As Boolean
        Get
            Return FloatingCursorT
        End Get
        Set(ByVal Value As Boolean)
            FloatingCursorT = Value
            tmrFloatCursor.Enabled = Value
        End Set
    End Property

    Friend WithEvents mnDraw As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDrawLine As New System.Windows.Forms.MenuItem
    Friend WithEvents pImage As New System.Windows.Forms.PictureBox
    Friend WithEvents lblLocCur As New System.Windows.Forms.Label
    Friend WithEvents pCursor As New System.Windows.Forms.PictureBox
    Friend WithEvents mnImage As New System.Windows.Forms.MenuItem
    Friend WithEvents mnShowDimensions As New System.Windows.Forms.MenuItem
    Friend WithEvents HScroll As New System.Windows.Forms.HScrollBar
    Friend WithEvents VScroll As New System.Windows.Forms.VScrollBar
    Friend WithEvents mnOpenFile As New System.Windows.Forms.MenuItem
    Friend WithEvents pBgImg As New System.Windows.Forms.PictureBox
    Friend WithEvents mnPaintColor As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDrawSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents pnlColor1Bg As New System.Windows.Forms.Panel
    Friend WithEvents pPaintColor As New System.Windows.Forms.Panel
    Friend WithEvents pPaintSize As New System.Windows.Forms.Panel
    Friend WithEvents mnHelp As New System.Windows.Forms.MenuItem
    Friend WithEvents mnAbout As New System.Windows.Forms.MenuItem
    Friend WithEvents mnEffects As New System.Windows.Forms.MenuItem
    Friend WithEvents mnNegativeColors As New System.Windows.Forms.MenuItem
    Friend WithEvents mnImageEdit As New System.Windows.Forms.MenuItem
    Friend WithEvents mnImageSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnFlipH As New System.Windows.Forms.MenuItem
    Friend WithEvents mnFlipV As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSaveFileTo As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMenu As New System.Windows.Forms.MenuItem
    Friend WithEvents mnAction As New System.Windows.Forms.MenuItem
    Friend WithEvents mnOptions As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents tmrFloatCursor As New System.Windows.Forms.Timer
    Friend WithEvents mnPaintMove As New System.Windows.Forms.MenuItem
    Public WithEvents Menus As New System.Windows.Forms.MainMenu
    Friend WithEvents pPencilMode As New System.Windows.Forms.PictureBox
    Friend WithEvents imgPencils As New System.Windows.Forms.ImageList
    Friend WithEvents mnFloatingCursorSpeed As New System.Windows.Forms.MenuItem
    Friend WithEvents mnFloatingCursorSpeedVerySlow As New System.Windows.Forms.MenuItem
    Friend WithEvents mnFloatingCursorSpeedSlow As New System.Windows.Forms.MenuItem
    Friend WithEvents mnFloatingCursorSpeedMedium As New System.Windows.Forms.MenuItem
    Friend WithEvents mnFloatingCursorSpeedFast As New System.Windows.Forms.MenuItem
    Friend WithEvents mnFloatingCursorSpeedVeryFast As New System.Windows.Forms.MenuItem
    Friend WithEvents imgCursors As New System.Windows.Forms.ImageList
    Friend WithEvents mnCursorStyle As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCursorStyleBlackWhite As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCursorStyleBlackWhiteRev As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCursorStyleBlackYelBlCr As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCursorStyleBlackBlSCr As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSelection As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSelectionNew As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSelectionSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSelectionCopy As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSelectionClear As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSelectionPaste As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSelectionFill As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSelectionSeperator2 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDrawText As New System.Windows.Forms.MenuItem
    Friend WithEvents mnNewFile As New System.Windows.Forms.MenuItem
    Friend WithEvents mnLicence As New System.Windows.Forms.MenuItem
    Friend WithEvents mnImageResize As New System.Windows.Forms.MenuItem
    Friend WithEvents mnImageEditSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnBlackAndWhite As New System.Windows.Forms.MenuItem
    Friend WithEvents mnLightness As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSelectionNewCopy As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDrawRectangle As New System.Windows.Forms.MenuItem
    Friend WithEvents mnImagePaperSize As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDrawPoly As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDrawEllipse As New System.Windows.Forms.MenuItem
    Friend WithEvents mnImportFile As New System.Windows.Forms.MenuItem
    Friend WithEvents mnImageSeperator2 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnImportActual As New System.Windows.Forms.MenuItem
    Friend WithEvents mnImportIntoSelection As New System.Windows.Forms.MenuItem
    Friend WithEvents mnZoom As New System.Windows.Forms.MenuItem
    Friend WithEvents mnZoom10 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnZoom20 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnZoom30 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnZoom40 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnZoom50 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnZoom60 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnZoom70 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnZoom80 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnZoom90 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnZoom5 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnExit As New System.Windows.Forms.MenuItem
    Friend WithEvents mnLowLvUndo As New System.Windows.Forms.MenuItem
    Friend WithEvents tmrDoubleClickOnImage As New System.Windows.Forms.Timer
    Friend WithEvents pMouseClickEvents As New System.Windows.Forms.PictureBox
    Friend WithEvents pZoom As New System.Windows.Forms.PictureBox
    Friend WithEvents ppZoom As New System.Windows.Forms.PictureBox
    Friend WithEvents mnAllowDoubleClicks As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDefaultExplDir As New System.Windows.Forms.MenuItem
    Friend WithEvents mnExplDirPrompt As New System.Windows.Forms.MenuItem
    Friend WithEvents mnExplDirPC As New System.Windows.Forms.MenuItem
    Friend WithEvents mnExplDirCurrent As New System.Windows.Forms.MenuItem
    Friend WithEvents mnExplDirMyDocs As New System.Windows.Forms.MenuItem



    Shared Sub Main(ByVal CmdArgs() As String) 'MAIN sub for application
        'The following help find if the command arguments contain any path string. The last path string found will be loaded as an image.
        Dim filepath As String = ""
        Dim NewPath As String
        Dim fullpath As String = ""
        If CmdArgs.Length > 0 Then
            Dim i
            For i = 0 To (CmdArgs.Length - 1)
                Try
                    If i = 0 Then
                        fullpath &= CmdArgs(i)
                    Else
                        fullpath &= " " & CmdArgs(i)
                    End If
                    NewPath = Path.GetFileName(CmdArgs(i)) 'If finally the command argument was a path...
                    filepath = CmdArgs(i)
                Catch

                End Try
            Next
            Try
                NewPath = Path.GetFileName(fullpath) 'If finally the command argument was a path...
                filepath = fullpath
            Catch

            End Try
        End If
        NewPath = Nothing
        fullpath = Nothing
        'End of path finding process

        System.Windows.Forms.Application.Run(New frmMain(filepath))
        filepath = Nothing
    End Sub

    Public Sub New(Optional ByVal strFileToOpenOnStart As String = "")
        MyBase.New()
        Init()
        If Not strFileToOpenOnStart = "" Then
            Try
                MakeUndo()
                Dim btmOpenedImage As New Bitmap(strFileToOpenOnStart)
                pImage.Size = btmOpenedImage.Size
                pImage.Image = btmOpenedImage
                CenterImage()
                CenterCursor()
            Catch ex As Exception
                System.Windows.Forms.MessageBox.Show("The file you pointed at wasn't successfully loaded. Please, verify that the file is an image.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            End Try
        End If
    End Sub

    Private Sub LoadUpResources()
        Dim iStream As Stream = System.Reflection.Assembly.GetExecutingAssembly.GetManifestResourceStream(System.Reflection.Assembly.GetExecutingAssembly.GetManifestResourceNames(0))
        Dim rr As New System.Resources.ResourceReader(iStream)
        Dim id As IDictionaryEnumerator = rr.GetEnumerator()
        While id.MoveNext()
            hResources.Add(id.Key, id.Value)
        End While
    End Sub

    Sub Init()
        PlatformType = LoadPlatformType()
        LabelFont = New System.Drawing.Font("Nina", 9.0!, System.Drawing.FontStyle.Bold)
        Dim WorkingHeight As Integer = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height
        Dim WorkingWidth As Integer = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width
        If Not LCase(PlatformType).IndexOf(LCase("PocketPC")) = -1 Or LCase(PlatformType).IndexOf(LCase("WindowsCE")) = -1 Then
            WorkingHeight = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height - System.Windows.Forms.SystemInformation.MenuHeight
        End If
        If Not LCase(PlatformType).IndexOf(LCase("WindowsPC")) = -1 Then
            WorkingHeight = 400
            WorkingWidth = 300
            LabelFont = New System.Drawing.Font("Nina", 8.0!, System.Drawing.FontStyle.Regular)
        End If
        WorkingSize = New Size(WorkingWidth, WorkingHeight)
        LoadUpResources()

        Me.Location = New Point(0, 0)
        Me.Size = New Size(WorkingWidth, WorkingHeight)

        Menus.MenuItems.Add(mnAction)
        Menus.MenuItems.Add(mnMenu)

        mnAction.Text = "Undo"

        mnMenu.MenuItems.Add(mnDraw)
        mnMenu.MenuItems.Add(mnEffects)
        mnMenu.MenuItems.Add(mnImage)
        mnMenu.MenuItems.Add(mnSelection)
        mnMenu.MenuItems.Add(mnSeperator1)
        mnMenu.MenuItems.Add(mnOptions)
        mnMenu.MenuItems.Add(mnHelp)
        mnMenu.MenuItems.Add(mnExit)
        mnMenu.Text = "Menu"

        mnDraw.MenuItems.Add(mnDrawLine)
        mnDraw.MenuItems.Add(mnDrawRectangle)
        mnDraw.MenuItems.Add(mnDrawEllipse)
        mnDraw.MenuItems.Add(mnDrawPoly)
        mnDraw.MenuItems.Add(mnDrawText)
        mnDraw.MenuItems.Add(mnDrawSeperator1)
        mnDraw.MenuItems.Add(mnPaintColor)
        mnDraw.Text = "Draw"

        mnDrawLine.Text = "Line..."

        mnDrawRectangle.Enabled = False
        mnDrawRectangle.Text = "Rectangle..."

        mnDrawEllipse.Enabled = False
        mnDrawEllipse.Text = "Ellipse..."

        mnDrawPoly.Text = "Polygon..."

        mnDrawText.Text = "Text..."

        mnDrawSeperator1.Text = "-"

        mnPaintColor.Text = "Paint Color..."

        mnEffects.MenuItems.Add(mnNegativeColors)
        mnEffects.MenuItems.Add(mnBlackAndWhite)
        mnEffects.MenuItems.Add(mnLightness)
        mnEffects.Text = "Effects"

        mnNegativeColors.Text = "Negative Colors"

        mnBlackAndWhite.Text = "Black and White"

        mnLightness.Text = "Lightness..."

        mnImage.MenuItems.Add(mnImageEdit)
        mnImage.MenuItems.Add(mnImageSeperator1)
        mnImage.MenuItems.Add(mnImportFile)
        mnImage.MenuItems.Add(mnImageSeperator2)
        mnImage.MenuItems.Add(mnNewFile)
        mnImage.MenuItems.Add(mnOpenFile)
        mnImage.MenuItems.Add(mnSaveFileTo)
        mnImage.MenuItems.Add(mnShowDimensions)
        mnImage.Text = "Image"

        mnImageEdit.MenuItems.Add(mnFlipH)
        mnImageEdit.MenuItems.Add(mnFlipV)
        mnImageEdit.MenuItems.Add(mnImageEditSeperator1)
        mnImageEdit.MenuItems.Add(mnImageResize)
        mnImageEdit.MenuItems.Add(mnImagePaperSize)
        mnImageEdit.Text = "Edit"

        mnFlipH.Text = "Flip Horizontally"

        mnFlipV.Text = "Flip Vertically"

        mnImageEditSeperator1.Text = "-"

        mnImageResize.Text = "Resize..."

        mnImagePaperSize.Text = "Paper Size..."

        mnImageSeperator1.Text = "-"

        mnImportFile.MenuItems.Add(mnImportActual)
        mnImportFile.MenuItems.Add(mnImportIntoSelection)
        mnImportFile.Text = "Import File"

        mnImportActual.Text = "Actual size..."

        mnImportIntoSelection.Enabled = False
        mnImportIntoSelection.Text = "Inside selection..."

        mnImageSeperator2.Text = "-"

        mnNewFile.Text = "New File..."

        mnOpenFile.Text = "Open File..."

        mnSaveFileTo.Text = "Save File To..."

        mnShowDimensions.Text = "Show Dimensions"

        mnSelection.MenuItems.Add(mnSelectionNew)
        mnSelection.MenuItems.Add(mnSelectionNewCopy)
        mnSelection.MenuItems.Add(mnSelectionClear)
        mnSelection.MenuItems.Add(mnSelectionSeperator1)
        mnSelection.MenuItems.Add(mnSelectionCopy)
        mnSelection.MenuItems.Add(mnSelectionPaste)
        mnSelection.MenuItems.Add(mnSelectionSeperator2)
        mnSelection.MenuItems.Add(mnSelectionFill)
        mnSelection.Text = "Selection"

        mnSelectionNew.Text = "New"

        mnSelectionNewCopy.Text = "New from Copy"

        mnSelectionClear.Enabled = False
        mnSelectionClear.Text = "Clear Selection"

        mnSelectionSeperator1.Text = "-"

        mnSelectionCopy.Enabled = False
        mnSelectionCopy.Text = "Copy"

        mnSelectionPaste.Enabled = False
        mnSelectionPaste.Text = "Paste"

        mnSelectionSeperator2.Text = "-"

        mnSelectionFill.Enabled = False
        mnSelectionFill.Text = "Fill..."

        mnSeperator1.Text = "-"

        mnOptions.MenuItems.Add(mnFloatingCursorSpeed)
        mnOptions.MenuItems.Add(mnCursorStyle)
        mnOptions.MenuItems.Add(mnDefaultExplDir)
        mnOptions.MenuItems.Add(mnZoom)
        mnOptions.MenuItems.Add(mnLowLvUndo)
        mnOptions.MenuItems.Add(mnPaintMove)
        If LCase(PlatformType).IndexOf(LCase("Smartphone")) = -1 Then
            mnOptions.MenuItems.Add(mnAllowDoubleClicks)
        End If
        mnOptions.Text = "Options"

        mnFloatingCursorSpeed.MenuItems.Add(mnFloatingCursorSpeedVerySlow)
        mnFloatingCursorSpeed.MenuItems.Add(mnFloatingCursorSpeedSlow)
        mnFloatingCursorSpeed.MenuItems.Add(mnFloatingCursorSpeedMedium)
        mnFloatingCursorSpeed.MenuItems.Add(mnFloatingCursorSpeedFast)
        mnFloatingCursorSpeed.MenuItems.Add(mnFloatingCursorSpeedVeryFast)
        mnFloatingCursorSpeed.Text = "Floating Cursor speed"

        mnFloatingCursorSpeedVerySlow.Text = "Very Slow"

        mnFloatingCursorSpeedSlow.Text = "Slow"

        mnFloatingCursorSpeedMedium.Text = "Medium"

        mnFloatingCursorSpeedFast.Text = "Fast"

        mnFloatingCursorSpeedVeryFast.Checked = True
        mnFloatingCursorSpeedVeryFast.Text = "Very Fast"

        mnCursorStyle.MenuItems.Add(mnCursorStyleBlackWhite)
        mnCursorStyle.MenuItems.Add(mnCursorStyleBlackWhiteRev)
        mnCursorStyle.MenuItems.Add(mnCursorStyleBlackYelBlCr)
        mnCursorStyle.MenuItems.Add(mnCursorStyleBlackBlSCr)
        mnCursorStyle.Text = "Cursor Style"

        mnCursorStyleBlackWhite.Checked = True
        mnCursorStyleBlackWhite.Text = "Black&&White"

        mnCursorStyleBlackWhiteRev.Text = "Black&&White (reversed)"

        mnCursorStyleBlackYelBlCr.Text = "Yellow && blue cross"

        mnCursorStyleBlackBlSCr.Text = "Black small cross"

        mnDefaultExplDir.Text = "Default Explorer Dir"
        mnDefaultExplDir.MenuItems.Add(mnExplDirPrompt)
        mnDefaultExplDir.MenuItems.Add(mnExplDirPC)
        mnDefaultExplDir.MenuItems.Add(mnExplDirMyDocs)
        mnDefaultExplDir.MenuItems.Add(mnExplDirCurrent)

        mnExplDirPrompt.text = "Prompt"
        mnExplDirPC.Text = "Device Root"
        mnExplDirCurrent.Text = "Current Directory"
        mnExplDirMyDocs.Text = "My Documents"
        If Not LCase(PlatformType).IndexOf(LCase("WindowsPC")) = -1 Then
            mnExplDirPrompt.Checked = True
            DefaultExplorerDir = "Prompt"
        Else
            mnExplDirMyDocs.Checked = True
            DefaultExplorerDir = "MyDocuments"
        End If

        mnZoom.MenuItems.Add(mnZoom5)
        mnZoom.MenuItems.Add(mnZoom10)
        mnZoom.MenuItems.Add(mnZoom20)
        mnZoom.MenuItems.Add(mnZoom30)
        mnZoom.MenuItems.Add(mnZoom40)
        mnZoom.MenuItems.Add(mnZoom50)
        mnZoom.MenuItems.Add(mnZoom60)
        mnZoom.MenuItems.Add(mnZoom70)
        mnZoom.MenuItems.Add(mnZoom80)
        mnZoom.MenuItems.Add(mnZoom90)
        mnZoom.Text = "Zoom"

        mnZoom5.Text = "5x5 pixels"

        mnZoom10.Text = "10x10 pixels"

        mnZoom20.Checked = True
        mnZoom20.Text = "20x20 pixels"

        mnZoom30.Text = "30x30 pixels"

        mnZoom40.Text = "40x40 pixels"

        mnZoom50.Text = "50x50 pixels"

        mnZoom60.Text = "60x60 pixels"

        mnZoom70.Text = "70x70 pixels"

        mnZoom80.Text = "80x80 pixels"

        mnZoom90.Text = "90x90 pixels"

        mnPaintMove.Text = "Paint when moving"

        mnAllowDoubleClicks.Text = "Allow Double Clicking"
        mnAllowDoubleClicks.Checked = True

        mnHelp.MenuItems.Add(mnAbout)
        mnHelp.MenuItems.Add(mnLicence)
        mnHelp.Text = "Help"

        mnAbout.Text = "About..."

        mnLicence.Text = "Licence..."

        mnExit.Text = "Exit"

        pImage.Image = CType(hResources("IntroImage"), System.Drawing.Image)
        pImage.Location = New System.Drawing.Point(28, 26)
        pImage.Size = New System.Drawing.Size(120, 120)
        pImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage

        pCursor.Image = CType(hResources("Cursor1"), System.Drawing.Image)
        pCursor.Location = New System.Drawing.Point(86, 82)
        pCursor.Size = New System.Drawing.Size(5, 5)
        pCursor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage

        VScroll.Maximum = 90
        VScroll.Size = New System.Drawing.Size(7, WorkingHeight)
        VScroll.Location = New System.Drawing.Point(WorkingWidth - VScroll.Width, 0)

        HScroll.Maximum = 90
        HScroll.Size = New System.Drawing.Size(WorkingWidth - VScroll.Width, 7)
        HScroll.Location = New System.Drawing.Point(0, WorkingHeight - HScroll.Height)

        lblLocCur.Font = New System.Drawing.Font("Nina", 9.0!, System.Drawing.FontStyle.Regular)
        lblLocCur.Size = New System.Drawing.Size(WorkingWidth - VScroll.Width, 18)
        lblLocCur.Location = New System.Drawing.Point(0, WorkingHeight - HScroll.Height - lblLocCur.Height)
        lblLocCur.Text = "X: 0, Y: 0, Step: 3"

        pBgImg.Image = CType(hResources("GrayBackground"), System.Drawing.Image)
        pBgImg.Location = New System.Drawing.Point(0, 0)
        pBgImg.Size = New System.Drawing.Size(WorkingWidth, WorkingHeight)
        'Process for tiling Background Image
        If pBgImg.Image.Width < pBgImg.Width Then
            Dim TimesToTile As Integer = CInt(pBgImg.Width / pBgImg.Image.Width) + 1
            Dim NewImage As New Bitmap(pBgImg.Image.Width * TimesToTile, pBgImg.Image.Height)
            Dim g As Graphics = Graphics.FromImage(NewImage)
            Dim i As Integer
            For i = 0 To (TimesToTile - 1)
                g.DrawImage(pBgImg.Image, pBgImg.Image.Width * i, 0)
            Next
            i = Nothing
            TimesToTile = Nothing
            g = Nothing
            pBgImg.Image = New Bitmap(NewImage)
            NewImage = Nothing
        End If
        If pBgImg.Image.Height < pBgImg.Height Then
            Dim TimesToTile As Integer = CInt(pBgImg.Height / pBgImg.Image.Height) + 1
            Dim NewImage As New Bitmap(pBgImg.Image.Width, pBgImg.Image.Height * TimesToTile)
            Dim g As Graphics = Graphics.FromImage(NewImage)
            Dim i As Integer
            For i = 0 To (TimesToTile - 1)
                g.DrawImage(pBgImg.Image, 0, pBgImg.Image.Height * i)
            Next
            i = Nothing
            TimesToTile = Nothing
            g = Nothing
            pBgImg.Image = New Bitmap(NewImage)
            NewImage = Nothing
        End If
        'End Tiling background image

        pPaintSize.BackColor = System.Drawing.Color.Black
        pPaintSize.Size = New System.Drawing.Size(3, 3)
        pPaintSize.Location = New System.Drawing.Point(lblLocCur.Right - 10, CInt(lblLocCur.Bottom - (lblLocCur.Height / 2) - (pPaintSize.Height / 2)))

        imgPencils.Images.Add(CType(hResources("Pencil_Plain"), System.Drawing.Image))
        imgPencils.Images.Add(CType(hResources("Pencil_Write"), System.Drawing.Image))
        imgPencils.Images.Add(CType(hResources("Pencil_Accelarated"), System.Drawing.Image))
        imgPencils.Images.Add(CType(hResources("Pencil_AccelaratedWrite"), System.Drawing.Image))
        imgPencils.ImageSize = New System.Drawing.Size(17, 13)

        pPaintColor.BackColor = System.Drawing.Color.White
        pPaintColor.Size = New System.Drawing.Size(8, 8)
        pPaintColor.Location = New System.Drawing.Point(pPaintSize.Left - 17, CInt(lblLocCur.Bottom - (lblLocCur.Height / 2) - (pPaintColor.Height / 2)))

        pnlColor1Bg.BackColor = System.Drawing.Color.Black
        pnlColor1Bg.Size = New System.Drawing.Size(pPaintColor.Width + 2, pPaintColor.Height + 2)
        pnlColor1Bg.Location = New System.Drawing.Point(pPaintColor.Left - 1, pPaintColor.Top - 1)

        tmrFloatCursor.Interval = 50

        pPencilMode.Size = imgPencils.ImageSize
        pPencilMode.Location = New System.Drawing.Point(pnlColor1Bg.Left - 20, CInt(lblLocCur.Bottom - (lblLocCur.Height / 2) - (pPencilMode.Height / 2)))

        pMouseClickEvents.Image = CType(hResources("MouseClickEvents"), System.Drawing.Image)
        pMouseClickEvents.Size = pMouseClickEvents.Image.Size
        pMouseClickEvents.Location = New System.Drawing.Point(pPencilMode.Left - pMouseClickEvents.Width - 4, CInt(lblLocCur.Bottom - (lblLocCur.Height / 2) - (pMouseClickEvents.Height / 2)))

        ppZoom.Image = CType(hResources("UnZoom"), System.Drawing.Image)
        ppZoom.Size = ppZoom.Image.Size
        ppZoom.Location = New System.Drawing.Point(pMouseClickEvents.left - ppZoom.Width - 4, CInt(lblLocCur.Bottom - (lblLocCur.Height / 2) - (ppZoom.Height / 2)))

        imgCursors.Images.Add(CType(hResources("Cursor1"), System.Drawing.Image))
        imgCursors.Images.Add(CType(hResources("Cursor2"), System.Drawing.Image))
        imgCursors.Images.Add(CType(hResources("Cursor3"), System.Drawing.Image))
        imgCursors.Images.Add(CType(hResources("Cursor4"), System.Drawing.Image))
        imgCursors.ImageSize = New System.Drawing.Size(5, 5)

        pZoom.Location = New System.Drawing.Point(154, 132)
        pZoom.Size = New System.Drawing.Size(11, 12)
        pZoom.Visible = False

        If Not LCase(PlatformType).IndexOf(LCase("WindowsPC")) = -1 Then
            mnLowLvUndo.Checked = False
        Else
            mnLowLvUndo.Checked = True
        End If
        mnLowLvUndo.Text = "Low level undo"

        tmrDoubleClickOnImage.Enabled = False
        tmrDoubleClickOnImage.Interval = APICalls.DoubleClickTime()

        Me.BackColor = System.Drawing.Color.Gainsboro
        'Me.ClientSize = New System.Drawing.Size(176, 467)
        'MessageBox.Show(PlatformType)
        If LCase(PlatformType).IndexOf(LCase("SmartPhone")) = -1 Then
            Me.Controls.Add(ppZoom)
            Me.Controls.Add(pMouseClickEvents)
        Else
            ppZoom = Nothing
            pMouseClickEvents = Nothing
        End If
        Me.Controls.Add(pPencilMode)
        Me.Controls.Add(pPaintSize)
        Me.Controls.Add(pPaintColor)
        Me.Controls.Add(pnlColor1Bg)
        Me.Controls.Add(VScroll)
        Me.Controls.Add(HScroll)
        Me.Controls.Add(pZoom)
        Me.Controls.Add(pCursor)
        Me.Controls.Add(lblLocCur)
        Me.Controls.Add(pImage)
        Me.Controls.Add(pBgImg)
        Me.Icon = CType(hResources("ProgramIcon16"), System.Drawing.Icon)
        Me.Text = "Pocket Image Editor"
        Me.MaximizeBox = False
        Me.WindowState = FormWindowState.Normal
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        If Not LCase(PlatformType).IndexOf(LCase("WindowsPC")) = -1 Then
            Me.ClientSize = New Size(WorkingSize.Width, WorkingSize.Height)
        End If
        Me.Menu = Menus

    End Sub




    Private Sub frmMain_LostFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.LostFocus
        Me.Focus()
    End Sub

    Private Sub frmMain_Closed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        Try
            SaveOptions()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Me.Size = New Size(182, 235)
        'Me.Size = New Size(System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height)
        frmHeight = lblLocCur.Top
        frmWidth = WorkingSize.Width - VScroll.Width
        'Dim emptybmp As Bitmap = New Bitmap(120, 120)
        'pImage.Size = emptybmp.Size
        'pImage.Image = emptybmp
        CenterImage()
        CenterCursor()
        Paint1Color = pPaintColor.BackColor
        PaintSize = pPaintSize.Size
        pPaintSizeFirstMiddlePoint = New Point(pPaintSize.Left + (pPaintSize.Width / 2), pPaintSize.Top + (pPaintSize.Height / 2))
        MakeUndo()
        ShowPencilModeIcon()
        pZoom.Width = frmWidth
        pZoom.Height = frmHeight
        pZoom.Location = New Point(0, 0)
        mnFloatingCursorSpeedMedium_Click(Me, EventArgs.Empty)
        Me.Refresh()
        Me.Show()
        Me.Focus()
        Me.Menu = Nothing 'Refresh Menus
        Me.Menu = Menus
        LoadOptions()
    End Sub

    Private Sub frmMain_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        'If Not LCase(PlatformType).IndexOf(LCase("WindowsPC")) = -1 Then
        Select Case e.KeyValue
            Case 13 'action 'Draw Pixel
                FloatingCursor = False
                If isEditSession Then
                    If EditPoint1.IsEmpty Then
                        EditPoint1.X = LocX - 1
                        EditPoint1.Y = LocY - 1
                    ElseIf EditPoint2.IsEmpty And Not (EditPoint1.X = LocX - 1) And Not (EditPoint1.Y = LocY - 1) Then
                        EditPoint2.X = LocX - 1
                        EditPoint2.Y = LocY - 1
                    End If
                Else
                    PaintCurrent()
                End If
            Case 49 '1
                CursorStep -= 1 'Reduce Cursor Step
                If CursorStep <= 0 Then
                    CursorStep += 1
                End If
                UpdateLocCur()
            Case 50 '2
                CursorStep += 1 'Enlarge Cursor step
                If CursorStep >= ((frmWidth / 2) + 1) Or CursorStep >= ((frmHeight / 2) + 1) Then
                    CursorStep -= 1
                End If
                UpdateLocCur()
            Case 51 '3
                If pCursor.Visible = True Then 'Toggle Cursor visibility
                    pCursor.Visible = False
                Else
                    pCursor.Visible = True
                End If
            Case 52 '4 'Decrease PaintSize
                PaintSize.Height -= 2
                PaintSize.Width = PaintSize.Height
                If PaintSize.Height < 1 Then
                    PaintSize.Height = 9
                    PaintSize.Width = PaintSize.Height
                End If
                pPaintSize.Size = PaintSize
                CenterpPaintSize()
            Case 53 '5 'Increase PaintSize
                PaintSize.Height += 2
                PaintSize.Width = PaintSize.Height
                If PaintSize.Height > 10 Then
                    PaintSize.Height = 1
                    PaintSize.Width = PaintSize.Height
                End If
                pPaintSize.Size = PaintSize
                CenterpPaintSize()
            Case 54 '6 'Toggles floating cursor
                If FloatingCursor Then
                    FloatingCursor = False
                Else
                    FloatingCursorT = True
                End If
            Case 55 '7 'Changes 'Paint When Move'
                mnPaintMove_Click(Me, EventArgs.Empty)
            Case 56 '8 'Toggles Zoom
                ToggleZoom()
            Case 57 '9
                FloatingCursor = False
            Case 119 '*
                FloatingCursor = False
            Case 48 '0
                FloatingCursor = False
            Case 120 '#
                Try
                    Me.DialogResult = DialogResult.OK
                Catch

                End Try
                FloatingCursor = False
            Case 37
                navKeyLastPressed = e.KeyValue
            Case 38
                navKeyLastPressed = e.KeyValue
            Case 39
                navKeyLastPressed = e.KeyValue
            Case 40
                navKeyLastPressed = e.KeyValue
            Case 65 'PCs: A
                frmMain_KeyDown(Me, New KeyEventArgs(37))
            Case 87 'PCs: W
                frmMain_KeyDown(Me, New KeyEventArgs(38))
            Case 68 'PCs: D
                frmMain_KeyDown(Me, New KeyEventArgs(39))
            Case 83 'PCs: S
                frmMain_KeyDown(Me, New KeyEventArgs(40))
            Case 32 'PCs: Space
                frmMain_KeyDown(Me, New KeyEventArgs(13))
            Case 84 'PCs: T
                frmMain_KeyDown(Me, New KeyEventArgs(49))
            Case 89 'PCs: Y
                frmMain_KeyDown(Me, New KeyEventArgs(50))
            Case 85 'PCs: U
                frmMain_KeyDown(Me, New KeyEventArgs(51))
            Case 71 'PCs: G
                frmMain_KeyDown(Me, New KeyEventArgs(52))
            Case 72 'PCs: H
                frmMain_KeyDown(Me, New KeyEventArgs(53))
            Case 74 'PCs: J
                frmMain_KeyDown(Me, New KeyEventArgs(54))
            Case 66 'PCs: B
                frmMain_KeyDown(Me, New KeyEventArgs(55))
            Case 78 'PCs: N
                frmMain_KeyDown(Me, New KeyEventArgs(56))
            Case 77 'PCs: M
                frmMain_KeyDown(Me, New KeyEventArgs(57))
            Case 73 'PCs: I
                frmMain_KeyDown(Me, New KeyEventArgs(119))
            Case 75 'PCs: K
                frmMain_KeyDown(Me, New KeyEventArgs(120))
            Case 188 'PCs: ,
                frmMain_KeyDown(Me, New KeyEventArgs(48))
        End Select

        MoveCursor(e.KeyValue) 'For left-right-up-down keys
    End Sub




    Private Sub mnDrawEllipse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDrawEllipse.Click 'Draw Ellipse
        If isEditSession And Not EditPoint1.IsEmpty Then
            Dim nn As New frmBasicShapeDrawProperties
            Dim attr As New Hashtable
            If nn.ShowDialog = DialogResult.OK Then
                attr.Add("Border", nn.BorderWidth)
                attr.Add("BorderColor", nn.BorderColor)
                attr.Add("isFill", nn.isFill)
                attr.Add("FillColor", nn.FillColor)
                attr.Add("isTransparent", nn.isTransparent)
                attr.Add("TranspPercent", nn.TranspPercent)
                attr.Add("hasShadow", nn.hasShadow)
                attr.Add("ShadowLevels", nn.ShadowLevels)
                attr.Add("ShadowColor", nn.ShadowColor)
                MakeUndo()
                PreEditImageBackup = ImageEditingFunctions.DrawEllipse(PreEditImageBackup, EditRectangle, attr)
                mnSelectionClear_Click(Me, EventArgs.Empty)
            End If
        End If
    End Sub

    Private Sub mnDrawPoly_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDrawPoly.Click 'Draw Polygon
        Dim nP As New frmGetPoints
        nP.Image2Show = GetImageEdited()
        nP.NumPoints = 5
        nP.AllowCustomNumber = True
        Dim nn As New frmBasicShapeDrawProperties
        nn.ImageEdited = GetImageEdited()

        If nP.ShowDialog = DialogResult.OK Then
            If nn.ShowDialog = DialogResult.OK Then
                Dim attr As New Hashtable
                Dim i As Integer
                attr.Add("Border", nn.BorderWidth)
                attr.Add("BorderColor", nn.BorderColor)
                attr.Add("isFill", nn.isFill)
                attr.Add("FillColor", nn.FillColor)
                attr.Add("isTransparent", nn.isTransparent)
                attr.Add("TranspPercent", nn.TranspPercent)
                attr.Add("hasShadow", nn.hasShadow)
                attr.Add("ShadowLevels", nn.ShadowLevels)
                attr.Add("ShadowColor", nn.ShadowColor)
                Dim pop(nP.NumPoints) As Point
                For i = 0 To nP.NumPoints
                    If i = nP.NumPoints Then
                        pop.SetValue(nP.PointsSelected(nP.NumPoints - 1), i)
                    Else
                        pop.SetValue(nP.PointsSelected(i), i)
                    End If
                Next
                MakeUndo()
                pImage.Image = ImageEditingFunctions.DrawPolygon(pImage.Image, pop, attr)
                attr = Nothing
                pop = Nothing
                i = Nothing
            End If
        End If

        nP = Nothing
        nn = Nothing
    End Sub

    Private Sub mnDrawRectangle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDrawRectangle.Click 'Draw Rectangle
        If isEditSession And Not EditPoint1.IsEmpty Then
            Dim nn As New frmBasicShapeDrawProperties
            Dim attr As New Hashtable
            If nn.ShowDialog = DialogResult.OK Then
                attr.Add("Border", nn.BorderWidth)
                attr.Add("BorderColor", nn.BorderColor)
                attr.Add("isFill", nn.isFill)
                attr.Add("FillColor", nn.FillColor)
                attr.Add("isTransparent", nn.isTransparent)
                attr.Add("TranspPercent", nn.TranspPercent)
                attr.Add("hasShadow", nn.hasShadow)
                attr.Add("ShadowLevels", nn.ShadowLevels)
                attr.Add("ShadowColor", nn.ShadowColor)
                MakeUndo()
                PreEditImageBackup = ImageEditingFunctions.DrawRectangle(PreEditImageBackup, EditRectangle, attr)
                mnSelectionClear_Click(Me, EventArgs.Empty)
            End If
        End If
    End Sub

    Private Sub mnDrawText_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDrawText.Click 'Generate Text
        Dim nFont As New frmGenerateText
        nFont.Image2Show = pImage.Image
        If isEditSession And Not EditPoint1.IsEmpty Then
            nFont.UseRectangle = True
            nFont.Rectangle2Use = EditRectangle
        End If
        If nFont.ShowDialog = DialogResult.OK Then
            MakeUndo()
            If isEditSession Then
                PreEditImageBackup = ImageEditingFunctions.pDrawString(PreEditImageBackup, nFont.TextCommands)
                mnSelectionClear_Click(Me, EventArgs.Empty)
            Else
                pImage.Image = ImageEditingFunctions.pDrawString(pImage.Image, nFont.TextCommands)
            End If
        End If
    End Sub

    Private Sub mnDrawLine_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDrawLine.Click 'Draw Line
        Dim nLine As New frmGenerateLine
        If isEditSession Then
            nLine.ImageEdited = PreEditImageBackup
        Else
            nLine.ImageEdited = pImage.Image
        End If
        nLine.ImageEdited = pImage.Image
        nLine.ChosenColor = Paint1Color
        If nLine.ShowDialog = DialogResult.OK Then
            MakeUndo()
            pImage.Image = ImageEditingFunctions.pDrawLine(pImage.Image, nLine.LineCommands)
        End If
        nLine = Nothing
    End Sub

    Private Sub mnPaintColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnPaintColor.Click 'Paint COlor
        Dim fPaintColor As New frmColorPicker
        If isEditSession Then
            fPaintColor.ImageForPick = PreEditImageBackup
        Else
            fPaintColor.ImageForPick = pImage.Image
        End If
        If fPaintColor.ShowDialog = DialogResult.OK Then
            Paint1Color = fPaintColor.pChosenColor.BackColor
            pPaintColor.BackColor = Paint1Color
        End If
        fPaintColor = Nothing
    End Sub



    Private Sub mnNegativeColors_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnNegativeColors.Click 'Negative Colors
        MakeUndo()
        If isEditSession And Not EditPoint1.IsEmpty Then
            PreEditImageBackup = ImageEditingFunctions.GetNegativeColorsImage(PreEditImageBackup, EditRectangle)
            mnSelectionClear_Click(Me, EventArgs.Empty)
        Else
            pImage.Image = ImageEditingFunctions.GetNegativeColorsImage(pImage.Image, New Rectangle(0, 0, pImage.Image.Width, pImage.Image.Height))
        End If
    End Sub

    Private Sub mnBlackAndWhite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnBlackAndWhite.Click 'Black & White
        MakeUndo()
        If isEditSession And Not EditPoint1.IsEmpty Then
            PreEditImageBackup = ImageEditingFunctions.GetBlackWhite(PreEditImageBackup, EditRectangle)
            mnSelectionClear_Click(Me, EventArgs.Empty)
        Else
            pImage.Image = ImageEditingFunctions.GetBlackWhite(pImage.Image, New Rectangle(0, 0, pImage.Image.Width, pImage.Image.Height))
        End If
    End Sub

    Private Sub mnLightness_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnLightness.Click 'Lightness...
        Dim inP As New InputDialog
        inP.AssignedValue = 0
        inP.Description = "Enter a number between -255 and 255 to adjust the lightness of the image. Negative values darken the image. Positive will lighten it. 0 will leave it as is."
        If inP.ShowDialog = DialogResult.OK Then
            If Not inP.AssignedValue = 0 And IsNumeric(inP.AssignedValue) Then
                MakeUndo()
                If isEditSession And Not EditPoint1.IsEmpty Then
                    PreEditImageBackup = ImageEditingFunctions.GetLightnessAdjusted(PreEditImageBackup, inP.AssignedValue, EditRectangle)
                    mnSelectionClear_Click(Me, EventArgs.Empty)
                Else
                    pImage.Image = ImageEditingFunctions.GetLightnessAdjusted(pImage.Image, inP.AssignedValue, New Rectangle(0, 0, pImage.Image.Width, pImage.Image.Height))
                End If
                inP = Nothing
            End If
        End If
    End Sub



    Private Sub mnImportActual_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnImportActual.Click 'Import File Actual Size
        Dim mOpenImg As New frmExplorer
        If mOpenImg.ShowDialog = DialogResult.OK Then
            Try
                MakeUndo()
                Dim btmOpenedImage As New Bitmap(mOpenImg.SelectedPath)
                Dim g As Graphics = Graphics.FromImage(pImage.Image)
                g.DrawImage(btmOpenedImage, LocX - 1, LocY - 1)
                g = Nothing
                btmOpenedImage = Nothing
            Catch ex As Exception
                System.Windows.Forms.MessageBox.Show("The file you pointed at wasn't successfully imported. Please, verify that the file is an image.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            End Try
        End If
        mOpenImg = Nothing
    End Sub

    Private Sub mnImportIntoSelection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnImportIntoSelection.Click 'Import File Inside Selection
        If isEditSession And Not EditPoint1.IsEmpty Then
            Dim mOpenImg As New frmExplorer
            If mOpenImg.ShowDialog = DialogResult.OK Then
                Try
                    MakeUndo()
                    Dim btmOpenedImage As New Bitmap(mOpenImg.SelectedPath)
                    Dim g As Graphics = Graphics.FromImage(PreEditImageBackup)
                    g.DrawImage(btmOpenedImage, EditRectangle, 0, 0, btmOpenedImage.Width, btmOpenedImage.Height, GraphicsUnit.Pixel, New System.Drawing.Imaging.ImageAttributes)
                    mnSelectionClear_Click(Me, EventArgs.Empty)
                    g = Nothing
                    btmOpenedImage = Nothing
                Catch ex As Exception
                    System.Windows.Forms.MessageBox.Show("The file you pointed at wasn't successfully imported. Please, verify that the file is an image.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                End Try
            End If
            mOpenImg = Nothing
        End If
    End Sub

    Private Sub mnNewFile_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnNewFile.Click 'New image
        Dim nIn As New InputDialog
        nIn.AssignedValue = "150x150"
        nIn.Description = "Enter the dimensions of the blank (white) image to be created. Format accepted is 'WidthxHeight'. An example is given."
        If nIn.ShowDialog = DialogResult.OK Then
            MakeUndo()
            Dim w As Integer = nIn.AssignedValue.Substring(0, nIn.AssignedValue.IndexOf("x"))
            Dim h As Integer = nIn.AssignedValue.Substring(nIn.AssignedValue.IndexOf("x") + 1)
            Dim tempBit As New Bitmap(w, h)
            Dim g As Graphics = Graphics.FromImage(tempBit)
            g.FillRectangle(New SolidBrush(Color.White), 0, 0, w, h)
            pImage.Image = tempBit
            pImage.Size = tempBit.Size
            CenterImage()
            CenterCursor()
            tempBit = Nothing
            g = Nothing
            w = Nothing
            h = Nothing
        End If
        nIn = Nothing
    End Sub

    Private Sub mnFlipH_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnFlipH.Click 'Flip horizontally
        MakeUndo()
        If isEditSession And Not EditPoint1.IsEmpty Then
            PreEditImageBackup = ImageEditingFunctions.GetFlippedImage(PreEditImageBackup, True, EditRectangle)
            mnSelectionClear_Click(Me, EventArgs.Empty)
        Else
            pImage.Image = ImageEditingFunctions.GetFlippedImage(pImage.Image, True, New Rectangle(0, 0, pImage.Image.Width, pImage.Image.Height))
        End If
    End Sub

    Private Sub mnFlipV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnFlipV.Click 'Flip Vertically
        MakeUndo()
        If isEditSession And Not EditPoint1.IsEmpty Then
            PreEditImageBackup = ImageEditingFunctions.GetFlippedImage(PreEditImageBackup, False, EditRectangle)
            mnSelectionClear_Click(Me, EventArgs.Empty)
        Else
            pImage.Image = ImageEditingFunctions.GetFlippedImage(pImage.Image, False, New Rectangle(0, 0, pImage.Image.Width, pImage.Image.Height))
        End If
    End Sub

    Private Sub mnOpenFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnOpenFile.Click 'Open File
        Dim mOpenImg As New frmExplorer
        If mOpenImg.ShowDialog = DialogResult.OK Then
            Try
                MakeUndo()
                Dim btmOpenedImage As New Bitmap(mOpenImg.SelectedPath)
                pImage.Size = btmOpenedImage.Size
                pImage.Image = btmOpenedImage
                CenterImage()
                CenterCursor()
            Catch ex As Exception
                System.Windows.Forms.MessageBox.Show("The file you pointed at wasn't successfully loaded. Please, verify that the file is an image.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            End Try
        End If
        mOpenImg = Nothing
    End Sub

    Private Sub mnSaveFileTo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSaveFileTo.Click 'Save Image To...
        Dim nGetFile As New frmFileSave
        If nGetFile.ShowDialog = DialogResult.OK Then
            SaveImageBMP.SaveImageToFile(GetImageEdited, nGetFile.FullFilePath)
        End If
        nGetFile = Nothing
    End Sub

    Private Sub mnShowDimensions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnShowDimensions.Click 'Show Dimensions
        System.Windows.Forms.MessageBox.Show("Width: " & pImage.Width & vbCrLf & "Height: " & pImage.Height, "Image Info", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1)
    End Sub

    Private Sub mnImageResize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnImageResize.Click 'Resize
        Dim nIn As New InputDialog
        nIn.AssignedValue = "100x100"
        nIn.Description = "Enter the dimensions of the blank (white) image to be created. Format accepted is 'WidthxHeight'. An example is given." & vbCrLf & "Advanced: To keep the aspect ratio (according to width), replace the 'x' with an 'r'." & vbCrLf & "Current Size: " & pImage.Image.Width & "x" & pImage.Image.Height
        If nIn.ShowDialog = DialogResult.OK Then
            MakeUndo()
            Try
                Dim wid As Integer
                Dim hei As Integer
                If nIn.AssignedValue.IndexOf("r") = -1 Then 'No aspect ratio
                    wid = nIn.AssignedValue.Substring(0, nIn.AssignedValue.IndexOf("x"))
                    hei = nIn.AssignedValue.Substring(nIn.AssignedValue.IndexOf("x") + 1)
                Else 'With Aspect Ratio
                    wid = nIn.AssignedValue.Substring(0, nIn.AssignedValue.IndexOf("r"))
                    hei = (wid / pImage.Image.Width) * pImage.Image.Height
                End If

                Dim nRes As New Bitmap(wid, hei)
                Dim g As Graphics = Graphics.FromImage(nRes)
                g.DrawImage(pImage.Image, New Rectangle(0, 0, nRes.Width, nRes.Height), New Rectangle(0, 0, pImage.Image.Width, pImage.Image.Height), GraphicsUnit.Pixel)
                pImage.Image = nRes
                pImage.Size = nRes.Size

                nRes = Nothing
                wid = Nothing
                hei = Nothing

                CenterImage()
                CenterCursor()
            Catch ex As Exception
                System.Windows.Forms.MessageBox.Show("Width: " & pImage.Width & vbCrLf & "Height: " & pImage.Height, "Image Info", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            End Try
        End If
        nIn = Nothing
    End Sub

    Private Sub mnImagePaperSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnImagePaperSize.Click 'Paper Size
        Dim wid As Integer = 100
        Dim hei As Integer = 100
        Dim bgcol As Color = Color.Black
        Dim ni As New InputDialog
        Dim imgBackup As New Bitmap(GetImageEdited)
        ni.AssignedValue = "100x100"
        ni.Description = "Enter the new dimensions of the paper. Format should be widthxheight. An example is given. The current dimensions are " & pImage.Image.Width & "x" & pImage.Image.Height & "."
        If ni.ShowDialog = DialogResult.OK Then
            If System.Windows.Forms.MessageBox.Show("The default paper (background) color is black. Would you like to change it for the paper editing?", "Info", System.Windows.Forms.MessageBoxButtons.YesNo, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1) = DialogResult.Yes Then
                Dim nc As New frmColorPicker
                nc.ImageForPick = GetImageEdited()
                If nc.ShowDialog = DialogResult.OK Then
                    bgcol = nc.SelectedColor
                End If
                nc = Nothing
            End If

            wid = ni.AssignedValue.Substring(0, ni.AssignedValue.IndexOf("x"))
            hei = ni.AssignedValue.Substring(ni.AssignedValue.IndexOf("x") + 1)
            pImage.Size = New Size(wid, hei)
            pImage.Image = New Bitmap(wid, hei)
            Dim g As Graphics = Graphics.FromImage(pImage.Image)
            g.FillRectangle(New SolidBrush(bgcol), 0, 0, wid, hei)
            g.DrawImage(imgBackup, wid / 2 - imgBackup.Width / 2, hei / 2 - imgBackup.Height / 2)
            g = Nothing
            CenterImage()
            CenterCursor()
        End If
        wid = Nothing
        hei = Nothing
        bgcol = Nothing
        ni = Nothing
        imgBackup = Nothing
    End Sub



    Private Sub mnZoom20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnZoom20.Click
        mnZoom10.Checked = False
        mnZoom20.Checked = False
        mnZoom30.Checked = False
        mnZoom40.Checked = False
        mnZoom50.Checked = False
        mnZoom60.Checked = False
        mnZoom70.Checked = False
        mnZoom80.Checked = False
        mnZoom90.Checked = False
        mnZoom5.Checked = False

        mnZoom20.Checked = True
        ZoomPixels = 20
        DoZoom()
    End Sub

    Private Sub mnZoom10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnZoom10.Click
        mnZoom10.Checked = False
        mnZoom20.Checked = False
        mnZoom30.Checked = False
        mnZoom40.Checked = False
        mnZoom50.Checked = False
        mnZoom60.Checked = False
        mnZoom70.Checked = False
        mnZoom80.Checked = False
        mnZoom90.Checked = False
        mnZoom5.Checked = False

        mnZoom10.Checked = True
        ZoomPixels = 10
        DoZoom()
    End Sub

    Private Sub mnZoom5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnZoom5.Click
        mnZoom10.Checked = False
        mnZoom20.Checked = False
        mnZoom30.Checked = False
        mnZoom40.Checked = False
        mnZoom50.Checked = False
        mnZoom60.Checked = False
        mnZoom70.Checked = False
        mnZoom80.Checked = False
        mnZoom90.Checked = False
        mnZoom5.Checked = False

        mnZoom5.Checked = True
        ZoomPixels = 5
        DoZoom()
    End Sub

    Private Sub mnZoom30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnZoom30.Click
        mnZoom10.Checked = False
        mnZoom20.Checked = False
        mnZoom30.Checked = False
        mnZoom40.Checked = False
        mnZoom50.Checked = False
        mnZoom60.Checked = False
        mnZoom70.Checked = False
        mnZoom80.Checked = False
        mnZoom90.Checked = False
        mnZoom5.Checked = False

        mnZoom30.Checked = True
        ZoomPixels = 30
        DoZoom()
    End Sub

    Private Sub mnZoom40_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnZoom40.Click
        mnZoom10.Checked = False
        mnZoom20.Checked = False
        mnZoom30.Checked = False
        mnZoom40.Checked = False
        mnZoom50.Checked = False
        mnZoom60.Checked = False
        mnZoom70.Checked = False
        mnZoom80.Checked = False
        mnZoom90.Checked = False
        mnZoom5.Checked = False

        mnZoom40.Checked = True
        ZoomPixels = 40
        DoZoom()
    End Sub

    Private Sub mnZoom50_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnZoom50.Click
        mnZoom10.Checked = False
        mnZoom20.Checked = False
        mnZoom30.Checked = False
        mnZoom40.Checked = False
        mnZoom50.Checked = False
        mnZoom60.Checked = False
        mnZoom70.Checked = False
        mnZoom80.Checked = False
        mnZoom90.Checked = False
        mnZoom5.Checked = False

        mnZoom50.Checked = True
        ZoomPixels = 50
        DoZoom()
    End Sub

    Private Sub mnZoom60_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnZoom60.Click
        mnZoom10.Checked = False
        mnZoom20.Checked = False
        mnZoom30.Checked = False
        mnZoom40.Checked = False
        mnZoom50.Checked = False
        mnZoom60.Checked = False
        mnZoom70.Checked = False
        mnZoom80.Checked = False
        mnZoom90.Checked = False
        mnZoom5.Checked = False

        mnZoom60.Checked = True
        ZoomPixels = 60
        DoZoom()
    End Sub

    Private Sub mnZoom70_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnZoom70.Click
        mnZoom10.Checked = False
        mnZoom20.Checked = False
        mnZoom30.Checked = False
        mnZoom40.Checked = False
        mnZoom50.Checked = False
        mnZoom60.Checked = False
        mnZoom70.Checked = False
        mnZoom80.Checked = False
        mnZoom90.Checked = False
        mnZoom5.Checked = False

        mnZoom70.Checked = True
        ZoomPixels = 70
        DoZoom()
    End Sub

    Private Sub mnZoom80_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnZoom80.Click
        mnZoom10.Checked = False
        mnZoom20.Checked = False
        mnZoom30.Checked = False
        mnZoom40.Checked = False
        mnZoom50.Checked = False
        mnZoom60.Checked = False
        mnZoom70.Checked = False
        mnZoom80.Checked = False
        mnZoom90.Checked = False
        mnZoom5.Checked = False

        mnZoom80.Checked = True
        ZoomPixels = 80
        DoZoom()
    End Sub

    Private Sub mnZoom90_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnZoom90.Click
        mnZoom10.Checked = False
        mnZoom20.Checked = False
        mnZoom30.Checked = False
        mnZoom40.Checked = False
        mnZoom50.Checked = False
        mnZoom60.Checked = False
        mnZoom70.Checked = False
        mnZoom80.Checked = False
        mnZoom90.Checked = False
        mnZoom5.Checked = False

        mnZoom90.Checked = True
        ZoomPixels = 90
        DoZoom()
    End Sub

    Private Sub mnFloatingCursorSpeedVerySlow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnFloatingCursorSpeedVerySlow.Click
        mnFloatingCursorSpeedVerySlow.Checked = False
        mnFloatingCursorSpeedSlow.Checked = False
        mnFloatingCursorSpeedMedium.Checked = False
        mnFloatingCursorSpeedFast.Checked = False
        mnFloatingCursorSpeedVeryFast.Checked = False

        mnFloatingCursorSpeedVerySlow.Checked = True
        tmrFloatCursor.Interval = 950
    End Sub

    Private Sub mnFloatingCursorSpeedSlow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnFloatingCursorSpeedSlow.Click
        mnFloatingCursorSpeedVerySlow.Checked = False
        mnFloatingCursorSpeedSlow.Checked = False
        mnFloatingCursorSpeedMedium.Checked = False
        mnFloatingCursorSpeedFast.Checked = False
        mnFloatingCursorSpeedVeryFast.Checked = False

        mnFloatingCursorSpeedSlow.Checked = True
        tmrFloatCursor.Interval = 600
    End Sub

    Private Sub mnFloatingCursorSpeedMedium_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnFloatingCursorSpeedMedium.Click
        mnFloatingCursorSpeedVerySlow.Checked = False
        mnFloatingCursorSpeedSlow.Checked = False
        mnFloatingCursorSpeedMedium.Checked = False
        mnFloatingCursorSpeedFast.Checked = False
        mnFloatingCursorSpeedVeryFast.Checked = False

        mnFloatingCursorSpeedMedium.Checked = True
        tmrFloatCursor.Interval = 300
    End Sub

    Private Sub mnFloatingCursorSpeedFast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnFloatingCursorSpeedFast.Click
        mnFloatingCursorSpeedVerySlow.Checked = False
        mnFloatingCursorSpeedSlow.Checked = False
        mnFloatingCursorSpeedMedium.Checked = False
        mnFloatingCursorSpeedFast.Checked = False
        mnFloatingCursorSpeedVeryFast.Checked = False

        mnFloatingCursorSpeedFast.Checked = True
        tmrFloatCursor.Interval = 150
    End Sub

    Private Sub mnFloatingCursorSpeedVeryFast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnFloatingCursorSpeedVeryFast.Click
        mnFloatingCursorSpeedVerySlow.Checked = False
        mnFloatingCursorSpeedSlow.Checked = False
        mnFloatingCursorSpeedMedium.Checked = False
        mnFloatingCursorSpeedFast.Checked = False
        mnFloatingCursorSpeedVeryFast.Checked = False

        mnFloatingCursorSpeedVeryFast.Checked = True
        tmrFloatCursor.Interval = 30
    End Sub

    Private Sub mnCursorStyleBlackWhite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCursorStyleBlackWhite.Click
        mnCursorStyleBlackWhite.Checked = False
        mnCursorStyleBlackWhiteRev.Checked = False
        mnCursorStyleBlackYelBlCr.Checked = False
        mnCursorStyleBlackBlSCr.Checked = False

        mnCursorStyleBlackWhite.Checked = True
        pCursor.Image = imgCursors.Images(0)
        pCursor.Size = imgCursors.Images(0).Size
    End Sub

    Private Sub mnCursorStyleBlackWhiteRev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCursorStyleBlackWhiteRev.Click
        mnCursorStyleBlackWhite.Checked = False
        mnCursorStyleBlackWhiteRev.Checked = False
        mnCursorStyleBlackYelBlCr.Checked = False
        mnCursorStyleBlackBlSCr.Checked = False

        mnCursorStyleBlackWhiteRev.Checked = True
        pCursor.Image = imgCursors.Images(1)
        pCursor.Size = imgCursors.Images(1).Size
    End Sub

    Private Sub mnCursorStyleBlackYelBlCr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCursorStyleBlackYelBlCr.Click
        mnCursorStyleBlackWhite.Checked = False
        mnCursorStyleBlackWhiteRev.Checked = False
        mnCursorStyleBlackYelBlCr.Checked = False
        mnCursorStyleBlackBlSCr.Checked = False

        mnCursorStyleBlackYelBlCr.Checked = True
        pCursor.Image = imgCursors.Images(2)
        pCursor.Size = imgCursors.Images(2).Size
    End Sub

    Private Sub mnCursorStyleBlackBlSCr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCursorStyleBlackBlSCr.Click
        mnCursorStyleBlackWhite.Checked = False
        mnCursorStyleBlackWhiteRev.Checked = False
        mnCursorStyleBlackYelBlCr.Checked = False
        mnCursorStyleBlackBlSCr.Checked = False

        mnCursorStyleBlackBlSCr.Checked = True
        pCursor.Image = imgCursors.Images(3)
        pCursor.Size = imgCursors.Images(3).Size
    End Sub

    Private Sub mnPaintMove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnPaintMove.Click 'Paint Move
        If mnPaintMove.Checked Then
            mnPaintMove.Checked = False
        Else
            mnPaintMove.Checked = True
        End If
    End Sub

    Private Sub mnLowLvUndo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnLowLvUndo.Click 'Low level Undo
        If mnLowLvUndo.Checked Then
            mnLowLvUndo.Checked = False
        Else
            mnLowLvUndo.Checked = True
        End If
    End Sub

    Private Sub mnExplDirPrompt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnExplDirPrompt.Click
        mnExplDirPrompt.checked = True
        mnExplDirPC.checked = False
        mnExplDirMyDocs.checked = False
        mnExplDirCurrent.checked = False
        DefaultExplorerDir = "Prompt"
    End Sub
    Private Sub mnExplDirPC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnExplDirPC.Click
        mnExplDirPrompt.checked = False
        mnExplDirPC.checked = True
        mnExplDirMyDocs.checked = False
        mnExplDirCurrent.checked = False
        DefaultExplorerDir = "Root"
    End Sub
    Private Sub mnExplDirMyDocs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnExplDirMyDocs.Click
        mnExplDirPrompt.checked = False
        mnExplDirPC.checked = False
        mnExplDirMyDocs.checked = True
        mnExplDirCurrent.checked = False
        DefaultExplorerDir = "MyDocuments"
    End Sub
    Private Sub mnExplDirCurrent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnExplDirCurrent.Click
        mnExplDirPrompt.checked = False
        mnExplDirPC.checked = False
        mnExplDirMyDocs.checked = False
        mnExplDirCurrent.checked = True
        DefaultExplorerDir = "Current"
    End Sub

    Private Sub mnAllowDoubleClicks_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnAllowDoubleClicks.Click
        If mnAllowDoubleClicks.Checked Then
            mnAllowDoubleClicks.Checked = False
        Else
            mnAllowDoubleClicks.Checked = True
        End If
    End Sub



    Private Sub mnSelectionNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSelectionNew.Click 'New
        isEditSession = True
        mnSelectionCopy.Enabled = True
        mnSelectionClear.Enabled = True
        mnSelectionPaste.Enabled = True
        mnSelectionFill.Enabled = True
        mnDrawLine.Enabled = False
        If mnPaintMove.Checked Then
            mnPaintMove.Checked = False
        End If
        ShowPencilModeIcon()
        PreEditImageBackup = New Bitmap(pImage.Image)
        mnSelectionNew.Enabled = False
        mnSelectionNewCopy.Enabled = False
        mnDrawRectangle.Enabled = True
        mnDrawPoly.Enabled = False
        mnDrawEllipse.Enabled = True
        mnImportIntoSelection.Enabled = True
        mnImportActual.Enabled = False
    End Sub

    Private Sub mnSelectionNewCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSelectionNewCopy.Click 'new selection with size from copy and lower-right point the location of the cursor.
        Try
            mnSelectionNew_Click(Me, EventArgs.Empty)
            EditRectangle.Size = CopiedImage.Size
            EditRectangle.X = LocX - 1 - EditRectangle.Width
            EditRectangle.Y = LocY - 1 - EditRectangle.Height
            If EditRectangle.X < 0 Then
                EditRectangle.X = 0
            End If
            If EditRectangle.Y < 0 Then
                EditRectangle.Y = 0
            End If
            EditPoint1.X = EditRectangle.X
            EditPoint1.Y = EditRectangle.Y
            DrawSelection()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show("Possibly, there isn't an already copied selection from which to create a new selection.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            mnSelectionClear_Click(Me, EventArgs.Empty)
        End Try
    End Sub

    Private Sub mnSelectionClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSelectionClear.Click 'Clear
        isEditSession = False
        EditPoint1 = Point.Empty
        EditPoint2 = Point.Empty
        mnSelectionNew.Enabled = True
        mnSelectionCopy.Enabled = False
        mnSelectionClear.Enabled = False
        mnSelectionPaste.Enabled = False
        mnSelectionFill.Enabled = False
        mnDrawRectangle.Enabled = False
        mnDrawLine.Enabled = True
        mnSelectionNewCopy.Enabled = True
        'pImage.Image = New Bitmap(PreEditImageBackup)
        pImage.Image = PreEditImageBackup
        EditRectangle = Nothing
        PreEditImageBackup = Nothing
        mnDrawPoly.Enabled = True
        mnDrawEllipse.Enabled = False
        mnImportIntoSelection.Enabled = False
        mnImportActual.Enabled = True
    End Sub

    Private Sub mnSelectionCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSelectionCopy.Click 'Copy
        If isEditSession And Not EditPoint1.IsEmpty Then
            'COPY SELECTION
            CopiedImage = New Bitmap(EditRectangle.Width, EditRectangle.Height)
            Dim g As Graphics = Graphics.FromImage(CopiedImage)
            g.DrawImage(PreEditImageBackup, 0, 0, EditRectangle, GraphicsUnit.Pixel)
            g = Nothing
            mnSelectionClear_Click(Me, EventArgs.Empty)
        End If
    End Sub

    Private Sub mnSelectionPaste_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSelectionPaste.Click 'Paste
        If isEditSession And Not EditPoint1.IsEmpty Then
            'COPY SELECTION
            MakeUndo()
            Dim g As Graphics = Graphics.FromImage(PreEditImageBackup)
            g.DrawImage(CopiedImage, EditRectangle, New Rectangle(0, 0, CopiedImage.Width, CopiedImage.Height), GraphicsUnit.Pixel)
            g = Nothing
            mnSelectionClear_Click(Me, EventArgs.Empty)
        End If
    End Sub

    Private Sub mnSelectionFill_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSelectionFill.Click 'Fill
        If isEditSession And Not EditPoint1.IsEmpty Then
            Dim nFill As New frmFillSelection
            nFill.ImageEdited = PreEditImageBackup
            If nFill.ShowDialog = DialogResult.OK Then
                MakeUndo()
                If nFill.FillAll Then
                    Dim g As Graphics = Graphics.FromImage(PreEditImageBackup)
                    g.FillRectangle(New SolidBrush(nFill.FillColor), EditRectangle)
                    g = Nothing
                    mnSelectionClear_Click(Me, EventArgs.Empty)
                Else
                    PreEditImageBackup = ImageEditingFunctions.pReplaceColorSelection(PreEditImageBackup, EditRectangle, nFill.FillColor, nFill.ReplaceColor)
                    mnSelectionClear_Click(Me, EventArgs.Empty)
                End If
            End If
            nFill = Nothing
        End If
    End Sub



    Private Sub mnAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAbout.Click 'About
        System.Windows.Forms.MessageBox.Show("Pocket Image Editor v1.2" & vbCrLf & "by Kingherc" & vbCrLf & vbCrLf & "The program is free and anyone can help in its development. More information, instructions and help in readme.html found in the directory of the program or at http://www34.brinkster.com/kingherc/.", "About", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1)
    End Sub

    Private Sub mnLicence_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnLicence.Click 'Licence
        System.Windows.Forms.MessageBox.Show("Pocket Image Editor" & vbCrLf & "Copyright (C) 2004 Iraklis Psaroudakis" & vbCrLf & "" & vbCrLf & "This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version." & vbCrLf & "This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. " & vbCrLf & "" & vbCrLf & "You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA", "About", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1)
    End Sub



    Private Sub mnAction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAction.Click 'Undo
        pImage.Image = New Bitmap(pUndoImage)
        pImage.Size = pImage.Image.Size
        CenterImage()
        CenterCursor()
    End Sub

    Private Sub mnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnExit.Click ' Exit
        Me.Close()
    End Sub




    Private Sub ppZoom_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ppZoom.MouseDown
        ToggleZoom()
    End Sub

    Private Sub HScroll_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HScroll.ValueChanged
        UpdateScrollbars()
    End Sub

    Private Sub VScroll_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VScroll.ValueChanged
        UpdateScrollbars()
    End Sub

    Private Sub pImage_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pImage.MouseDown
        MoveCursor(e.X, e.Y)
        If tmrDoubleClickOnImage.Enabled Then
            If mnAllowDoubleClicks.Checked Then
                frmMain_KeyDown(Me, New KeyEventArgs(13))
            End If
        Else
            tmrDoubleClickOnImage.Enabled = True
        End If
    End Sub

    Private Sub pMouseClickEvents_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pMouseClickEvents.MouseDown
        If e.Y < (pMouseClickEvents.Height / 2) Then
            If e.X < (pMouseClickEvents.Width / 2) Then
                frmMain_KeyDown(Me, New KeyEventArgs(49))
            Else
                frmMain_KeyDown(Me, New KeyEventArgs(52))
            End If
        Else
            If e.X < (pMouseClickEvents.Width / 2) Then
                frmMain_KeyDown(Me, New KeyEventArgs(50))
            Else
                frmMain_KeyDown(Me, New KeyEventArgs(53))
            End If
        End If
    End Sub

    Private Sub pCursor_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pCursor.MouseDown
        pImage_MouseDown(Me, New MouseEventArgs(MouseButtons.Left, 1, LocX - 1, LocY - 1, 0))
    End Sub

    Private Sub tmrDoubleClickOnImage_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrDoubleClickOnImage.Tick
        tmrDoubleClickOnImage.enabled = False
    End Sub

    Private Sub pPaintColor_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pPaintColor.MouseDown
        mnPaintColor_Click(Me, System.EventArgs.Empty)
    End Sub

    Private Sub pPaintSize_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pPaintSize.MouseDown
        frmMain_KeyDown(Me, New KeyEventArgs(53))
    End Sub

    Private Sub pPencilMode_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pPencilMode.MouseDown
        If FloatingCursor Then
            If mnPaintMove.Checked Then
                mnPaintMove.Checked = False
                FloatingCursor = False
            Else
                mnPaintMove.Checked = True
            End If
        Else
            If mnPaintMove.Checked Then
                mnPaintMove.Checked = False
                FloatingCursorT = True
            Else
                mnPaintMove.Checked = True
            End If
        End If
        ShowPencilModeIcon()
    End Sub

    Private Sub tmrFloatCursor_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrFloatCursor.Tick
        If FloatingCursor Then
            MoveCursor(navKeyLastPressed)
        End If
    End Sub




    Sub MoveCursor(ByVal LocX As Integer, ByVal LocY As Integer) 'For use within the current bounds of the image shown in the working area
        'If LocX > pImage.Image.Width Or 
        'pCursor.Left = pImage.Left
        If pImage.Left < 0 Then 'If Image is larger that screen and image's left side is out of the screen.
            If LocX < 0 Then 'If the request Left location is out of bounds too
                pImage.Left += (Math.Abs(pImage.Left) - LocX)
                pCursor.Left = 0
            Else
                pCursor.Left = LocX - Math.Abs(pImage.Left)
            End If
        Else
            If pImage.Right > frmWidth Then 'If Image is larger than screen and image's right side is out of bounds
                If LocX > frmWidth Then 'If the request X location is out of bounds too
                    pImage.Left -= (Math.Abs(pImage.Right) - LocX)
                    pCursor.Left = frmWidth - 1
                Else
                    pCursor.Left = LocX
                End If
            Else
                pCursor.Left = pImage.Left + LocX
            End If
        End If
        If pImage.Top < 0 Then 'If Image is larger that screen and image's top side is out of the screen.
            If LocY < 0 Then 'If the request Y location is out of bounds too
                pImage.Top += (Math.Abs(pImage.Top) - LocY)
                pCursor.Top = 0
            Else
                pCursor.Top = LocY - Math.Abs(pImage.Top)
            End If
        Else
            If pImage.Bottom > frmHeight Then 'If Image is larger than screen and image's bottom side is out of bounds
                If LocY > frmHeight Then 'If the request Y location is out of bounds too
                    pImage.Top -= (Math.Abs(pImage.Bottom) - LocY)
                    pCursor.Top = frmHeight - 1
                Else
                    pCursor.Top = LocY
                End If
            Else
                pCursor.Top = pImage.Top + LocY
            End If
        End If
        pCursor.Left -= (pCursor.Width - 1) / 2
        pCursor.Top -= (pCursor.Height - 1) / 2
        CursorMoved()
    End Sub


    Private Sub CenterpPaintSize()
        'Centers the panel for showing the size of the square to be painted upon action is hit.
        pPaintSize.Left = pPaintSizeFirstMiddlePoint.X - (pPaintSize.Width / 2)
        pPaintSize.Top = pPaintSizeFirstMiddlePoint.Y - (pPaintSize.Height / 2)
    End Sub

    Private Sub CursorMoved()
        'When the Cursor is moved, this function must always be called after the movement.
        'If Picture's Width is <= the max allowed
        If pImage.Width <= frmWidth And (pCursor.Left + (pCursor.Width - 1) / 2) < pImage.Left Then
            FloatingCursor = False
            pCursor.Left += CursorStep
        End If
        If pImage.Width <= frmWidth And (pCursor.Left + 1 + (pCursor.Width - 1) / 2) > (pImage.Left + pImage.Width) Then
            FloatingCursor = False
            pCursor.Left -= CursorStep
        End If
        'If Picture's Height is <= the max allowed
        If pImage.Height <= frmHeight And (pCursor.Top + (pCursor.Height - 1) / 2) < pImage.Top Then
            FloatingCursor = False
            pCursor.Top += CursorStep
        End If
        If pImage.Height <= frmHeight And (pCursor.Top + 1 + (pCursor.Height - 1) / 2) > (pImage.Top + pImage.Height) Then
            FloatingCursor = False
            pCursor.Top -= CursorStep
        End If
        'If Picture's Width is > the max allowed
        If pImage.Width > frmWidth And (pCursor.Left - 1 + (pCursor.Width - 1) / 2) < 0 Then
            pCursor.Left = 0 - (pCursor.Width - 1) / 2 + 1
            pImage.Left += CursorStep
            If pImage.Left > 1 Then
                FloatingCursor = False
                pImage.Left = 1
            End If
        End If
        If pImage.Width > frmWidth And (pCursor.Left + 1 + (pCursor.Width - 1) / 2) > frmWidth Then
            pCursor.Left = frmWidth - pCursor.Width + (pCursor.Width - 1) / 2
            pImage.Left -= CursorStep
            If (pImage.Left + pImage.Width) < frmWidth Then
                FloatingCursor = False
                pImage.Left += (frmWidth - pImage.Right)
            End If
        End If
        'If Picture's Height is > the max allowed
        If pImage.Height > frmHeight And (pCursor.Top + (pCursor.Height - 1) / 2) < 0 Then
            pCursor.Top = 0 - (pCursor.Height - 1) / 2
            pImage.Top += CursorStep
            If pImage.Top > 0 Then
                FloatingCursor = False
                pImage.Top = 0
            End If
        End If
        If pImage.Height > frmHeight And (pCursor.Top + 1 + (pCursor.Height - 1) / 2) > frmHeight Then
            pCursor.Top = frmHeight - pCursor.Height + (pCursor.Height - 1) / 2
            pImage.Top -= CursorStep
            If (pImage.Top + pImage.Height) < frmHeight Then
                FloatingCursor = False
                pImage.Top += (frmHeight - pImage.Bottom)
            End If
        End If

        UpdateLocCur() 'Update Coordinates
        If mnPaintMove.Checked And Not isEditSession Then
            PaintCurrent()
        End If

        If isEditSession Then
            DrawSelection()
        End If

        If FloatingCursor Then
            tmrFloatCursor.Enabled = True
        Else
            tmrFloatCursor.Enabled = False
        End If

        DoZoom()
    End Sub

    Private Sub CenterCursor()
        'This functions centers the cursor related to the size of the form that the image can have.
        pCursor.Top = CInt(frmHeight / 2)
        pCursor.Left = CInt(frmWidth / 2)
        CursorMoved()
    End Sub

    Private Sub MoveCursor(ByVal nkey As Integer)
        'Moves the cursor left,right,up,down when a key is pressed.
        'navKeyLastPressed = nkey
        Select Case nkey
            Case 38 'up
                pCursor.Top = pCursor.Top - CursorStep
                CursorMoved()
            Case 39 'right
                pCursor.Left = pCursor.Left + CursorStep
                CursorMoved()
            Case 40 'down
                pCursor.Top = pCursor.Top + CursorStep
                CursorMoved()
            Case 37 'left
                pCursor.Left = pCursor.Left - CursorStep
                CursorMoved()
        End Select

        ShowPencilModeIcon()
    End Sub



    Public Shared Function LoadPlatformType() As String
        If PlatformType Is Nothing Or PlatformType = Nothing Or PlatformType = "" Then
            PlatformType = APICalls.GetPlatformName()
        End If
        Return PlatformType
    End Function

    Private Sub UpdateLocCur() 'Update Coordinates in the label
        Dim CurAddWid As Integer = ((pCursor.Width - 1) / 2) + 1
        Dim CurAddHei As Integer = ((pCursor.Height - 1) / 2) + 1

        LocX = ((0 - pImage.Left) + pCursor.Left) + CurAddWid
        LocY = ((0 - pImage.Top) + pCursor.Top) + CurAddHei

        lblLocCur.Text = "X: " & LocX & ", Y: " & LocY & ", Step: " & CursorStep
        CurAddWid = Nothing
        CurAddHei = Nothing

        UpdateScrollbars()
    End Sub

    Private Sub UpdateScrollbars()
        Try
            HScroll.Minimum = 1
            HScroll.Maximum = pImage.Image.Width + 9
            HScroll.Value = LocX
            VScroll.Minimum = 1
            VScroll.Maximum = pImage.Image.Height + 9
            VScroll.Value = LocY
        Catch

        End Try
    End Sub

    Private Sub CenterImage()
        'Centers the image related to the size of the form that the image can have.
        pImage.Left = (frmWidth - pImage.Width) / 2
        pImage.Top = (frmHeight - pImage.Height) / 2
    End Sub

    Private Sub MakeUndo()
        'Stores the previous image to use it when Undo is clicked. Only one Undo is supported for now.
        If isEditSession Then
            If Not mnLowLvUndo.Checked Then
                pUndoImage = New Bitmap(PreEditImageBackup)
            Else
                pUndoImage = PreEditImageBackup
            End If
        Else
            If Not mnLowLvUndo.Checked Then
                pUndoImage = New Bitmap(pImage.Image)
            Else
                pUndoImage = pImage.Image
            End If
        End If
    End Sub

    Private Sub DrawSelection()
        If Not EditPoint1.IsEmpty Then
            pImage.Image = New Bitmap(PreEditImageBackup)
            Dim g As Graphics = Graphics.FromImage(pImage.Image)
            Dim i As Integer
            DefineEditRectangle()

            g.DrawRectangle(New Pen(Color.White), EditRectangle)
            If EditRectangle.Width > 3 Then
                For i = 1 To EditRectangle.Width Step 3
                    If Not (i + 1) >= EditRectangle.Width Then
                        g.DrawLine(New Pen(Color.Black), EditRectangle.X + i, EditRectangle.Y, EditRectangle.X + i + 1, EditRectangle.Y)
                        g.DrawLine(New Pen(Color.Black), EditRectangle.X + i, EditRectangle.Bottom, EditRectangle.X + i + 1, EditRectangle.Bottom)
                    End If
                Next
            End If
            If EditRectangle.Height > 3 Then
                For i = 1 To EditRectangle.Height Step 3
                    If Not (i + 1) >= EditRectangle.Height Then
                        g.DrawLine(New Pen(Color.Black), EditRectangle.X, EditRectangle.Y + i, EditRectangle.X, EditRectangle.Y + i + 1)
                        g.DrawLine(New Pen(Color.Black), EditRectangle.Right, EditRectangle.Y + i, EditRectangle.Right, EditRectangle.Y + i + 1)
                    End If
                Next
            End If

            g = Nothing
            i = Nothing

            DoZoom()
        End If
    End Sub

    Private Sub PaintCurrent()
        'When executed, it paints the location of the cursor with the current paintsize and color.
        MakeUndo()
        Dim g As Graphics = Graphics.FromImage(pImage.Image)
        If Not (pPaintSize.Width - 1) = 0 Then
            Dim Rect2Draw As Rectangle = New Rectangle((LocX - 1) - ((pPaintSize.Width - 1) / 2), (LocY - 1) - ((pPaintSize.Height - 1) / 2), pPaintSize.Width, pPaintSize.Height)
            g.FillRectangle(New SolidBrush(Paint1Color), Rect2Draw)
            pCursor.Width = 10 'Small cursor trick to refresh drawn image. Should be absent but it seems like a bug of Windows Mobile 2003.
            If pCursor.Visible Then
                CursorsPreviousLocation = pCursor.Location
                pCursor.Size = New Size(frmWidth, frmHeight)
                pCursor.Left = 0
                pCursor.Top = 0
                pCursor.Size = pCursor.Image.Size
                pCursor.Location = CursorsPreviousLocation
            Else
                pCursor.Visible = True
                CursorsPreviousLocation = pCursor.Location
                pCursor.Size = New Size(frmWidth, frmHeight)
                pCursor.Left = 0
                pCursor.Top = 0
                pCursor.Size = pCursor.Image.Size
                pCursor.Location = CursorsPreviousLocation
                pCursor.Visible = False
            End If 'End of small cursor trick
            Rect2Draw = Nothing
        Else
            g.FillRectangle(New SolidBrush(Paint1Color), LocX - 1, LocY - 1, 1, 1)
        End If
        g = Nothing
        DoZoom()
    End Sub

    Public Function GetImageEdited() As Bitmap
        If isEditSession And Not EditPoint1.IsEmpty Then
            Return PreEditImageBackup
        Else
            Return pImage.Image
        End If
    End Function

    Sub DoZoom()
        If isZoom Then
            Dim nZoom As New Bitmap(frmWidth, frmHeight)
            Dim widthSpace As Integer = nZoom.Width / ZoomPixels
            Dim heightSpace As Integer = nZoom.Height / ZoomPixels
            Dim cx As Integer = 0, cy As Integer = 0
            Dim g As Graphics = Graphics.FromImage(nZoom)
            g.DrawImage(pImage.Image, New Rectangle(0, 0, nZoom.Width, nZoom.Height), New Rectangle(LocX - 1 - (ZoomPixels / 2), LocY - 1 - (ZoomPixels / 2), ZoomPixels, ZoomPixels), GraphicsUnit.Pixel)
            If pCursor.Visible Then
                g.DrawImage(pCursor.Image, nZoom.Width / 2 - 1 + 3, nZoom.Height / 2 - 1 + 3)
            End If
            'cx = widthSpace * ZoomPixels / 2
            'cy = heightSpace * ZoomPixels / 2
            'g.DrawImage(pCursor.Image, cx, cy)
            pZoom.Visible = True
            pZoom.Image = nZoom
            nZoom = Nothing
            g = Nothing
            cx = Nothing
            cy = Nothing
            widthSpace = Nothing
            heightSpace = Nothing
        End If
    End Sub

    Sub ToggleZoom()
        If Not isZoom Then
            isZoom = True
            If LCase(PlatformType).IndexOf(LCase("SmartPhone")) = -1 Then
                ppZoom.Image = hResources("Zoom")
            End If
            DoZoom()
        Else
            isZoom = False
            If LCase(PlatformType).IndexOf(LCase("SmartPhone")) = -1 Then
                ppZoom.Image = hResources("UnZoom")
            End If
            pZoom.Visible = False
        End If
    End Sub

    Private Sub DefineEditRectangle()
        If Not EditPoint1.IsEmpty Then
            Dim rC As Rectangle
            If EditPoint2.IsEmpty Then
                If EditPoint1.X > (LocX - 1) Then
                    rC.X = (LocX - 1)
                Else
                    rC.X = EditPoint1.X
                End If
                If EditPoint1.Y > (LocY - 1) Then
                    rC.Y = (LocY - 1)
                Else
                    rC.Y = EditPoint1.Y
                End If
                rC.Width = Math.Abs(EditPoint1.X - (LocX - 1))
                rC.Height = Math.Abs(EditPoint1.Y - (LocY - 1))
            Else
                If EditPoint1.X > EditPoint2.X Then
                    rC.X = EditPoint2.X
                Else
                    rC.X = EditPoint1.X
                End If
                If EditPoint1.Y > EditPoint2.Y Then
                    rC.Y = EditPoint2.Y
                Else
                    rC.Y = EditPoint1.Y
                End If
                rC.Width = Math.Abs(EditPoint1.X - EditPoint2.X)
                rC.Height = Math.Abs(EditPoint1.Y - EditPoint2.Y)
            End If
            EditRectangle = rC
            rC = Nothing
        End If
    End Sub

    Sub ShowPencilModeIcon()
        If FloatingCursor Then 'If Floating cursor
            If mnPaintMove.Checked Then 'If Floating AND paint when move
                pPencilMode.Image = imgPencils.Images(3)
            Else 'If Floating AND NOT paint when move
                pPencilMode.Image = imgPencils.Images(2)
            End If
        Else 'If NOT floating cursor
            If mnPaintMove.Checked Then 'If NOT floating AND paint when move
                pPencilMode.Image = imgPencils.Images(1)
            Else 'If NOT Floating AND NOT paint when move
                pPencilMode.Image = imgPencils.Images(0)
            End If
        End If
    End Sub



    Sub LoadOptions()

        If Reg.KeyExists(strRegKey) Then

            Dim CursorStepOp As String = CStr(Reg.GetValue(strRegKey & "\" & "CursorStep")).Trim
            Dim FloatingCursorSpeedOp As String = CStr(Reg.GetValue(strRegKey & "\" & "FloatingCursorSpeed")).Trim
            Dim CursorStyleOp As String = CStr(Reg.GetValue(strRegKey & "\" & "CursorStyle")).Trim
            Dim DefaultExplDirOp As String = CStr(Reg.GetValue(strRegKey & "\" & "DefaultExplDir")).Trim
            Dim ZoomPixelsOp As String = CStr(Reg.GetValue(strRegKey & "\" & "ZoomPixels")).Trim
            Dim LowLvUndoOp As String = CStr(Reg.GetValue(strRegKey & "\" & "LowLvUndo")).Trim
            Dim PaintMoveOp As String = CStr(Reg.GetValue(strRegKey & "\" & "PaintMove")).Trim
            Dim AllowDoubleClicksOp As String = CStr(Reg.GetValue(strRegKey & "\" & "AllowDoubleClicks")).Trim

            If Not CursorStepOp.Length = 0 Then
                CursorStep = CursorStepOp
                UpdateLocCur()
            End If
            If Not FloatingCursorSpeedOp.Length = 0 Then
                Dim TmpNum As Integer = FloatingCursorSpeedOp
                Select Case TmpNum
                    Case 1
                        If Not mnFloatingCursorSpeedVerySlow.checked Then
                            mnFloatingCursorSpeedVerySlow_Click(Me, EventArgs.Empty)
                        End If
                    Case 2
                        If Not mnFloatingCursorSpeedSlow.checked Then
                            mnFloatingCursorSpeedSlow_Click(Me, EventArgs.Empty)
                        End If
                    Case 3
                        If Not mnFloatingCursorSpeedMedium.checked Then
                            mnFloatingCursorSpeedMedium_Click(Me, EventArgs.Empty)
                        End If
                    Case 4
                        If Not mnFloatingCursorSpeedFast.checked Then
                            mnFloatingCursorSpeedFast_Click(Me, EventArgs.Empty)
                        End If
                    Case 5
                        If Not mnFloatingCursorSpeedVeryFast.checked Then
                            mnFloatingCursorSpeedVeryFast_Click(Me, EventArgs.Empty)
                        End If
                End Select
            End If
            If Not CursorStyleOp.Length = 0 Then
                Dim TmpNum As Integer = CursorStyleOp
                Select Case TmpNum
                    Case 1
                        If Not mnCursorStyleBlackWhite.checked Then
                            mnCursorStyleBlackWhite_Click(Me, EventArgs.Empty)
                        End If
                    Case 2
                        If Not mnCursorStyleBlackWhiteRev.checked Then
                            mnCursorStyleBlackWhiteRev_Click(Me, EventArgs.Empty)
                        End If
                    Case 3
                        If Not mnCursorStyleBlackYelBlCr.checked Then
                            mnCursorStyleBlackYelBlCr_Click(Me, EventArgs.Empty)
                        End If
                    Case 4
                        If Not mnCursorStyleBlackBlSCr.checked Then
                            mnCursorStyleBlackBlSCr_Click(Me, EventArgs.Empty)
                        End If
                End Select
            End If
            If Not DefaultExplDirOp.Length = 0 Then
                Dim TmpNum As Integer = DefaultExplDirOp
                Select Case TmpNum
                    Case 1
                        If Not mnExplDirPrompt.checked Then
                            mnExplDirPrompt_Click(Me, EventArgs.Empty)
                        End If
                    Case 2
                        If Not mnExplDirPC.checked Then
                            mnExplDirPC_Click(Me, EventArgs.Empty)
                        End If
                    Case 3
                        If Not mnExplDirMyDocs.checked Then
                            mnExplDirMyDocs_Click(Me, EventArgs.Empty)
                        End If
                    Case 4
                        If Not mnExplDirCurrent.checked Then
                            mnExplDirCurrent_Click(Me, EventArgs.Empty)
                        End If
                End Select
            End If
            If Not ZoomPixelsOp.Length = 0 Then
                Dim TmpNum As Integer = ZoomPixelsOp
                Select Case TmpNum
                    Case 5
                        If Not mnZoom5.checked Then
                            mnZoom5_Click(Me, EventArgs.Empty)
                        End If
                    Case 10
                        If Not mnZoom10.checked Then
                            mnZoom10_Click(Me, EventArgs.Empty)
                        End If
                    Case 20
                        If Not mnZoom20.checked Then
                            mnZoom20_Click(Me, EventArgs.Empty)
                        End If
                    Case 30
                        If Not mnZoom30.checked Then
                            mnZoom30_Click(Me, EventArgs.Empty)
                        End If
                    Case 40
                        If Not mnZoom40.checked Then
                            mnZoom40_Click(Me, EventArgs.Empty)
                        End If
                    Case 50
                        If Not mnZoom50.checked Then
                            mnZoom50_Click(Me, EventArgs.Empty)
                        End If
                    Case 60
                        If Not mnZoom60.checked Then
                            mnZoom60_Click(Me, EventArgs.Empty)
                        End If
                    Case 70
                        If Not mnZoom70.checked Then
                            mnZoom70_Click(Me, EventArgs.Empty)
                        End If
                    Case 80
                        If Not mnZoom80.checked Then
                            mnZoom80_Click(Me, EventArgs.Empty)
                        End If
                    Case 90
                        If Not mnZoom90.checked Then
                            mnZoom90_Click(Me, EventArgs.Empty)
                        End If
                End Select
            End If
            If Not LowLvUndoOp.Length = 0 Then
                If LowLvUndoOp = 0 Then
                    If mnLowLvUndo.checked Then
                        mnLowLvUndo_Click(Me, EventArgs.Empty)
                    End If
                ElseIf LowLvUndoOp = -1 Then
                    If Not mnLowLvUndo.checked Then
                        mnLowLvUndo_Click(Me, EventArgs.Empty)
                    End If
                End If
            End If
            If Not PaintMoveOp.Length = 0 Then
                If PaintMoveOp = 0 Then
                    If mnPaintMove.checked Then
                        mnPaintMove_Click(Me, EventArgs.Empty)
                    End If
                ElseIf PaintMoveOp = -1 Then
                    If Not mnPaintMove.checked Then
                        mnPaintMove_Click(Me, EventArgs.Empty)
                    End If
                End If
            End If

            If LCase(PlatformType).IndexOf(LCase("SmartPhone")) = -1 Then
                'On platforms other than Smartphones

                If Not AllowDoubleClicksOp.Length = 0 Then
                    If AllowDoubleClicksOp = 0 Then
                        If mnAllowDoubleClicks.checked Then
                            mnAllowDoubleClicks_Click(Me, EventArgs.Empty)
                        End If
                    ElseIf AllowDoubleClicksOp = -1 Then
                        If Not mnAllowDoubleClicks.checked Then
                            mnAllowDoubleClicks_Click(Me, EventArgs.Empty)
                        End If
                    End If
                End If
            End If

        Else
            'Things to do if options weren't found

        End If
    End Sub

    Sub SaveOptions()

        'FloatingCursorSpeed
        Dim FloatingCursorSpeedOp As Integer = 3
        If mnFloatingCursorSpeedVerySlow.checked Then
            FloatingCursorSpeedOp = 1
        End If
        If mnFloatingCursorSpeedSlow.checked Then
            FloatingCursorSpeedOp = 2
        End If
        If mnFloatingCursorSpeedMedium.checked Then
            FloatingCursorSpeedOp = 3
        End If
        If mnFloatingCursorSpeedFast.checked Then
            FloatingCursorSpeedOp = 4
        End If
        If mnFloatingCursorSpeedVeryFast.checked Then
            FloatingCursorSpeedOp = 5
        End If
        'CursorStyle
        Dim CursorStyleOp As Integer = 1
        If mnCursorStyleBlackWhite.checked Then
            CursorStyleOp = 1
        End If
        If mnCursorStyleBlackWhiteRev.checked Then
            CursorStyleOp = 2
        End If
        If mnCursorStyleBlackYelBlCr.checked Then
            CursorStyleOp = 3
        End If
        If mnCursorStyleBlackBlSCr.checked Then
            CursorStyleOp = 4
        End If
        'DefaultExplDir
        Dim DefaultExplDirOp As Integer = 1
        If mnExplDirPrompt.checked Then
            DefaultExplDirOp = 1
        End If
        If mnExplDirPC.checked Then
            DefaultExplDirOp = 2
        End If
        If mnExplDirMyDocs.checked Then
            DefaultExplDirOp = 3
        End If
        If mnExplDirCurrent.checked Then
            DefaultExplDirOp = 4
        End If

        Reg.CreateKey(strRegKey)
        Reg.SetValue(strRegKey & "\" & "CursorStep", CursorStep)
        Reg.SetValue(strRegKey & "\" & "FloatingCursorSpeed", FloatingCursorSpeedOp)
        Reg.SetValue(strRegKey & "\" & "CursorStyle", CursorStyleOp)
        Reg.SetValue(strRegKey & "\" & "DefaultExplDir", DefaultExplDirOp)
        Reg.SetValue(strRegKey & "\" & "ZoomPixels", ZoomPixels)
        If mnLowLvUndo.checked Then
            Reg.SetValue(strRegKey & "\" & "LowLvUndo", -1)
        Else
            Reg.SetValue(strRegKey & "\" & "LowLvUndo", 0)
        End If
        If mnPaintMove.checked Then
            Reg.SetValue(strRegKey & "\" & "PaintMove", -1)
        Else
            Reg.SetValue(strRegKey & "\" & "PaintMove", 0)
        End If

        If LCase(PlatformType).IndexOf(LCase("SmartPhone")) = -1 Then
            'On platforms other than Smartphones
            If mnAllowDoubleClicks.checked Then
                Reg.SetValue(strRegKey & "\" & "AllowDoubleClicks", -1)
            Else
                Reg.SetValue(strRegKey & "\" & "AllowDoubleClicks", 0)
            End If
        End If

    End Sub



End Class

