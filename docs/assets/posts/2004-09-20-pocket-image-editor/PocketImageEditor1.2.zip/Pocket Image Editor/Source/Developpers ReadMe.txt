These lines are to be used with the vbc.exe compiler of .net framework sdk. Copy the line and paste it in a command prompt (right-click the icon > Edit > Paste).

FOR THE PROGRAM:

"C:\WINDOWS\Microsoft.NET\Framework\v1.1.4322\vbc.exe" /out:"C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket Image Editor\Pocket Image Editor.exe" /target:winexe /r:System.Windows.Forms.dll /r:System.dll,System.Drawing.dll,Microsoft.VisualBasic.dll /imports:System,System.Net.Sockets,System.Net,System.Threading,System.Text,System.IO,System.Drawing,System.Drawing.Imaging,System.Runtime.InteropServices /main:frmMain /netcf /sdkpath:"c:\Program Files\[SDK Path]\CompactFrameworkSDK\v1.0.5000\Windows CE" /win32icon:"C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket Image Editor\Images\ProgramIcon.ico" /res:"C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket Image Editor\Main.resources" /recurse:"C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket Image Editor\SubSource\*.vb" "C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket Image Editor\Main.vb"

FOR RESOURCES:

"C:\WINDOWS\Microsoft.NET\Framework\v1.1.4322\vbc.exe" /out:"C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket Image Editor\MakeResource.exe" /r:System.Windows.Forms.dll /r:System.dll,System.Drawing.Design.dll,System.Drawing.dll,Microsoft.VisualBasic.dll /imports:System.Text,System.IO,System.Runtime.InteropServices,Microsoft.Win32 /target:winexe "C:\Documents and Settings\Kingherc\My Documents\[NETProjects]\Pocket Image Editor\CreateResources.vb"

.Resources are files that contain the resources to be used in a program. This file must be created first so that it can be compiled with the source in one executable file. So, use the vbc.exe compiler to create MakeResource.exe. Then execute it. The .resources file will be created. This will be used by the vbc.exe compiler for the source/program compilation.