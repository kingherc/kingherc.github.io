﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Linq;
using System.Linq.Expressions;
using System.Collections.Generic;
using System.Net;
using System.IO;
using System.Xml;

namespace HitEmUp
{
	public partial class MainPage : UserControl
	{

        class ScoreClass : Dictionary<int, String> { }

        ScoreClass ranks = new ScoreClass();
        private int maxScore = 800;
        private int spidersSpawnInterval = 700;
        private int spidersTimeToSmash = 5000;
        private int badProbability = 98;
        private DispatcherTimer timer;
        private Nest[,] Nests = new Nest[4,4];

        private int _score;
        public int Score
        {
            get
            {
                return _score;
            }
            set
            {
                _score = value;

                if (_score < maxScore)
                {
                    ScoreProgressBar.Value = _score;
                    int k = ranks.First(o => o.Key > Score).Key;
                    double bottom = Canvas.GetTop(ScoreProgressBar);
                    double top = bottom - ScoreProgressBar.ActualWidth;
                    double yToPlaceMark = bottom - (bottom - top) * k / maxScore;
                    ScoreNextRankText.Text = "Next Rank:\n" + ranks[k];
                    Canvas.SetTop(ScoreNextRankText, yToPlaceMark - ScoreNextRankText.ActualHeight / 2);
                    Canvas.SetTop(ScoreProgressMarker, yToPlaceMark - ScoreProgressMarker.ActualHeight / 2);
                }
                else
                {
                    Lives = 0;
                }

                if (_score % 20 == 0)
                {
                    spidersSpawnInterval = Math.Max(300, spidersSpawnInterval - 50);
                    timer.Interval = TimeSpan.FromMilliseconds(spidersSpawnInterval);
                }

                if (_score % 10 == 0)
                    spidersTimeToSmash = Math.Max(2500, spidersTimeToSmash - 100);

                if (_score % 40 == 0 && _score < maxScore)
                    badProbability--;

                ScoreText.Text = _score.ToString();
            }
        }

        private int _lives;
        public int Lives
        {
            get
            {
                return _lives;
            }
            set
            {
                if (value <= 0)
                {
                    timer.Stop();
                    NestGrid.Children.Clear();
                    sndApplause.Stop();
                    sndApplause.Play();
                    ScoreProgressBar.Visibility = ScoreProgressMarker.Visibility = ScoreNextRankText.Visibility = Visibility.Collapsed;
                    int offset = h.r(0, 14);
                    Uri serviceUri = new Uri(@"http://api.bing.net/xml.aspx?AppId=F3D9778767AD110124582507C12FBF9C773167DE&Version=2.2&Market=en-US&Query=congratulations&Sources=Image&Image.Count=1&Image.Filters=Size:Small+Style:Graphics+Color:Color+Aspect:Square&Image.Offset=" + offset);
                    WebClient downloader = new WebClient();
                    downloader.OpenReadCompleted += new OpenReadCompletedEventHandler(downloader_OpenReadCompleted);
                    downloader.OpenReadAsync(serviceUri);
                    LivesText.Visibility = LivesTextLabel.Visibility = Visibility.Collapsed;
                    String resultDescription;
                    resultDescription = ranks.Last(o => Score >= o.Key).Value;
                    gameover.Text += "\nRank: " + resultDescription;
                    gameover.Visibility = Visibility.Visible;
                }
                else
                {
                    if (value > _lives)
                    {
                        sndLifePlus.Stop();
                        sndLifePlus.Play();
                    }
                    else
                    {
                        sndOuch.Stop();
                        sndOuch.Play();
                    }
                    _lives = value;
                }
                LivesText.Text = _lives.ToString();
            }
        }

        void downloader_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                XmlReader reader = XmlReader.Create(e.Result);
                using (reader)
                {
                    if (reader.ReadToFollowing("mms:Url") && reader.ReadToFollowing("mms:Url"))
                    {
                        ImageSourceConverter i = new ImageSourceConverter();
                        congrats.Source = (ImageSource)i.ConvertFromString(reader.ReadElementContentAsString());
                        congratsborder.Visibility = Visibility.Visible;
                    }
                }
            }

        }

		public MainPage()
		{
			InitializeComponent();
            ranks.Add(0, "Newbie");
            ranks.Add(50, "Apprentice");
            ranks.Add(100, "Sergeant");
            ranks.Add(200, "Lieutenant");
            ranks.Add(400, "Captain");
            ranks.Add(600, "Major");
            ranks.Add(800, "Ultimate Champion");
            ScoreProgressBar.Maximum = maxScore;
		}

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            timer = new DispatcherTimer();
            ScoreProgressMarker.Visibility = ScoreNextRankText.Visibility = Visibility.Visible;
            Instructions.Visibility = Visibility.Collapsed;
            Score = 1;
            Lives = 3;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Nest newNest = new Nest();
                    newNest.Hit += new EventHandler(newNest_Hit);
                    newNest.Miss += new EventHandler(newNest_Miss);
                    newNest.Cursor = Cursors.Hand;
                    newNest.Width = newNest.Height = 100;
                    newNest.HorizontalAlignment = HorizontalAlignment.Center;
                    newNest.VerticalAlignment = VerticalAlignment.Top;
                    Nests[i, j] = newNest;
                    Grid.SetRow(newNest, i);
                    Grid.SetColumn(newNest, j);
                    NestGrid.Children.Add(newNest);
                }
            }

            timer.Interval = TimeSpan.FromMilliseconds(spidersSpawnInterval);
            timer.Tick += new EventHandler(timer_Tick);
            timer.Start();

            startButton.Visibility = Visibility.Collapsed;
        }

        void newNest_Miss(object sender, EventArgs e)
        {
            if (timer.IsEnabled) Lives--;
        }

        void newNest_Hit(object sender, EventArgs e)
        {
            if (((Nest)sender).isBad) Score ++; else Lives++;
        }

        void timer_Tick(object sender, EventArgs e)
        {
            List<Nest> emptyNests = new List<Nest>();
            for (int i=0;i<4;i++)
                for (int j=0;j<4;j++)
                    if (Nests[i,j].IsEmpty())
                        emptyNests.Add(Nests[i,j]);

            if (emptyNests.Count != 0) {
                Nest nest = emptyNests[h.r(0, emptyNests.Count - 1)];
                if (h.r(0, 99) < badProbability)
                    nest.Infect(spidersTimeToSmash, true);
                else
                    nest.Infect(spidersTimeToSmash/2, false);
            }
        }

    }
}