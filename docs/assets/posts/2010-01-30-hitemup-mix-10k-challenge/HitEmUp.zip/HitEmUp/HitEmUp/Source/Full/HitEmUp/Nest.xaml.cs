﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Threading;
using System.Windows.Media.Effects;

namespace HitEmUp
{
    public static class h
    {
        public static FontFamily w = new FontFamily("Webdings");

        public static int r(int s, int e)
        {
            return (new Random(DateTime.Now.Millisecond)).Next(s, e);
        }
    }

	public partial class Nest : UserControl
	{

        Storyboard storyCountdown;
        TextBlock spider;
        public bool isBad;

        public event EventHandler Hit;
        void RaiseHit()
        {
            if (Hit != null)
            {
                Hit(this, new EventArgs()); 
            } 
        }

        public event EventHandler Miss;
        void RaiseMiss()
        {
            if (Miss != null)
            {
                Miss(this, new EventArgs());
            }
        }

		public Nest()
		{
			InitializeComponent();
        }

        public bool IsEmpty()
        {
            return (storyCountdown==null)||(storyCountdown.GetCurrentState() == ClockState.Stopped);
        }

        public void Infect(int milliseconds, bool isBad) {

            this.isBad = isBad;

            spider = new TextBlock();
            spider.Opacity = 0;
            spider.Height = 35;
            spider.Width = 32;
            spider.FontFamily = h.w;
            spider.FontSize = 34;
            Canvas.SetLeft(spider, 32);
            Canvas.SetTop(spider, 60);
            spider.Effect = new DropShadowEffect() { ShadowDepth = 1};
            spider.Foreground = new SolidColorBrush((isBad) ? Colors.Magenta : Colors.Yellow);
            spider.Text = (isBad) ? "!\u0085\u00A0"[h.r(0, 3)].ToString() : "eh\u0098"[h.r(0, 3)].ToString();

            LayoutRoot.Children.Add(spider);
            Storyboard storyboard = new Storyboard();

            DoubleAnimation comeOutAnimation = new DoubleAnimation();
            comeOutAnimation.To = 45;
            comeOutAnimation.Duration = TimeSpan.FromMilliseconds(500);
            Storyboard.SetTarget(comeOutAnimation, spider);
            Storyboard.SetTargetProperty(comeOutAnimation, new PropertyPath("(Canvas.Top)"));
            storyboard.Children.Add(comeOutAnimation);

            DoubleAnimation comeOutFadeAnimation = new DoubleAnimation();
            comeOutFadeAnimation.To = 1;
            comeOutFadeAnimation.Duration = TimeSpan.FromMilliseconds(500);
            Storyboard.SetTarget(comeOutFadeAnimation, spider);
            Storyboard.SetTargetProperty(comeOutFadeAnimation, new PropertyPath("(Opacity)"));
            storyboard.Children.Add(comeOutFadeAnimation);

            storyboard.Duration = comeOutAnimation.Duration;
            storyboard.Begin();

            progessBar.Visibility = Visibility.Visible;
            progessBar.Value = progessBar.Maximum = milliseconds;

            storyCountdown = new Storyboard();

            DoubleAnimation countDownAnimation = new DoubleAnimation();
            countDownAnimation.To = 0;
            countDownAnimation.Duration = TimeSpan.FromMilliseconds(milliseconds);
            Storyboard.SetTarget(countDownAnimation, progessBar);
            Storyboard.SetTargetProperty(countDownAnimation, new PropertyPath("(Value)"));
            storyCountdown.Children.Add(countDownAnimation);

            storyCountdown.Duration = countDownAnimation.Duration;
            storyCountdown.Completed += new EventHandler(storyboard_Completed);
            storyCountdown.Begin();
        }

        void storyboard_Completed(object sender, EventArgs e)
        {
            if (!IsEmpty())
            {
                LayoutRoot.Children.Remove(spider);
                progessBar.Visibility = Visibility.Collapsed;
                storyCountdown.Stop();
                if (isBad) RaiseMiss();
            }
        }

        private void LayoutRoot_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (IsEmpty())
            {
                RaiseMiss();
            }
            else
            {
                LayoutRoot.Children.Remove(spider);
                storyCountdown.Stop();
                progessBar.Visibility = Visibility.Collapsed;
                RaiseHit();
            }
        }
    }
}