// Kingherc's ASP.NET toolkit guide
document.write('<center><table width="740" cellpadding="0" cellspacing="0"><tr><td valign="bottom"><img src="Images/Outline-topleft.gif"></td><td width="100%"><table width="100%" cellpadding="0" cellspacing="0"><tr><td width="100%" background="Images/Outline-top.gif" style="background: url(images/Outline-top.gif)"></td><td align="right" valign="bottom"><img src="Images/HeaderNav.jpg" border="0" usemap="#Map" style="align:right"></td></tr></table></td></tr><tr><td width="3" height="100%" background="Images/Outline-left.gif" style="background: url(images/Outline-left.gif)"></td><td width="100%"><table width="100%" cellpadding="0" cellspacing="0"><tr><td width="100%" style="font-size:12px">')

function showmenu () {
overlib("<a href='index.htm'>Main Page</a><br><a href='History.htm'>Toolkit version history</a><br><a href='Contacts.htm'>Contacts / Links</a><br><a href='InstallInstr.htm'>Install Instructions</a><br><a href='Licence.htm'>Legal Notes (Licence)</a>", STICKY, CAPTION, "Menu", FGCOLOR, "black")
}
function showimageeditorexample () {
overlib("<img src='Images/ImageEditorExample.jpg'>", STICKY, CAPTION, "Image Editor Example", FGCOLOR, "#606C7C")
}
function showdisplayorexample () {
overlib("<img src='Images/DisplayorExample.jpg'>", STICKY, CAPTION, "Displayor Example", FGCOLOR, "#606C7C")
}
function showfiledirexample () {
overlib("<img src='Images/FileDirExample.jpg'>", STICKY, CAPTION, "Photo/File Dir Example", FGCOLOR, "#606C7C")
}
function showpollexample () {
overlib("<img src='Images/PollExample.jpg'>", STICKY, CAPTION, "Poll Example", FGCOLOR, "#606C7C")
}
function showtitleexample () {
overlib("<img src='Images/TitleExample.jpg'>", STICKY, CAPTION, "Title Example", FGCOLOR, "#606C7C")
}
function shownewsexample () {
overlib("<img src='Images/NewsExample.jpg'>", STICKY, CAPTION, "News Example", FGCOLOR, "#606C7C")
}