Kingherc's ASP.NET toolkit version 1.0
======================================

To view the guide and get instructions on how to use the toolkit, open with a browser the file "index.htm" (html file, offline).

Else, if you want to use the controls right away, search the Files folder for the files "TheProblemControls"(.vb for developers, .dll for users). Keep in mind that by using the controls you are bound to the licence presented in the Legal.htm file (html file, offline).

31/1/07: The website's address changed from http://www34.brinkster.com/kingherc/ to http://kherc.brinkster.net/.


Configuring a webserver with the .NET Framework on Windows XP Pro and Windows 2000 Pro
--------------------------------------------------------------------------------------
To be able to use the web controls of this toolkit, you must have a web server running with the .NET framework installed. This section helps you configure one on Windows XP Professional or Windows 2000 Professional. Be advised that it'd be better to visit Microsoft's website (www.microsoft.com) to get instruction on how to configure IIS (for the web server) than following the short steps below.

Mini-guide:
1) It's better to download the latest Service Pack for your operating system. (Windows 2000 requires that for the .NET framework to be installed).
2) Click Start, Setting and Control Panel, Add/Remove Programs, Add/Remove Window Components.
3) Select to install Internet Information Services (web server). [Currently, only winxppro and win2kpro support this. If you can, download IIS for your operating system if it's possible]
* You can alter the webserver options, by viewing the Administrative Tools from the control Panel.
4) Install it. Restart. Now, the web root directory of your web server is C:\Inetpub\wwwroot\. You can store there asp (not asp.net yet) pages and html pages to view. To view the default directory through the browser, open Internet Explorer, and type http://localhost/.
5) Download and install Microsoft .NET Framework 1.1 Redistributable Package.
6) Now, you are ready to run asp.net pages on your web server.