'The Problem Controls. Copyright, Kingherc, 2004

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Collections.Specialized
Imports System.Text
Imports System.IO
Imports System.Data
Imports System.Data.Oledb
Imports System.Xml
Imports System.ComponentModel
Imports System.ValueType
Imports Microsoft.VisualBasic
Imports System.Drawing
Imports System.Drawing.Text
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D

Namespace TPControls


    Public Class Displayor
	Inherits Control
	Implements INamingContainer
	'Implements IPostBackDataHandler

		Public strTitle As String = "Undefined main title"
		
		Public Property Opened As Boolean 'This saves the state (open/hidden) of the control in the viewstate
		Get
			Return CType(ViewState("MenusDisplayor" & Me.UniqueID), Boolean)
		End Get
		Set
			ViewState("MenusDisplayor" & Me.UniqueID) = value
		End Set
		End Property
		
		Public Sub Add(ByVal Value As Object) 'This adds an object to the main placeholder of the control
			Me.EnsureChildControls()
			CType(Controls(7), System.Web.UI.WebControls.PlaceHolder).Controls.Add(Value)
		End Sub

		Public Event Change(s As Object, e As EventArgs) 'When the link is clicked
		Protected Sub OnChange(e As EventArgs)
				RaiseEvent Change(Me, EventArgs.Empty)
		End Sub

		Public OpenCloseLink As System.Web.UI.WebControls.LinkButton
		Public BodyHolder As System.Web.UI.WebControls.PlaceHolder

		Protected Overrides Sub CreateChildControls()		
								'Linkbutton
						OpenCloseLink = New System.Web.UI.WebControls.LinkButton()
						AddHandler OpenCloseLink.Click, AddressOf Me.ChangeStatus
						OpenCloseLink.ID = "MenuLink" & Me.UniqueID
						OpenCloseLink.Style("font-size") = "13px"
						If Opened Then
						OpenCloseLink.Style("color") = "DimGray"
						OpenCloseLink.Text = "Close"
						Else
						OpenCloseLink.Style("color") = "White"
						OpenCloseLink.Text = "Open"
						End If
								'PlaceHolder
						BodyHolder = New System.Web.UI.WebControls.PlaceHolder()
						BodyHolder.ID = "MenuBodyHolder" & Me.UniqueID
								Dim CControl
								For Each CControl In Me.Controls
									BodyHolder.Controls.Add(CControl)
								Next
						BodyHolder.visible = Opened
		
				Me.Controls.Add(New LiteralControl("<center><table cellpadding='0' cellspacing='0' width='90%' style='border: 1px solid #D3D3D3'><tr><td Width='100%' style='font-size:15px; color:black;background-color:#A9A9A9'>"))
				Me.Controls.Add(New LiteralControl("<table cellpadding='0' cellspacing='0' width='100%'><tr><td width='100%' style='font-size:15px; color:black;background-color:#A9A9A9'>"))
				Me.Controls.Add(New LiteralControl(strTitle))
				Me.Controls.Add(New LiteralControl("</td><td><b>"))
				Me.Controls.Add(OpenCloseLink)
				Me.Controls.Add(New LiteralControl("</b></td></tr></table></td></tr>"))
				Me.Controls.Add(New LiteralControl("<tr><td width='100%' height='100%' style='font-size:12px;color:white; background-color: #696969'>"))
				Me.Controls.Add(BodyHolder)
				Me.Controls.Add(New LiteralControl("</td></tr></table></center>"))
		
		End Sub

		Sub ChangeStatus(sender As Object, e As EventArgs)
		DoChange(Me, EventArgs.Empty)
		OnChange(EventArgs.Empty)
		'Page.FindControl("MenuBodyHolder" & Me.cID).visible = Opened
		End Sub

		Sub DoChange(sender As Object, e As EventArgs)
			If Opened Then
				CType(Controls(7), System.Web.UI.WebControls.PlaceHolder).visible = False
				CType(Controls(4), System.Web.UI.WebControls.LinkButton).text = "Open"
				CType(Controls(4), System.Web.UI.WebControls.LinkButton).Style("color") = "White"
				Opened = False
			Else
				CType(Controls(7), System.Web.UI.WebControls.PlaceHolder).visible = True
				CType(Controls(4), System.Web.UI.WebControls.LinkButton).text = "Close"
				CType(Controls(4), System.Web.UI.WebControls.LinkButton).Style("color") = "DimGray"
				Opened = True
			End If
		End Sub
		
    End Class
	
	
	'---------------------- PHOTO DIRS CLASS ------------------------------------
	'----------------------------------------------------------------------------
	'----------------------------------------------------------------------------
	'----------------------------------------------------------------------------

	
    Public Class GalleryDir
	Inherits Control
	Implements INamingContainer

		Public rPath As String = "\" 'The Path of the main directories of the main box
		Public TablesWidth As String = "48%" 'The width of the boxes
		Public TablesStyleClass As String = "defaulttext" 'The CSS class added in each box
		Public ImgsPath As String = "/Images/Menu/" 'The path  where the icons exist
		Public MaxSubDirs As Integer = 50 'This specifies how many label controls will be created
		Public MaxFiles As Integer = 300 'This specifies how many label controls will be created
		Public UseFileViewer As Boolean = True 'If the third box will be shown
		
		Public DirDisplayed As String 'The path of the directory displayed
		Public DirToView As String 'The path of the directory displayed when the view button was clicked
		Public FileToView As String 'The path of the file clicked
		
				Public Event DirChange(s As Object, e As EventArgs) 'When another directory is changed
				Protected Sub OnDirChange(e As EventArgs)
						DirDisplayed = CType(CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).Controls(1), System.Web.UI.WebControls.Label).text
						RaiseEvent DirChange(Me, EventArgs.Empty)
				End Sub
				
				Public Event ViewClicked(s As Object, e As EventArgs) 'When the view link is clicked
				Protected Sub OnViewClicked(s As Object, e As EventArgs)
						DirToView = s.CommandArgument
						RaiseEvent ViewClicked(Me, EventArgs.Empty)
						If UseFileViewer Then
						LoadFiles(s, EventArgs.Empty)
						End If
				End Sub
				
				Public Event FileClicked(s As Object, e As EventArgs) 'When a file is clicked
				Protected Sub OnFileClicked(s As Object, e As EventArgs)
						FileToView = s.CommandArgument
						RaiseEvent FileClicked(Me, EventArgs.Empty)
				End Sub
		
		Dim MainDirLinks As System.Web.UI.WebControls.PlaceHolder = New System.Web.UI.WebControls.PlaceHolder()
		Dim SubDirLinks As System.Web.UI.WebControls.PlaceHolder = New System.Web.UI.WebControls.PlaceHolder()
		Dim FilesLinks As System.Web.UI.WebControls.PlaceHolder = New System.Web.UI.WebControls.PlaceHolder()

				Sub CreateMainDirs(s As Object, e As EventArgs) 'Gets the main directories of the specified path
					Dim PrimeDirs As String() = Directory.GetDirectories(Context.Request.MapPath(rPath))
					Dim i, str, Dirname
					For i = 0 to PrimeDirs.length - 1
					str = PrimeDirs(i)
					Dirname = "\" & mid(str, str.LastIndexOf(rPath) + 2, str.length - str.LastIndexOf(rPath))
					Dim newLink As System.Web.UI.WebControls.LinkButton
					newLink = New System.Web.UI.WebControls.LinkButton()
					newLink.text = mid(str, str.LastIndexOf("\") + 2, str.length - str.LastIndexOf("\"))
					newLink.CommandArgument = Dirname
					AddHandler newLink.Click, AddressOf Me.LoadNewDir
					MainDirLinks.Controls.Add(new LiteralControl("<img src='" & ImgsPath & "Folder.gif' align='absmiddle'>�"))
					MainDirLinks.Controls.Add(newLink)
					MainDirLinks.Controls.Add(new LiteralControl("<br>"))
					Next
					Dim ViewLink As System.Web.UI.WebControls.LinkButton
					ViewLink = New System.Web.UI.WebControls.LinkButton()
					ViewLink.text = "<img src='" & ImgsPath & "ViewWeb.gif' align='absmiddle' border='0'>�<i><font style='color:lightgreen'>View this directory!</font></i>"
					ViewLink.CommandArgument = rPath
					AddHandler ViewLink.Click, AddressOf Me.OnViewClicked
					MainDirLinks.Controls.Add(ViewLink)
					MainDirLinks.Controls.Add(new LiteralControl("<br>"))
				End Sub
				
		Protected Overrides Sub CreateChildControls()
		'Holder For MainDirs
			Dim BodyHolder As System.Web.UI.WebControls.PlaceHolder = New System.Web.UI.WebControls.PlaceHolder()
			BodyHolder.Controls.Add(new LiteralControl("<table class='" & TablesStyleClass & "' style='font-size:12px;color:white' width='" & TablesWidth & "' cellpadding='0'><tr><td><b>Main Directories:</b><br>"))
			BodyHolder.Controls.Add(new LiteralControl("<table width='100%' cellpadding='0' style='border: 1px solid #FFFFFF' class='defaulttext'><tr><td>"))
			CreateMainDirs(Me, EventArgs.Empty)
			BodyHolder.Controls.Add(MainDirLinks)
			BodyHolder.Controls.Add(new LiteralControl("</td></tr></table></td></tr></table>"))
			
			Me.Controls.Add(BodyHolder)
		'Holder For SubDirs
			Dim SubDirHolder As System.Web.UI.WebControls.PlaceHolder = New System.Web.UI.WebControls.PlaceHolder()
			SubDirHolder.visible = "False"
			Dim SubLabel As System.Web.UI.WebControls.Label = new System.Web.UI.WebControls.Label()
			SubLabel.text = "Unknown directory yet"
			SubDirHolder.Controls.Add(new LiteralControl("<p><table class='" & TablesStyleClass & "' style='font-size:12px;color:white' width='" & TablesWidth & "' cellpadding='0'><tr><td><b>"))
			SubDirHolder.Controls.Add(SubLabel)
			SubDirHolder.Controls.Add(new LiteralControl(":</b><br><table width='100%' cellpadding='0' style='border: 1px dashed #FFFFFF' class='defaulttext'><tr><td>"))
						Dim i As Integer
						SubDirLinks.visible = True
						'SubDirLinks.Controls.Clear
						For i = 0 to MaxSubDirs
						Dim newSubDir As System.Web.UI.WebControls.LinkButton = New System.Web.UI.WebControls.LinkButton()
						newSubDir.text = "Undefined Directory"
						newSubDir.CommandArgument = "/"
						newSubDir.visible = True
						AddHandler newSubDir.Click, AddressOf Me.LoadNewDir
						SubDirLinks.Controls.Add(newSubDir)
						Next
			SubDirHolder.Controls.Add(SubDirLinks)
				Dim FolderUpLink As System.Web.UI.WebControls.LinkButton = New System.Web.UI.WebControls.LinkButton()
				FolderUpLink.text = "<img src='" & ImgsPath & "FolderUp.gif' align='absmiddle' border='0'>�<i><font style='color:lightgreen'>Go to parent directory (up)!</font></i><br>"
				AddHandler FolderUpLink.Click, AddressOf Me.LoadNewDir
				SubDirHolder.Controls.Add(FolderUpLink)
				Dim ViewLink As System.Web.UI.WebControls.LinkButton = New System.Web.UI.WebControls.LinkButton()
				ViewLink.text = "<img src='" & ImgsPath & "ViewWeb.gif' align='absmiddle' border='0'>�<i><font style='color:lightgreen'>View this directory!</font></i>"
				AddHandler ViewLink.Click, AddressOf Me.OnViewClicked
				SubDirHolder.Controls.Add(ViewLink)
			SubDirHolder.Controls.Add(new LiteralControl("<br></td></tr></table></td></tr></table>"))
			Me.Controls.Add(SubDirHolder)
			
		'Holder For Optional FileViewer
			Dim FilesHolder As System.Web.UI.WebControls.PlaceHolder = New System.Web.UI.WebControls.PlaceHolder()
			FilesHolder.visible = "False"
			Dim FilesLabel As System.Web.UI.WebControls.Label = new System.Web.UI.WebControls.Label()
			FilesLabel.text = "Unknown directory yet"
			FilesHolder.Controls.Add(new LiteralControl("<p><table class='" & TablesStyleClass & "' style='font-size:12px;color:white' width='" & TablesWidth & "' cellpadding='0'><tr><td><b>"))
			FilesHolder.Controls.Add(FilesLabel)
			FilesHolder.Controls.Add(new LiteralControl(":</b><br><table width='100%' cellpadding='0' style='border: 1px dotted #FFFFFF' class='defaulttext'><tr><td>"))
						FilesLinks.visible = True
						For i = 0 to MaxFiles
						Dim newFiles As System.Web.UI.WebControls.LinkButton = New System.Web.UI.WebControls.LinkButton()
						newFiles.text = "Undefined Directory"
						newFiles.CommandArgument = "/"
						newFiles.visible = True
						AddHandler newFiles.Click, AddressOf Me.OnFileClicked
						FilesLinks.Controls.Add(newFiles)
						Next
			FilesHolder.Controls.Add(FilesLinks)
			
			FilesHolder.Controls.Add(new LiteralControl("</td></tr></table></td></tr></table>"))
			Me.Controls.Add(FilesHolder)
			
		End Sub
		
		
				Public Sub LoadNewDir(s As Object, e As EventArgs) 'Load a new dir to the second box
				'Context.Trace.Write("0")
				Dim strPath As String = s.CommandArgument
				'Context.Trace.Write("0-1")
				CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).visible="true"
				'Context.Trace.Write("0-2")
				CType(CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).Controls(1), System.Web.UI.WebControls.Label).text = strPath
				'Context.Trace.Write("0-3")
				CType(CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).Controls(5), System.Web.UI.WebControls.LinkButton).CommandArgument = strPath
				'Context.Trace.Write("1")
							Dim ti As Integer
							For ti = 0 to SubDirLinks.Controls.Count - 1
							CType(CType(CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).Controls(3), System.Web.UI.WebControls.PlaceHolder).Controls(ti), System.Web.UI.WebControls.LinkButton).visible = "False"
							Next
				'Context.Trace.Write("2")
						Dim PrimeDirs As String() = Directory.GetDirectories(Context.Request.MapPath(strPath))
						Dim i, str, Dirname
						For i = 0 to PrimeDirs.length - 1
						If i < SubDirLinks.Controls.Count Then
						str = PrimeDirs(i)
						Dirname = "\" & mid(str, str.LastIndexOf(rPath) + 2, str.length - str.LastIndexOf(rPath))
						CType(CType(CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).Controls(3), System.Web.UI.WebControls.PlaceHolder).Controls(i), System.Web.UI.WebControls.LinkButton).visible = "True"
						CType(CType(CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).Controls(3), System.Web.UI.WebControls.PlaceHolder).Controls(i), System.Web.UI.WebControls.LinkButton).text = "<img src='" & ImgsPath & "Folder.gif' align='absmiddle' border='0'>�" & mid(str, str.LastIndexOf("\") + 2, str.length - str.LastIndexOf("\")) & "<br>"
						CType(CType(CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).Controls(3), System.Web.UI.WebControls.PlaceHolder).Controls(i), System.Web.UI.WebControls.LinkButton).CommandArgument = Dirname
						End If
						Next
				'Context.Trace.Write("3")
				If Not strPath = rPath Then
				Dim UpPath As String
				UpPath = mid(strPath, 1, strPath.LastIndexOf("\"))
				CType(CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).Controls(4), System.Web.UI.WebControls.LinkButton).CommandArgument = UpPath
				End If
				'Context.Trace.Write("4")
				OnDirChange(EventArgs.Empty)
				End Sub
				
				
				Sub LoadFiles(s As Object, e As EventArgs) 'Load the files to the fileviewer
				Dim WorkDir As String = s.CommandArgument
				CType(Controls(2), System.Web.UI.WebControls.PlaceHolder).visible="true"
				CType(CType(Controls(2), System.Web.UI.WebControls.PlaceHolder).Controls(1), System.Web.UI.WebControls.Label).text = WorkDir
				
							Dim ti As Integer
							For ti = 0 to FilesLinks.Controls.Count - 1
							CType(CType(CType(Controls(2), System.Web.UI.WebControls.PlaceHolder).Controls(3), System.Web.UI.WebControls.PlaceHolder).Controls(ti), System.Web.UI.WebControls.LinkButton).visible = "False"
							Next
							
						Dim PrimeFiles As String() = Directory.GetFiles(Context.Request.MapPath(WorkDir))
						Dim i, str, Filename, Thumb
						For i = 0 to PrimeFiles.length - 1
						If i < FilesLinks.Controls.Count Then
						str = PrimeFiles(i)
						Filename = "\" & mid(str, str.LastIndexOf(rPath) + 2, str.length - str.LastIndexOf(rPath))
						CType(CType(CType(Controls(2), System.Web.UI.WebControls.PlaceHolder).Controls(3), System.Web.UI.WebControls.PlaceHolder).Controls(i), System.Web.UI.WebControls.LinkButton).visible = "True"
						Thumb = ImgsPath & "File" & mid(Filename, Filename.LastIndexOf(".")+2, Filename.length - Filename.LastIndexOf(".")) & ".gif"
						If Not File.Exists(Context.Request.MapPath(Thumb)) Then
						Thumb = ImgsPath & "File.gif" 'Use this general icon if the icon for the extension of one file isn't found
						End If
						CType(CType(CType(Controls(2), System.Web.UI.WebControls.PlaceHolder).Controls(3), System.Web.UI.WebControls.PlaceHolder).Controls(i), System.Web.UI.WebControls.LinkButton).text = "<img src='" & Thumb & "' align='absmiddle' border='0'>�" & mid(str, str.LastIndexOf("\") + 2, str.length - str.LastIndexOf("\")) & "<br>"
						CType(CType(CType(Controls(2), System.Web.UI.WebControls.PlaceHolder).Controls(3), System.Web.UI.WebControls.PlaceHolder).Controls(i), System.Web.UI.WebControls.LinkButton).CommandArgument = Filename
						End If
						Next
				End Sub
    End Class
	
	
	
	
	'---------------------- POLLS CLASS ------------------------------------
	'----------------------------------------------------------------------------
	'----------------------------------------------------------------------------
	'----------------------------------------------------------------------------

	
    Public Class Poll
	Inherits Control
	Implements INamingContainer
	
	Public TableWidth As String = "200" 'The width of the box
	Public DbConStr As String = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" & Context.Request.MapPath("Files/TextFiles.mdb") 'The string to connect to the database
	Public ID22Show As Integer = 0
	Public IDSelected As Integer
	Public MaxSelections As Integer = 9 'The maximum possible answers. The number of answer fields in the database should be so many.
	Public PercentageTablesMaxWidth As Integer = 140 'The maximum width of the tables that show the result percentage
	Public RandomPoll As Boolean = False 'If the poll should search randomly the database
	Public DisposeIfAlreadyShown As Boolean = True 'If RandomPoll is true, then the control is shown only if it can find randomly a poll not already shown on the page.
	Public PollUsersTxt As String = "Files/PollUsers.txt" 'If a poll doesn't accept multiple votes, here the users that have already voted are written

	Dim OptionsAlreadyAdded As Boolean = False
	Dim PreviousStates As String = ""
	Dim PreviousPollsCount As Integer = 0
	Dim PollStats As New System.Data.DataSet()
	Dim IDs As New System.Data.DataSet()
	Dim PollOptions As New System.Collections.Hashtable()
    Dim pAdapter As System.Data.IDbDataAdapter = New System.Data.OleDb.OleDbDataAdapter
	Dim i As Integer
	
	Public Property ID2Show As Integer
	Get
		return Viewstate("ID2Show" & Me.UniqueID)
		'return ID22Show
	End Get
	Set
		Viewstate("ID2Show" & Me.UniqueID) = value
		'ID22Show = value
	End Set
	End Property
	
	Private Property IDsShown As String 'This searches the parent page for other Poll controls and get their pollIDs
	Set
		PreviousStates = value
	End Set
	Get
		Dim cc
		Dim PreviousStatesT As String = PreviousStates
		For Each cc In Page.Controls(0).Controls
			If cc.GetType().Fullname = "TPControls.Poll" Then
			If Not cc.UniqueID = Me.UniqueID Then
			  PreviousStatesT = PreviousStatesT & "-" & cc.ID2Show & "-"
			  PreviousPollsCount = PreviousPollsCount + 1
			End If
			 End If
		Next
		return PreviousStatesT
	End Get
	End Property
	
	
		Protected Overrides Sub CreateChildControls()
			If Not Page.IsPostBack Then
			DetermineID2Show 'Get the pollID for this control
			End If
		If Me.Visible Then
			GetPollFiles 'Retrieve info about the specified pollID from the database
							Dim RandomPollMsg As String = ""
							If RandomPoll Then RandomPollMsg="Random "
			Controls.Add(new LiteralControl("<table width='" & TableWidth & "' cellpadding='2' cellspacing='0'><tr><td class='PollTableUp' width='100%' bgcolor='#49525B'><font style='font-size:14px'><b>" & RandomPollMsg & "Poll #" & PollStats.Tables(0).Rows(0).Item(0) & ":</b></font><BR><b>" & PollStats.Tables(0).Rows(0).Item(2) & "</b></td></tr><tr><td width='100%' bgcolor='#535D67' class='PollTableDown'><BR>"))
				Dim Selections As new System.Web.UI.WebControls.PlaceHolder()
				Selections.ID = "Selections-" & ID2Show & "-" & Me.UniqueID
				For i=1 to PollStats.Tables(0).Rows(0).Item(6)
					Dim NewSelection As new System.Web.UI.WebControls.RadioButton()
					NewSelection.GroupName = Me.UniqueID
					NewSelection.ID = "Answer-" & i & "-" & ID2Show & "-" & Me.UniqueID
					NewSelection.text = PollStats.Tables(0).Rows(0).Item(6 + i) & "<br>"
					NewSelection.EnableViewState = True
					Selections.Controls.Add(NewSelection)
				Next
				Selections.Controls.Add(new LiteralControl("<p>Poll Created On: " & PollStats.Tables(0).Rows(0).Item(4) & " by " & PollStats.Tables(0).Rows(0).Item(5) & "<br>Category: <i>" & PollOptions("Category") & "</i>"))
			Controls.Add(Selections)
				Dim Result1 As New System.Web.UI.WebControls.Label()
				Result1.id = "Result1-" & ID2Show & "-" & Me.UniqueID
			Controls.Add(Result1)
				Dim ResultsPlace As new System.Web.UI.WebControls.PlaceHolder()
				ResultsPlace.ID = "ResultsPlace-" & ID2Show & "-" & Me.UniqueID
				ResultsPlace.Controls.Add(new LiteralControl("<p><b><u>Vote Results:</u></b><br>"))
				ResultsPlace.visible = False
					Dim TotalVoteResult As new System.Web.UI.WebControls.Label()
					TotalVoteResult.ID = "TotalVoteResult-" & i & "-" & ID2Show & "-" & Me.UniqueID
					ResultsPlace.Controls.Add(TotalVoteResult)
				For i=1 to PollStats.Tables(0).Rows(0).Item(6)
					Dim VoteResult As new System.Web.UI.WebControls.Label()
					VoteResult.ID = "VoteResult-" & i & "-" & ID2Show & "-" & Me.UniqueID
					ResultsPlace.Controls.Add(VoteResult)
				Next
					Dim HideResultsPlace As new System.Web.UI.WebControls.LinkButton()
					HideResultsPlace.text = "Hide Results"
					HideResultsPlace.id = "HideResultsPlace-" & ID2Show & "-" & Me.UniqueID
					AddHandler HideResultsPlace.Click, AddressOf Me.HideResults
				ResultsPlace.Controls.Add(HideResultsPlace)
			Controls.Add(ResultsPlace)
			Controls.Add(new LiteralControl("<br><br><table width='100%' cellpadding='0' cellspacing='0' width='100%' bgcolor='#364372'><tr><td bgcolor='#49525B' class='defaulttext'>"))
				Dim VoteLink As new System.Web.UI.WebControls.LinkButton()
				VoteLink.text = "Vote!"
				VoteLink.id = "VoteLink-" & ID2Show & "-" & Me.UniqueID
				AddHandler VoteLink.Click, AddressOf Me.CastVote
			Controls.Add(VoteLink)
			Controls.Add(new LiteralControl("</td><td width='100%' bgcolor='#49525B' align='right' class='defaulttext'>"))
				Dim ResultsLink As new System.Web.UI.WebControls.LinkButton()
				ResultsLink.text = "Current Results"
				ResultsLink.id = "ResultsLink-" & ID2Show & "-" & Me.UniqueID
				AddHandler ResultsLink.Click, AddressOf Me.ShowResults
			Controls.Add(ResultsLink)
			Controls.Add(new LiteralControl("</td></tr></table></td></tr></table>"))
		End If
			Context.Trace.Write("TPControls","CreateChildControls executed for control with Id " & Me.UniqueID & "that is visible=" & Me.Visible)
		End Sub
	
	
		Sub GetPollFiles
			     Dim dbConnection As System.Data.IDbConnection = New System.Data.OleDb.OleDbConnection(DbConStr)
				 Dim queryString As String = "SELECT * FROM tblPolls WHERE ID_No=" & ID2Show
                 Dim dbCommand As System.Data.IDbCommand = New System.Data.OleDb.OleDbCommand
                 dbCommand.CommandText = queryString
                 dbCommand.Connection = dbConnection
                 pAdapter.SelectCommand = dbCommand
                 pAdapter.Fill(PollStats)
				 dbConnection.Close()
				 		'Options
				 If Not OptionsAlreadyAdded Then
				 PollOptions.Add("MultipleVotes", CBool(CStr(PollStats.Tables(0).Rows(0).Item(1)).substring(0, CStr(PollStats.Tables(0).Rows(0).Item(1)).indexOf(","))))
				 PollOptions.Add("OnlyUsers", CBool(CStr(PollStats.Tables(0).Rows(0).Item(1)).substring(CStr(PollStats.Tables(0).Rows(0).Item(1)).indexOf(",")+1, CStr(PollStats.Tables(0).Rows(0).Item(1)).LastindexOf(",") - (CStr(PollStats.Tables(0).Rows(0).Item(1)).indexOf(",") + 1))))
				 PollOptions.Add("Category", CStr(PollStats.Tables(0).Rows(0).Item(1)).substring(CStr(PollStats.Tables(0).Rows(0).Item(1)).indexOf("'")+1, CStr(PollStats.Tables(0).Rows(0).Item(1)).LastindexOf("'") - (CStr(PollStats.Tables(0).Rows(0).Item(1)).indexOf("'")+1)))
				 OptionsAlreadyAdded = True
				 End if
				 Context.Trace.Write("TPControls","GetPollFiles Executed for control with Id " & Me.UniqueID)
		End Sub
		
		
		Sub DetermineID2Show
		If RandomPoll Then
			     Dim dbConnection As System.Data.IDbConnection = New System.Data.OleDb.OleDbConnection(DbConStr)
				 Dim queryString As String = "SELECT ID_No,Options FROM tblPolls"
                 Dim dbCommand As System.Data.IDbCommand = New System.Data.OleDb.OleDbCommand
                 dbCommand.CommandText = queryString
                 dbCommand.Connection = dbConnection
                 pAdapter.SelectCommand = dbCommand
                 pAdapter.Fill(IDs)
				 dbConnection.Close()
				 Dim RandomInt As Integer
				 If DisposeIfAlreadyShown Then
					 Do
						 Dim newRandom As Object = new Random
						 RandomInt = newRandom.Next(0, IDs.Tables(0).Rows.Count)
						 ID2Show = IDs.Tables(0).Rows(RandomInt).Item(0)
						 If IDs.Tables(0).Rows.Count < PreviousPollsCount Then
						 Me.visible = False
						 Context.Trace.Warn("TPControls",Me.UniqueID & " was made invisible because it cannot find another available poll id that is not already shown. Polls counted:" & PreviousPollsCount)
						 Exit Do
						 End If
					 Loop Until CStr(IDsShown).indexOf("-" & ID2Show & "-") = -1 AND CStr(IDs.Tables(0).Rows(RandomInt).Item("Options")).indexOf("Test Polls") = -1
				 Else
					 Dim newRandom As Object = new Random
					 ID2Show = IDs.Tables(0).Rows(newRandom.Next(0, IDs.Tables(0).Rows.Count)).Item(0)
				 End If
		Else
				If DisposeIfAlreadyShown And Not CStr(IDsShown).indexOf("-" & ID2Show & "-") = -1 Then
				If IsOtherIDvisible Then
				Me.visible = False
				Context.Trace.Warn("TPControls",Me.UniqueID & " was made invisible because its poll id is already shown. Polls Counted:" & PreviousPollsCount)
				ENd If
				End if
		End If
		End Sub
		
		
		Sub CastVote(s As Object, e As EventArgs)
		Dim GoOn4Cast As Boolean = True
		Dim ErrorExplain As String = "No error occurred, sorry for the inconvenience"
		If PollOptions("OnlyUsers") And Not Context.User.Identity.IsAuthenticated Then
		GoOn4Cast = False
		ErrorExplain = "This poll accepts votes only from authenticated users. Please log in, and then try again."
		Else
				If Not PollOptions("MultipleVotes") Then
				If HasAlreadyVoted Then
				GoOn4Cast = False
				ErrorExplain = "This poll does not accept multiple votes. You have already voted in this poll."
				End If
				End If
		End If
			If CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).visible And GoOn4Cast Then
                 Dim EditConnection As New OleDbConnection(DbConStr)
                 Dim UpdateVotes As New OleDbCommand("UPDATE [tblPolls] SET [AnswerVotes" & GetSelection & "]=" & CInt(PollStats.Tables(0).Rows(0).Item(6 + MaxSelections + GetSelection) + 1) & " WHERE [ID_No]=" & ID2Show, EditConnection)
				 Dim UpdateTotalVotes As New OleDbCommand("UPDATE [tblPolls] SET [TotalVotes]=" & CInt(PollStats.Tables(0).Rows(0).Item(3) + 1) & " WHERE [ID_No]=" & ID2Show, EditConnection)
                 EditConnection.Open()
                 UpdateVotes.ExecuteNonQuery()
				 UpdateTotalVotes.ExecuteNonQuery()
				 EditConnection.Close()
				 CType(Controls(2), System.Web.UI.WebControls.Label).text = "<p><b>Your vote has been counted!</b>"
				 CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).visible = False
				 WriteVote2Txt
				 Context.Trace.Write("TPControls","CastVote Executed for control with Id " & Me.UniqueID & " with 'OnlyUsers'=" & PollOptions("OnlyUsers") & " and with 'MultipleVotes'=" & PollOptions("MultipleVotes") & " and with 'Category'=" & PollOptions("Category"))
			Else
				If Not GoOn4Cast Then
				 CType(Controls(2), System.Web.UI.WebControls.Label).text = "<p><b>Your vote has not been counted!</b><br>" & ErrorExplain
				 CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).visible = False
				 Context.Trace.Warn("TPControls","CastVote was not executed for control with Id " & Me.UniqueID & ". Error: " & ErrorExplain)
				End If
			End If
		End Sub
		
		Sub ShowResults(s As Object, e As EventArgs)
		CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).visible = False
		CType(Controls(2), System.Web.UI.WebControls.Label).visible = False
		CType(Controls(3), System.Web.UI.WebControls.PlaceHolder).visible = True
		GetPollFiles
			For i=1 to PollStats.Tables(0).Rows(0).Item(6)
				Dim newpercent As Integer = 0
				newpercent = Cint((PollStats.Tables(0).Rows(0).Item(6 + MaxSelections + i) * 100) / PollStats.Tables(0).Rows(0).Item(3))
				CType(CType(Controls(3), System.Web.UI.WebControls.PlaceHolder).Controls(1 + i), System.Web.UI.WebControls.Label).text = "<table cellpadding='0' cellspacing='0' border='0' width='100%'><tr><td class='defaulttext' width='100%'>" & i & ") " & newpercent & "%</td><td><table cellpadding='0' width='" & Cint((newpercent / 100) * PercentageTablesMaxWidth) & "' bgcolor='red' style='border-left: 2px solid darkred'><tr><td><font style='font-size:1px;color:red'>.</font></td></tr></table></td></tr></table>"
			Next
		CType(CType(Controls(3), System.Web.UI.WebControls.PlaceHolder).Controls(1), System.Web.UI.WebControls.Label).text = "Total Votes: " & PollStats.Tables(0).Rows(0).Item(3) & "<br>"
		Context.Trace.Write("TPControls","ShowResults Executed for control with Id " & Me.UniqueID)
		End Sub
		
		Sub HideResults(s As Object, e As EventArgs)
		CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).visible = True
		CType(Controls(2), System.Web.UI.WebControls.Label).visible = True
		CType(Controls(3), System.Web.UI.WebControls.PlaceHolder).visible = False
		Context.Trace.Write("TPControls","HideResults Executed for control with Id " & Me.UniqueID)
		End Sub
		
		Function GetSelection As Integer
			Dim pp As Integer
			For pp = 0 to CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).Controls.Count - 1
				If CType(CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).Controls(pp), System.Web.UI.WebControls.RadioButton).checked Then
					return pp + 1
					Exit For
				End If
			Next
			return -1
			Context.Trace.Write("TPControls","GetSelection Executed for control with Id " & Me.UniqueID)
		End Function
		
		Function IsOtherIDvisible As Boolean
			Dim cc
			For Each cc In Page.Controls(0).Controls
				If cc.GetType().Fullname = "TPControls.Poll" Then
				If Not cc.UniqueID = Me.UniqueID Then
				  If cc.ID2Show = ID2Show Then
				  return  cc.visible
				  End If
				End If
				 End If
			Next
			Context.Trace.Write("TPControls","IsOtherIDvisible Executed for control with Id " & Me.UniqueID)
		End Function
		
		Function HasAlreadyVoted As Boolean
		Dim wt2return As Boolean = False
		Dim txtFrag As String
		Dim Alltxt As String = ReadTxt(PollUsersTxt)
		
		If Not Alltxt.indexOf("#$" & ID2Show & "$#") = -1 Then
		txtFrag = Alltxt.substring(Alltxt.indexOf("#$" & ID2Show & "$#") + 4 + CStr(ID2Show).length, Alltxt.indexOf(":" & ID2Show & ":") - (Alltxt.indexOf("#$" & ID2Show & "$#") + 4 + CStr(ID2Show).length))
			If PollOptions("OnlyUsers") Then
			If Not txtFrag.indexOf("," & Context.User.Identity.Name & ",") = -1 Then wt2return = True
			Else
			If Not txtFrag.indexOf("," & Context.Request.UserHostAddress & ",") = -1 Then wt2return = True
			End If
		Else
		wt2return = False
		End If
		return wt2return
		End Function
		
		Sub WriteVote2Txt
		If Not PollOptions("MultipleVotes") Then
			Dim Alltxt As String = ReadTxt(PollUsersTxt)
			
			Dim objStreamWriter As StreamWriter
			objStreamWriter = File.CreateText(Context.Request.MapPath(PollUsersTxt))
			If Not Alltxt.indexOf("#$" & ID2Show & "$#") = -1 Then
					Dim txtFrag As String = Alltxt.substring(Alltxt.indexOf("#$" & ID2Show & "$#") + 4 + CStr(ID2Show).length, Alltxt.indexOf(":" & ID2Show & ":") - (Alltxt.indexOf("#$" & ID2Show & "$#") + 4 + CStr(ID2Show).length))
					If Context.User.Identity.IsAuthenticated Then
					Alltxt = Replace(Alltxt, txtFrag, txtFrag & "," & Context.User.Identity.Name & ",")
					Else
					Alltxt = Replace(Alltxt, txtFrag, txtFrag & "," & Context.Request.UserHostAddress & ",")
					End If
			Else
					If Context.User.Identity.IsAuthenticated Then
					Alltxt = Alltxt & "#$" & ID2Show & "$#" & "," & Context.User.Identity.Name & "," & ":" & ID2Show & ":"
					Else
					Alltxt = Alltxt & "#$" & ID2Show & "$#" & "," & Context.Request.UserHostAddress & "," & ":" & ID2Show & ":"
					End If
			End If
			objStreamWriter.WriteLine(Alltxt)
			objStreamWriter.Close
		End if
		Context.Trace.Write("TPControls","WriteVote2Txt Executed for control with Id " & Me.UniqueID)
		End Sub
		
				Function ReadTxt(ByVal TxtPath As String) As String
					Dim Wt2Return As String
					if File.Exists(Context.Request.MapPath(TxtPath)) Then
							Dim objStreamReader As StreamReader
							Dim strInput As String
							objStreamReader = File.OpenText(Context.Request.MapPath(TxtPath))
							Wt2Return = objStreamReader.ReadToEnd()
								objStreamReader.Close
								objStreamReader = Nothing
								strInput = Nothing
					Else
							Wt2Return = ""
					End If
							return Wt2Return
				End Function
		
		 Private Function TakeHashString(ByVal obj2Hash) As String 'For the password maybe
              Dim strHash As String = ""
              Dim HashValue() As Byte
              Dim TempB As Byte
              Dim UE As New UnicodeEncoding()
              Dim PassBytes As Byte() = UE.GetBytes(obj2Hash)
              Dim SHhash As New System.Security.Cryptography.SHA1Managed()
              HashValue = SHhash.ComputeHash(PassBytes)
                  For Each TempB In HashValue
                      strHash = strHash & TempB
                  Next TempB
              strHash = StrReverse(strHash)
			  
              return strHash
			  			  		HashValue = Nothing
					TempB = Nothing
					UE = Nothing
					PassBytes = Nothing
					SHhash = Nothing
         End Function
		
	End Class
	
	
	'---------------------- TITLE CLASS ------------------------------------
	'----------------------------------------------------------------------------
	'----------------------------------------------------------------------------
	'----------------------------------------------------------------------------
	
	
	Public Class Title
	Inherits Control
	Implements INamingContainer
	
	Public Style As Integer = 1
	Public Width As String = "537"
	Public Height As String = "26"
	Public ArrowAnchor As String = "#top"
	
			Protected Overrides Sub CreateChildControls()
							Dim BodyHolder
							BodyHolder = New System.Web.UI.WebControls.PlaceHolder()
							BodyHolder.ID = "TitleBodyHolder" & Me.UniqueID
								Dim CControl
								For Each CControl In Me.Controls
									BodyHolder.Controls.Add(CControl)
								Next
				Select Case Style
					Case 1
						Me.Controls.Add(new LiteralControl("<table cellpadding='0' cellspacing='0' height='26'><tr><td width='" & Width & "' height='" & Height & "' BACKGROUND='Images/Menu/TitlesSectionsBar.gif' class='TitlesSectionsBar'>"))
						Me.Controls.Add(BodyHolder)
						Me.Controls.Add(new LiteralControl("</td><td BACKGROUND='Images/Menu/TitlesSectionsBarArrow.gif' class='TitlesSectionsBarArrow'><a href='" & ArrowAnchor & "'><img src='Images/Menu/TitlesSectionsBarBlank.gif' border='0' width='23' height='26'></a></td></tr></table>"))
					Case 2
						Me.Controls.Add(new LiteralControl("<table cellpadding='0' cellspacing='0' height='26'><tr><td width='" & Width & "' height='" & Height & "' BACKGROUND='Images/Menu/TitlesSectionsBar.gif' class='TitlesSectionsBar'>"))
						Me.Controls.Add(BodyHolder)
						Me.Controls.Add(new LiteralControl("</td><td BACKGROUND='Images/Menu/TitlesSectionsBarArrow.gif' class='TitlesSectionsBarArrow'><a href='" & ArrowAnchor & "'><img src='Images/Menu/TitlesSectionsBarBlank.gif' border='0' width='23' height='26'></a></td></tr></table>"))
				End Select
			End Sub
	
	End Class
	
	
	'---------------------- NEWS CLASSES ------------------------------------
	'----------------------------------------------------------------------------
	'----------------------------------------------------------------------------
	'----------------------------------------------------------------------------
	
	
	Public Class News
	Inherits Control
	Implements INamingContainer
	
	Public Width As String = "95%"
	Public Title As String = "Undefined Title"
	Public byStr As String = "by -Unknown- (Unknown date)"
	Public UseRandomBottomBorder As Boolean = True
	Public fOpened As Boolean = False
	
	Public Property aOpened As Boolean
	Get
		return CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).visible
	End Get
	Set
		If value Then
			CType(CType(Controls(2), System.Web.UI.WebControls.PlaceHolder).Controls(1), System.Web.UI.WebControls.LinkButton).text = "Hide"
		Else
			CType(CType(Controls(2), System.Web.UI.WebControls.PlaceHolder).Controls(1), System.Web.UI.WebControls.LinkButton).text = "Show"
		End If
		CType(Controls(1), System.Web.UI.WebControls.PlaceHolder).visible = value
	End Set
	End Property
	
	Dim i
	
			Protected Overrides Sub CreateChildControls()
							Dim MainBody As New System.Web.UI.WebControls.PlaceHolder()
							For Each i in Me.Controls
								MainBody.Controls.Add(i)
							Next
							MainBody.ID = "NewsMainBody" & Me.UniqueID
							MainBody.visible = fOpened
					Dim PrePlace As New System.Web.UI.WebControls.PlaceHolder()
					PrePlace.ID = "NewsPrePlace" & Me.UniqueID
					PrePlace.Controls.Add(new LiteralControl("<center><table width='" & Width & "' cellpadding='0'><tr><td><table cellpadding='0' cellspacing='0' bgcolor='#6F7E8D' class='defaulttext' width='100%'><tr><td class='News-News'>�<b>News!</b>�</td><td style='font-size:14px' width='70%'>" & Title))
					PrePlace.Controls.Add(new LiteralControl("</td><td class='News-By' align='right'>���" & byStr & "</td></tr></table></td></tr><tr><td class='News-Main' width='100%' valign='top'>"))
				Controls.Add(PrePlace)
				Controls.Add(MainBody)
					Dim LastPlace As New System.Web.UI.WebControls.PlaceHolder()
					LastPlace.ID = "NewsLastPlace" & Me.UniqueID
					Dim nInt As Integer = 65
					Dim nRandom As New Random((Title.length + byStr.length) * 3)
						If UseRandomBottomBorder Then
						nInt = nRandom.Next(40,75)
						End If
					LastPlace.Controls.Add(new LiteralControl("</td></tr><tr><td width='100%'><table width='100%' cellpadding='0' cellspacing='0' width='100%'><td width='" & nInt & "%'></td><td width='" & (100 - nInt) & "%' class='News-HideShow' align='right'>"))
							Dim ShowHideLink As New System.Web.UI.WebControls.LinkButton()
							AddHandler ShowHideLink.Click, AddressOf Me.ShowOrHide
							If fOpened Then
							ShowHideLink.text = "Hide"
							Else
							ShowHideLink.text = "Show"
							End If
							ShowHideLink.ID = "ShowHideLink" & Me.UniqueID
					LastPlace.Controls.Add(ShowHideLink)
					LastPlace.Controls.Add(new LiteralControl("</td></tr></table></td></tr></table></center>"))
				Controls.Add(LastPlace)
			End Sub
	
			
			Sub ShowOrHide(s As Object, e As EventArgs)
				If aOpened Then
					aOpened = False
				Else
					aOpened = True
				End If
			End Sub
		 
	End Class
	
	'---------------------- IMAGE EDITOR CLASS ----------------------------------
	'----------------------------------------------------------------------------
	'----------------------------------------------------------------------------
	'----------------------------------------------------------------------------
	
	
Public Class ImageEdit
	Inherits Control
	Implements INamingContainer
	
	Public UseOverlibHelp As Boolean = False 'If this is true, you must have installed the overlib javascript script. Then, help is provided at some points with "(?)"
	Public UseTextureBrush As Boolean = True 'On my PC, the texture brush presents an Out Of Memory asp.net error. So, turn it off with this boolean.
	Public UseImageAdd As Boolean = True 'Check if you allow users to locate an image on the server and load it on the edit image.
	Public ImageEditoraspxPath As String = "/Files/IMG-ImageEditor.aspx"
	
	Dim i,dt,dr,dv
	Public q As System.Collections.Hashtable = new System.Collections.Hashtable()
	Public p As System.Drawing.Drawing2D.GraphicsPath = new System.Drawing.Drawing2D.GraphicsPath()
	
	Protected Overrides Sub CreateChildControls()
		LoadUpHashtable 'If a hashtable is in the session (from previous edits), load it up for editing, else make a deafult hashtable
		Controls.Add(new LiteralControl("<center><table width='90%'><tr><td style='border:1px solid black' class='defaulttext'><center>"))
			Dim EditImg As System.Web.UI.WebControls.ImageButton = new System.Web.UI.WebControls.ImageButton()
			EditImg.ID = "oImageEdited"
			EditImg.ImageUrl = ImageEditoraspxPath
			AddHandler EditImg.Click, AddressOf Me.ShowEditImgCoord
		Controls.Add(EditImg)
		Controls.Add(new LiteralControl("<br>" & mkhelp("This image is what you have created until now. You can save it by right-clicking on it and clicking the appropriate command. Save the file with the extension .gif/.jpg according to the type you selected. Also, you can find the coordinates of the point you click on the image.") & " X:"))
			Dim imgXlabel As System.Web.UI.WebControls.Label = new System.Web.UI.WebControls.Label()
			imgXlabel.ID = "oimgXlabel"
			imgXlabel.text = 0
		Controls.Add(imgXlabel)
		Controls.Add(new LiteralControl(" Y:"))
			Dim imgYlabel As System.Web.UI.WebControls.Label = new System.Web.UI.WebControls.Label()
			imgYlabel.ID = "oimgYlabel"
			imgYlabel.text = 0
		Controls.Add(imgYlabel)
		Controls.Add(new LiteralControl("</center></td><td width='100%' class='defaulttext' style='border: 1px solid black' valign='top'><b><u><font class='ImageEditorTitle'>Image Editor Wizard " & mkhelp("Click here to open a window with full instructions on how to use the editor. Some help is still available by hovering over question marks but can be confusing if you have not read these instructions.", 12,GetMainHelpStr) & " :</font></u></b><p>"))
			'ACT placeholder
			Dim ActEdits As Object = new System.Web.UI.WebControls.PlaceHolder()
			ActEdits.ID = "oActEdits"
			ActEdits.Controls.Add(new LiteralControl("<font class='ImageEditorMainTitle'><b>1.</b> Act Edit " & mkhelp("Click here to open a window with some help for this section.", 12, "><font color=orange size=3>Act Edit explanation:</font><br>With the acts, you can draw things on the Image. Two types of acts are now supported: Path & Image.<p><b>Path:</b>Paths can contain shapes and text. They are drawn with the brush you specify.<p><b>Image:</b> You can draw images from the server.<p>The order of acts is very important. You specify the order by the Act Number. The lower the position of the act, the first it will be drawn. That is, the next act to be drawn, will be drawn over it (if it has such coordinates) -that is where opacity is useful-. Specifying an act over an already specified act is possible. Also, be sure to count right, and not leave numbers.<p>Coordinates specify where things are drawn on the image. You can get the coordinates of a point on the image by clicking the image.") & " :</font><br>"))
			ActEdits.Controls.Add(new LiteralControl("Act Number " & mkhelp("Each number is a command. You must change this (+1) for each new act you want to add. If you want to delete an act, change this number to accord the act you want to delete and click the appropriate button (counting must continue from where you stopped normally). Acts that are already present will be replaced when the add act is clicked.)") & ": "))
				Dim txtActNumber As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
				txtActNumber.ID = "otxtActNumber"
				txtActNumber.MaxLength = 2
				txtActNumber.CssClass = "ImageEditorTxtBox"
				txtActNumber.Text = 1
			ActEdits.Controls.Add(txtActNumber)
			ActEdits.Controls.Add(new LiteralControl(" , Type:"))
				Dim ActTypeDrop As System.Web.UI.WebControls.DropDownList = new System.Web.UI.WebControls.DropDownList()
				ActTypeDrop.ID = "oActTypeDrop"
				ActTypeDrop.CssClass = "ImageEditorTxtBoxNoWidthRestr"
					dt = New DataTable()
					dt.Columns.Add(New DataColumn("StringValue", GetType(String)))
					dr = dt.NewRow()
					dr(0) = "Path"
					dt.Rows.Add(dr)
					If UseImageAdd Then
					dr = dt.NewRow()
					dr(0) = "Image"
					dt.Rows.Add(dr)
					End If
					dv = New DataView(dt)
				ActTypeDrop.DataSource = dv
				ActTypeDrop.DataTextField = "StringValue"
				ActTypeDrop.DataValueField = "StringValue"
				ActTypeDrop.DataBind()
					dt = Nothing
					dr = Nothing
					dv = Nothing
				ActTypeDrop.SelectedIndex = 0
			ActEdits.Controls.Add(ActTypeDrop)
				Dim aChangeActType As System.Web.UI.WebControls.LinkButton = new System.Web.UI.WebControls.LinkButton()
				aChangeActType.text = " Change Type!"
				aChangeActType.ID = "oaChangeActType"
				AddHandler aChangeActType.Click, AddressOf Me.ChangeActType
			ActEdits.Controls.Add(aChangeActType)
			ActEdits.Controls.Add(new LiteralControl("<br>"))
				Dim ActPath As System.Web.UI.WebControls.Placeholder = new System.Web.UI.WebControls.Placeholder()
				ActPath.ID = "oActPath"
				'ActPath.visible = False
				ActPath.Controls.Add(new LiteralControl("<br><font class='ImageEditorTitle'>Path " & mkhelp("The path can contain many types (shapes and text). To select which type to add to the current path, select one from the dropdownlist. Then click the next link. Shapes require coordinates and specifications. Coordinates can be retrieved by clicking on the image. Text requires coordinates and font specs. The Path also required a wrap mode (if areas that coincide will be drawn or not). The brush is intended for all the path. Then click the Add Act button.") & " :</font> "))
					Dim PathFillBrush As System.Web.UI.WebControls.Checkbox = new System.Web.UI.WebControls.Checkbox()
					PathFillBrush.ID = "oPathFillBrush"
					PathFillBrush.text = "Fill with brush"
					PathFillBrush.checked = True
				ActPath.Controls.Add(PathFillBrush)
				ActPath.Controls.Add(new LiteralControl(" , Wrap mode:"))
					Dim PathFillMode As System.Web.UI.WebControls.DropDownList = new System.Web.UI.WebControls.DropDownList()
					PathFillMode.ID = "oPathFillMode"
					PathFillMode.CssClass = "ImageEditorTxtBoxNoWidthRestr"
						dt = New DataTable()
						dt.Columns.Add(New DataColumn("StringValue", GetType(String)))
						dt.Columns.Add(New DataColumn("FillModeValue", GetType(String)))
						dr = dt.NewRow()
						dr(0) = "Alternate"
						dr(1) = 0
						dt.Rows.Add(dr)
						dr = dt.NewRow()
						dr(0) = "Winding"
						dr(1) = 1
						dt.Rows.Add(dr)
						dv = New DataView(dt)
					PathFillMode.DataSource = dv
					PathFillMode.DataTextField = "StringValue"
					PathFillMode.DataValueField = "FillModeValue"
					PathFillMode.DataBind()
						dt = Nothing
						dr = Nothing
						dv = Nothing
					PathFillMode.SelectedIndex = 0
				ActPath.Controls.Add(PathFillMode)
				ActPath.Controls.Add(new LiteralControl(" , Pen Width: "))
					Dim txtPathPenWidth As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtPathPenWidth.ID = "otxtPathPenWidth"
					txtPathPenWidth.MaxLength = 2
					txtPathPenWidth.CssClass = "ImageEditorTxtBox"
					txtPathPenWidth.Text = 3
				ActPath.Controls.Add(txtPathPenWidth)
				ActPath.Controls.Add(new LiteralControl(" , Pen Color:"))
					Dim txtPathPenColor As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtPathPenColor.ID = "otxtPathPenColor"
					txtPathPenColor.MaxLength = 7
					txtPathPenColor.CssClass = "ImageEditorTxtBoxColor"
					txtPathPenColor.Text = "#BBBBBB"
				ActPath.Controls.Add(txtPathPenColor)
				ActPath.Controls.Add(new LiteralControl(" , Opacity " & mkhelp("Opacity configures the transparency of the whole path except the fill, which is configured in the brush. The higher it is, the more visible the draw will be. The max value is 255 (visible) and the min is 0 (invisible).") & ":"))
					Dim txtPathOpac As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtPathOpac.ID = "otxtPathOpac"
					txtPathOpac.MaxLength = 3
					txtPathOpac.CssClass = "ImageEditorTxtBox"
					txtPathOpac.Text = 255
				ActPath.Controls.Add(txtPathOpac)
				ActPath.Controls.Add(new LiteralControl(" , Type:"))
					Dim PathType As System.Web.UI.WebControls.DropDownList = new System.Web.UI.WebControls.DropDownList()
					PathType.ID = "oPathType"
					PathType.CssClass = "ImageEditorTxtBoxNoWidthRestr"
						dt = New DataTable()
						dt.Columns.Add(New DataColumn("StringValue", GetType(String)))
						dr = dt.NewRow()
						dr(0) = "Arc/Ellipse/Circle"
						dt.Rows.Add(dr)
						dr = dt.NewRow()
						dr(0) = "Bezier"
						dt.Rows.Add(dr)
						dr = dt.NewRow()
						dr(0) = "Line"
						dt.Rows.Add(dr)
						dr = dt.NewRow()
						dr(0) = "Pie"
						dt.Rows.Add(dr)
						dr = dt.NewRow()
						dr(0) = "Rectangle"
						dt.Rows.Add(dr)
						dr = dt.NewRow()
						dr(0) = "Text"
						dt.Rows.Add(dr)
						dv = New DataView(dt)
					PathType.DataSource = dv
					PathType.DataTextField = "StringValue"
					PathType.DataValueField = "StringValue"
					PathType.DataBind()
						dt = Nothing
						dr = Nothing
						dv = Nothing
					PathType.SelectedIndex = 0
				ActPath.Controls.Add(PathType)
					Dim aChangePathType As System.Web.UI.WebControls.LinkButton = new System.Web.UI.WebControls.LinkButton()
					aChangePathType.text = " Change Type!"
					aChangePathType.ID = "oaChangePathType"
					AddHandler aChangePathType.Click, AddressOf Me.ChangePathType
				ActPath.Controls.Add(aChangePathType)
				ActPath.Controls.Add(new LiteralControl(" , Special " & mkhelp("To add special characteristics to the path, such as shadow or blur, use the special charcteristics area below the brush.")))
				ActPath.Controls.Add(new LiteralControl("<center><table width='95%' class='defaulttext'><tr><td>"))
				
				'Arc PathType
					Dim PathArc As Object = new System.Web.UI.WebControls.PlaceHolder()
					PathArc.ID = "oPathArc"
					PathArc.Controls.Add(new LiteralControl("<font class='ImageEditorTitle'>Arc/Ellipse/Circle " & mkhelp("An arc is a part of an ellipse, or a whole ellipse. It requires a point -X & Y-. This defines the upperleft corner of the rectangle that is further specified by width and height. In the rectangle (which is not drawn), the ellipse is bounded. The part of the ellipse to draw is then defined by the startAngle and the sweepAngle (the angle between the startAngle and the end of the Arc). If the Angles signify a 360 degrees *spin*, the whole ellipse is drawn. Furthermore, if the rectangle has the same height and width (a square), a circle is drawn.") & " :</font> "))
					PathArc.Controls.Add(new LiteralControl("X:"))
						Dim txtpArcX As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpArcX.ID = "otxtpArcX"
						txtpArcX.MaxLength = 4
						txtpArcX.CssClass = "ImageEditorTxtBox"
						txtpArcX.Text = 30
					PathArc.Controls.Add(txtpArcX)
					PathArc.Controls.Add(new LiteralControl(" , Y:"))
						Dim txtpArcY As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpArcY.ID = "otxtpArcY"
						txtpArcY.MaxLength = 4
						txtpArcY.CssClass = "ImageEditorTxtBox"
						txtpArcY.Text = 30
					PathArc.Controls.Add(txtpArcY)
					PathArc.Controls.Add(new LiteralControl(" , Width:"))
						Dim txtpArcWidth As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpArcWidth.ID = "otxtpArcWidth"
						txtpArcWidth.MaxLength = 4
						txtpArcWidth.CssClass = "ImageEditorTxtBox"
						txtpArcWidth.Text = 50
					PathArc.Controls.Add(txtpArcWidth)
					PathArc.Controls.Add(new LiteralControl(" , Height:"))
						Dim txtpArcHeight As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpArcHeight.ID = "otxtpArcHeight"
						txtpArcHeight.MaxLength = 4
						txtpArcHeight.CssClass = "ImageEditorTxtBox"
						txtpArcHeight.Text = 50
					PathArc.Controls.Add(txtpArcHeight)
					PathArc.Controls.Add(new LiteralControl(" , startAngle " & mkhelp("Starts from 0 to 360. e.g. 90 signifies up, 180 left, 270 down, 360=0 right.") & ":"))
						Dim txtpArcStartAngle As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpArcStartAngle.ID = "otxtpArcStartAngle"
						txtpArcStartAngle.MaxLength = 3
						txtpArcStartAngle.CssClass = "ImageEditorTxtBox"
						txtpArcStartAngle.Text = 150
					PathArc.Controls.Add(txtpArcStartAngle)
					PathArc.Controls.Add(new LiteralControl(" , sweepAngle " & mkhelp("Starts from 0 to 360. e.g. 90 signifies up, 180 left, 270 down, 360=0 right.") & ":"))
						Dim txtpArcSweepAngle As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpArcSweepAngle.ID = "otxtpArcSweepAngle"
						txtpArcSweepAngle.MaxLength = 3
						txtpArcSweepAngle.CssClass = "ImageEditorTxtBox"
						txtpArcSweepAngle.Text = 340
					PathArc.Controls.Add(txtpArcSweepAngle)
				ActPath.Controls.Add(PathArc)
				'Bezier PathType
					Dim PathBezier As Object = new System.Web.UI.WebControls.PlaceHolder()
					PathBezier.ID = "oPathBezier"
					PathBezier.visible = False
					PathBezier.Controls.Add(new LiteralControl("<font class='ImageEditorTitle'>Bezier " & mkhelp("The cubic curve is constructed from the first point to the fourth point by using the second and third points as control points. Use the X and Y fields to specify the four points.") & " :</font> "))
					PathBezier.Controls.Add(new LiteralControl("X1:"))
						Dim txtpBezierX1 As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpBezierX1.ID = "otxtpBezierX1"
						txtpBezierX1.MaxLength = 4
						txtpBezierX1.CssClass = "ImageEditorTxtBox"
						txtpBezierX1.Text = 30
					PathBezier.Controls.Add(txtpBezierX1)
					PathBezier.Controls.Add(new LiteralControl(" , Y1:"))
						Dim txtpBezierY1 As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpBezierY1.ID = "otxtpBezierY1"
						txtpBezierY1.MaxLength = 4
						txtpBezierY1.CssClass = "ImageEditorTxtBox"
						txtpBezierY1.Text = 30
					PathBezier.Controls.Add(txtpBezierY1)
					PathBezier.Controls.Add(new LiteralControl(" , X2:"))
						Dim txtpBezierX2 As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpBezierX2.ID = "otxtpBezierX2"
						txtpBezierX2.MaxLength = 4
						txtpBezierX2.CssClass = "ImageEditorTxtBox"
						txtpBezierX2.Text = 50
					PathBezier.Controls.Add(txtpBezierX2)
					PathBezier.Controls.Add(new LiteralControl(" , Y2:"))
						Dim txtpBezierY2 As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpBezierY2.ID = "otxtpBezierY2"
						txtpBezierY2.MaxLength = 4
						txtpBezierY2.CssClass = "ImageEditorTxtBox"
						txtpBezierY2.Text = 50
					PathBezier.Controls.Add(txtpBezierY2)
					PathBezier.Controls.Add(new LiteralControl(" , X3:"))
						Dim txtpBezierX3 As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpBezierX3.ID = "otxtpBezierX3"
						txtpBezierX3.MaxLength = 4
						txtpBezierX3.CssClass = "ImageEditorTxtBox"
						txtpBezierX3.Text = 20
					PathBezier.Controls.Add(txtpBezierX3)
					PathBezier.Controls.Add(new LiteralControl(" , Y3:"))
						Dim txtpBezierY3 As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpBezierY3.ID = "otxtpBezierY3"
						txtpBezierY3.MaxLength = 4
						txtpBezierY3.CssClass = "ImageEditorTxtBox"
						txtpBezierY3.Text = 80
					PathBezier.Controls.Add(txtpBezierY3)
					PathBezier.Controls.Add(new LiteralControl(" , X4:"))
						Dim txtpBezierX4 As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpBezierX4.ID = "otxtpBezierX4"
						txtpBezierX4.MaxLength = 4
						txtpBezierX4.CssClass = "ImageEditorTxtBox"
						txtpBezierX4.Text = 40
					PathBezier.Controls.Add(txtpBezierX4)
					PathBezier.Controls.Add(new LiteralControl(" , Y4:"))
						Dim txtpBezierY4 As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpBezierY4.ID = "otxtpBezierY4"
						txtpBezierY4.MaxLength = 4
						txtpBezierY4.CssClass = "ImageEditorTxtBox"
						txtpBezierY4.Text = 40
					PathBezier.Controls.Add(txtpBezierY4)
				ActPath.Controls.Add(PathBezier)
				'Line PathType
					Dim PathLine As Object = new System.Web.UI.WebControls.PlaceHolder()
					PathLine.ID = "oPathLine"
					PathLine.visible = False
					PathLine.Controls.Add(new LiteralControl("<font class='ImageEditorTitle'>Line " & mkhelp("The line requires two points, specified by the X and Y coordinates.") & " :</font> "))
					PathLine.Controls.Add(new LiteralControl("X1:"))
						Dim txtplineX1 As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtplineX1.ID = "otxtplineX1"
						txtplineX1.MaxLength = 4
						txtplineX1.CssClass = "ImageEditorTxtBox"
						txtplineX1.Text = 30
					Pathline.Controls.Add(txtplineX1)
					Pathline.Controls.Add(new LiteralControl(" , Y1:"))
						Dim txtplineY1 As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtplineY1.ID = "otxtplineY1"
						txtplineY1.MaxLength = 4
						txtplineY1.CssClass = "ImageEditorTxtBox"
						txtplineY1.Text = 30
					Pathline.Controls.Add(txtplineY1)
					Pathline.Controls.Add(new LiteralControl(" , X2:"))
						Dim txtplineX2 As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtplineX2.ID = "otxtplineX2"
						txtplineX2.MaxLength = 4
						txtplineX2.CssClass = "ImageEditorTxtBox"
						txtplineX2.Text = 50
					Pathline.Controls.Add(txtplineX2)
					Pathline.Controls.Add(new LiteralControl(" , Y2:"))
						Dim txtplineY2 As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtplineY2.ID = "otxtplineY2"
						txtplineY2.MaxLength = 4
						txtplineY2.CssClass = "ImageEditorTxtBox"
						txtplineY2.Text = 50
					Pathline.Controls.Add(txtplineY2)
				ActPath.Controls.Add(Pathline)
				'Pie PathType
					Dim PathPie As Object = new System.Web.UI.WebControls.PlaceHolder()
					PathPie.ID = "oPathPie"
					PathPie.visible = False
					PathPie.Controls.Add(new LiteralControl("<font class='ImageEditorTitle'>Pie " & mkhelp("The pie shape is defined by a partial outline of an ellipse and the two radial lines that intersect the endpoints of the partial outline. The partial outline begins at startAngle (measured clockwise from the x-axis) and ends at startAngle + sweepAngle.<p>Requires a rectangle specified by its upperleft point (x and y coordinates) and its width and height. The reactangle is not drawn. An eelipse is bound to the rectangle. The startAngle and sweepAngle further specify the pie.") & " :</font> "))
					PathPie.Controls.Add(new LiteralControl("X:"))
						Dim txtpPieX As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpPieX.ID = "otxtpPieX"
						txtpPieX.MaxLength = 4
						txtpPieX.CssClass = "ImageEditorTxtBox"
						txtpPieX.Text = 30
					PathPie.Controls.Add(txtpPieX)
					PathPie.Controls.Add(new LiteralControl(" , Y:"))
						Dim txtpPieY As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpPieY.ID = "otxtpPieY"
						txtpPieY.MaxLength = 4
						txtpPieY.CssClass = "ImageEditorTxtBox"
						txtpPieY.Text = 30
					PathPie.Controls.Add(txtpPieY)
					PathPie.Controls.Add(new LiteralControl(" , Width:"))
						Dim txtpPieWidth As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpPieWidth.ID = "otxtpPieWidth"
						txtpPieWidth.MaxLength = 4
						txtpPieWidth.CssClass = "ImageEditorTxtBox"
						txtpPieWidth.Text = 50
					PathPie.Controls.Add(txtpPieWidth)
					PathPie.Controls.Add(new LiteralControl(" , Height:"))
						Dim txtpPieHeight As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpPieHeight.ID = "otxtpPieHeight"
						txtpPieHeight.MaxLength = 4
						txtpPieHeight.CssClass = "ImageEditorTxtBox"
						txtpPieHeight.Text = 50
					PathPie.Controls.Add(txtpPieHeight)
					PathPie.Controls.Add(new LiteralControl(" , startAngle " & mkhelp("Starts from 0 to 360. e.g. 90 signifies up, 180 left, 270 down, 360=0 right.") & ":"))
						Dim txtpPieStartAngle As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpPieStartAngle.ID = "otxtpPieStartAngle"
						txtpPieStartAngle.MaxLength = 3
						txtpPieStartAngle.CssClass = "ImageEditorTxtBox"
						txtpPieStartAngle.Text = 150
					PathPie.Controls.Add(txtpPieStartAngle)
					PathPie.Controls.Add(new LiteralControl(" , sweepAngle " & mkhelp("Starts from 0 to 360. e.g. 90 signifies up, 180 left, 270 down, 360=0 right.") & ":"))
						Dim txtpPieSweepAngle As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpPieSweepAngle.ID = "otxtpPieSweepAngle"
						txtpPieSweepAngle.MaxLength = 3
						txtpPieSweepAngle.CssClass = "ImageEditorTxtBox"
						txtpPieSweepAngle.Text = 340
					PathPie.Controls.Add(txtpPieSweepAngle)
				ActPath.Controls.Add(PathPie)
				'Rectangle PathType
					Dim PathRectangle As Object = new System.Web.UI.WebControls.PlaceHolder()
					PathRectangle.ID = "oPathRectangle"
					PathRectangle.visible = False
					PathRectangle.Controls.Add(new LiteralControl("<font class='ImageEditorTitle'>Rectangle " & mkhelp("The rectangle is defined by its upperleft point (X and Y coordinates). It also requires a height and width (if they're the same, a square will be drawn).") & " :</font> "))
					PathRectangle.Controls.Add(new LiteralControl("X:"))
						Dim txtpRectangleX As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpRectangleX.ID = "otxtpRectangleX"
						txtpRectangleX.MaxLength = 4
						txtpRectangleX.CssClass = "ImageEditorTxtBox"
						txtpRectangleX.Text = 30
					PathRectangle.Controls.Add(txtpRectangleX)
					PathRectangle.Controls.Add(new LiteralControl(" , Y:"))
						Dim txtpRectangleY As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpRectangleY.ID = "otxtpRectangleY"
						txtpRectangleY.MaxLength = 4
						txtpRectangleY.CssClass = "ImageEditorTxtBox"
						txtpRectangleY.Text = 30
					PathRectangle.Controls.Add(txtpRectangleY)
					PathRectangle.Controls.Add(new LiteralControl(" , Width:"))
						Dim txtpRectangleWidth As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpRectangleWidth.ID = "otxtpRectangleWidth"
						txtpRectangleWidth.MaxLength = 4
						txtpRectangleWidth.CssClass = "ImageEditorTxtBox"
						txtpRectangleWidth.Text = 50
					PathRectangle.Controls.Add(txtpRectangleWidth)
					PathRectangle.Controls.Add(new LiteralControl(" , Height:"))
						Dim txtpRectangleHeight As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpRectangleHeight.ID = "otxtpRectangleHeight"
						txtpRectangleHeight.MaxLength = 4
						txtpRectangleHeight.CssClass = "ImageEditorTxtBox"
						txtpRectangleHeight.Text = 50
					PathRectangle.Controls.Add(txtpRectangleHeight)
				ActPath.Controls.Add(PathRectangle)
				'Text PathType
					Dim PathText As Object = new System.Web.UI.WebControls.PlaceHolder()
					PathText.ID = "oPathText"
					PathText.visible = False
					PathText.Controls.Add(new LiteralControl("<font class='ImageEditorTitle'>Text " & mkhelp("Type the text to be drawn. Specify also the FontFamily and the Em size of the font as well as the style (bold...). At last a point (X and Y coordinates) where the text will begin to be drawn.") & " :</font> "))
					PathText.Controls.Add(new LiteralControl("X:"))
						Dim txtpTextX As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpTextX.ID = "otxtpTextX"
						txtpTextX.MaxLength = 4
						txtpTextX.CssClass = "ImageEditorTxtBox"
						txtpTextX.Text = 30
					PathText.Controls.Add(txtpTextX)
					PathText.Controls.Add(new LiteralControl(" , Y:"))
						Dim txtpTextY As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpTextY.ID = "otxtpTextY"
						txtpTextY.MaxLength = 4
						txtpTextY.CssClass = "ImageEditorTxtBox"
						txtpTextY.Text = 30
					PathText.Controls.Add(txtpTextY)
					PathText.Controls.Add(new LiteralControl(" , Text:"))
						Dim txtpTextTxt As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpTextTxt.ID = "otxtpTextTxt"
						txtpTextTxt.CssClass = "ImageEditorTxtBoxNoWidthRestr"
						txtpTextTxt.Text = "Hello"
					PathText.Controls.Add(txtpTextTxt)
					PathText.Controls.Add(new LiteralControl(" , FontFamily " & mkhelp("The fonts that are used exist on the server. Unfortunately, font lists are not supported yet. So, you cannot be sure of the existence of a font. You can always type a name; if it shows an error, the font does not exist, so delete the act you made and try another fontname.") & ":"))
						Dim txtpTextFontFamily As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpTextFontFamily.ID = "otxtpTextFontFamily"
						txtpTextFontFamily.CssClass = "ImageEditorTxtBoxNoWidthRestr"
						txtpTextFontFamily.Text = "Arial"
					PathText.Controls.Add(txtpTextFontFamily)
					PathText.Controls.Add(new LiteralControl(" , FontStyle:"))
						Dim pTextStyleDrop As System.Web.UI.WebControls.DropDownList = new System.Web.UI.WebControls.DropDownList()
						pTextStyleDrop.ID = "opTextStyleDrop"
						pTextStyleDrop.CssClass = "ImageEditorTxtBoxNoWidthRestr"
							dt = New DataTable()
							dt.Columns.Add(New DataColumn("StringValue", GetType(String)))
							dt.Columns.Add(New DataColumn("IntegerValue", GetType(Int32)))
							dr = dt.NewRow()
							dr(0) = "Bold"
							dr(1) = 1
							dt.Rows.Add(dr)
							dr = dt.NewRow()
							dr(0) = "Italic"
							dr(1) = 2
							dt.Rows.Add(dr)
							dr = dt.NewRow()
							dr(0) = "Regular"
							dr(1) = 0
							dt.Rows.Add(dr)
							dr = dt.NewRow()
							dr(0) = "Strikeout"
							dr(1) = 8
							dt.Rows.Add(dr)
							dr = dt.NewRow()
							dr(0) = "Underline"
							dr(1) = 4
							dt.Rows.Add(dr)
							dv = New DataView(dt)
						pTextStyleDrop.DataSource = dv
						pTextStyleDrop.DataTextField = "StringValue"
						pTextStyleDrop.DataValueField = "IntegerValue"
						pTextStyleDrop.DataBind()
							dt = Nothing
							dr = Nothing
							dv = Nothing
						pTextStyleDrop.SelectedIndex = 0
					PathText.Controls.Add(pTextStyleDrop)
					PathText.Controls.Add(new LiteralControl(" , Size:"))
						Dim txtpTextSize As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
						txtpTextSize.ID = "otxtpTextSize"
						txtpTextSize.MaxLength = 3
						txtpTextSize.CssClass = "ImageEditorTxtBox"
						txtpTextSize.Text = 12
					PathText.Controls.Add(txtpTextSize)
					PathText.Controls.Add(new LiteralControl("Em"))
				ActPath.Controls.Add(PathText)
				
				ActPath.Controls.Add(new LiteralControl("</tr></td></table></center>"))
				'SubCommands for path
				ActPath.Controls.Add(new LiteralControl(" "))
					Dim aAddThing2Path As System.Web.UI.WebControls.LinkButton = new System.Web.UI.WebControls.LinkButton()
					aAddThing2Path.text = "Add to current Path!"
					aAddThing2Path.ID = "oaAddThing2Path"
					AddHandler aAddThing2Path.Click, AddressOf Me.AddThing2Path
				ActPath.Controls.Add(aAddThing2Path)
				ActPath.Controls.Add(new LiteralControl(" , "))
					Dim aResetPath As System.Web.UI.WebControls.LinkButton = new System.Web.UI.WebControls.LinkButton()
					aResetPath.text = "Reset current Path!"
					aResetPath.ID = "oaResetPath"
					AddHandler aResetPath.Click, AddressOf Me.ResetPath
				ActPath.Controls.Add(aResetPath)
			ActEdits.Controls.Add(ActPath)
				Dim ActImg As Object = new System.Web.UI.WebControls.PlaceHolder()
				ActImg.ID = "oActImg"
				ActImg.visible = False
				ActImg.Controls.Add(new LiteralControl("<br><font class='ImageEditorTitle'>Image " & mkhelp("This will draw an image of the server. The image is specified by its relative path. It requires a point with X and Y coordinates (to retrieve them, click on the image to the left). This defines its upperleft point. Then it requires a width and height.") & " :</font>"))
				ActImg.Controls.Add(new LiteralControl(" Path:"))
					Dim txtimgPath As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtimgPath.ID = "otxtimgPath"
					txtimgPath.CssClass = "ImageEditorTxtBoxNoWidthRestr"
					txtimgPath.Text = "../Images/ToolkitScreenshot.jpg"
				ActImg.Controls.Add(txtimgPath)
				ActImg.Controls.Add(new LiteralControl(" , X:"))
					Dim txtimgX As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtimgX.ID = "otxtimgX"
					txtimgX.MaxLength = 4
					txtimgX.CssClass = "ImageEditorTxtBox"
					txtimgX.Text = 30
				ActImg.Controls.Add(txtimgX)
				ActImg.Controls.Add(new LiteralControl(" , Y:"))
					Dim txtimgY As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtimgY.ID = "otxtimgY"
					txtimgY.MaxLength = 4
					txtimgY.CssClass = "ImageEditorTxtBox"
					txtimgY.Text = 30
				ActImg.Controls.Add(txtimgY)
				ActImg.Controls.Add(new LiteralControl(" , Width:"))
					Dim txtimgWidth As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtimgWidth.ID = "otxtimgWidth"
					txtimgWidth.MaxLength = 4
					txtimgWidth.CssClass = "ImageEditorTxtBox"
					txtimgWidth.Text = 50
				ActImg.Controls.Add(txtimgWidth)
				ActImg.Controls.Add(new LiteralControl(" , Height:"))
					Dim txtimgHeight As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtimgHeight.ID = "otxtimgHeight"
					txtimgHeight.MaxLength = 4
					txtimgHeight.CssClass = "ImageEditorTxtBox"
					txtimgHeight.Text = 50
				ActImg.Controls.Add(txtimgHeight)
			ActEdits.Controls.Add(ActImg)
			ActEdits.visible = False
		Controls.Add(ActEdits)
			'INITIALIZATION placeholder
			Dim InitChoices As Object = new System.Web.UI.WebControls.PlaceHolder()
			InitChoices.ID = "oInitChoices"
			InitChoices.Controls.Add(new LiteralControl("<font class='ImageEditorMainTitle'><b>1.</b> Initialization options " & mkhelp("These options specify the characteristics of the image, such as the type, the background brush (select the brush options you want for the background), the size etc. After this, you will create the acts.") & " :</font><br>"))
			InitChoices.Controls.Add(new LiteralControl("Type: "))
				Dim ImgTypeDrop As System.Web.UI.WebControls.DropDownList = new System.Web.UI.WebControls.DropDownList()
				ImgTypeDrop.ID = "oImgTypeDrop"
				ImgTypeDrop.CssClass = "ImageEditorTxtBoxNoWidthRestr"
					dt = New DataTable()
					dt.Columns.Add(New DataColumn("StringValue", GetType(String)))
					dr = dt.NewRow()
					dr(0) = "Jpg"
					dt.Rows.Add(dr)
					dr = dt.NewRow()
					dr(0) = "Gif"
					dt.Rows.Add(dr)
					dv = New DataView(dt)
				ImgTypeDrop.DataSource = dv
				ImgTypeDrop.DataTextField = "StringValue"
				ImgTypeDrop.DataValueField = "StringValue"
				ImgTypeDrop.DataBind()
					dt = Nothing
					dr = Nothing
					dv = Nothing
				ImgTypeDrop.SelectedIndex = 0
			InitChoices.Controls.Add(ImgTypeDrop)
			InitChoices.Controls.Add(new LiteralControl(" , Width: "))
				Dim txtWidth As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
				txtWidth.ID = "otxtWidth"
				txtWidth.MaxLength = 4
				txtWidth.CssClass = "ImageEditorTxtBox"
				txtWidth.Text = 200
			InitChoices.Controls.Add(txtWidth)
			InitChoices.Controls.Add(new LiteralControl(" px , Height: "))
				Dim txtHeight As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
				txtHeight.ID = "otxtHeight"
				txtHeight.MaxLength = 4
				txtHeight.CssClass = "ImageEditorTxtBox"
				txtHeight.Text = 200
			InitChoices.Controls.Add(txtHeight)
			InitChoices.Controls.Add(new LiteralControl(" px , "))
				Dim aChangeMoreChoices As System.Web.UI.WebControls.LinkButton = new System.Web.UI.WebControls.LinkButton()
				aChangeMoreChoices.text = "Advanced " & mkhelp("Show/Hide panel with more initialization options, such as switching antialising fonts off or on.")
				aChangeMoreChoices.ID = "oaChangeMoreChoices"
				AddHandler aChangeMoreChoices.Click, AddressOf Me.SwitchMoreInitOptions
			InitChoices.Controls.Add(aChangeMoreChoices)
				Dim InitChoicesMore As System.Web.UI.WebControls.PlaceHolder = new System.Web.UI.WebControls.PlaceHolder()
				InitChoicesMore.ID = "oInitChoicesMore"
				InitChoicesMore.visible = False
				InitChoicesMore.Controls.Add(new LiteralControl("<br><font class='ImageEditorTitle'>More Advanced Options " & mkhelp("This opens a new window to show you instructions on how to use these options.", 12, "><font size=3 color=orange>More Advanced Initialization Options:</font><p>You can specify options by designating them with a number according to the order given for each field (starting from 0, not 1). For now, the options are configured for best results.<p><u>PixelFormat:</u> Alpha, DontCare, Extended, Format16bppArgb1555, Format16bppGrayScale, Format16bppRgb555, Format16bppRgb565, Format1bppIndexed, Format24bppRgb, Format32bppArgb, Format32bppPArgb, Format32bppRgb, Format48bppRgb, Format4bppIndexed, Format64bppArgb, Format64bppPArgb, Format8bppIndexed, Indexed, Max, PAlpha, Undefined.<br><u>Text Rendering Hint:</u>AntiAlias, AntiAliasGridFit, ClearTypeGridFit, SingleBitPerPixel, SingleBitPerPixelGridFit, SystemDefault.<br><u>Compositing Mode:</u> SourceCopy, SourceOver.<br><u>Compositing Quality:</u> AssumeLinear, Default, GammaCorrected, HighQuality, HighSpeed, Invalid.<br><u>Smoothing Mode:</u> AntiAlias, Default, HighQuality, HighSpeed, Invalid, None.<br><u>Interpolation Mode:</u> Bicubic, Bilinear, Default, High, HighQualityBicubic, HighQualityBilinear, Invalid, Low, NearestNeighbor.<br><u>Pixel Offset Mode:</u> Default, Half, HighQuality, HighSpeed, Invalid, None.") & " :</font>"))
				InitChoicesMore.Controls.Add(new LiteralControl("<br>Pixel Format:"))
					Dim txtPxFormat As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtPxFormat.ID = "otxtPxFormat"
					txtPxFormat.MaxLength = 2
					txtPxFormat.CssClass = "ImageEditorTxtBox"
					txtPxFormat.Text = 9
				InitChoicesMore.Controls.Add(txtPxFormat)
				InitChoicesMore.Controls.Add(new LiteralControl(" , Text Rendering Hint:"))
					Dim txtRendHint As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtRendHint.ID = "otxtRendHint"
					txtRendHint.MaxLength = 2
					txtRendHint.CssClass = "ImageEditorTxtBox"
					txtRendHint.Text = 4
				InitChoicesMore.Controls.Add(txtRendHint)
				InitChoicesMore.Controls.Add(new LiteralControl(" , Compositing Mode:"))
					Dim txtCompMode As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtCompMode.ID = "otxtCompMode"
					txtCompMode.MaxLength = 2
					txtCompMode.CssClass = "ImageEditorTxtBox"
					txtCompMode.Text = 0
				InitChoicesMore.Controls.Add(txtCompMode)
				InitChoicesMore.Controls.Add(new LiteralControl(" , Compositing Quality:"))
					Dim txtCompQual As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtCompQual.ID = "otxtCompQual"
					txtCompQual.MaxLength = 2
					txtCompQual.CssClass = "ImageEditorTxtBox"
					txtCompQual.Text = 3
				InitChoicesMore.Controls.Add(txtCompQual)
				InitChoicesMore.Controls.Add(new LiteralControl(" , Smoothing Mode:"))
					Dim txtSmoothMode As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtSmoothMode.ID = "otxtSmoothMode"
					txtSmoothMode.MaxLength = 2
					txtSmoothMode.CssClass = "ImageEditorTxtBox"
					txtSmoothMode.Text = 2
				InitChoicesMore.Controls.Add(txtSmoothMode)
				InitChoicesMore.Controls.Add(new LiteralControl(" , Interpolation Mode:"))
					Dim txtInterpMode As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtInterpMode.ID = "otxtInterpMode"
					txtInterpMode.MaxLength = 2
					txtInterpMode.CssClass = "ImageEditorTxtBox"
					txtInterpMode.Text = 2
				InitChoicesMore.Controls.Add(txtInterpMode)
				InitChoicesMore.Controls.Add(new LiteralControl(" , Pixel Offset Mode:"))
					Dim txtPxOffMode As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtPxOffMode.ID = "otxtPxOffMode"
					txtPxOffMode.MaxLength = 2
					txtPxOffMode.CssClass = "ImageEditorTxtBox"
					txtPxOffMode.Text = 0
				InitChoicesMore.Controls.Add(txtPxOffMode)
			InitChoices.Controls.Add(InitChoicesMore)
		Controls.Add(InitChoices)
			'BRUSH placeholder
			Dim BrushEdit As System.Web.UI.WebControls.PlaceHolder = new System.Web.UI.WebControls.PlaceHolder()
			BrushEdit.ID = "oBrushEdit"
			BrushEdit.Controls.Add(new LiteralControl("<p><font class='ImageEditorMainTitle'><b>2.</b> Brush options " & mkhelp("The brush specifies how a thing (can be background, a shape, a line etc.) will be drawn. It has many styles: You can choose from plain colors to gradient and textures. Colors must be given in hex format. Click to get more info about hex colors.", 12, "><font size=3 color=orange>Hex Colors explanation:</font><p> Ordinary configuration includes setting a value for the three base colors: Red, Green, Blue (RGB). Each such value starts from 0 to 255, signifying the intense of each one of the base colors to the resulting color.<p>In the web, colors are needed much and a shorter form was used. Colors can be configured by a set of 6 alphanumerical characters. The first two chars signify the instense of red, the following two the intense of green and the last two the instense of blue. Again, each set of two chars is in hex format (base 16 math) and signify (in our ordinary base 10 math) a value from 0 to 255.<p><b>Translation of base 16 math to base 10 math:</b><br>1,2,3...,9 are used normally. But for 10, we use A, for 11 we use B... for 15 we use F. In ordinary counting, after 9, we start counting in tens, that is: We use a number from 1 to 9 to signify how many tens we have and then a number normally. So 34 means 3 times 10 and 3. In hex, the first digit signifies the 16s and the second is normal. So, CF for example is C times 16 and F, that is 12 times 16 and 15 = 207. Or, 27 is 2 times 16 and 7 = 39. So, 10 means 1 time 16 and 0 = 16. As you have guessed, to continue further counting from F=15, you continue like 10(=16),11,...19,1A,1B..1F,20,21...,9F,A0,A1...AF....,FF(=256). We do not need to learn further counting because for our hex colors we need only 2 digits that signify numbers till 255.<p><b>Translation of hex colors:</b><br>So FF is tha max value (=256, but is translated now as 255) and 00 the min value for each intensity of each one of the base colors (RGB). Take for example the color <b>#FA4B96</b>. The # characters just shows that the format is hex, and can be omitted. FA = 250 of red, 4B = 75 of green, 96 = 150 of blue. And some of the basic colors are: #000000 (black), #FFFFFF (white), #FF0000 (red), #00FF00 (green), #0000FF (blue).") & " :</font><br>Style:"))
				Dim BrushStyleDrop As System.Web.UI.WebControls.DropDownList = new System.Web.UI.WebControls.DropDownList()
				BrushStyleDrop.ID = "oBrushStyleDrop"
				BrushStyleDrop.CssClass = "ImageEditorTxtBoxNoWidthRestr"
					dt = New DataTable()
					dt.Columns.Add(New DataColumn("StringValue", GetType(String)))
					dt.Columns.Add(New DataColumn("IntegerValue", GetType(Int32)))
					dr = dt.NewRow()
					dr(0) = "Solid"
					dr(1) = 0
					dt.Rows.Add(dr)
					dr = dt.NewRow()
					dr(0) = "Gradient"
					dr(1) = 1
					dt.Rows.Add(dr)
					dr = dt.NewRow()
					dr(0) = "Hatch"
					dr(1) = 2
					dt.Rows.Add(dr)
					If UseTextureBrush Then
					dr = dt.NewRow()
					dr(0) = "Texture"
					dr(1) = 3
					dt.Rows.Add(dr)
					End If
					dv = New DataView(dt)
				BrushStyleDrop.DataSource = dv
				BrushStyleDrop.DataTextField = "StringValue"
				BrushStyleDrop.DataValueField = "IntegerValue"
				BrushStyleDrop.DataBind()
					dt = Nothing
					dr = Nothing
					dv = Nothing
				BrushStyleDrop.SelectedIndex = 0
			BrushEdit.Controls.Add(BrushStyleDrop)
				Dim aChangeBrushStyle As System.Web.UI.WebControls.LinkButton = new System.Web.UI.WebControls.LinkButton()
				aChangeBrushStyle.text = " Change Style!"
				aChangeBrushStyle.ID = "oaChangeBrushStyle"
				AddHandler aChangeBrushStyle.Click, AddressOf Me.ShowBrushStylePlaceholder
			BrushEdit.Controls.Add(aChangeBrushStyle)
				Dim BrushSolid As System.Web.UI.WebControls.PlaceHolder = new System.Web.UI.WebControls.PlaceHolder()
				BrushSolid.ID = "oBrushSolid"
				BrushSolid.Controls.Add(new LiteralControl("<br><b>Solid:</b> Color:"))
					Dim txtSolidColor As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtSolidColor.ID = "otxtSolidColor"
					txtSolidColor.MaxLength = 7
					txtSolidColor.CssClass = "ImageEditorTxtBoxColor"
					txtSolidColor.Text = "#FFFFFF"
				BrushSolid.Controls.Add(txtSolidColor)
			BrushEdit.Controls.Add(BrushSolid)
				Dim BrushGradient As System.Web.UI.WebControls.PlaceHolder = new System.Web.UI.WebControls.PlaceHolder()
				BrushGradient.visible = False
				BrushGradient.ID = "oBrushGradient"
				BrushGradient.Controls.Add(new LiteralControl("<br><b>Gradient:</b> Starting Color:"))
					Dim txtGradStartColor As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtGradStartColor.ID = "otxtGradStartColor"
					txtGradStartColor.MaxLength = 7
					txtGradStartColor.CssClass = "ImageEditorTxtBoxColor"
					txtGradStartColor.Text = "#FF0000"
				BrushGradient.Controls.Add(txtGradStartColor)
				BrushGradient.Controls.Add(new LiteralControl(" , Last Color:"))
					Dim txtGradLastColor As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtGradLastColor.ID = "otxtGradLastColor"
					txtGradLastColor.MaxLength = 7
					txtGradLastColor.CssClass = "ImageEditorTxtBoxColor"
					txtGradLastColor.Text = "#00CCAA"
				BrushGradient.Controls.Add(txtGradLastColor)
				BrushGradient.Controls.Add(new LiteralControl(" , Opacity Of Starting Color " & mkhelp("Opacity configures the transparency. The higher it is, the more visible the draw will be. The max value is 255 (visible) and the min is 0 (invisible).") & ":"))
					Dim txtGradStartOpac As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtGradStartOpac.ID = "otxtGradStartOpac"
					txtGradStartOpac.MaxLength = 3
					txtGradStartOpac.CssClass = "ImageEditorTxtBox"
					txtGradStartOpac.Text = 180
				BrushGradient.Controls.Add(txtGradStartOpac)
				BrushGradient.Controls.Add(new LiteralControl(" , Opacity Of Last Color " & mkhelp("Opacity configures the transparency. The higher it is, the more visible the draw will be. The max value is 255 (visible) and the min is 0 (invisible).") & ":"))
					Dim txtGradLastOpac As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtGradLastOpac.ID = "otxtGradLastOpac"
					txtGradLastOpac.MaxLength = 3
					txtGradLastOpac.CssClass = "ImageEditorTxtBox"
					txtGradLastOpac.Text = 255
				BrushGradient.Controls.Add(txtGradLastOpac)
				BrushGradient.Controls.Add(new LiteralControl(" , Angle " & mkhelp("The angle specifies the angle in degrees according to which the orientation of the gradient fill is configured. Starts from 0 to 360. e.g. 90 signifies up, 180 left, 270 down, 360=0 right.") & ":"))
					Dim txtGradAngle As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtGradAngle.ID = "otxtGradAngle"
					txtGradAngle.MaxLength = 3
					txtGradAngle.CssClass = "ImageEditorTxtBox"
					txtGradAngle.Text = 240
				BrushGradient.Controls.Add(txtGradAngle)
			BrushEdit.Controls.Add(BrushGradient)
				Dim BrushHatch As System.Web.UI.WebControls.PlaceHolder = new System.Web.UI.WebControls.PlaceHolder()
				BrushHatch.visible = False
				BrushHatch.ID = "oBrushHatch"
				BrushHatch.Controls.Add(new LiteralControl("<br><b>Hatch " & mkhelp("Hatch brushes include 2 colors, mixed on a certain template (can be lines, squares ...). Each template is designated by a style number. Click to see the templates.", 12, "><font size=3 color=orange>Hatch templates:</font><p> Fill the textbox with a number that shows one of the following templates in order (starting from 0):<p>BackwardDiagonal (0),Cross, DarkDownwardDiagonal, DarkHorizontal, DarkUpwardDiagonal, DarkVertical, DashedDownwardDiagonal, DashedHorizontal, DashedUpwardDiagonal, DashedVertical, DiagonalBrick (10), DiagonalCross, Divot, DottedDiamond, DottedGrid, ForwardDiagonal, Horizontal, HorizontalBrick, LargeCheckerBoard, LargeConfetti, LargeGrid (20), LightDownwardDiagonal, LightHorizontal, LightUpwardDiagonal, LightVertical, Max, Min, NarrowHorizontal, NarrowVertical, OutlinedDiamond, Percent05 (30), Percent10, Percent20, Percent25, Percent30, Percent40, Percent50, Percent60, Percent70, Percent75, Percent80, Percent90, Plaid, Shingle, SmallCheckerBoard, SmallConfetti (45), SmallGrid, SolidDiamond, Sphere, Trellis, Vertical, Wave, Weave, WideDownwardDiagonal, WideUpwardDiagonal, ZigZag (55)") & ":</b> ForeColor:"))
					Dim txtHatchForeColor As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtHatchForeColor.ID = "otxtHatchForeColor"
					txtHatchForeColor.MaxLength = 7
					txtHatchForeColor.CssClass = "ImageEditorTxtBoxColor"
					txtHatchForeColor.Text = "#FFFFFF"
				BrushHatch.Controls.Add(txtHatchForeColor)
				BrushHatch.Controls.Add(new LiteralControl(" , BackColor:"))
					Dim txtHatchBackColor As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtHatchBackColor.ID = "otxtHatchBackColor"
					txtHatchBackColor.MaxLength = 7
					txtHatchBackColor.CssClass = "ImageEditorTxtBoxColor"
					txtHatchBackColor.Text = "#000000"
				BrushHatch.Controls.Add(txtHatchBackColor)
				BrushHatch.Controls.Add(new LiteralControl(" , Style:"))
					Dim txtHatchStyle As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtHatchStyle.ID = "otxtHatchStyle"
					txtHatchStyle.MaxLength = 2
					txtHatchStyle.CssClass = "ImageEditorTxtBox"
					txtHatchStyle.Text = 2
				BrushHatch.Controls.Add(txtHatchStyle)
				BrushHatch.Controls.Add(new LiteralControl(" , Opacity Of ForeColor " & mkhelp("Opacity configures the transparency. The higher it is, the more visible the draw will be. The max value is 255 (visible) and the min is 0 (invisible).") & ":"))
					Dim txtHatchForeOpac As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtHatchForeOpac.ID = "otxtHatchForeOpac"
					txtHatchForeOpac.MaxLength = 3
					txtHatchForeOpac.CssClass = "ImageEditorTxtBox"
					txtHatchForeOpac.Text = 200
				BrushHatch.Controls.Add(txtHatchForeOpac)
				BrushHatch.Controls.Add(new LiteralControl(" , Opacity Of BackColor " & mkhelp("Opacity configures the transparency. The higher it is, the more visible the draw will be. The max value is 255 (visible) and the min is 0 (invisible).") & ":"))
					Dim txtHatchBackOpac As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtHatchBackOpac.ID = "otxtHatchBackOpac"
					txtHatchBackOpac.MaxLength = 3
					txtHatchBackOpac.CssClass = "ImageEditorTxtBox"
					txtHatchBackOpac.Text = 255
				BrushHatch.Controls.Add(txtHatchBackOpac)
			BrushEdit.Controls.Add(BrushHatch)
				Dim BrushTexture As System.Web.UI.WebControls.PlaceHolder = new System.Web.UI.WebControls.PlaceHolder()
				BrushTexture.visible = False
				BrushTexture.ID = "oBrushTexture"
				BrushTexture.Controls.Add(new LiteralControl("<br><b>Texture:</b> Virtual FilePath " & mkhelp("This path refers on a location on the server. If you want to load up an image of yours, you have to upload an image to the server temporarily. This may or may not be allowed by the website.<p>Also, the path must not contain the characters , and �") & ":"))
					Dim txtTexturePath As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtTexturePath.ID = "otxtTexturePath"
					txtTexturePath.CssClass = "ImageEditorTxtBoxNoWidthRestr"
					txtTexturePath.Text = "\"
				BrushTexture.Controls.Add(txtTexturePath)
				BrushTexture.Controls.Add(new LiteralControl(" , Wrap Style " & mkhelp("Fill this textbox with a number that signifies one of the following wrap styles in order (starting from 0):<p>Clamp, Tile, TileFlipX, TileFlipXY, TileFlipY") & ":"))
					Dim txtTextureWrap As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
					txtTextureWrap.ID = "otxtTextureWrap"
					txtTextureWrap.MaxLength = 2
					txtTextureWrap.CssClass = "ImageEditorTxtBox"
					txtTextureWrap.Text = 2
				BrushTexture.Controls.Add(txtTextureWrap)
			BrushEdit.Controls.Add(BrushTexture)
		Controls.Add(BrushEdit)
		'SPECIAL chars
			Dim SpeacialActEdit As System.Web.UI.WebControls.Placeholder = new System.Web.UI.WebControls.Placeholder()
			SpeacialActEdit.Id = "oSpeacialActEdit"
			SpeacialActEdit.visible = False
			SpeacialActEdit.Controls.Add(new LiteralControl("<p><font class='ImageEditorMainTitle'><b>3.</b> Special Features " & mkhelp("These options apply to shapes and text. They include some nice features to make your image editing more flashy.") & " :</font>"))
			SpeacialActEdit.Controls.Add(new LiteralControl("<br><b>Shadow " & mkhelp("Shadows are used much. They often make objects differ from others. Specify how much big the shadow will be in the ShadowLevels by a number. Then a color. If you want a blur, and not a shadow, configure the same but also check the appropriate checkbox.") & " :</b> Shadow Levels:"))
				Dim txtShadowLevels As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
				txtShadowLevels.ID = "otxtShadowLevels"
				txtShadowLevels.MaxLength = 3
				txtShadowLevels.CssClass = "ImageEditorTxtBox"
				txtShadowLevels.Text = 6
			SpeacialActEdit.Controls.Add(txtShadowLevels)
			SpeacialActEdit.Controls.Add(new LiteralControl(" , Color:"))
				Dim txtShadowColor As System.Web.UI.WebControls.TextBox = new System.Web.UI.WebControls.TextBox()
				txtShadowColor.ID = "otxtShadowColor"
				txtShadowColor.MaxLength = 7
				txtShadowColor.CssClass = "ImageEditorTxtBoxColor"
				txtShadowColor.Text = "#000000"
			SpeacialActEdit.Controls.Add(txtShadowColor)
			SpeacialActEdit.Controls.Add(new LiteralControl(" , Orientation: "))
				Dim ShadowOrientDrop As System.Web.UI.WebControls.DropDownList = new System.Web.UI.WebControls.DropDownList()
				ShadowOrientDrop.ID = "oShadowOrientDrop"
				ShadowOrientDrop.CssClass = "ImageEditorTxtBoxNoWidthRestr"
					dt = New DataTable()
					dt.Columns.Add(New DataColumn("StringValue", GetType(String)))
					dr = dt.NewRow()
					dr(0) = "BottomLeft"
					dt.Rows.Add(dr)
					dr = dt.NewRow()
					dr(0) = "Bottom"
					dt.Rows.Add(dr)
					dr = dt.NewRow()
					dr(0) = "BottomRight"
					dt.Rows.Add(dr)
					dr = dt.NewRow()
					dr(0) = "Right"
					dt.Rows.Add(dr)
					dr = dt.NewRow()
					dr(0) = "UpperRight"
					dt.Rows.Add(dr)
					dr = dt.NewRow()
					dr(0) = "Upper"
					dt.Rows.Add(dr)
					dr = dt.NewRow()
					dr(0) = "UpperLeft"
					dt.Rows.Add(dr)
					dr = dt.NewRow()
					dr(0) = "Left"
					dt.Rows.Add(dr)
					dv = New DataView(dt)
				ShadowOrientDrop.DataSource = dv
				ShadowOrientDrop.DataTextField = "StringValue"
				ShadowOrientDrop.DataValueField = "StringValue"
				ShadowOrientDrop.DataBind()
					dt = Nothing
					dr = Nothing
					dv = Nothing
				ShadowOrientDrop.SelectedIndex = 0
			SpeacialActEdit.Controls.Add(ShadowOrientDrop)
			SpeacialActEdit.Controls.Add(new LiteralControl(" , "))
				Dim ShadowBlur As System.Web.UI.WebControls.Checkbox = new System.Web.UI.WebControls.Checkbox()
				ShadowBlur.ID = "oShadowBlur"
				ShadowBlur.text = "Blur"
				ShadowBlur.checked = False
			SpeacialActEdit.Controls.Add(ShadowBlur)
		Controls.Add(SpeacialActEdit)
		Controls.Add(new LiteralControl("<p><center>"))
		Controls.Add(new LiteralControl(" "))
			Dim btnBack2Init As System.Web.UI.WebControls.Button = new System.Web.UI.WebControls.Button()
			btnBack2Init.ID = "obtnBack2Init"
			btnBack2Init.CSSClass = "ImageEditorTxtButton"
			btnBack2Init.Text = "� Back (Init)"
			AddHandler btnBack2Init.Click, AddressOf Me.Back2Init
			btnBack2Init.visible = False
		Controls.Add(btnBack2Init)
		Controls.Add(new LiteralControl(" "))
			Dim btnResetQ As System.Web.UI.WebControls.Button = new System.Web.UI.WebControls.Button()
			btnResetQ.ID = "obtnResetQ"
			btnResetQ.CSSClass = "ImageEditorTxtButton"
			btnResetQ.Text = "Reset"
			AddHandler btnResetQ.Click, AddressOf Me.ResetQ
		Controls.Add(btnResetQ)
		Controls.Add(new LiteralControl(" "))
			Dim btnDelAct As System.Web.UI.WebControls.Button = new System.Web.UI.WebControls.Button()
			btnDelAct.ID = "obtnDelAct"
			btnDelAct.CSSClass = "ImageEditorTxtButton"
			btnDelAct.Text = "Delete Act"
			AddHandler btnDelAct.Click, AddressOf Me.DelAct
			btnDelAct.visible = False
		Controls.Add(btnDelAct)
		Controls.Add(new LiteralControl(" "))
			Dim btnContinue2Act As System.Web.UI.WebControls.Button = new System.Web.UI.WebControls.Button()
			btnContinue2Act.ID = "obtnContinue2Act"
			btnContinue2Act.CSSClass = "ImageEditorTxtButton"
			btnContinue2Act.Text = "Continue �"
			AddHandler btnContinue2Act.Click, AddressOf Me.Continue2Act
		Controls.Add(btnContinue2Act)
		Controls.Add(new LiteralControl(" "))
			Dim btnAddAct As System.Web.UI.WebControls.Button = new System.Web.UI.WebControls.Button()
			btnAddAct.ID = "obtnAddAct"
			btnAddAct.CSSClass = "ImageEditorTxtButton"
			btnAddAct.Text = "Add/Replace Act"
			AddHandler btnAddAct.Click, AddressOf Me.AddAct
			btnAddAct.visible = False
		Controls.Add(btnAddAct)
		Controls.Add(new LiteralControl("</center><br>"))
			Dim lblMsg As System.Web.UI.WebControls.Label = new System.Web.UI.WebControls.Label()
			lblMsg.ID = "olblMsg"
			lblMsg.CSSClass = "defaulttext"
		Controls.Add(lblMsg)
		Controls.Add(new LiteralControl("</td></tr></table></center>"))
	End Sub
	
	Sub ShowEditImgCoord (s As Object, e As ImageClickEventArgs)
	CType(Me.FindControl("oimgXlabel"), System.Web.UI.WebControls.Label).text = e.X.ToString()
	CType(Me.FindControl("oimgYlabel"), System.Web.UI.WebControls.Label).text = e.Y.ToString()
	End Sub
	
	Sub ResetPath (s As Object, e As EventArgs)
	ReconstructPath
	p.Reset
	SavePoints
	End Sub
	
	Sub ChangePathType (s As Object, e As EventArgs)
	CType(Me.FindControl("oPathArc"), System.Web.UI.WebControls.Placeholder).visible = False
	CType(Me.FindControl("oPathBezier"), System.Web.UI.WebControls.Placeholder).visible = False
	CType(Me.FindControl("oPathLine"), System.Web.UI.WebControls.Placeholder).visible = False
	CType(Me.FindControl("oPathPie"), System.Web.UI.WebControls.Placeholder).visible = False
	CType(Me.FindControl("oPathRectangle"), System.Web.UI.WebControls.Placeholder).visible = False
	CType(Me.FindControl("oPathText"), System.Web.UI.WebControls.Placeholder).visible = False
	Select Case CType(Me.FindControl("oPathType"), System.Web.UI.WebControls.DropDownList).SelectedValue
	Case "Arc/Ellipse/Circle"
		CType(Me.FindControl("oPathArc"), System.Web.UI.WebControls.Placeholder).visible = True
	Case "Bezier"
		CType(Me.FindControl("oPathBezier"), System.Web.UI.WebControls.Placeholder).visible = True
	Case "Line"
		CType(Me.FindControl("oPathLine"), System.Web.UI.WebControls.Placeholder).visible = True
	Case "Pie"
		CType(Me.FindControl("oPathPie"), System.Web.UI.WebControls.Placeholder).visible = True
	Case "Rectangle"
		CType(Me.FindControl("oPathRectangle"), System.Web.UI.WebControls.Placeholder).visible = True
	Case "Text"
		CType(Me.FindControl("oPathText"), System.Web.UI.WebControls.Placeholder).visible = True
	End Select
	End Sub
	
	Sub SavePoints
	If p.PointCount = 0 Then
	Context.Session("TempImgEditPathPoints") = Nothing
	Context.Session("TempImgEditPathPointsT") = Nothing
	Else
	Context.Session("TempImgEditPathPoints") = p.PathPoints
	Context.Session("TempImgEditPathPointsT") = p.PathTypes
	Context.Trace.Write((Context.Session("TempImgEditPathPoints")).Length)
	End If
	End Sub
	
	Sub ReconstructPath
	If Not Context.Session("TempImgEditPathPoints") Is Nothing And Not Context.Session("TempImgEditPathPointsT") Is Nothing Then
	Dim tmpPpoints() As PointF = Context.Session("TempImgEditPathPoints")
	Dim tmpPpTypes() As Byte = Context.Session("TempImgEditPathPointsT")
	p = new System.Drawing.Drawing2D.GraphicsPath(tmpPpoints, tmpPpTypes)
	Context.Trace.Write(p.PointCount)
	tmpPpoints = Nothing
	tmpPpTypes = Nothing
	End If
	End Sub
	
	Sub AddThing2Path (s As Object, e As EventArgs)
		ReconstructPath
		If CType(Me.FindControl("oPathArc"), System.Web.UI.WebControls.Placeholder).visible Then
			p.AddArc(CInt(CType(Me.FindControl("otxtpArcX"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpArcY"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpArcWidth"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpArcHeight"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpArcStartAngle"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpArcSweepAngle"), System.Web.UI.WebControls.textbox).text))
		Context.Trace.Write("Arc Added")
		End If
		If CType(Me.FindControl("oPathBezier"), System.Web.UI.WebControls.Placeholder).visible Then
			p.AddBezier(CInt(CType(Me.FindControl("otxtpBezierX1"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpBezierY1"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpBezierX2"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpBezierY2"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpBezierX3"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpBezierY3"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpBezierX4"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpBezierY4"), System.Web.UI.WebControls.textbox).text))
		Context.Trace.Write("Bezier Added")
		End If
		If CType(Me.FindControl("oPathLine"), System.Web.UI.WebControls.Placeholder).visible Then
			p.AddLine(CInt(CType(Me.FindControl("otxtplineX1"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtplineY1"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtplineX2"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtplineY2"), System.Web.UI.WebControls.textbox).text))
		Context.Trace.Write("Line Added")
		End If
		If CType(Me.FindControl("oPathPie"), System.Web.UI.WebControls.Placeholder).visible Then
			p.AddPie(CInt(CType(Me.FindControl("otxtpPieX"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpPieY"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpPieWidth"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpPieHeight"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpPieStartAngle"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpPieSweepAngle"), System.Web.UI.WebControls.textbox).text))
		Context.Trace.Write("Pie Added")
		End If
		If CType(Me.FindControl("oPathRectangle"), System.Web.UI.WebControls.Placeholder).visible Then
			p.AddRectangle(new System.Drawing.Rectangle(CInt(CType(Me.FindControl("otxtpRectangleX"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpRectangleY"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpRectangleWidth"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpRectangleHeight"), System.Web.UI.WebControls.textbox).text)))
		Context.Trace.Write("Rectangle Added")
		End If
		If CType(Me.FindControl("oPathText"), System.Web.UI.WebControls.Placeholder).visible Then
			Dim newTxtForm As System.Drawing.StringFormat = new System.Drawing.StringFormat()
			newTxtForm.Alignment = StringAlignment.Center
			newTxtForm.LineAlignment = StringAlignment.Center
			p.AddString(CStr(CType(Me.FindControl("otxtpTextTxt"), System.Web.UI.WebControls.textbox).text), new System.Drawing.FontFamily(CType(Me.FindControl("otxtpTextFontFamily"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("opTextStyleDrop"), System.Web.UI.WebControls.DropDownList).SelectedValue), CSng(CType(Me.FindControl("otxtpTextSize"), System.Web.UI.WebControls.textbox).text), new Point(CInt(CType(Me.FindControl("otxtpTextX"), System.Web.UI.WebControls.textbox).text), CInt(CType(Me.FindControl("otxtpTextY"), System.Web.UI.WebControls.textbox).text)), newTxtForm)
			newTxtForm = Nothing
		Context.Trace.Write("Text Added")
		End If
		SavePoints
	End Sub
	
	Sub ChangeActType (s As Object, e As EventArgs)
	CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.Placeholder).visible = False
	CType(Me.FindControl("oSpeacialActEdit"), System.Web.UI.WebControls.Placeholder).visible = False
	CType(Me.FindControl("oActImg"), System.Web.UI.WebControls.Placeholder).visible = False
	CType(Me.FindControl("oActPath"), System.Web.UI.WebControls.Placeholder).visible = False
	Select Case CType(Me.FindControl("oActTypeDrop"), System.Web.UI.WebControls.DropDownList).SelectedValue
	Case "Path"
	CType(Me.FindControl("oActPath"), System.Web.UI.WebControls.Placeholder).visible = True
	CType(Me.FindControl("oSpeacialActEdit"), System.Web.UI.WebControls.Placeholder).visible = True
	CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.Placeholder).visible = True
	Case "Image"
	CType(Me.FindControl("oActImg"), System.Web.UI.WebControls.Placeholder).visible = True
	'CType(Me.FindControl("oActEdits"), System.Web.UI.WebControls.Placeholder)
	End Select
	End Sub
	
	Sub DelAct (s As Object, e As EventArgs)
	Dim numbe As Integer = CType(Me.FindControl("otxtActNumber"), System.Web.UI.WebControls.Textbox).text
	If q.ContainsKey("Act" & numbe) Then
	q.Remove("Act" & numbe)
	q.Add("Act" & numbe, "DoNothing:")
	End If
	Context.Session("ImageEditorCommands") = q
	End Sub
	
	Sub AddAct (s As Object, e As EventArgs)
	Dim strAct2Add As String = "DoNothing:"
	If q.ContainsKey("Act" & CInt(CType(Me.FindControl("otxtActNumber"), System.Web.UI.WebControls.Textbox).text)) Then
	q.Remove("Act" & CInt(CType(Me.FindControl("otxtActNumber"), System.Web.UI.WebControls.Textbox).text))
	End If
		If CType(Me.FindControl("oActPath"), System.Web.UI.WebControls.Placeholder).visible Then
			ReconstructPath
			'(p).Reset
			'(p).AddLine(1,1,40,50)
			If Not p.PointCount = 0 Then
			strAct2Add = "DrawPath:Points=" & GetSerializedStr((p).PathPoints) & ",Types=" & GetSerializedStr((p).PathTypes) & ",Fill=" & CType(Me.FindControl("oPathFillBrush"), System.Web.UI.WebControls.Checkbox).checked & ",FillMode=" & CType(Me.FindControl("oPathFillMode"), System.Web.UI.WebControls.DropDownList).SelectedValue & ",PenWidth=" & CType(Me.FindControl("otxtPathPenWidth"), System.Web.UI.WebControls.Textbox).Text & ",PenColor=" & CType(Me.FindControl("otxtPathPenColor"), System.Web.UI.WebControls.Textbox).Text & ",Opacity=" & CType(Me.FindControl("otxtPathOpac"), System.Web.UI.WebControls.Textbox).Text & "," & GetSpecialStr & ",Brush:" & GetBrushEditStr & ":Brush"
			End If
			ResetPath(new Object(), EventArgs.Empty)
		End If
		If CType(Me.FindControl("oActImg"), System.Web.UI.WebControls.Placeholder).visible Then
			strAct2Add = "DrawImage:ImagePath=" & CType(Me.FindControl("otxtimgPath"), System.Web.UI.WebControls.Textbox).text & ",Width=" & CType(Me.FindControl("otxtimgWidth"), System.Web.UI.WebControls.Textbox).text & ",Height=" & CType(Me.FindControl("otxtimgHeight"), System.Web.UI.WebControls.Textbox).text & ",X=" & CType(Me.FindControl("otxtimgX"), System.Web.UI.WebControls.Textbox).text & ",Y=" & CType(Me.FindControl("otxtimgY"), System.Web.UI.WebControls.Textbox).text & ","
		End If
	q.Add("Act" & CInt(CType(Me.FindControl("otxtActNumber"), System.Web.UI.WebControls.Textbox).text), strAct2Add)
	CType(Me.FindControl("otxtActNumber"), System.Web.UI.WebControls.Textbox).text = CInt(CType(Me.FindControl("otxtActNumber"), System.Web.UI.WebControls.Textbox).text) + 1
	Context.Session("ImageEditorCommands") = q
	strAct2Add = Nothing
	End Sub
	
	Function GetSpecialStr As String
		return CStr("ShadowLevels=" & CType(Me.FindControl("otxtShadowLevels"), System.Web.UI.WebControls.Textbox).text & ",ShadowColor=" & CType(Me.FindControl("otxtShadowColor"), System.Web.UI.WebControls.Textbox).text & ",ShadowOrientation=" & CType(Me.FindControl("oShadowOrientDrop"), System.Web.UI.WebControls.DropDownList).SelectedValue & ",Blur=" & CType(Me.FindControl("oShadowBlur"), System.Web.UI.WebControls.Checkbox).checked)
	End Function
	
	Sub ResetQ (s As Object, e As EventArgs)
	q.Clear
	q.Add("Init", "Width=200,Height=200,PixelFormat=9,TextRenderingHint=4,CompositingMode=0," _
	& "CompositingQuality=3,SmoothingMode=2,InterpolationMode=2,PixelOffsetMode=0,fFormat=jpg," _
	& "bgBrush:bType=2,bFColor=#555555,bBColor=#777777,bStyle=20,bFOpac=255,bBOpac=255,:bgBrush")
	q.Add("Act1", "DoNothing:")
	Context.Session("ImageEditorCommands") = q
	ResetPath(new Object(), EventArgs.Empty)
	End Sub
	
	Sub Back2Init (s As Object, e As EventArgs)
	CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).visible = True
	CType(Me.FindControl("obtnContinue2Act"), System.Web.UI.WebControls.Button).visible = True
	CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.Placeholder).visible = True
	CType(Me.FindControl("obtnBack2Init"), System.Web.UI.WebControls.Button).visible = False
	CType(Me.FindControl("oActEdits"), System.Web.UI.WebControls.PlaceHolder).visible = False
	CType(Me.FindControl("obtnAddAct"), System.Web.UI.WebControls.Button).visible = False
	CType(Me.FindControl("obtnDelAct"), System.Web.UI.WebControls.Button).visible = False
	CType(Me.FindControl("oSpeacialActEdit"), System.Web.UI.WebControls.PlaceHolder).visible = False
	End Sub
	
	Sub Continue2Act (s As Object, e As EventArgs)
	If q.ContainsKey("Init") Then
		q.Remove("Init")
	End If
	q.Add("Init", GetInitStr & "bgBrush:" & GetBrushEditStr & ":bgBrush")
	Context.Session("ImageEditorCommands") = q
	CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).visible = False
	CType(Me.FindControl("obtnContinue2Act"), System.Web.UI.WebControls.Button).visible = False
	CType(Me.FindControl("obtnBack2Init"), System.Web.UI.WebControls.Button).visible = True
	CType(Me.FindControl("oActEdits"), System.Web.UI.WebControls.PlaceHolder).visible = True
	CType(Me.FindControl("obtnAddAct"), System.Web.UI.WebControls.Button).visible = True
	CType(Me.FindControl("obtnDelAct"), System.Web.UI.WebControls.Button).visible = True
	CType(Me.FindControl("oSpeacialActEdit"), System.Web.UI.WebControls.PlaceHolder).visible = True
	End Sub
	
	Function GetInitStr () As String
	return "Width=" & CType(CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).FindControl("otxtWidth"), System.Web.UI.WebControls.TextBox).Text & ",Height=" & CType(CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).FindControl("otxtHeight"), System.Web.UI.WebControls.TextBox).Text & ",PixelFormat=" & CType(CType(CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).FindControl("oInitChoicesMore"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtPxFormat"), System.Web.UI.WebControls.TextBox).text & ",TextRenderingHint=" & CType(CType(CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).FindControl("oInitChoicesMore"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtRendHint"), System.Web.UI.WebControls.TextBox).text & ",CompositingMode=" & CType(CType(CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).FindControl("oInitChoicesMore"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtCompMode"), System.Web.UI.WebControls.TextBox).text & ",CompositingQuality=" & CType(CType(CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).FindControl("oInitChoicesMore"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtCompQual"), System.Web.UI.WebControls.TextBox).text & ",SmoothingMode=" & CType(CType(CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).FindControl("oInitChoicesMore"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtSmoothMode"), System.Web.UI.WebControls.TextBox).text & ",InterpolationMode=" & CType(CType(CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).FindControl("oInitChoicesMore"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtInterpMode"), System.Web.UI.WebControls.TextBox).text & ",PixelOffsetMode=" & CType(CType(CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).FindControl("oInitChoicesMore"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtPxOffMode"), System.Web.UI.WebControls.TextBox).text & ",fFormat=" & CType(CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).FindControl("oImgTypeDrop"), System.Web.UI.WebControls.DropDownList).SelectedValue & ","
	End Function
	
	Function GetBrushEditStr () As String
	If CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushSolid"),System.Web.UI.WebControls.PlaceHolder).visible Then
		return "bType=0,bColor=" & CType(CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushSolid"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtSolidColor"), System.Web.UI.WebControls.TextBox).text & ","
	End If
	If CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushGradient"),System.Web.UI.WebControls.PlaceHolder).visible Then
		return "bType=1,bGradFirst=" & CType(CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushGradient"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtGradStartColor"), System.Web.UI.WebControls.TextBox).text & ",bGradLast=" & CType(CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushGradient"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtGradLastColor"), System.Web.UI.WebControls.TextBox).text & ",bGradAngle=" & CType(CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushGradient"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtGradAngle"), System.Web.UI.WebControls.TextBox).text & ",bOpacFirst=" & CType(CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushGradient"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtGradStartOpac"), System.Web.UI.WebControls.TextBox).text & ",bOpacLast=" & CType(CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushGradient"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtGradLastOpac"), System.Web.UI.WebControls.TextBox).text & ","
	End If
	If CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushHatch"),System.Web.UI.WebControls.PlaceHolder).visible Then
		return "bType=2,bFColor=" & CType(CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushHatch"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtHatchForeColor"), System.Web.UI.WebControls.TextBox).text & ",bBColor=" & CType(CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushHatch"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtHatchBackColor"), System.Web.UI.WebControls.TextBox).text & ",bStyle=" & CType(CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushHatch"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtHatchStyle"), System.Web.UI.WebControls.TextBox).text & ",bFOpac=" & CType(CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushHatch"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtHatchForeOpac"), System.Web.UI.WebControls.TextBox).text & ",bBOpac=" & CType(CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushHatch"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtHatchBackOpac"), System.Web.UI.WebControls.TextBox).text & ","
	End If
	If CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushTexture"),System.Web.UI.WebControls.PlaceHolder).visible Then
		return "bType=3,bImagePath=" & CType(CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushTexture"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtTexturePath"), System.Web.UI.WebControls.TextBox).text & ",bWrapStyle=" & CType(CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushTexture"),System.Web.UI.WebControls.PlaceHolder).FindControl("otxtTextureWrap"), System.Web.UI.WebControls.TextBox).text & ","
	End If
	End Function
	
	Sub ShowBrushStylePlaceholder (s As Object, e As EventArgs)
	CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushSolid"),System.Web.UI.WebControls.PlaceHolder).visible = False
	CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushGradient"),System.Web.UI.WebControls.PlaceHolder).visible = False
	CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushHatch"),System.Web.UI.WebControls.PlaceHolder).visible = False
	CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushTexture"),System.Web.UI.WebControls.PlaceHolder).visible = False
	Select Case CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushStyleDrop"),System.Web.UI.WebControls.DropDownList).SelectedValue
		Case 0 'Solid
			CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushSolid"),System.Web.UI.WebControls.PlaceHolder).visible = True
		Case 1 'Gradient
			CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushGradient"),System.Web.UI.WebControls.PlaceHolder).visible = True
		Case 2 'Hatch
			CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushHatch"),System.Web.UI.WebControls.PlaceHolder).visible = True
		Case 3 'Texture
			CType(CType(Me.FindControl("oBrushEdit"), System.Web.UI.WebControls.PlaceHolder).FindControl("oBrushTexture"),System.Web.UI.WebControls.PlaceHolder).visible = True
	End Select
	End Sub
	
	Sub SwitchMoreInitOptions (s As Object, e As EventArgs)
	If CType(CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).FindControl("oInitChoicesMore"), System.Web.UI.WebControls.PlaceHolder).visible Then
	CType(CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).FindControl("oInitChoicesMore"), System.Web.UI.WebControls.PlaceHolder).visible = False
	Else
	CType(CType(Me.FindControl("oInitChoices"), System.Web.UI.WebControls.PlaceHolder).FindControl("oInitChoicesMore"), System.Web.UI.WebControls.PlaceHolder).visible = True
	End If
	End Sub
	
	Sub LoadUpHashtable
	If Not Context.Session("ImageEditorCommands") Is Nothing Then
	q = Context.Session("ImageEditorCommands")
	'Else
	'q.Add("Init", "Width=200,Height=200,PixelFormat=9,TextRenderingHint=4,CompositingMode=0," _
	'& "CompositingQuality=3,SmoothingMode=2,InterpolationMode=2,PixelOffsetMode=0,fFormat=jpg," _
	'& "bgBrush:bType=2,bFColor=#555555,bBColor=#777777,bStyle=20,bFOpac=255,bBOpac=255,:bgBrush")
	'q.Add("Act1", "DoNothing:")
	'Context.Session("ImageEditorCommands") = q
	'q.Clear
	End If
	End Sub
	
	Function mkhelp (ByVal explStr As String, Optional ByVal fsize As Integer = 12, Optional ByVal winCont As String = "") As String
	If UseOverlibHelp Then
	If winCont = "" Then
	return "<a href=""javascript:"" onmouseover=""overlib('" & explStr & "', CSSSTYLE, TEXTSIZEUNIT, 'px', TEXTSIZE, " & fsize & ");"" onmouseout=""nd();"">(?)</a>"
	Else 'Create help window
	Context.Response.Write("<script language=""JavaScript"">" & vbCrLf)
	Context.Response.Write("function showImageEdithelpWindow (txt2show) {" & vbCrLf)
	Context.Response.Write("ImageEditWin=window.open('','','statusbar=no,scrollbars=yes,width=400,height=200')" & vbCrLf)
	Context.Response.Write("ImageEditWin.document.open()" & vbCrLf)
	Context.Response.Write("ImageEditWin.document.write(""<html><head><Title>Image Editor help window</title></head><body style='FONT-SIZE: 12px; COLOR: black; FONT-FAMILY: Tahoma' text='#FFFFFF' vlink='#800080' alink='#ff0000' link='#000080' bgcolor='#778899'><font style='color:white'>"" + txt2show + ""</font></body></html>"")" & vbCrLf)
	Context.Response.Write("ImageEditWin.document.close()" & vbCrLf)
	Context.Response.Write(vbCrLf & "}" & vbCrLf & "</script>")
	return "<a href=""javascript:showImageEdithelpWindow('" & winCont & "')"" onmouseover=""overlib('" & explStr & "', CSSSTYLE, TEXTSIZEUNIT, 'px', TEXTSIZE, " & fsize & ");"" onmouseout=""nd();"">(?)</a>"
	End If
	Else
	return ""
	End If
	End Function
	
	Public Function GetSerializedStr(ByVal obj2Serial As Object) As String
		Dim objBinaryFormatterC As System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
		objBinaryFormatterC = New System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
		Dim MemoryStreamC
		MemoryStreamC = New MemoryStream
		objBinaryFormatterC.Serialize(MemoryStreamC, obj2Serial)
		Dim ArrayByteC() As Byte
		ArrayByteC = MemoryStreamC.ToArray()
		Dim TTS As String
		Dim TempCB As Byte
			For Each TempCB In ArrayByteC
				TTS = TTS & "-" & TempCB
			Next TempCB
		MemoryStreamC.Close()
		'Replace all 1 with {
		Dim TTS2 As String = TTS.Replace("1", "{")
		'Replace all 5 with >
		TTS2 = TTS2.Replace("5", ">")
		'Replace all 49 with *
		TTS2 = TTS2.Replace("49", "*")
		'Replace all {{ with $
		TTS2 = TTS2.Replace("{{", "$")
		'Replace all >> with <
		TTS2 = TTS2.Replace(">>", "<")
		'Replace all -0- with ]
		TTS2 = TTS2.Replace("-0-", "]")
		'Replace all -{ with @
		TTS2 = TTS2.Replace("-{", "@")
		'Replace all -$ with underscore
		TTS2 = TTS2.Replace("-$", "_")
		'Replace all 08 with +
		TTS2 = TTS2.Replace("08", "+")
		'Replace all 00 with ,
		TTS2 = TTS2.Replace("00", ".")
		'Replace all -*- with %
		TTS2 = TTS2.Replace("-*-", "%")
		'Replace all 0] with ^
		TTS2 = TTS2.Replace("0]", "^")
		
		Return TTS2
					objBinaryFormatterC = Nothing
			MemoryStreamC = Nothing
			ArrayByteC = Nothing
			TTS = Nothing
			TempCB = Nothing
			TTS2 = Nothing
	End Function
	
	'Function to get the object back through a string returned by GetSerializedStr()
	
	Public Function GetDeSerializedObj(ByVal strSerialized As String) As Object
			Dim SobjBinaryFormatterC As System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
			SobjBinaryFormatterC = New System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
			Dim SMemoryStreamC
			SMemoryStreamC = New MemoryStream
			Dim STT As String = strSerialized.Replace("^", "0]")
			STT = STT.Replace("%", "-*-")
			STT = STT.Replace(".", "00")
			STT = STT.Replace("+", "08")
			STT = STT.Replace("_", "-$")
			STT = STT.Replace("@", "-{")
			STT = STT.Replace("]", "-0-")
			STT = STT.Replace("<", ">>")
			STT = STT.Replace("$", "{{")
			STT = STT.Replace("*", "49")
			STT = STT.Replace(">", "5")
			STT = STT.Replace("{", "1")
			Dim STempCB As String
			Dim SArrayByte
			SArrayByte = New System.Collections.ArrayList
			Dim SContinue As Boolean = True
			Dim SPosition As Integer = 0
			Dim SCounterB As Integer = 0
			Dim PtempP As Integer
			Dim PPtempPP
			
			Do While SContinue
			If Not SPosition = -1 Then
			If Not STT.indexOf("-", SPosition + 1) = -1 Then
			PPtempPP = STT.indexOf("-", SPosition + 1) -1
			STempCB = STT.substring(SPosition + 1, PPtempPP - SPosition)
			SArrayByte.Insert(SCounterB, CByte(STempCB))
			Else
			PtempP = STT.length - 1
			STempCB = STT.substring(SPosition + 1, PtempP - SPosition)
			SArrayByte.Insert(SCounterB, CByte(STempCB))
			SContinue = False
			End If
			Else
			SContinue = False
			End If
			SPosition = STT.indexOf("-", SPosition + 1)
			SCounterB = SCounterB + 1
			Loop
			
			Dim SCounter As Integer = 0
			Dim SArrayByte2
			SArrayByte2 = SArrayByte.ToArray()
			Do
			SMemoryStreamC.WriteByte(SArrayByte2(SCounter))
			SCounter = SCounter + 1
			Loop Until SCounter = SArrayByte2.Length
					Dim SObj2get
					SMemoryStreamC.Position = 0
					SObj2get = SobjBinaryFormatterC.Deserialize(SMemoryStreamC)
			SMemoryStreamC.Close()
			
			Return SObj2get
								SobjBinaryFormatterC = Nothing
					SMemoryStreamC = Nothing
					STT = Nothing
					STempCB = Nothing
					SArrayByte = Nothing
					SContinue = Nothing
					SPosition = Nothing
					SCounterB = Nothing
					PtempP = Nothing
					PPtempPP = Nothing
					SCounter = Nothing
					SArrayByte2 = Nothing
	End Function
	
	Function GetMainHelpStr As String
	return "> <font color=orange size=3>Image Editor Instructions</font><br>Image Editor is a small piece of code to help people make simple images with the help of the server on which the code is run. So, you cannot expect much from this, although you can achieve pretty nice results with right usage.<p>" _
	& "<b>The GUI (graphical user interface):</b><br>It contains two boxes. The first one shows the image as it was edited (grey with lines if not) and underneath it the coordinates of the point on which you clicked the image. THe second box contains the real image editor. Upon starting, you must first specify the initialization options (the characteristics of the image). Then, if you want a background, specify it by choosing from the Brush options. To change the brush style, select one from the dropdown list and click the Chnage Style link. When you are ready, click the continue button. (You can always click the Reset button to undo all the editing you have done). The image commands are called Acts. Each act is defined by a number which also defines the order according to which they will be drawn (especially important when opacity of things is wanted)." _
	& "When you have finished editing the act, click the Add/Replace button. If you have already added an act with the specified number, it will be replaced. To delete an act, type its number and click the delete button (you must continue counting normally as if it was not deleted)." _
	& "<p><b>Path Act Type Explanation:</b><br>Path is a type for an act which needs a little bit of explanation. Paths can contain shapes and text. To add a thing to the path, specify its options and click the Add to path link. When you have finished storing all the things, click the Add Act button. Then, the path is reset. So, you must re-edit a new path to add. (This can also be done by clicking the Reset Path link.)" _
	& "<p><b>Brushes:</b><br>Brushes can be used to specify things that are painted with colors. On some occasions it can mean a line, on others a fill, on other a background."
	End Function
		 
End Class



End Namespace