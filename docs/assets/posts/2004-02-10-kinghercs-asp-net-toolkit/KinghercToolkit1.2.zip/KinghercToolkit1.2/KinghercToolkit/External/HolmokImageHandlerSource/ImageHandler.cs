using System;
using System.IO;
using System.Web;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace Holmok.HttpHandlers
{

	public class ImageHandler:IHttpHandler
	{

		HttpResponse Response;
		HttpRequest Request;
		HttpServerUtility Server;

		#region IHttpHandler Members

		public void ProcessRequest(HttpContext context)
		{

			//Set global context objects
			Server = context.Server;
			Response = context.Response;
			Request = context.Request;

			//Do the image stuff
			RequestImage();

		}

		public bool IsReusable
		{
			get{return true;}
		}

		#endregion

		#region Image Members

		private void ShowNoAccessImage()
		{
			//They are not allowed to veiw the actual image, so let's deal with that.
			string image_path = Setting("no access");
			string  content_type = ResponseType(image_path);
			if (content_type == null)
			{
				//It's not an image, it's a redirect.
				Response.Redirect(image_path);
			}
			else
			{
				image_path = Server.MapPath(image_path);
				Response.ContentType = content_type;
				if (File.Exists(image_path))
				{
					Response.WriteFile(image_path);
				}
			}
		}

		private void ShowImage(string image_path)
		{

			//Retrieve Querystring Attributes
			bool thumb = (Request.QueryString["thumb"] != null);

			int percent = 0;
			if (Request.QueryString["p"]!=null){percent = Int32.Parse(Request.QueryString["p"]);}

			int height=0,width=0;
			if (Request.QueryString["h"]!=null){height = Int32.Parse(Request.QueryString["h"]);}
			if (Request.QueryString["w"]!=null){width = Int32.Parse(Request.QueryString["w"]);}

			//Send the response content type
			Response.ContentType = ResponseType(image_path);

			//Grab Image
			Bitmap image = (Bitmap)Bitmap.FromFile(image_path);
			Bitmap output = null;

			//what do we do?
			if (thumb)
			{
				//get thumbnail size, resize image and send it out.
				int thumbsize = Int32.Parse(Setting("thumbnail size"));
				float new_width=0f;
				float new_height=0f;
				if (image.Width > image.Height)
				{
					new_width = thumbsize;
					new_height = thumbsize * ((float)image.Height/(float)image.Width);
				}
				else
				{
					new_height = thumbsize;
					new_width = thumbsize * ((float)image.Width/(float)image.Height);
				}
				output = Resize(image,(int)new_height,(int)new_width);
			}
			else if(height > 0 && width > 0)
			{ 
				output = Resize(image,height,width);
			}
			else if(height > 0 && !(width > 0))
			{ 
				width = (int)(image.Width * (float)height/(float)image.Height);
				output = Resize(image,height,width);
			}
			else if(!(height > 0) && width > 0)
			{ 
				height = (int)(image.Height * (float)width/(float)image.Width);
				output = Resize(image,height,width);
			}
			else if(percent > 0)
			{
				float per = (float)percent/100;
				output = Resize(image,(int)(image.Height*per),(int)(image.Width*per));
			}
			else{output = image;}

			//Do we watermark it?
			int wmmw = Int32.Parse(Setting("watermark minimum wdith"));

			if (output.Width >= wmmw)
			{
				//Add watermark
				output = Watermark(output);
			}

			output.Save(Response.OutputStream,ImageType(image_path));
		}

		private void RequestImage()
		{
			//Get stuffs from the query string.
			string image_path = Request.Path;
            image_path = Server.MapPath(image_path);

			//See if file asked for another site, if it is allowed
			if(
				Setting("allow external referrers").ToLower() == "no" 
					&& 
				Request.UrlReferrer != null
			)
			{
				if (Request.UrlReferrer.Host == Request.Url.Host)
				{
					ShowImage(image_path);
				}
				else
				{
					ShowNoAccessImage();
				}
			}
			//No Referers Allowed?
			else if (
				Setting("allow no referrers").ToLower() == "no" 
				&& 
				Request.UrlReferrer == null
				)
			{
				ShowNoAccessImage();
			}
			else
			{
				ShowImage(image_path);
			}
		}

		private Bitmap Watermark(Bitmap image)
		{

			//Make graphic for drawing
			Graphics watermark = Graphics.FromImage(image);
			int width = image.Width;
			int height = image.Height;

			//figure start position
			string position = Setting("watermark position").ToLower();
			float x,y;
			x = float.Parse(Setting("watermark x"));
			y = float.Parse(Setting("watermark y"));

			switch(position)
			{
				case "top right":
					x = width + x;
					break;

				case "bottom right":
					x = width + x;
					y = height + y;
					break;

				case "bottom left":
					y = height + y;
					break;

				default:
					//just leave them an do to left
					break;
			}

			//what watermark?
			string type = Setting("watermark type");
			switch (type.ToLower())
			{
				case "text":
					//Setup color, brush, and font.
					Color color = ColorTranslator.FromHtml(Setting("watermark color"));
					Brush brush = new SolidBrush(color);
					Font font = new Font
						(
						Setting("watermark font"),
						float.Parse(Setting("watermark size")),
						GraphicsUnit.Pixel
						);
					string text = Setting("watermark text");

					string shadow = Setting("watermark shadow color");
					if (shadow != null)
					{
						//Add drop shadow
						Color s_color = ColorTranslator.FromHtml(shadow);
						Brush s_brush = new SolidBrush(s_color);
						string distance = Setting("watermark shadow distance");
						float dist = 0.0f;
						if (distance != null)
						{dist = float.Parse(distance);}
						else
						{dist = 2.0f;}
						watermark.DrawString(text,font,s_brush,x+dist,y+dist);

					}
					watermark.DrawString(text,font,brush,x,y);
					break;

				case "graphic":
					string wm_image_path = Setting("watermark graphic");
					if (wm_image_path == null){break;}
					wm_image_path = Server.MapPath(wm_image_path);
					if (File.Exists(wm_image_path))
					{
                        Bitmap wm_image = (Bitmap)Bitmap.FromFile(wm_image_path);
						string transparent = Setting("watermark graphic transparent color");
						if (transparent != null)
						{
							Color t_color = ColorTranslator.FromHtml(transparent);
							wm_image.MakeTransparent(t_color);
						}
						watermark.DrawImage(wm_image,x,y,wm_image.Width,wm_image.Height);
					}
					break;

			}

			return image;

		}

		private Bitmap Resize(Bitmap image, int height, int width)
		{
			Bitmap thumb = new Bitmap(width,height);
			Graphics g_thumb = Graphics.FromImage(thumb);
			g_thumb.InterpolationMode = InterpolationMode.HighQualityBicubic;
			g_thumb.DrawImage(image,0,0,width,height);
			return thumb;
		}

		private string ResponseType(string image_path)
		{
			switch(Path.GetExtension(image_path).ToLower())
			{
				case ".bmp"	: return "Image/bmp";
				case ".gif"	: return "Image/gif";
				case ".jpg"	: return "Image/jpeg";
				case ".png"	: return "Image/png";
				default		: return null;
			}
		}

		private ImageFormat ImageType(string image_path)
		{
			switch(Path.GetExtension(image_path).ToLower())
			{
				case ".bmp"	: return ImageFormat.Bmp;
				case ".gif"	: return ImageFormat.Gif;
				case ".jpg"	: return ImageFormat.Jpeg;
				case ".png"	: return ImageFormat.Png;
				default		: return null;
			}
		}

		private string Setting(string key)
		{
			key = "hih " + key;
			return ConfigurationSettings.AppSettings[key];
		}

		#endregion
	}
}
