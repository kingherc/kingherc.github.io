'Pocket Control PC - NetCf
'Copyright (C) 2004 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Net.Sockets
Imports System.Net
Imports System.Threading
Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Runtime.InteropServices
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.Windows.Forms

<Assembly: AssemblyTitle("Pocket Control PC - NetCf")> 
<Assembly: AssemblyDescription("Used along with Pocket Control PC - PC to control a PC from a remote device. E.g. Control PC's mouse and keyboard. More info possibly at http://www34.brinkster.com/kingherc/.")> 
<Assembly: AssemblyCompany("None")> 
<Assembly: AssemblyProduct("Pocket Control PC - NetCf")> 
<Assembly: AssemblyCopyright("2004 Iraklis Psaroudakis")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: AssemblyVersion("1.0.0")> 

Public Class Main
    Inherits System.Windows.Forms.Form


    Public Sub New()
        MyBase.New()
        Init()
    End Sub

    Public Shared strRegKey As String = "HKEY_CURRENT_USER\Software\Pocket Control PC - NetCf"
    Dim ProgramVersion As New Version(1, 0, 0)
    Dim IPtoConnect As IPAddress
    Dim PORT_NO As Integer = IPEndPoint.MaxPort
    Dim scon As New TcpClient
    Dim bConnected As Boolean = False
    Dim ns As NetworkStream
    Dim LastCommand As String = ""
    Dim WasValidated As Boolean = False
    Dim LogFirstMessage As String = "Please see Help > Licence. The log will be shown below this line:"
    Dim RemoteScreenSize As New Size(800, 600)
    Dim RemoteMouseLocation As New Point(1, 1)
    Dim MouseMoveStep As Integer = 30
    Dim ScrollMoveStep As Integer = 5
    Dim KeyboardKeys As New Hashtable
    Dim CurrentKeyIndex As Integer = 1
    Dim keyboardBackupImg As Image
    Dim hResources As New Hashtable
    Dim IsMacroRec As Boolean = False
    Dim IsTimeMacroExe As Boolean = False
    Dim MacroRecText As String
    Dim TimeMacroComm As Hashtable
    Dim MacroShorcuts As New ArrayList(7)
    Dim MacroTimerDecimate As Double = 1
    Dim IsQuickMouse As Boolean = False
    Dim QuickMouseInterval As Integer = 300
    Public Shared WorkingSize As Size
    Public Shared SmartphonePanelsSize As Size = New Size(176, 180)
    Public Shared LabelFont As Font

    Structure KeyboardIndex
        Dim Index As Integer
        Dim Value As Integer
        Dim Representation As String
        Dim KeyOutline As Rectangle
        Dim AboveIndex As Integer
        Dim RightIndex As Integer
        Dim BelowIndex As Integer
        Dim LeftIndex As Integer
        Dim IsPressed As Boolean 'Used for shifts, alts etc.
    End Structure

    Const KEYEVENTF_EXTENDEDKEY As Integer = &H1
    Const KEYEVENTF_KEYUP As Integer = &H2

    Friend WithEvents mnConnect As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMenus As New System.Windows.Forms.MainMenu
    Friend WithEvents tmrListenCommandsLoop As New System.Windows.Forms.Timer
    Friend WithEvents mnMenu As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDisconnect As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSendTest As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSendMessage As New System.Windows.Forms.MenuItem
    Friend WithEvents txtLog As New System.Windows.Forms.TextBox
    Friend WithEvents mnSendCustom As New System.Windows.Forms.MenuItem
    Friend WithEvents mnLog As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSeperator2 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnLogClear As New System.Windows.Forms.MenuItem
    Friend WithEvents mnLogSave As New System.Windows.Forms.MenuItem
    Friend WithEvents mnOptions As New System.Windows.Forms.MenuItem
    Friend WithEvents mnOptionsSeperator As New System.Windows.Forms.MenuItem
    Friend WithEvents mnOptionsSave As New System.Windows.Forms.MenuItem
    Friend WithEvents mnConValidate As New System.Windows.Forms.MenuItem
    Friend WithEvents mnOIP As New System.Windows.Forms.MenuItem
    Friend WithEvents mnOEnsureConnection As New System.Windows.Forms.MenuItem
    Friend WithEvents mnExit As New System.Windows.Forms.MenuItem
    Friend WithEvents mnHelp As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnAbout As New System.Windows.Forms.MenuItem
    Friend WithEvents mnLicence As New System.Windows.Forms.MenuItem
    Friend WithEvents imgCursorClicks As New System.Windows.Forms.ImageList
    Friend WithEvents mnMode As New System.Windows.Forms.MenuItem
    Friend WithEvents mnModeNone As New System.Windows.Forms.MenuItem
    Friend WithEvents mnModeMouse As New System.Windows.Forms.MenuItem
    Friend WithEvents pbDepictMouse As New System.Windows.Forms.PictureBox
    Friend WithEvents lblMouseInfo As New System.Windows.Forms.Label
    Friend WithEvents imgScrollClicks As New System.Windows.Forms.ImageList
    Friend WithEvents pbDepictScroll As New System.Windows.Forms.PictureBox
    Friend WithEvents mnModeKeyboard As New System.Windows.Forms.MenuItem
    Friend WithEvents nKeyboard As New System.Windows.Forms.PictureBox
    Friend WithEvents mnInputKeys As New System.Windows.Forms.MenuItem
    Friend WithEvents mnInputMousePos As New System.Windows.Forms.MenuItem
    Friend WithEvents mnOtherActions As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSeperator3 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacros As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroExe As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroSeperator2 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroRec As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroStop As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroSeperator As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroOptions As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroOExeIn As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroOExeOut As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroOExeTime As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroOInvCom As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroODecim As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcuts As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcut1 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcut2 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcut3 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcut4 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcut5 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcut6 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcut7 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcutSeperator As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcutsManage As New System.Windows.Forms.MenuItem
    Friend WithEvents tmrTimeMacroExe As New System.Windows.Forms.Timer
    Friend WithEvents tmrEnsureConnection As New System.Windows.Forms.Timer
    Friend WithEvents tmrSendEnsureConnection As New System.Windows.Forms.Timer

    Private Sub LoadUpResources()
        Dim iStream As Stream = System.Reflection.Assembly.GetExecutingAssembly.GetManifestResourceStream(System.Reflection.Assembly.GetExecutingAssembly.GetManifestResourceNames(0))
        Dim rr As New System.Resources.ResourceReader(iStream)
        Dim id As IDictionaryEnumerator = rr.GetEnumerator()
        While id.MoveNext()
            hResources.Add(id.Key, id.Value)
        End While
    End Sub

    Sub Init()
        If APICalls.GetPlatformName.IndexOf("WindowsPC") = -1 Then
            WorkingSize = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Size
            LabelFont = New System.Drawing.Font("Nina", 9.0!, System.Drawing.FontStyle.Regular)
        Else
            WorkingSize = New Size(300, 400)
            LabelFont = New System.Drawing.Font("Nina", 8.0!, System.Drawing.FontStyle.Regular)
        End If
        Me.ClientSize = WorkingSize
        WorkingSize = Me.ClientSize

        LoadUpResources()

        mnMenus.MenuItems.Add(mnConnect)
        mnMenus.MenuItems.Add(mnMenu)

        mnConnect.Text = "Connect"

        mnMenu.MenuItems.Add(mnMode)
        mnMenu.MenuItems.Add(mnMacros)
        mnMenu.MenuItems.Add(mnDisconnect)
        mnMenu.MenuItems.Add(mnSeperator2)
        mnMenu.MenuItems.Add(mnOptions)
        mnMenu.MenuItems.Add(mnSeperator1)
        mnMenu.MenuItems.Add(mnHelp)
        mnMenu.MenuItems.Add(mnExit)
        mnMenu.Text = "Menu"

        mnMode.MenuItems.Add(mnModeNone)
        mnMode.MenuItems.Add(mnModeMouse)
        mnMode.MenuItems.Add(mnModeKeyboard)
        mnMode.MenuItems.Add(mnSeperator3)
        mnMode.MenuItems.Add(mnOtherActions)
        mnMode.Text = "Mode"

        mnModeMouse.Enabled = False
        mnModeKeyboard.Enabled = False
        mnOtherActions.Enabled = False

        mnModeNone.Checked = True
        mnModeNone.Text = "None / Log"

        'mnModeMouse.Enabled = False
        mnModeMouse.Text = "Mouse"

        'mnModeKeyboard.Enabled = False
        mnModeKeyboard.Text = "Keyboard"

        mnSeperator3.Text = "-"

        'mnOtherActions.Enabled = False
        mnOtherActions.MenuItems.Add(mnInputKeys)
        mnOtherActions.MenuItems.Add(mnInputMousePos)
        mnOtherActions.MenuItems.Add(mnSendMessage)
        mnOtherActions.Text = "Other Actions"

        mnInputKeys.Text = "Input Text/Keys"
        mnInputMousePos.Text = "Input Mouse Position"

        mnMacros.Text = "Macros"
        mnMacros.MenuItems.Add(mnMacroExe)
        mnMacros.MenuItems.Add(mnMacroShorcuts)
        mnMacros.MenuItems.Add(mnMacroSeperator2)
        mnMacros.MenuItems.Add(mnMacroRec)
        mnMacros.MenuItems.Add(mnMacroStop)
        mnMacros.MenuItems.Add(mnMacroSeperator)
        mnMacros.MenuItems.Add(mnMacroOptions)

        mnMacroOptions.MenuItems.Add(mnMacroOExeIn)
        mnMacroOptions.MenuItems.Add(mnMacroOExeOut)
        mnMacroOptions.MenuItems.Add(mnMacroOExeTime)
        mnMacroOptions.MenuItems.Add(mnMacroODecim)
        mnMacroOptions.MenuItems.Add(mnMacroOInvCom)

        mnMacroExe.Text = "Execute file..."
        mnMacroShorcuts.Text = "Shorcuts"
        mnMacroSeperator2.Text = "-"
        mnMacroRec.Text = "Start Recording"
        mnMacroStop.Text = "Stop Rec - Save..."
        mnMacroSeperator.Text = "-"
        mnMacroStop.Enabled = False

        mnMacroOptions.Text = "Options"
        mnMacroOExeIn.Text = "Execute Incoming commands"
        mnMacroOExeOut.Text = "Execute Outgoing commands"
        mnMacroOExeTime.Text = "Timeless execution"
        mnMacroOExeIn.Checked = True
        mnMacroOExeTime.Checked = True
        mnMacroOInvCom.Text = "Invert Incoming & Outgoing"
        mnMacroODecim.Text = "Decimate Timers by..."

        mnMacroShorcuts.MenuItems.Add(mnMacroShorcut1)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcut2)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcut3)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcut4)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcut5)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcut6)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcut7)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcutSeperator)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcutsManage)

        mnMacroShorcut1.Text = "1. Undefined"
        mnMacroShorcut2.Text = "2. Undefined"
        mnMacroShorcut3.Text = "3. Undefined"
        mnMacroShorcut4.Text = "4. Undefined"
        mnMacroShorcut5.Text = "5. Undefined"
        mnMacroShorcut6.Text = "6. Undefined"
        mnMacroShorcut7.Text = "7. Undefined"
        mnMacroShorcutSeperator.Text = "-"
        mnMacroShorcutsManage.Text = "Manage Shorcuts..."

        tmrTimeMacroExe.Enabled = False

        mnSendMessage.MenuItems.Add(mnSendTest)
        mnSendMessage.MenuItems.Add(mnSendCustom)
        mnSendMessage.Text = "Send Message"

        mnSendTest.Text = "Test Message"

        mnSendCustom.Text = "Custom..."

        mnDisconnect.Enabled = False
        mnDisconnect.Text = "Disconnect"

        mnSeperator2.Text = "-"

        mnOptions.MenuItems.Add(mnLog)
        mnOptions.MenuItems.Add(mnConValidate)
        mnOptions.MenuItems.Add(mnOEnsureConnection)
        mnOptions.MenuItems.Add(mnOIP)
        mnOptions.MenuItems.Add(mnOptionsSeperator)
        mnOptions.MenuItems.Add(mnOptionsSave)
        mnOptions.Text = "Options"

        mnOEnsureConnection.Text = "Ensure active connection"
        mnOEnsureConnection.Checked = True
        mnOEnsureConnection.Enabled = False

        mnOIP.Text = "Configure IP..."

        mnOptionsSeperator.Text = "-"
        mnOptionsSave.Text = "Save Options"

        mnConValidate.Checked = True
        mnConValidate.Text = "Validate Connection"

        mnLog.MenuItems.Add(mnLogClear)
        mnLog.MenuItems.Add(mnLogSave)
        mnLog.Text = "Log"

        mnLogClear.Text = "Clear"

        mnLogSave.Text = "Save..."

        mnSeperator1.Text = "-"

        mnHelp.MenuItems.Add(mnAbout)
        mnHelp.MenuItems.Add(mnLicence)
        mnHelp.Text = "Help"

        mnAbout.Text = "About"

        mnLicence.Text = "Licence"

        mnExit.Text = "Exit"

        txtLog.Font = New System.Drawing.Font("Nina", 9.0!, System.Drawing.FontStyle.Regular)
        txtLog.Multiline = True
        txtLog.ReadOnly = True
        txtLog.ScrollBars = ScrollBars.Both
        txtLog.Size = New System.Drawing.Size(175, 175)
        txtLog.WordWrap = False
        txtLog.Location = New Point(0, -1)
        txtLog.Text = LogFirstMessage
        txtLog.Width = WorkingSize.Width
        txtLog.Height = WorkingSize.Height + 2

        imgCursorClicks.Images.Add(New Bitmap(CType(hResources("MouseIdle"), System.Drawing.Image)))
        imgCursorClicks.Images.Add(New Bitmap(CType(hResources("MouseLeft"), System.Drawing.Image)))
        imgCursorClicks.Images.Add(New Bitmap(CType(hResources("MouseUp"), System.Drawing.Image)))
        imgCursorClicks.Images.Add(New Bitmap(CType(hResources("MouseRight"), System.Drawing.Image)))
        imgCursorClicks.Images.Add(New Bitmap(CType(hResources("MouseDown"), System.Drawing.Image)))
        imgCursorClicks.Images.Add(New Bitmap(CType(hResources("MouseLeftClick"), System.Drawing.Image)))
        imgCursorClicks.Images.Add(New Bitmap(CType(hResources("MouseMiddleClick"), System.Drawing.Image)))
        imgCursorClicks.Images.Add(New Bitmap(CType(hResources("MouseRightClick"), System.Drawing.Image)))
        imgCursorClicks.ImageSize = New System.Drawing.Size(81, 87)

        pbDepictMouse.Location = New System.Drawing.Point(40, 3)
        pbDepictMouse.Size = imgCursorClicks.ImageSize
        pbDepictMouse.Image = imgCursorClicks.Images(0)
        pbDepictMouse.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        pbDepictMouse.Visible = False

        imgScrollClicks.Images.Add(New Bitmap(CType(hResources("ScrollIdle"), System.Drawing.Image)))
        imgScrollClicks.Images.Add(New Bitmap(CType(hResources("ScrollUp"), System.Drawing.Image)))
        imgScrollClicks.Images.Add(New Bitmap(CType(hResources("ScrollDown"), System.Drawing.Image)))
        imgScrollClicks.Images.Add(New Bitmap(CType(hResources("ScrollX1Button"), System.Drawing.Image)))
        imgScrollClicks.Images.Add(New Bitmap(CType(hResources("ScrollX2Button"), System.Drawing.Image)))
        imgScrollClicks.ImageSize = New System.Drawing.Size(50, 42)

        pbDepictScroll.Location = New System.Drawing.Point(60, 3)
        pbDepictScroll.Size = imgScrollClicks.ImageSize
        pbDepictScroll.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        pbDepictScroll.Visible = False
        pbDepictScroll.Image = imgScrollClicks.Images(0)

        lblMouseInfo.Font = LabelFont
        lblMouseInfo.Location = New Point(0, pbDepictMouse.Bottom + 2)
        lblMouseInfo.Text = "Mouse Info"
        lblMouseInfo.Visible = False

        tmrListenCommandsLoop.Interval = 50

        tmrEnsureConnection.Interval = 20000
        tmrSendEnsureConnection.Interval = 17000

        nKeyboard.Location = New System.Drawing.Point(0, 0)
        nKeyboard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        nKeyboard.Visible = False
        nKeyboard.Image = New Bitmap(166, 171)
        nKeyboard.Image = New Bitmap(CType(hResources("Keyboard"), System.Drawing.Image))
        keyboardBackupImg = New Bitmap(nKeyboard.Image)

        Me.BackColor = Color.White
        Me.Icon = CType(hResources("ApplicationIcon 16"), System.Drawing.Icon)
        Controls.Add(nKeyboard)
        Controls.Add(pbDepictScroll)
        Controls.Add(lblMouseInfo)
        Controls.Add(pbDepictMouse)
        Controls.Add(txtLog)
        Menu = mnMenus
        Text = "Pocket Control PC - NetCf"
    End Sub



    Private Sub Main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DefineKeyboard()
        Try
            LoadOptions()
        Catch ex As Exception
            Out("Loading options was met with errors.")
        End Try
    End Sub

    Private Sub Main_Closed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        If bConnected Then
            mnDisconnect_Click(Me, EventArgs.Empty)
        End If
        Try
            SaveOptions()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Main_Resize(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        WorkingSize = Me.ClientSize
        txtLog.Size = New Size(WorkingSize.Width, WorkingSize.Height + 2)
        pbDepictMouse.Left = (WorkingSize.Width - (pbDepictMouse.Width + pbDepictScroll.Width + 5)) / 2
        pbDepictScroll.Left = pbDepictMouse.Right + 5
        nKeyboard.Size = WorkingSize
        lblMouseInfo.Size = New Size(WorkingSize.Width, WorkingSize.Height - lblMouseInfo.Top)
    End Sub

    'When a key is pressed on the form
    Private Sub Main_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Select Case e.KeyValue
            Case 13 'action
                If mnModeMouse.Checked Then 'Mouse Mode > Left Mouse Button Down
                    CancelRemoteQuickMouse()
                    pbDepictMouse.Image = imgCursorClicks.Images(5)
                    cOut("MouseLeftButtonDown")
                End If
            Case 49 '1
                If mnModeMouse.Checked Then 'Mouse Mode > Quick Mouse Mode
                    'pbDepictMouse.Image = imgCursorClicks.Images(5)
                    'cOut("MouseLeftButtonDown")
                    If IsQuickMouse Then
                        IsQuickMouse = False
                    Else
                        IsQuickMouse = True
                    End If
                    UpdateMouseLabel()
                End If
            Case 50 '2
                If mnModeMouse.Checked Then 'Mouse Mode > Middle mouse Button
                    CancelRemoteQuickMouse()
                    pbDepictMouse.Image = imgCursorClicks.Images(6)
                    cOut("MouseMiddleButtonDown")
                End If
            Case 51 '3
                If mnModeMouse.Checked Then 'Mouse Mode > Right Mouse Button Down
                    CancelRemoteQuickMouse()
                    pbDepictMouse.Image = imgCursorClicks.Images(7)
                    cOut("MouseRightButtonDown")
                End If
            Case 52 '4
                If mnModeMouse.Checked Then 'Mouse Mode > Decrease Mouse Step
                    MouseMoveStep -= 1
                    If MouseMoveStep < 1 Then
                        MouseMoveStep = 1
                    End If
                    UpdateMouseLabel()
                End If
            Case 53 '5
                If mnModeMouse.Checked Then 'Mouse Mode > Increase Mouse Step
                    MouseMoveStep += 1
                    UpdateMouseLabel()
                End If
            Case 54 '6
                If mnModeMouse.Checked Then 'Mouse Mode > Scroll Up
                    pbDepictScroll.Image = imgScrollClicks.Images(1)
                    cOut("ScrollUp:" & ScrollMoveStep & ".")
                End If
            Case 55 '7
                If mnModeMouse.Checked Then 'Mouse Mode > Decrease Scroll Step or QuickMouseInterval
                    If IsQuickMouse Then
                        QuickMouseInterval -= 100
                        If QuickMouseInterval <= 0 Then
                            QuickMouseInterval = 10
                        End If
                    Else
                        ScrollMoveStep -= 1
                        If ScrollMoveStep < 1 Then
                            ScrollMoveStep = 1
                        End If
                    End If
                    UpdateMouseLabel()
                End If
            Case 56 '8
                If mnModeMouse.Checked Then 'Mouse Mode > Increase Scroll Step or QuickMouseInterval
                    If IsQuickMouse Then
                        QuickMouseInterval += 100
                        If QuickMouseInterval = 110 Then
                            QuickMouseInterval = 100
                        End If
                    Else
                        ScrollMoveStep += 1
                    End If
                    UpdateMouseLabel()
                End If
            Case 57 '9
                If mnModeMouse.Checked Then 'Mouse Mode > Scroll Down
                    pbDepictScroll.Image = imgScrollClicks.Images(2)
                    cOut("ScrollDown:" & ScrollMoveStep & ".")
                End If
            Case 119 '*
                If mnModeMouse.Checked Then 'Mouse Mode > X1 Mouse Button Down
                    pbDepictScroll.Image = imgScrollClicks.Images(3)
                    cOut("MouseX1ButtonDown")
                End If
            Case 48 '0
                If mnModeMouse.Checked Then 'Mouse Mode > X2 Mouse Button Down
                    pbDepictScroll.Image = imgScrollClicks.Images(4)
                    cOut("MouseX2ButtonDown")
                End If
            Case 120 '#
                If mnModeMouse.Checked Then 'Mouse Mode > Request Remote Mouse Location & Screen Size
                    cOut("RequestMouseLocation")
                End If
            Case 37 'left
                If mnModeMouse.Checked Then 'Mouse Mode > Left
                    pbDepictMouse.Image = imgCursorClicks.Images(1)
                    If IsQuickMouse Then
                        cOut("QuickMouseAction:Left," & MouseMoveStep & ";" & QuickMouseInterval & ".")
                    Else
                        cOut("MouseLeftMove:" & MouseMoveStep & ".")
                    End If
                End If
            Case 38 'up
                If mnModeMouse.Checked Then 'Mouse Mode > Up
                    pbDepictMouse.Image = imgCursorClicks.Images(2)
                    If IsQuickMouse Then
                        cOut("QuickMouseAction:Up," & MouseMoveStep & ";" & QuickMouseInterval & ".")
                    Else
                        cOut("MouseUpMove:" & MouseMoveStep & ".")
                    End If
                End If
            Case 39 'right
                If mnModeMouse.Checked Then 'Mouse Mode > Right
                    pbDepictMouse.Image = imgCursorClicks.Images(3)
                    If IsQuickMouse Then
                        cOut("QuickMouseAction:Right," & MouseMoveStep & ";" & QuickMouseInterval & ".")
                    Else
                        cOut("MouseRightMove:" & MouseMoveStep & ".")
                    End If
                End If
            Case 40 'down
                If mnModeMouse.Checked Then 'Mouse Mode > Down
                    pbDepictMouse.Image = imgCursorClicks.Images(4)
                    If IsQuickMouse Then
                        cOut("QuickMouseAction:Down," & MouseMoveStep & ";" & QuickMouseInterval & ".")
                    Else
                        cOut("MouseDownMove:" & MouseMoveStep & ".")
                    End If
                End If
        End Select
    End Sub

    Private Sub Main_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyUp
        Select Case e.KeyValue
            Case 13 'action
                If mnModeMouse.Checked Then 'Mouse Mode > Left Mouse Button Up
                    pbDepictMouse.Image = imgCursorClicks.Images(0)
                    cOut("MouseLeftButtonUp")
                End If
            Case 49 '1
                If mnModeMouse.Checked Then 'Mouse Mode > Left Mouse Button Up
                    'pbDepictMouse.Image = imgCursorClicks.Images(0)
                    'cOut("MouseLeftButtonUp")
                End If
            Case 50 '2
                If mnModeMouse.Checked Then 'Mouse Mode > Reserved for middle mouse Button
                    pbDepictMouse.Image = imgCursorClicks.Images(0)
                    cOut("MouseMiddleButtonUp")
                End If
            Case 51 '3
                If mnModeMouse.Checked Then 'Mouse Mode > Right Mouse Button Up
                    pbDepictMouse.Image = imgCursorClicks.Images(0)
                    cOut("MouseRightButtonUp")
                End If
            Case 54 '6
                If mnModeMouse.Checked Then 'Mouse Mode > Scroll Up
                    pbDepictScroll.Image = imgScrollClicks.Images(0)
                End If
            Case 57 '9
                If mnModeMouse.Checked Then 'Mouse Mode > Scroll Down
                    pbDepictScroll.Image = imgScrollClicks.Images(0)
                End If
            Case 119 '*
                If mnModeMouse.Checked Then 'Mouse Mode > X1 Mouse Button Up
                    pbDepictScroll.Image = imgScrollClicks.Images(0)
                    cOut("MouseX1ButtonUp")
                End If
            Case 48 '0
                If mnModeMouse.Checked Then 'Mouse Mode > X2 Mouse Button Up
                    pbDepictScroll.Image = imgScrollClicks.Images(0)
                    cOut("MouseX2ButtonUp")
                End If
            Case 37 'left
                If mnModeMouse.Checked Then 'Mouse Mode
                    pbDepictMouse.Image = imgCursorClicks.Images(0)
                End If
            Case 38 'up
                If mnModeMouse.Checked Then 'Mouse Mode
                    pbDepictMouse.Image = imgCursorClicks.Images(0)
                End If
            Case 39 'right
                If mnModeMouse.Checked Then 'Mouse Mode
                    pbDepictMouse.Image = imgCursorClicks.Images(0)
                End If
            Case 40 'down
                If mnModeMouse.Checked Then 'Mouse Mode
                    pbDepictMouse.Image = imgCursorClicks.Images(0)
                End If
        End Select
    End Sub




    'Mode > None
    Private Sub mnModeNone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnModeNone.Click
        mnModeNone.Checked = True
        mnModeMouse.Checked = False
        mnModeKeyboard.Checked = False
        txtLog.Visible = True
        txtLog.Enabled = True
        nKeyboard.Visible = False
        pbDepictMouse.Visible = False
        pbDepictScroll.Visible = False
        lblMouseInfo.Visible = False
        txtLog.Focus()
        Out("", False)
    End Sub

    'Mode > Mouse
    Private Sub mnModeMouse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnModeMouse.Click
        mnModeNone.Checked = False
        mnModeMouse.Checked = True
        mnModeKeyboard.Checked = False
        txtLog.Visible = False
        txtLog.Enabled = False
        nKeyboard.Visible = False
        pbDepictMouse.Visible = True
        pbDepictScroll.Visible = True
        lblMouseInfo.Visible = True
        Try
            UpdateMouseLabel()
        Catch ex As Exception

        End Try
        Me.Focus()
    End Sub

    'Mode > Keyboard
    Private Sub mnModeKeyboard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnModeKeyboard.Click
        mnModeNone.Checked = False
        mnModeMouse.Checked = False
        mnModeKeyboard.Checked = True
        txtLog.Visible = False
        txtLog.Enabled = False
        pbDepictMouse.Visible = False
        pbDepictScroll.Visible = False
        lblMouseInfo.Visible = False
        nKeyboard.Visible = True
        nKeyboard.Focus()
    End Sub

    'Mode > Keyboard > Input Text/Keys
    Private Sub mnInputKeys_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnInputKeys.Click
        Dim nn As New InputDialog
        nn.AssignedValue = "Undefined Input"
        nn.Description = "Every usual character you type in the textbox will be typed on the remote PC. For example: Writing 'abc' in this text box will trigger the remote PC to type the keystrokes 'a', 'b', 'c' and thus type again 'abc'. But to represent the following characters, you need to enclose them in braces {}: +, ^, %, ~, (, ), [, ], {, }. So, to trigger a keystroke of %, you must type {%}." & vbCrLf & vbCrLf & "Again, there are special words enclosed in braces that trigger keystrokes like Shift or Enter. These are the following: {BACKSPACE},{BREAK},{CAPSLOCK},{DELETE},{DOWN},{END},{ENTER},{ESC},{HELP},{HOME},{INSERT},{LEFT},{NUMLOCK},{PGDN},{PGUP},{PRTSC},{RIGHT},{SCROLLLOCK},{TAB},{UP},{F1},{F2},{F3},{F4},{F5},{F6},{F7},{F8},{F9},{F10},{F11},{F12},{F13},{F14},{F15},{F16},{ADD},{SUBTRACT},{MULTIPLY},{DIVIDE}." & vbCrLf & vbCrLf & "Furthermore, to specify key combinations with ALT, SHIFT, or CTRL, precede the keys with one of the following characters: + for SHIFT, ^ for CTRL and % for ALT. To specify the combinations with several keys, enclose the several keys into parentheses and then precede them with the desired character. E.g. to hold down Shift along with E and C, type '+(EC)'." & vbCrLf & vbCrLf & "Finally, To specify repeating keys, use the form {key number}. E.g. {LEFT 42} means press the LEFT ARROW key 42 times." & vbCrLf & vbCrLf & "Note: Because keys like {} may not be typable on a device, or it is not easy to type full words like {ENTER}, there is a function 'Insert Special' in the Input Dialog, to insert several phrases in the text box automatically."
        nn.MultiLine = True
        nn.InsertSpecial = True
        If nn.ShowDialog = DialogResult.OK Then
            cOut("SendKeys:" & nn.AssignedValue & "%.PocketPCRemoteSendKeys.$")
        End If
        nn = Nothing
    End Sub

    Private Sub mnInputMousePos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnInputMousePos.Click
        Dim nn As New InputDialog
        nn.AssignedValue = "(1,1)"
        nn.Description = "Input the new coordinates of the remote mouse in the format (x,y). Maximum coordinates can be (" & RemoteScreenSize.Width & "," & RemoteScreenSize.Height & ")."
        If nn.ShowDialog = DialogResult.OK Then
            Try
                Dim tmpP As New Point(nn.AssignedValue.Substring(1, nn.AssignedValue.IndexOf(",") - 1), nn.AssignedValue.Substring(nn.AssignedValue.IndexOf(",") + 1, nn.AssignedValue.IndexOf(")") - nn.AssignedValue.IndexOf(",") - 1))
                If tmpP.X <= RemoteScreenSize.Width And tmpP.Y <= RemoteScreenSize.Height And tmpP.X > 0 And tmpP.Y > 0 Then
                    cOut("InputMousePos:" & nn.AssignedValue & ".")
                Else
                    MessageBox.Show("aYou didn't input valid coordinates.")
                End If
            Catch ex As Exception
                MessageBox.Show("fYou didn't input valid coordinates.")
            End Try
        End If
        nn = Nothing
    End Sub


    'Menu item used for sending two test strings to the remote host
    Private Sub mnSendTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSendTest.Click
        cOut("{Is anybody there?}")
        cOut("{For crying out aloud!!!}")
    End Sub

    'Menu > Send message > Custom...
    Private Sub mnSendCustom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSendCustom.Click
        Dim nn As New InputDialog
        nn.AssignedValue = "Is anybody there?"
        nn.Description = "Specify a phrase to send to the remote client. This will be shown on the client's log."
        If nn.ShowDialog = DialogResult.OK Then
            cOut("{" & nn.AssignedValue & "}")
        End If
        nn = Nothing
    End Sub




    Private Sub mnMacroExe_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroExe.Click
        Dim nn As New frmExplorer
        If nn.ShowDialog = DialogResult.OK Then
            Try
                Out("Started executing macro " & nn.SelectedPath & ".")
                Dim AllText As String = APICalls.ReadTxt(nn.SelectedPath, True)
                If mnMacroOExeTime.Checked Then
                    StartExeMacro(AllText)
                Else 'Execute with time
                    StartExeTimeMacro(AllText)
                End If
            Catch ex As Exception
                Out("Execution of macro " & nn.SelectedPath & " was made with errors.")
            End Try
        End If
        nn = Nothing
    End Sub

    Private Sub mnMacroRec_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroRec.Click
        IsMacroRec = True
        Dim nowDate As DateTime = DateTime.Now
        Dim DateString As String = nowDate.Day & "/" & nowDate.Month & "/" & nowDate.Year & " " & nowDate.Hour & ":"
        If nowDate.Minute.ToString.Length = 1 Then
            DateString &= "0" & nowDate.Minute.ToString & ":"
        Else
            DateString &= nowDate.Minute.ToString & ":"
        End If
        If nowDate.Second.ToString.Length = 1 Then
            DateString &= "0" & nowDate.Second.ToString
        Else
            DateString &= nowDate.Second.ToString
        End If
        MacroRecText = "Pocket Control PC - NetCf Macro ##%%## " & DateString & " ##%%## " & ProgramVersion.ToString
        mnMacroStop.Enabled = True
        mnMacroRec.Enabled = False
        Out("Started recording a macro.")
    End Sub

    Private Sub mnMacroStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroStop.Click
        IsMacroRec = False
        If Not MacroRecText = "" Then
            Dim nn As New frmFileSave
            nn.FilenameSelected = "PCPCMacro.txt"
            If nn.ShowDialog = DialogResult.OK Then
                APICalls.Write2Txt(nn.FullFilePath, MacroRecText, True, True)
            End If
            Out("Macro saved at " & nn.FullFilePath & ".")
            nn = Nothing
        End If
        mnMacroStop.Enabled = False
        mnMacroRec.Enabled = True
        Out("Stopped recording a macro.")
    End Sub

    Private Sub mnMacroOExeIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroOExeIn.Click
        If mnMacroOExeIn.Checked Then
            mnMacroOExeIn.Checked = False
        Else
            mnMacroOExeIn.Checked = True
        End If
    End Sub
    Private Sub mnMacroOExeOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroOExeOut.Click
        If mnMacroOExeOut.Checked Then
            mnMacroOExeOut.Checked = False
        Else
            mnMacroOExeOut.Checked = True
        End If
    End Sub
    Private Sub mnMacroOExeTime_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroOExeTime.Click
        If mnMacroOExeTime.Checked Then
            mnMacroOExeTime.Checked = False
        Else
            mnMacroOExeTime.Checked = True
        End If
    End Sub
    Private Sub mnMacroODecim_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroODecim.Click
        Dim nn As New InputDialog
        nn.Description = "Enter a number. The time between two commands of a macro will be divided by this number. e.g. " & CStr(CDbl(2.5))
        nn.AssignedValue = MacroTimerDecimate

        If nn.ShowDialog = DialogResult.OK Then
            Dim nDbl As String = nn.AssignedValue
            If IsNumeric(nDbl) Then
                MacroTimerDecimate = Math.Abs(CDbl(nDbl))
            End If
        End If
    End Sub
    Private Sub mnMacroOInvCom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroOInvCom.Click
        If mnMacroOInvCom.Checked Then
            mnMacroOInvCom.Checked = False
        Else
            mnMacroOInvCom.Checked = True
        End If
    End Sub


    Private Sub mnMacroShorcutsManage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcutsManage.Click
        Dim InInt As New InputDialog
        InInt.Description = "Enter the number of the shorcut (1-7) you wish to change."
        If InInt.ShowDialog = DialogResult.OK Then
            If IsNumeric(InInt.AssignedValue) Then
                Dim IntPl As Integer = InInt.AssignedValue
                If IntPl >= 1 And IntPl <= 7 Then

                    If MessageBox.Show("Click Yes to replace this shorcut with a new one." & vbCrLf & "Click No to delete this shorcut.", "Error", System.Windows.Forms.MessageBoxButtons.YesNo, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1) = DialogResult.Yes Then
                        Dim nFile As New frmExplorer
                        If nFile.ShowDialog = DialogResult.OK Then
                            MacroShorcuts(IntPl - 1) = nFile.SelectedPath
                            LoadMacroShorcutNames()
                        End If
                    Else
                        MacroShorcuts(IntPl - 1) = "Undefined"
                        LoadMacroShorcutNames()
                    End If

                Else
                    MessageBox.Show("You need to input a number ranging from 1 to 7.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                End If
            Else
                MessageBox.Show("You need to input a number ranging from 1 to 7.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            End If
        End If
    End Sub

    Private Sub mnMacroShorcut1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcut1.Click
        ExeMacroShorcut(0)
    End Sub

    Private Sub mnMacroShorcut2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcut2.Click
        ExeMacroShorcut(1)
    End Sub

    Private Sub mnMacroShorcut3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcut3.Click
        ExeMacroShorcut(2)
    End Sub

    Private Sub mnMacroShorcut4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcut4.Click
        ExeMacroShorcut(3)
    End Sub

    Private Sub mnMacroShorcut5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcut5.Click
        ExeMacroShorcut(4)
    End Sub

    Private Sub mnMacroShorcut6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcut6.Click
        ExeMacroShorcut(5)
    End Sub

    Private Sub mnMacroShorcut7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcut7.Click
        ExeMacroShorcut(6)
    End Sub

    Sub ExeMacroShorcut(ByVal IntNo As Integer)
        Dim strPath As String = MacroShorcuts(IntNo)
        If Not strPath = "Undefined" And Not strPath = "" Then
            If File.Exists(strPath) Then
                Dim AllText As String = APICalls.ReadTxt(strPath, True)
                Out("Started executing shorcut macro " & strPath & ".")
                If mnMacroOExeTime.Checked Then
                    StartExeMacro(AllText)
                Else 'Execute with time
                    StartExeTimeMacro(AllText)
                End If
            Else
                Out("Macro shorcut was not found: " & strPath)
            End If
        End If
    End Sub




    Private Sub mnOEnsureConnection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnOEnsureConnection.Click
        If mnOEnsureConnection.Checked Then
            mnOEnsureConnection.Checked = False
            tmrEnsureConnection.Enabled = False
            tmrSendEnsureConnection.Enabled = False
            If bConnected Then
                cOut("DisableEnsure_Connection")
            End If
        Else
            mnOEnsureConnection.Checked = True
            If bConnected Then
                cOut("EnableEnsure_Connection")
                tmrEnsureConnection.Enabled = False
                tmrSendEnsureConnection.Enabled = False
                tmrEnsureConnection.Enabled = True
                tmrSendEnsureConnection.Enabled = True
            End If
        End If
    End Sub

    'Options > Validate Connection
    Private Sub mnConValidate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnConValidate.Click
        If mnConValidate.Checked Then
            mnConValidate.Checked = False
        Else
            mnConValidate.Checked = True
        End If
    End Sub

    Private Sub mnOIP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnOIP.Click
        Dim nn As New InputDialog
        nn.AssignedValue = IPtoConnect.ToString
        Dim ActiveSIP As String
        Try
            ActiveSIP = System.Net.Dns.GetHostByName("PPP_Peer").AddressList(0).ToString
        Catch ex As Exception
            ActiveSIP = "Disconnected"
        End Try
        nn.Description = "Enter the IP Address to connect to. Known IPs:" & vbCrLf & "ActiveSync: " & ActiveSIP & vbCrLf & "Any: " & IPAddress.Any.ToString & vbCrLf & "Broadcast: " & IPAddress.Broadcast.ToString & vbCrLf & "Loopback: " & IPAddress.Loopback.ToString

        If nn.ShowDialog = DialogResult.OK Then
            Try
                IPtoConnect = IPAddress.Parse(nn.AssignedValue)
            Catch ex As Exception
                MessageBox.Show("You didn't enter a valid IP address.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                Exit Sub
            End Try
        End If

        nn = Nothing

        Dim bb As New InputDialog
        bb.AssignedValue = PORT_NO
        bb.Description = "Enter the port to connect to." & vbCrLf & "Max: " & IPEndPoint.MaxPort & vbCrLf & "Min: " & IPEndPoint.MinPort

        If bb.ShowDialog = DialogResult.OK Then
            Try
                If CInt(bb.AssignedValue) >= IPEndPoint.MinPort And CInt(bb.AssignedValue) <= IPEndPoint.MaxPort Then
                    PORT_NO = CInt(bb.AssignedValue)
                Else
                    MessageBox.Show("You didn't enter a valid port.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                End If
            Catch ex As Exception
                MessageBox.Show("You didn't enter a valid port.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                Exit Sub
            End Try
        End If
    End Sub


    'Log > Clear
    Private Sub mnLogClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnLogClear.Click
        txtLog.Text = LogFirstMessage
    End Sub

    'Log > Save...
    Private Sub mnLogSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnLogSave.Click
        Dim nn As New frmFileSave
        nn.FilenameSelected = "PCPCLog.txt"
        If nn.ShowDialog = DialogResult.OK Then
            Dim sw As StreamWriter = File.CreateText(nn.FullFilePath)
            sw.Write("Log made from " & Me.Text & " on " & DateTime.Now & ":" & sw.NewLine & sw.NewLine & txtLog.Text)
            sw.Close()
            sw = Nothing
        End If
        nn = Nothing
    End Sub


    Private Sub mnOptionsSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnOptionsSave.Click
        Try
            SaveOptions()
        Catch ex As Exception
            Out("An error occurred while saving options.")
        End Try
    End Sub



    'Help > About
    Private Sub mnAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAbout.Click
        System.Windows.Forms.MessageBox.Show("Pocket Control PC - NetCf v1.0" & vbCrLf & "Copyright (c) 2004 Iraklis Psaroudakis" & vbCrLf & vbCrLf & "More information, help, updates about the program go to http://www34.brinkster.com/kingherc/ or read the ReadMe (contained in the root folder of the program which you can view with any Internet Browser)." & vbCrLf & vbCrLf & "This program connects to the PC version which runs on a remote PC. The device then sends commands to the PC such as mouse clicks, key clicks etc.", "About Pocket Control PC - NetCf", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1)
    End Sub

    'Help > Licence
    Private Sub mnLicence_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnLicence.Click
        System.Windows.Forms.MessageBox.Show("Pocket Control PC - NetCf" & vbCrLf & "Copyright (c) 2004 Iraklis Psaroudakis" & vbCrLf & vbCrLf & "This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version." & vbCrLf & "This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. " & vbCrLf & "" & vbCrLf & "You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA" & vbCrLf & vbCrLf & "* In the original distribution package, the GNU GPL Licence can be found at this program's root directory in text format.", "About Pocket Control PC - NetCf", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1)
    End Sub



    'Exit
    Private Sub mnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnExit.Click
        Me.Close()
        System.Windows.Forms.Application.Exit()
    End Sub

    'Button which is clicked to connect to remote host
    Private Sub mnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnConnect.Click
        If Not IsTimeMacroExe Then
            Try
                mnConnect.Enabled = False
                scon.Connect(New IPEndPoint(IPtoConnect, PORT_NO))
                bConnected = True
            Catch
                System.Windows.Forms.MessageBox.Show("The connection could not be achieved. Please ensure proper connection between the device and the host. Then, try again.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                bConnected = False
                mnConnect.Enabled = True
            End Try

            If bConnected Then 'If a connection was finally achieved
                mnDisconnect.Enabled = True
                Out("Connected to host")
                'Starting communication with sending data
                ns = scon.GetStream()
                mnConnect.Enabled = False
                tmrListenCommandsLoop.Interval = 50
                tmrListenCommandsLoop.Enabled = True
                If mnOEnsureConnection.Checked Then
                    tmrEnsureConnection.Enabled = True
                    tmrSendEnsureConnection.Enabled = True
                End If
                mnModeMouse.Enabled = True
                mnModeKeyboard.Enabled = True
                mnOtherActions.Enabled = True
                mnOEnsureConnection.Enabled = True
            End If
        Else
            MacroStopTimeExe()
        End If
    End Sub

    'Button which is clicked to disconnect from the remote host
    Private Sub mnDisconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDisconnect.Click
        Try
            If LastCommand.IndexOf("CloseConnection") = -1 Then
                cOut("CloseConnection")
            End If
            tmrEnsureConnection.Enabled = False
            tmrSendEnsureConnection.Enabled = False
            bConnected = False
            mnConnect.Enabled = True
            mnSendMessage.Enabled = False
            ns.Close()
            scon.Close()
            ns = Nothing
            scon = Nothing
            Out("Connection Closed")
            mnDisconnect.Enabled = False
            WasValidated = False
            tmrListenCommandsLoop.Enabled = False
            mnModeNone_Click(Me, EventArgs.Empty)
            mnModeMouse.Enabled = False
            mnModeKeyboard.Enabled = False
            mnOtherActions.Enabled = False
            mnOEnsureConnection.Enabled = False
        Catch
            System.Windows.Forms.MessageBox.Show("The connection could not be closed. Please ensure proper connection between the device and the host. Also, close any activities of this program that occupies the connection. Then, try again.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            mnConnect.Enabled = False
            mnSendMessage.Enabled = True
            mnDisconnect.Enabled = True
            tmrListenCommandsLoop.Enabled = True
        End Try
    End Sub




    'When connected, this timer listens for commands through the NetworkStream, logs them and executes them through another function
    Private Sub tmrListenCommandsLoop_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrListenCommandsLoop.Tick
        Try
            tmrListenCommandsLoop.Interval = 50
            If ns.CanRead And ns.DataAvailable Then
                Dim bytes(scon.ReceiveBufferSize) As Byte
                ns.Read(bytes, 0, CInt(scon.ReceiveBufferSize))
                Dim rc As String = Encoding.Unicode.GetString(bytes, 0, bytes.Length)
                If Not rc.IndexOf("PocketPCControl:") = -1 Then
                    'LastCommand = rc.Replace("PocketPCControl:", "")
                    'Out("Received: " & LastCommand)
                    'TranslateCommand(LastCommand)
                    rc = rc.Replace("PocketPCControl:", "")
                    Do
                        If Not rc.IndexOf("~~##COM##~~") = -1 Then
                            Dim tmpStr As String = rc.Substring(rc.IndexOf("~~##COM##~~"), rc.IndexOf("~~##COMEND##~~") + 14 - rc.IndexOf("~~##COM##~~"))
                            LastCommand = CStr(tmpStr.Replace("~~##COM##~~", "")).Replace("~~##COMEND##~~", "")
                            If LastCommand.IndexOf("EnsureConnection") = -1 Then
                                Out("Received: " & LastCommand)
                            End If
                            TranslateCommand(LastCommand)
                            If IsMacroRec Then
                                Dim DateNow As DateTime = DateTime.Now
                                'MacroRecText &= vbCrLf & "IN_:" & DateTime.Now.ToLongTimeString & ";" & LastCommand
                                MacroRecText &= vbCrLf & "IN_:" & CType(New TimeSpan(DateNow.Day, DateNow.Hour, DateNow.Minute, DateNow.Second), TimeSpan).ToString & ";" & LastCommand
                            End If
                            rc = rc.Replace(tmpStr, "")
                            tmpStr = Nothing
                        Else
                            Exit Do
                        End If
                    Loop
                Else
                    Out("Received Unidentified String: " & rc)
                End If
                TranslateCommand(LastCommand)
            End If
        Catch ex As Exception
            Out("Failed to listen to remote host. Retry in 5 secs.")
            tmrListenCommandsLoop.Interval = 5000
        End Try
    End Sub

    'When connected, this function is used to send away commands to the remote host
    Private Function cOut(ByVal strTransfer As String, Optional ByVal DoNotValidate As Boolean = False) As Boolean
        Try
            If WasValidated Or DoNotValidate Or Not mnConValidate.Checked Then
                If bConnected Then
                    If ns.CanWrite Then
                        Dim sendBytes As [Byte]() = Encoding.Unicode.GetBytes("PocketPCControl:~~##COM##~~" & strTransfer & "~~##COMEND##~~")
                        Try
                            ns.Write(sendBytes, 0, sendBytes.Length)
                        Catch ex As Exception
                            Out("Transfer not executed because of a connection problem.")
                            Return False
                            Exit Function
                        End Try
                        If IsMacroRec Then
                            'MacroRecText &= vbCrLf & "OUT:" & DateTime.Now.ToLongTimeString & ";" & strTransfer
                            Dim DateNow As DateTime = DateTime.Now
                            'MacroRecText &= vbCrLf & "IN_:" & DateTime.Now.ToLongTimeString & ";" & LastCommand
                            MacroRecText &= vbCrLf & "OUT:" & CType(New TimeSpan(DateNow.Day, DateNow.Hour, DateNow.Minute, DateNow.Second), TimeSpan).ToString & ";" & strTransfer
                        End If
                        If strTransfer.IndexOf("EnsureConnection") = -1 Then
                            Out("Transfered: " & strTransfer)
                        End If
                        sendBytes = Nothing
                        Return True
                    Else
                        Return False
                    End If
                Else
                    Out("Transfer was not executed because there is no connection.")
                    Return False
                End If
            Else
                Out("Transfer was not executed because connection is not yet validated")
                Return False
            End If
        Catch ex As Exception
            Out("Transfer was not executed because of an unrecognised error.")
            Return False
            Exit Function
        End Try
    End Function


    'This function receives a command and executes it
    Sub TranslateCommand(ByVal strCommand As String)
        If WasValidated Or Not mnConValidate.Checked Then
            'Command for closing the connection
            If Not strCommand.IndexOf("CloseConnection") = -1 Then
                If IsTimeMacroExe Then
                    MacroStopTimeExe()
                End If
                mnDisconnect_Click(Me, EventArgs.Empty)
                Out(" by remote host", False)
            End If
            'Command to refresh remote screen size
            If Not strCommand.IndexOf("ScreenSize") = -1 Then
                'Dim tWid As Integer = 
                RemoteScreenSize = New Size(strCommand.Substring(strCommand.IndexOf(":") + 1, strCommand.IndexOf("x") - strCommand.IndexOf(":") - 1), strCommand.Substring(strCommand.IndexOf("x") + 1, strCommand.IndexOf(".") - 1 - strCommand.IndexOf("x")))
                UpdateMouseLabel()
            End If
            'Command to refresh remote mouse location
            If Not strCommand.IndexOf("MouseLoc") = -1 Then
                RemoteMouseLocation = New Point(strCommand.Substring(strCommand.IndexOf(":") + 1, strCommand.IndexOf(",") - strCommand.IndexOf(":") - 1), strCommand.Substring(strCommand.IndexOf(",") + 1, strCommand.IndexOf(".") - strCommand.IndexOf(",") - 1))
                UpdateMouseLabel()
            End If
            If Not strCommand.IndexOf("EnsureConnection") = -1 Then
                tmrEnsureConnection.Enabled = False
                tmrEnsureConnection.Enabled = True
            End If
            If Not strCommand.IndexOf("DisableEnsure_Connection") = -1 Then
                If mnOEnsureConnection.Checked Then
                    mnOEnsureConnection_Click(Me, EventArgs.Empty)
                End If
            End If
            If Not strCommand.IndexOf("EnableEnsure_Connection") = -1 Then
                If Not mnOEnsureConnection.Checked Then
                    mnOEnsureConnection_Click(Me, EventArgs.Empty)
                End If
            End If
        Else
            If Not strCommand.IndexOf("ValidateClientConnection") = -1 Then
                WasValidated = True
                cOut("ValidateHostConnection")
                Out("Connection Validated")
                cOut("ClientScreenSize:" & System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width & "x" & System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height & ".")
            End If
        End If
    End Sub





    Private Sub DefineKeyboard()
        '1st row
        KeyboardKeys.Add(1, MakeKeyboardKey(1, &H1B, "Escape", New Rectangle(0, 0, 11, 11), 107, 2, 16, 15))
        KeyboardKeys.Add(2, MakeKeyboardKey(2, &H70, "F1", New Rectangle(11, 0, 11, 11), 107, 3, 17, 1))
        KeyboardKeys.Add(3, MakeKeyboardKey(3, &H71, "F2", New Rectangle(22, 0, 11, 11), 108, 4, 18, 2))
        KeyboardKeys.Add(4, MakeKeyboardKey(4, &H72, "F3", New Rectangle(33, 0, 11, 11), 108, 5, 19, 3))
        KeyboardKeys.Add(5, MakeKeyboardKey(5, &H73, "F4", New Rectangle(44, 0, 11, 11), 109, 6, 20, 4))
        KeyboardKeys.Add(6, MakeKeyboardKey(6, &H74, "F5", New Rectangle(55, 0, 11, 11), 110, 7, 21, 5))
        KeyboardKeys.Add(7, MakeKeyboardKey(7, &H75, "F6", New Rectangle(66, 0, 11, 11), 110, 8, 22, 6))
        KeyboardKeys.Add(8, MakeKeyboardKey(8, &H76, "F7", New Rectangle(77, 0, 11, 11), 111, 9, 23, 7))
        KeyboardKeys.Add(9, MakeKeyboardKey(9, &H77, "F8", New Rectangle(88, 0, 11, 11), 111, 10, 24, 8))
        KeyboardKeys.Add(10, MakeKeyboardKey(10, &H78, "F9", New Rectangle(99, 0, 11, 11), 0, 11, 25, 9))
        KeyboardKeys.Add(11, MakeKeyboardKey(11, &H79, "F10", New Rectangle(110, 0, 11, 11), 0, 12, 26, 10))
        KeyboardKeys.Add(12, MakeKeyboardKey(12, &H7A, "F11", New Rectangle(121, 0, 11, 11), 127, 13, 27, 11))
        KeyboardKeys.Add(13, MakeKeyboardKey(13, &H7B, "F12", New Rectangle(132, 0, 11, 11), 127, 14, 28, 12))
        KeyboardKeys.Add(14, MakeKeyboardKey(14, &H2D, "Insert", New Rectangle(143, 0, 11, 11), 128, 15, 29, 13))
        KeyboardKeys.Add(15, MakeKeyboardKey(15, &H2E, "Delete", New Rectangle(154, 0, 11, 11), 126, 1, 30, 14))
        '2nd row
        KeyboardKeys.Add(16, MakeKeyboardKey(16, &HDF, "`", New Rectangle(0, 13, 11, 11), 1, 17, 31, 30))
        KeyboardKeys.Add(17, MakeKeyboardKey(17, &H31, "1", New Rectangle(11, 13, 11, 11), 2, 18, 32, 16))
        KeyboardKeys.Add(18, MakeKeyboardKey(18, &H32, "2", New Rectangle(22, 13, 11, 11), 3, 19, 33, 17))
        KeyboardKeys.Add(19, MakeKeyboardKey(19, &H33, "3", New Rectangle(33, 13, 11, 11), 4, 20, 34, 18))
        KeyboardKeys.Add(20, MakeKeyboardKey(20, &H34, "4", New Rectangle(44, 13, 11, 11), 5, 21, 35, 19))
        KeyboardKeys.Add(21, MakeKeyboardKey(21, &H35, "5", New Rectangle(55, 13, 11, 11), 6, 22, 36, 20))
        KeyboardKeys.Add(22, MakeKeyboardKey(22, &H36, "6", New Rectangle(66, 13, 11, 11), 7, 23, 37, 21))
        KeyboardKeys.Add(23, MakeKeyboardKey(23, &H37, "7", New Rectangle(77, 13, 11, 11), 8, 24, 38, 22))
        KeyboardKeys.Add(24, MakeKeyboardKey(24, &H38, "8", New Rectangle(88, 13, 11, 11), 9, 25, 39, 23))
        KeyboardKeys.Add(25, MakeKeyboardKey(25, &H39, "9", New Rectangle(99, 13, 11, 11), 10, 26, 40, 24))
        KeyboardKeys.Add(26, MakeKeyboardKey(26, &H30, "0", New Rectangle(110, 13, 11, 11), 11, 27, 41, 25))
        KeyboardKeys.Add(27, MakeKeyboardKey(27, &H6D, "-", New Rectangle(121, 13, 11, 11), 12, 28, 42, 26))
        KeyboardKeys.Add(28, MakeKeyboardKey(28, &HBB, "=", New Rectangle(132, 13, 11, 11), 13, 29, 43, 27))
        KeyboardKeys.Add(29, MakeKeyboardKey(29, &H8, "Return", New Rectangle(143, 13, 11, 11), 14, 30, 44, 28))
        KeyboardKeys.Add(30, MakeKeyboardKey(30, &H24, "Home", New Rectangle(154, 13, 11, 11), 15, 16, 45, 29))
        '3rd row
        KeyboardKeys.Add(31, MakeKeyboardKey(31, &H9, "Tab", New Rectangle(0, 24, 11, 11), 16, 32, 46, 45))
        KeyboardKeys.Add(32, MakeKeyboardKey(32, &H51, "Q", New Rectangle(11, 24, 11, 11), 17, 33, 47, 31))
        KeyboardKeys.Add(33, MakeKeyboardKey(33, &H57, "W", New Rectangle(22, 24, 11, 11), 18, 34, 48, 32))
        KeyboardKeys.Add(34, MakeKeyboardKey(34, &H45, "E", New Rectangle(33, 24, 11, 11), 19, 35, 49, 33))
        KeyboardKeys.Add(35, MakeKeyboardKey(35, &H52, "R", New Rectangle(44, 24, 11, 11), 20, 36, 50, 34))
        KeyboardKeys.Add(36, MakeKeyboardKey(36, &H54, "T", New Rectangle(55, 24, 11, 11), 21, 37, 51, 35))
        KeyboardKeys.Add(37, MakeKeyboardKey(37, &H59, "Y", New Rectangle(66, 24, 11, 11), 22, 38, 52, 36))
        KeyboardKeys.Add(38, MakeKeyboardKey(38, &H55, "U", New Rectangle(77, 24, 11, 11), 23, 39, 53, 37))
        KeyboardKeys.Add(39, MakeKeyboardKey(39, &H49, "I", New Rectangle(88, 24, 11, 11), 24, 40, 54, 38))
        KeyboardKeys.Add(40, MakeKeyboardKey(40, &H4F, "O", New Rectangle(99, 24, 11, 11), 25, 41, 55, 39))
        KeyboardKeys.Add(41, MakeKeyboardKey(41, &H50, "P", New Rectangle(110, 24, 11, 11), 26, 42, 56, 40))
        KeyboardKeys.Add(42, MakeKeyboardKey(42, &HDB, "[", New Rectangle(121, 24, 11, 11), 27, 43, 57, 41))
        KeyboardKeys.Add(43, MakeKeyboardKey(43, &HDD, "]", New Rectangle(132, 24, 11, 11), 28, 44, 58, 42))
        KeyboardKeys.Add(44, MakeKeyboardKey(44, &HD, "Enter", New Rectangle(143, 24, 11, 22), 29, 45, 73, 43))
        KeyboardKeys.Add(45, MakeKeyboardKey(45, &H21, "Page Up", New Rectangle(154, 24, 11, 11), 30, 31, 59, 44))
        '4th row
        KeyboardKeys.Add(46, MakeKeyboardKey(46, &H14, "Caps Lock", New Rectangle(0, 35, 11, 11), 31, 47, 60, 59))
        KeyboardKeys.Add(47, MakeKeyboardKey(47, &H41, "A", New Rectangle(11, 35, 11, 11), 32, 48, 61, 46))
        KeyboardKeys.Add(48, MakeKeyboardKey(48, &H53, "S", New Rectangle(22, 35, 11, 11), 33, 49, 62, 47))
        KeyboardKeys.Add(49, MakeKeyboardKey(49, &H44, "D", New Rectangle(33, 35, 11, 11), 34, 50, 63, 48))
        KeyboardKeys.Add(50, MakeKeyboardKey(50, &H46, "F", New Rectangle(44, 35, 11, 11), 35, 51, 64, 49))
        KeyboardKeys.Add(51, MakeKeyboardKey(51, &H47, "G", New Rectangle(55, 35, 11, 11), 36, 52, 65, 50))
        KeyboardKeys.Add(52, MakeKeyboardKey(52, &H48, "H", New Rectangle(66, 35, 11, 11), 37, 53, 66, 51))
        KeyboardKeys.Add(53, MakeKeyboardKey(53, &H4A, "J", New Rectangle(77, 35, 11, 11), 38, 54, 67, 52))
        KeyboardKeys.Add(54, MakeKeyboardKey(54, &H4B, "K", New Rectangle(88, 35, 11, 11), 39, 55, 68, 53))
        KeyboardKeys.Add(55, MakeKeyboardKey(55, &H4C, "L", New Rectangle(99, 35, 11, 11), 40, 56, 69, 54))
        KeyboardKeys.Add(56, MakeKeyboardKey(56, &HBA, ";", New Rectangle(110, 35, 11, 11), 41, 57, 70, 55))
        KeyboardKeys.Add(57, MakeKeyboardKey(57, &HC0, "'", New Rectangle(121, 35, 11, 11), 42, 58, 71, 56))
        KeyboardKeys.Add(58, MakeKeyboardKey(58, &HDE, "#", New Rectangle(132, 35, 11, 11), 43, 44, 72, 57))
        KeyboardKeys.Add(59, MakeKeyboardKey(59, &H22, "Page Down", New Rectangle(154, 35, 11, 11), 45, 46, 74, 44))
        '5th row
        KeyboardKeys.Add(60, MakeKeyboardKey(60, &HA0, "Left Shift", New Rectangle(0, 46, 11, 11), 46, 61, 75, 74))
        KeyboardKeys.Add(61, MakeKeyboardKey(61, &HDC, "\", New Rectangle(11, 46, 11, 11), 47, 62, 76, 60))
        KeyboardKeys.Add(62, MakeKeyboardKey(62, &H5A, "Z", New Rectangle(22, 46, 11, 11), 48, 63, 77, 61))
        KeyboardKeys.Add(63, MakeKeyboardKey(63, &H58, "X", New Rectangle(33, 46, 11, 11), 49, 64, 78, 62))
        KeyboardKeys.Add(64, MakeKeyboardKey(64, &H43, "C", New Rectangle(44, 46, 11, 11), 50, 65, 78, 63))
        KeyboardKeys.Add(65, MakeKeyboardKey(65, &H56, "V", New Rectangle(55, 46, 11, 11), 51, 66, 78, 64))
        KeyboardKeys.Add(66, MakeKeyboardKey(66, &H42, "B", New Rectangle(66, 46, 11, 11), 52, 67, 78, 65))
        KeyboardKeys.Add(67, MakeKeyboardKey(67, &H4E, "N", New Rectangle(77, 46, 11, 11), 53, 68, 78, 66))
        KeyboardKeys.Add(68, MakeKeyboardKey(68, &H4D, "M", New Rectangle(88, 46, 11, 11), 54, 69, 78, 67))
        KeyboardKeys.Add(69, MakeKeyboardKey(69, &HBC, ",", New Rectangle(99, 46, 11, 11), 55, 70, 79, 68))
        KeyboardKeys.Add(70, MakeKeyboardKey(70, &HBE, ".", New Rectangle(110, 46, 11, 11), 56, 71, 80, 69))
        KeyboardKeys.Add(71, MakeKeyboardKey(71, &HBF, "/", New Rectangle(121, 46, 11, 11), 57, 72, 81, 70))
        KeyboardKeys.Add(72, MakeKeyboardKey(72, &HA1, "Right Shift", New Rectangle(132, 46, 11, 11), 58, 73, 82, 71))
        KeyboardKeys.Add(73, MakeKeyboardKey(73, &H26, "Arrow 'Up'", New Rectangle(143, 46, 11, 11), 44, 74, 83, 72))
        KeyboardKeys.Add(74, MakeKeyboardKey(74, &H23, "End", New Rectangle(154, 46, 11, 11), 59, 60, 84, 73))
        '6th row
        KeyboardKeys.Add(75, MakeKeyboardKey(75, &HA2, "Left Control", New Rectangle(0, 57, 14, 11), 60, 76, 85, 84))
        KeyboardKeys.Add(76, MakeKeyboardKey(76, &H5B, "Left Windows Key", New Rectangle(13, 57, 11, 11), 61, 77, 86, 75))
        KeyboardKeys.Add(77, MakeKeyboardKey(77, &H12, "Left Alt", New Rectangle(25, 57, 11, 11), 62, 78, 86, 76))
        KeyboardKeys.Add(78, MakeKeyboardKey(78, &H20, "Space", New Rectangle(36, 57, 63, 11), 65, 79, 88, 77))
        KeyboardKeys.Add(79, MakeKeyboardKey(79, &H12, "Right Alt", New Rectangle(99, 57, 11, 11), 69, 80, 89, 78))
        KeyboardKeys.Add(80, MakeKeyboardKey(80, &H5D, "Select", New Rectangle(110, 57, 11, 11), 70, 81, 90, 79))
        KeyboardKeys.Add(81, MakeKeyboardKey(81, &HA3, "Right Control", New Rectangle(121, 57, 11, 11), 71, 82, 90, 80))
        KeyboardKeys.Add(82, MakeKeyboardKey(82, &H25, "Arrow 'Left'", New Rectangle(132, 57, 11, 11), 72, 83, 91, 81))
        KeyboardKeys.Add(83, MakeKeyboardKey(83, &H28, "Arrow 'Down'", New Rectangle(143, 57, 11, 11), 73, 84, 92, 82))
        KeyboardKeys.Add(84, MakeKeyboardKey(84, &H27, "Arrow 'Right'", New Rectangle(154, 57, 11, 11), 74, 75, 92, 83))
        '7th row (under normal keyboard)
        KeyboardKeys.Add(85, MakeKeyboardKey(85, &H2C, "Print Screen", New Rectangle(0, 71, 17, 11), 75, 86, 93, 92))
        KeyboardKeys.Add(86, MakeKeyboardKey(86, &H3, "Break", New Rectangle(17, 71, 17, 11), 76, 87, 95, 85)) 'What Value??
        KeyboardKeys.Add(87, MakeKeyboardKey(87, &H13, "Pause", New Rectangle(34, 71, 17, 11), 78, 88, 96, 86))
        KeyboardKeys.Add(88, MakeKeyboardKey(88, &H91, "Scroll Lock", New Rectangle(51, 71, 17, 11), 78, 89, 98, 87))
        KeyboardKeys.Add(89, MakeKeyboardKey(89, &H2B, "Execute", New Rectangle(97, 71, 17, 11), 79, 90, 101, 88))
        KeyboardKeys.Add(90, MakeKeyboardKey(90, &H2A, "Print", New Rectangle(114, 71, 17, 11), 81, 91, 103, 89))
        KeyboardKeys.Add(91, MakeKeyboardKey(91, &H2F, "Help", New Rectangle(131, 71, 17, 11), 82, 92, 104, 90))
        KeyboardKeys.Add(92, MakeKeyboardKey(92, &H5F, "Sleep", New Rectangle(148, 71, 17, 11), 84, 85, 106, 91))
        '8th row (Windows Browser & Media)
        KeyboardKeys.Add(93, MakeKeyboardKey(93, &HA6, "Browser: Back", New Rectangle(0, 93, 11, 11), 85, 94, 107, 106))
        KeyboardKeys.Add(94, MakeKeyboardKey(94, &HA7, "Browser: Next", New Rectangle(11, 93, 11, 11), 85, 95, 107, 93))
        KeyboardKeys.Add(95, MakeKeyboardKey(95, &HA8, "Browser: Refresh", New Rectangle(22, 93, 11, 11), 86, 96, 108, 94))
        KeyboardKeys.Add(96, MakeKeyboardKey(96, &HA9, "Browser: Stop", New Rectangle(33, 93, 11, 11), 87, 97, 108, 95))
        KeyboardKeys.Add(97, MakeKeyboardKey(97, &HAA, "Browser: Search", New Rectangle(44, 93, 11, 11), 87, 98, 109, 96))
        KeyboardKeys.Add(98, MakeKeyboardKey(98, &HAB, "Browser: Favourites", New Rectangle(55, 93, 11, 11), 88, 99, 110, 97))
        KeyboardKeys.Add(99, MakeKeyboardKey(99, &HAC, "Browser: Home/Start", New Rectangle(66, 93, 11, 11), 0, 100, 110, 98))
        KeyboardKeys.Add(100, MakeKeyboardKey(100, &HAE, "Media: Volume Down", New Rectangle(84, 93, 11, 11), 0, 101, 111, 99))
        KeyboardKeys.Add(101, MakeKeyboardKey(101, &HAD, "Media: (Un)Mute", New Rectangle(95, 93, 11, 11), 89, 102, 111, 100))
        KeyboardKeys.Add(102, MakeKeyboardKey(102, &HAF, "Media: Volume Up", New Rectangle(106, 93, 11, 11), 89, 103, 0, 101))
        KeyboardKeys.Add(103, MakeKeyboardKey(103, &HB0, "Media: Next track", New Rectangle(121, 93, 11, 11), 90, 104, 112, 102))
        KeyboardKeys.Add(104, MakeKeyboardKey(104, &HB1, "Media: Previous track", New Rectangle(132, 93, 11, 11), 91, 105, 113, 103))
        KeyboardKeys.Add(105, MakeKeyboardKey(105, &HB2, "Media: Stop", New Rectangle(143, 93, 11, 11), 92, 106, 114, 104))
        KeyboardKeys.Add(106, MakeKeyboardKey(106, &HB3, "Media: Play/Pause", New Rectangle(154, 93, 11, 11), 92, 93, 115, 105))
        '9th row (Windows Launch & 1st row of Num Lock)
        KeyboardKeys.Add(107, MakeKeyboardKey(107, &HB4, "Launch: Mail", New Rectangle(0, 115, 16, 11), 93, 108, 1, 115))
        KeyboardKeys.Add(108, MakeKeyboardKey(108, &HB5, "Launch: Media", New Rectangle(16, 115, 22, 11), 95, 109, 3, 107))
        KeyboardKeys.Add(109, MakeKeyboardKey(109, &HB6, "Launch: App 1", New Rectangle(38, 115, 20, 11), 97, 110, 5, 108))
        KeyboardKeys.Add(110, MakeKeyboardKey(110, &HB7, "Launch: App 2", New Rectangle(58, 115, 22, 11), 99, 111, 7, 109))
        KeyboardKeys.Add(111, MakeKeyboardKey(111, &H5D, "Launch: Apps", New Rectangle(80, 115, 19, 11), 100, 112, 9, 110))
        KeyboardKeys.Add(112, MakeKeyboardKey(112, &H90, "Num Lock", New Rectangle(121, 115, 11, 11), 103, 113, 116, 111))
        KeyboardKeys.Add(113, MakeKeyboardKey(113, &H6F, "/", New Rectangle(132, 115, 11, 11), 104, 114, 117, 112))
        KeyboardKeys.Add(114, MakeKeyboardKey(114, &H6A, "*", New Rectangle(143, 115, 11, 11), 105, 115, 118, 113))
        KeyboardKeys.Add(115, MakeKeyboardKey(115, &H6D, "-", New Rectangle(154, 115, 11, 11), 106, 107, 119, 114))
        '10th row (Num Lock)
        KeyboardKeys.Add(116, MakeKeyboardKey(116, &H67, "Numpad 7", New Rectangle(121, 126, 11, 11), 112, 117, 120, 119))
        KeyboardKeys.Add(117, MakeKeyboardKey(117, &H68, "Numpad 8", New Rectangle(132, 126, 11, 11), 113, 118, 121, 116))
        KeyboardKeys.Add(118, MakeKeyboardKey(118, &H69, "Numpad 9", New Rectangle(143, 126, 11, 11), 114, 119, 122, 117))
        KeyboardKeys.Add(119, MakeKeyboardKey(119, &H6B, "+", New Rectangle(154, 126, 11, 22), 115, 116, 126, 118))
        '11th row (Num Lock)
        KeyboardKeys.Add(120, MakeKeyboardKey(120, &H64, "Numpad 4", New Rectangle(121, 137, 11, 11), 116, 121, 123, 119))
        KeyboardKeys.Add(121, MakeKeyboardKey(121, &H65, "Numpad 5", New Rectangle(132, 137, 11, 11), 117, 122, 124, 120))
        KeyboardKeys.Add(122, MakeKeyboardKey(122, &H66, "Numpad 6", New Rectangle(143, 137, 11, 11), 118, 119, 125, 121))
        '12th row (Num Lock)
        KeyboardKeys.Add(123, MakeKeyboardKey(123, &H61, "Numpad 1", New Rectangle(121, 148, 11, 11), 120, 124, 127, 126))
        KeyboardKeys.Add(124, MakeKeyboardKey(124, &H62, "Numpad 2", New Rectangle(132, 148, 11, 11), 121, 125, 127, 123))
        KeyboardKeys.Add(125, MakeKeyboardKey(125, &H63, "Numpad 3", New Rectangle(143, 148, 11, 11), 122, 126, 128, 124))
        KeyboardKeys.Add(126, MakeKeyboardKey(126, &HD, "Enter", New Rectangle(154, 148, 11, 22), 119, 123, 15, 125))
        '13th row (Num Lock)
        KeyboardKeys.Add(127, MakeKeyboardKey(127, &H60, "Numpad 0", New Rectangle(121, 159, 22, 11), 123, 128, 12, 126))
        KeyboardKeys.Add(128, MakeKeyboardKey(128, &H6E, "Demical", New Rectangle(143, 159, 11, 11), 125, 126, 14, 127))
    End Sub



    Private Sub nKeyboard_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles nKeyboard.GotFocus
        ChangeKey()
    End Sub

    Private Sub nKeyboard_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles nKeyboard.MouseDown
        Dim i As Integer
        Dim XtoRed As Integer = (nKeyboard.Width - nKeyboard.Image.Width) / 2
        Dim YtoRed As Integer = (nKeyboard.Height - nKeyboard.Image.Height) / 2
        For i = 1 To KeyboardKeys.Count
            Dim tmpKey As KeyboardIndex = KeyboardKeys(i)
            If (e.X - XtoRed) > tmpKey.KeyOutline.X And (e.X - XtoRed) <= tmpKey.KeyOutline.Right And (e.Y - YtoRed) > tmpKey.KeyOutline.Y And (e.Y - YtoRed) <= tmpKey.KeyOutline.Bottom Then
                CurrentKeyIndex = tmpKey.Index
                ChangeKey()
                nKeyboard_KeyDown(Me, New KeyEventArgs(13))
            End If
        Next
    End Sub

    Private Sub nKeyboard_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles nKeyboard.KeyDown
        Dim tmpKey As KeyboardIndex = KeyboardKeys(CurrentKeyIndex)
        Select Case e.KeyValue
            Case 13 'action
                If tmpKey.Representation.IndexOf("Shift") = -1 And tmpKey.Representation.IndexOf("Alt") = -1 And tmpKey.Representation.IndexOf("Control") = -1 And tmpKey.Representation.IndexOf("Windows Key") = -1 Then

                Else
                    If tmpKey.IsPressed Then
                        Exit Select
                    End If
                End If
                'cOut("KeyPress:" & tmpKey.Value & "," & KEYEVENTF_EXTENDEDKEY & ".")
                cOut("KeyPress:" & tmpKey.Value & "," & 0 & ".")
            Case 37 'left
                If Not tmpKey.LeftIndex = 0 Then
                    CurrentKeyIndex = tmpKey.LeftIndex
                End If
            Case 38 'up
                If Not tmpKey.AboveIndex = 0 Then
                    CurrentKeyIndex = tmpKey.AboveIndex
                End If
            Case 39 'right
                If Not tmpKey.RightIndex = 0 Then
                    CurrentKeyIndex = tmpKey.RightIndex
                End If
            Case 40 'down
                If Not tmpKey.BelowIndex = 0 Then
                    CurrentKeyIndex = tmpKey.BelowIndex
                End If
            Case 49 '1
                CurrentKeyIndex = 17
            Case 50 '2
                CurrentKeyIndex = 23
            Case 51 '3
                CurrentKeyIndex = 30
            Case 52 '4
                CurrentKeyIndex = 61
            Case 53 '5
                CurrentKeyIndex = 66
            Case 54 '6
                CurrentKeyIndex = 74
            Case 55 '7
                CurrentKeyIndex = 93
            Case 56 '8
                CurrentKeyIndex = 100
            Case 57 '9
                CurrentKeyIndex = 106
            Case 119 '*
                CurrentKeyIndex = 107
            Case 48 '0 'NEW: Cancel Pressed Keys
                'CurrentKeyIndex = 112
                CancelPressedKeys()
            Case 120 '#
                CurrentKeyIndex = 126
        End Select
        tmpKey = Nothing
        ChangeKey()
    End Sub

    Private Sub nKeyboard_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles nKeyboard.KeyUp
        Dim tmpKey As KeyboardIndex = KeyboardKeys(CurrentKeyIndex)
        Select Case e.KeyValue
            Case 13 'action
                If tmpKey.Representation.IndexOf("Shift") = -1 And tmpKey.Representation.IndexOf("Alt") = -1 And tmpKey.Representation.IndexOf("Control") = -1 And tmpKey.Representation.IndexOf("Windows Key") = -1 Then
                    cOut("KeyPress:" & tmpKey.Value & "," & KEYEVENTF_KEYUP & ".")
                Else
                    If tmpKey.IsPressed Then
                        Dim nKey As KeyboardIndex = tmpKey
                        nKey.IsPressed = False
                        KeyboardKeys.Remove(CurrentKeyIndex)
                        KeyboardKeys.Add(CurrentKeyIndex, nKey)
                        nKey = Nothing
                        cOut("KeyPress:" & tmpKey.Value & "," & KEYEVENTF_KEYUP & ".")
                    Else
                        Dim nKey As KeyboardIndex = tmpKey
                        nKey.IsPressed = True
                        KeyboardKeys.Remove(CurrentKeyIndex)
                        KeyboardKeys.Add(CurrentKeyIndex, nKey)
                        nKey = Nothing
                    End If
                End If
        End Select
        tmpKey = Nothing
        ChangeKey()
    End Sub



    Private Function MakeKeyboardKey(ByVal Index As Integer, ByVal Value As Integer, ByVal Representation As String, ByVal KeyOutline As Rectangle, ByVal AboveIndex As Integer, ByVal RightIndex As Integer, ByVal BelowIndex As Integer, ByVal LeftIndex As Integer, Optional ByVal IsPressed As Boolean = False) As KeyboardIndex
        Dim tmpKey As New KeyboardIndex
        tmpKey.Index = Index
        tmpKey.AboveIndex = AboveIndex
        tmpKey.BelowIndex = BelowIndex
        tmpKey.KeyOutline = KeyOutline
        tmpKey.LeftIndex = LeftIndex
        tmpKey.Representation = Representation
        tmpKey.RightIndex = RightIndex
        tmpKey.Value = Value
        tmpKey.IsPressed = IsPressed
        Return tmpKey
        tmpKey = Nothing
    End Function

    Sub ChangeKey(Optional ByVal descriptionSize As Integer = 9, Optional ByVal descriptionPlusOffset As Integer = 0)
        If Not APICalls.GetPlatformName.IndexOf("WindowsPC") = -1 Then
            descriptionSize = 7
            descriptionPlusOffset = -3
        End If
        Dim g As Graphics = Graphics.FromImage(nKeyboard.Image)
        Dim tmpKey As KeyboardIndex = KeyboardKeys(CurrentKeyIndex)
        Dim c1Color As Color = Color.DarkBlue
        Dim c2Color As Color = Color.DarkCyan
        g.DrawImage(keyboardBackupImg, 0, 0)

        'Keys that are hold down will be drawn with different colors
        Dim key1Pressed As KeyboardIndex = KeyboardKeys(60)
        Dim key2Pressed As KeyboardIndex = KeyboardKeys(72)
        Dim key3Pressed As KeyboardIndex = KeyboardKeys(77)
        Dim key4Pressed As KeyboardIndex = KeyboardKeys(79)
        Dim key5Pressed As KeyboardIndex = KeyboardKeys(75)
        Dim key6Pressed As KeyboardIndex = KeyboardKeys(81)
        Dim key7Pressed As KeyboardIndex = KeyboardKeys(76)
        If key1Pressed.IsPressed Then
            g.DrawRectangle(New Pen(c1Color), key1Pressed.KeyOutline)
            g.DrawRectangle(New Pen(c2Color), New Rectangle(key1Pressed.KeyOutline.X + 1, key1Pressed.KeyOutline.Y + 1, key1Pressed.KeyOutline.Width - 2, key1Pressed.KeyOutline.Height - 2))
        End If
        If key2Pressed.IsPressed Then
            g.DrawRectangle(New Pen(c1Color), key2Pressed.KeyOutline)
            g.DrawRectangle(New Pen(c2Color), New Rectangle(key2Pressed.KeyOutline.X + 1, key2Pressed.KeyOutline.Y + 1, key2Pressed.KeyOutline.Width - 2, key2Pressed.KeyOutline.Height - 2))
        End If
        If key3Pressed.IsPressed Then
            g.DrawRectangle(New Pen(c1Color), key3Pressed.KeyOutline)
            g.DrawRectangle(New Pen(c2Color), New Rectangle(key3Pressed.KeyOutline.X + 1, key3Pressed.KeyOutline.Y + 1, key3Pressed.KeyOutline.Width - 2, key3Pressed.KeyOutline.Height - 2))
        End If
        If key4Pressed.IsPressed Then
            g.DrawRectangle(New Pen(c1Color), key4Pressed.KeyOutline)
            g.DrawRectangle(New Pen(c2Color), New Rectangle(key4Pressed.KeyOutline.X + 1, key4Pressed.KeyOutline.Y + 1, key4Pressed.KeyOutline.Width - 2, key4Pressed.KeyOutline.Height - 2))
        End If
        If key5Pressed.IsPressed Then
            g.DrawRectangle(New Pen(c1Color), key5Pressed.KeyOutline)
            g.DrawRectangle(New Pen(c2Color), New Rectangle(key5Pressed.KeyOutline.X + 1, key5Pressed.KeyOutline.Y + 1, key5Pressed.KeyOutline.Width - 2, key5Pressed.KeyOutline.Height - 2))
        End If
        If key6Pressed.IsPressed Then
            g.DrawRectangle(New Pen(c1Color), key6Pressed.KeyOutline)
            g.DrawRectangle(New Pen(c2Color), New Rectangle(key6Pressed.KeyOutline.X + 1, key6Pressed.KeyOutline.Y + 1, key6Pressed.KeyOutline.Width - 2, key6Pressed.KeyOutline.Height - 2))
        End If
        If key7Pressed.IsPressed Then
            g.DrawRectangle(New Pen(c1Color), key7Pressed.KeyOutline)
            g.DrawRectangle(New Pen(c2Color), New Rectangle(key7Pressed.KeyOutline.X + 1, key7Pressed.KeyOutline.Y + 1, key7Pressed.KeyOutline.Width - 2, key7Pressed.KeyOutline.Height - 2))
        End If

        g.DrawRectangle(New Pen(Color.OrangeRed), tmpKey.KeyOutline)
        g.DrawRectangle(New Pen(Color.Red), New Rectangle(tmpKey.KeyOutline.X + 1, tmpKey.KeyOutline.Y + 1, tmpKey.KeyOutline.Width - 2, tmpKey.KeyOutline.Height - 2))
        g.DrawString(tmpKey.Representation, New Font(FontFamily.GenericSansSerif, descriptionSize, FontStyle.Regular), New SolidBrush(Color.LightGreen), 2 + descriptionPlusOffset, nKeyboard.Image.Height - g.MeasureString(tmpKey.Representation, New Font(FontFamily.GenericSansSerif, descriptionSize, FontStyle.Regular)).Height - 1)
        g.DrawString(tmpKey.Representation, New Font(FontFamily.GenericSansSerif, descriptionSize, FontStyle.Regular), New SolidBrush(Color.DarkGreen), 2 + descriptionPlusOffset, nKeyboard.Image.Height - g.MeasureString(tmpKey.Representation, New Font(FontFamily.GenericSansSerif, descriptionSize, FontStyle.Regular)).Height)
        g = Nothing
        tmpKey = Nothing
        key1Pressed = Nothing
        key2Pressed = Nothing
        key3Pressed = Nothing
        key4Pressed = Nothing
        key5Pressed = Nothing
        key6Pressed = Nothing
        key7Pressed = Nothing
        c1Color = Nothing
        c2Color = Nothing
        nKeyboard.Refresh()
    End Sub

    Sub CancelPressedKeys()
        Dim PreviousKeyIndex
        PreviousKeyIndex = CurrentKeyIndex
        Dim key1Pressed As KeyboardIndex = KeyboardKeys(60)
        Dim key2Pressed As KeyboardIndex = KeyboardKeys(72)
        Dim key3Pressed As KeyboardIndex = KeyboardKeys(77)
        Dim key4Pressed As KeyboardIndex = KeyboardKeys(79)
        Dim key5Pressed As KeyboardIndex = KeyboardKeys(75)
        Dim key6Pressed As KeyboardIndex = KeyboardKeys(81)
        Dim key7Pressed As KeyboardIndex = KeyboardKeys(76)

        If key1Pressed.IsPressed Then
            CurrentKeyIndex = key1Pressed.Index
            nKeyboard_KeyUp(Me, New KeyEventArgs(13))
        End If
        If key2Pressed.IsPressed Then
            CurrentKeyIndex = key2Pressed.Index
            nKeyboard_KeyUp(Me, New KeyEventArgs(13))
        End If
        If key3Pressed.IsPressed Then
            CurrentKeyIndex = key3Pressed.Index
            nKeyboard_KeyUp(Me, New KeyEventArgs(13))
        End If
        If key4Pressed.IsPressed Then
            CurrentKeyIndex = key4Pressed.Index
            nKeyboard_KeyUp(Me, New KeyEventArgs(13))
        End If
        If key5Pressed.IsPressed Then
            CurrentKeyIndex = key5Pressed.Index
            nKeyboard_KeyUp(Me, New KeyEventArgs(13))
        End If
        If key6Pressed.IsPressed Then
            CurrentKeyIndex = key6Pressed.Index
            nKeyboard_KeyUp(Me, New KeyEventArgs(13))
        End If
        If key7Pressed.IsPressed Then
            CurrentKeyIndex = key7Pressed.Index
            nKeyboard_KeyUp(Me, New KeyEventArgs(13))
        End If

        CurrentKeyIndex = PreviousKeyIndex

        PreviousKeyIndex = Nothing
        key1Pressed = Nothing
        key2Pressed = Nothing
        key3Pressed = Nothing
        key4Pressed = Nothing
        key5Pressed = Nothing
        key6Pressed = Nothing
        key7Pressed = Nothing
    End Sub




    Private Sub tmrSendEnsureConnection_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrSendEnsureConnection.Tick
        cOut("EnsureConnection")
    End Sub

    Private Sub tmrEnsureConnection_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrEnsureConnection.Tick
        mnDisconnect_Click(Me, EventArgs.Empty)
        Out(" - No response received.", False)
    End Sub

    Sub CancelRemoteQuickMouse()
        If IsQuickMouse Then
            cOut("CancelQuickMouse")
            Main_KeyDown(Me, New KeyEventArgs(49))
        End If
    End Sub

    'This function writes a message to the log
    Private Sub Out(ByVal str As String, Optional ByVal ChangeEvent As Boolean = True)
        If ChangeEvent Then
            txtLog.Text &= vbCrLf & DateTime.Now.Minute & "." & DateTime.Now.Second & ": "
        End If
        txtLog.Text &= str
        Try
            txtLog.Select(txtLog.Text.LastIndexOf(vbCrLf) + 2, 0)
            txtLog.ScrollToCaret()
        Catch ex As Exception
            txtLog.Select(txtLog.Text.Length - 1, 0)
            txtLog.ScrollToCaret()
        End Try
    End Sub

    'Update ScreenSize
    Private Sub UpdateMouseLabel()
        lblMouseInfo.Text = "Mouse Step: " & MouseMoveStep & vbCrLf & "Scroll Step: " & ScrollMoveStep & vbCrLf & "Mouse Location: " & RemoteMouseLocation.X & ", " & RemoteMouseLocation.Y & vbCrLf & "Screen Size: " & RemoteScreenSize.Width & "x" & RemoteScreenSize.Height
        If IsQuickMouse Then
            lblMouseInfo.Text &= vbCrLf & "Quick Mouse Enabled: " & QuickMouseInterval & " (ms)"
        Else
            lblMouseInfo.Text &= vbCrLf & "Quick Mouse Disabled"
        End If
    End Sub

    Private Sub txtLog_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtLog.KeyDown
        Select Case e.KeyValue
            Case 49 '1
                If mnModeNone.Checked Then 'Execute macro Shorcut
                    If mnMacros.Enabled And mnMacroShorcuts.Enabled And mnMacroShorcut1.Enabled Then
                        mnMacroShorcut1_Click(Me, EventArgs.Empty)
                    End If
                End If
            Case 50 '2
                If mnModeNone.Checked Then 'Execute macro Shorcut
                    If mnMacros.Enabled And mnMacroShorcuts.Enabled And mnMacroShorcut1.Enabled Then
                        mnMacroShorcut2_Click(Me, EventArgs.Empty)
                    End If
                End If
            Case 51 '3
                If mnModeNone.Checked Then 'Execute macro Shorcut
                    If mnMacros.Enabled And mnMacroShorcuts.Enabled And mnMacroShorcut1.Enabled Then
                        mnMacroShorcut3_Click(Me, EventArgs.Empty)
                    End If
                End If
            Case 52 '4
                If mnModeNone.Checked Then 'Execute macro Shorcut
                    If mnMacros.Enabled And mnMacroShorcuts.Enabled And mnMacroShorcut1.Enabled Then
                        mnMacroShorcut4_Click(Me, EventArgs.Empty)
                    End If
                End If
            Case 53 '5
                If mnModeNone.Checked Then 'Execute macro Shorcut
                    If mnMacros.Enabled And mnMacroShorcuts.Enabled And mnMacroShorcut1.Enabled Then
                        mnMacroShorcut5_Click(Me, EventArgs.Empty)
                    End If
                End If
            Case 54 '6
                If mnModeNone.Checked Then 'Execute macro Shorcut
                    If mnMacros.Enabled And mnMacroShorcuts.Enabled And mnMacroShorcut1.Enabled Then
                        mnMacroShorcut6_Click(Me, EventArgs.Empty)
                    End If
                End If
            Case 55 '7
                If mnModeNone.Checked Then 'Execute macro Shorcut
                    If mnMacros.Enabled And mnMacroShorcuts.Enabled And mnMacroShorcut1.Enabled Then
                        mnMacroShorcut7_Click(Me, EventArgs.Empty)
                    End If
                End If
        End Select
    End Sub


    Sub StartExeMacro(ByVal txtMacro As String)
        Dim Comm As Hashtable = TextToCommands(txtMacro)
        Dim ComCount As Integer = Comm("Command Count")
        Dim i
        For i = 1 To ComCount
            Dim strCom As String = Comm(i)
            Dim clrCom As String = strCom.Substring(strCom.IndexOf(";") + 1)
            Select Case strCom.Substring(0, 3)
                Case "OUT"
                    If mnMacroOExeOut.Checked Then
                        If Not mnMacroOInvCom.Checked Then
                            If Not cOut(clrCom) Then
                                Out("Macro execution interrupted. Info: " & Comm("Program Name") & " v" & CType(Comm("Program Version"), Version).ToString & " created at " & Comm("Creation Date") & ".")
                                Exit Sub
                            End If
                        Else
                            TranslateCommand(clrCom)
                        End If
                    End If
                Case "IN_"
                    If mnMacroOExeIn.Checked Then
                        If mnMacroOInvCom.Checked Then
                            If Not cOut(clrCom) Then
                                Out("Macro execution interrupted. Info: " & Comm("Program Name") & " v" & CType(Comm("Program Version"), Version).ToString & " created at " & Comm("Creation Date") & ".")
                                Exit Sub
                            End If
                        Else
                            TranslateCommand(clrCom)
                        End If
                    End If
            End Select
        Next
        Out("Executed macro. Info: " & Comm("Program Name") & " v" & CType(Comm("Program Version"), Version).ToString & " created at " & Comm("Creation Date") & ".")
    End Sub

    Sub StartExeTimeMacro(ByVal txtMacro As String)
        IsTimeMacroExe = True

        TimeMacroComm = TextToCommands(txtMacro)

        TimeMacroComm.Add("Time Count Position", 1)
        TimeMacroComm.Add("Previous State of mnConnect", mnConnect.Enabled)
        TimeMacroComm.Add("Previous Text of mnConnect", mnConnect.Text)

        mnMenu.Enabled = False
        mnConnect.Enabled = True
        mnConnect.Text = "Stop Macro"

        tmrTimeMacroExe.Interval = 5000
        tmrTimeMacroExe.Enabled = True

        Out("Execution of a macro with timers started. Info: " & TimeMacroComm("Program Name") & " v" & CType(TimeMacroComm("Program Version"), Version).ToString & " created at " & TimeMacroComm("Creation Date") & ".")
    End Sub

    Private Sub MacroStopTimeExe()
        tmrTimeMacroExe.Enabled = False
        mnMenu.Enabled = True
        mnConnect.Enabled = TimeMacroComm("Previous State of mnConnect")
        mnConnect.Text = TimeMacroComm("Previous Text of mnConnect")
        IsTimeMacroExe = False
        TimeMacroComm = Nothing
        Out("Execution of a macro with timers finished.")
    End Sub

    Private Sub tmrTimeMacroExe_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles tmrTimeMacroExe.Tick
        Dim CurrTimePos As Integer = TimeMacroComm("Time Count Position")
        Dim CommCount As Integer = TimeMacroComm("Command Count")
        Dim strCom As String = TimeMacroComm(CurrTimePos)
        Dim clrCom As String = strCom.Substring(strCom.IndexOf(";") + 1)

        Select Case strCom.Substring(0, 3)
            Case "OUT"
                If mnMacroOExeOut.Checked Then
                    If Not mnMacroOInvCom.Checked Then
                        If Not cOut(clrCom) Then
                            MacroStopTimeExe()
                            Exit Sub
                        End If
                    Else
                        TranslateCommand(clrCom)
                    End If
                End If
            Case "IN_"
                If mnMacroOExeIn.Checked Then
                    If mnMacroOInvCom.Checked Then
                        If Not cOut(clrCom) Then
                            MacroStopTimeExe()
                            Exit Sub
                        End If
                    Else
                        TranslateCommand(clrCom)
                    End If
                End If
        End Select

        If Not CurrTimePos >= CommCount Then
            Dim strNextCom As String = TimeMacroComm(CurrTimePos + 1)

            Dim FirstTimeSpan As TimeSpan = TimeSpan.Parse(strCom.Substring(strCom.IndexOf(":") + 1, strCom.IndexOf(";") - strCom.IndexOf(":") - 1))
            Dim SecondTimeSpan As TimeSpan = TimeSpan.Parse(strNextCom.Substring(strNextCom.IndexOf(":") + 1, strNextCom.IndexOf(";") - strNextCom.IndexOf(":") - 1))
            Dim DiffTimeSpan As TimeSpan = SecondTimeSpan.Subtract(FirstTimeSpan)
            If DiffTimeSpan.TotalMilliseconds <= 0 Then
                DiffTimeSpan = New TimeSpan(0, 0, 0, 1)
            End If
            tmrTimeMacroExe.Interval = DiffTimeSpan.TotalMilliseconds / MacroTimerDecimate

            TimeMacroComm.Remove("Time Count Position")
            TimeMacroComm.Add("Time Count Position", CurrTimePos + 1)
        Else
            MacroStopTimeExe()
        End If
    End Sub

    Function TextToCommands(ByVal Txt As String) As Hashtable
        'Create Hashtable and store macro's info
        Dim Comm As New Hashtable
        Comm.Add("Program Name", Txt.Substring(0, Txt.IndexOf("##%%##") - 1))
        Txt = Replace(Txt, Txt.Substring(0, Txt.IndexOf("##%%##") + 7), "", 1, 1)
        Comm.Add("Creation Date", CType(Txt.Substring(0, Txt.IndexOf("##%%##") - 1), DateTime))
        Txt = Replace(Txt, Txt.Substring(0, Txt.IndexOf("##%%##") + 7), "", 1, 1)
        Comm.Add("Program Version", New Version(Txt.Substring(0, Txt.IndexOf(vbCrLf))))
        Txt = Replace(Txt, Txt.Substring(0, Txt.IndexOf(vbCrLf) + 2), "", 1, 1)
        'Start saving commands
        Dim i As Integer = 1
        While Txt <> ""
            If Not Txt.IndexOf(vbCrLf) = -1 Then
                Comm.Add(i, Txt.Substring(0, Txt.IndexOf(vbCrLf)))
                Txt = Replace(Txt, Txt.Substring(0, Txt.IndexOf(vbCrLf) + 2), "", 1, 1)
                i += 1
            Else
                Comm.Add(i, Txt)
                Txt = ""
                i += 1
            End If
        End While
        Comm.Add("Command Count", i - 1)

        Return Comm
        Comm = Nothing
        i = Nothing
    End Function



    Sub LoadOptions()
        LoadMacroShorcuts(strRegKey)

        If Reg.KeyExists(strRegKey) Then

            Dim mMouseMoveStep As String = CStr(Reg.GetValue(strRegKey & "\" & "MouseMoveStep"))
            Dim mScrollMoveStep As String = CStr(Reg.GetValue(strRegKey & "\" & "ScrollMoveStep"))

            If Not CStr(Reg.GetValue(strRegKey & "\" & "ValidateConnection")).IndexOf("False") = -1 Then
                mnConValidate_Click(Me, EventArgs.Empty)
            End If
            If Not CStr(Reg.GetValue(strRegKey & "\" & "MacroExeIn")).IndexOf("False") = -1 Then
                mnMacroOExeIn_Click(Me, EventArgs.Empty)
            End If
            If Not CStr(Reg.GetValue(strRegKey & "\" & "MacroExeOut")).IndexOf("True") = -1 Then
                mnMacroOExeOut_Click(Me, EventArgs.Empty)
            End If
            If Not CStr(Reg.GetValue(strRegKey & "\" & "MacroExeTime")).IndexOf("False") = -1 Then
                mnMacroOExeTime_Click(Me, EventArgs.Empty)
            End If
            If IsNumeric(CStr(Reg.GetValue(strRegKey & "\" & "MacroTimerDecimate"))) Then
                MacroTimerDecimate = Reg.GetValue(strRegKey & "\" & "MacroTimerDecimate")
            End If
            If Not CStr(Reg.GetValue(strRegKey & "\" & "MacroInvCom")).IndexOf("True") = -1 Then
                mnMacroOInvCom_Click(Me, EventArgs.Empty)
            End If
            If Not mMouseMoveStep = "" And IsNumeric(mMouseMoveStep) Then
                MouseMoveStep = mMouseMoveStep
            End If
            If Not mScrollMoveStep = "" And IsNumeric(mScrollMoveStep) Then
                ScrollMoveStep = mScrollMoveStep
            End If
            If Not Reg.GetValue(strRegKey & "\" & "IPtoConnect") = "" Then
                IPtoConnect = IPAddress.Parse(Reg.GetValue(strRegKey & "\" & "IPtoConnect"))
            Else
                Try
                    IPtoConnect = System.Net.Dns.GetHostByName("PPP_Peer").AddressList(0)
                Catch ex As Exception
                    IPtoConnect = IPAddress.None
                End Try
            End If
            If Not Reg.GetValue(strRegKey & "\" & "PorttoConnect") = "" Then
                PORT_NO = CInt(Reg.GetValue(strRegKey & "\" & "PorttoConnect"))
            End If
            If Not CStr(Reg.GetValue(strRegKey & "\" & "OEnsureConnection")).IndexOf("False") = -1 Then
                mnOEnsureConnection.Checked = False
            End If

            Out("Loaded Options")
        Else
            Try
                IPtoConnect = System.Net.Dns.GetHostByName("PPP_Peer").AddressList(0)
            Catch ex As Exception
                IPtoConnect = IPAddress.None
            End Try
        End If
    End Sub

    Sub SaveOptions()
        Dim shorcutPrefix As String = "MacroShorcut"
        Dim i
        For i = 0 To MacroShorcuts.Count - 1
            If MacroShorcuts(i) = "" Then
                MacroShorcuts(i) = "Undefined"
            End If
        Next

        Reg.CreateKey(strRegKey)
        Reg.SetValue(strRegKey & "\" & "MouseMoveStep", MouseMoveStep)
        Reg.SetValue(strRegKey & "\" & "ScrollMoveStep", ScrollMoveStep)
        Reg.SetValue(strRegKey & "\" & "ValidateConnection", mnConValidate.Checked)
        Reg.SetValue(strRegKey & "\" & "MacroExeIn", mnMacroOExeIn.Checked)
        Reg.SetValue(strRegKey & "\" & "MacroExeOut", mnMacroOExeOut.Checked)
        Reg.SetValue(strRegKey & "\" & "MacroExeTime", mnMacroOExeTime.Checked)
        Reg.SetValue(strRegKey & "\" & "MacroExeTime", mnMacroOExeTime.Checked)
        Reg.SetValue(strRegKey & "\" & "OEnsureConnection", mnOEnsureConnection.Checked)
        Reg.SetValue(strRegKey & "\" & "MacroTimerDecimate", MacroTimerDecimate)
        Reg.SetValue(strRegKey & "\" & shorcutPrefix & "1", MacroShorcuts(0))
        Reg.SetValue(strRegKey & "\" & shorcutPrefix & "2", MacroShorcuts(1))
        Reg.SetValue(strRegKey & "\" & shorcutPrefix & "3", MacroShorcuts(2))
        Reg.SetValue(strRegKey & "\" & shorcutPrefix & "4", MacroShorcuts(3))
        Reg.SetValue(strRegKey & "\" & shorcutPrefix & "5", MacroShorcuts(4))
        Reg.SetValue(strRegKey & "\" & shorcutPrefix & "6", MacroShorcuts(5))
        Reg.SetValue(strRegKey & "\" & shorcutPrefix & "7", MacroShorcuts(6))
        Reg.SetValue(strRegKey & "\" & "IPtoConnect", IPtoConnect.ToString)
        Reg.SetValue(strRegKey & "\" & "PorttoConnect", PORT_NO)

        Out("Options Saved.")
    End Sub

    Sub LoadMacroShorcuts(ByVal strRegKey As String)
        MacroShorcuts = New ArrayList(7)
        Dim shorcutPrefix As String = "MacroShorcut"

        If Reg.KeyExists(strRegKey) Then
            Dim i As Integer
            For i = 1 To 7
                Dim RegValPath As String = strRegKey & "\" & shorcutPrefix & i
                If Reg.ValueExists(RegValPath) Then
                    MacroShorcuts.Add(Reg.GetValue(RegValPath))
                Else
                    MacroShorcuts.Add("Undefined")
                End If
            Next
        Else
            Dim i As Integer
            For i = 1 To 7
                MacroShorcuts.Add("Undefined")
            Next
        End If

        Dim ii
        For ii = 0 To 6
            Dim iii
            For iii = 0 To Path.InvalidPathChars.Length - 1
                If Not CStr(MacroShorcuts(ii)).IndexOf(Path.InvalidPathChars(iii)) = -1 Then
                    MacroShorcuts(ii) = CStr(MacroShorcuts(ii)).Replace(Path.InvalidPathChars(iii), "")
                End If
            Next
        Next

        LoadMacroShorcutNames()
    End Sub

    Sub LoadMacroShorcutNames()
        mnMacroShorcut1.Text = "1. " & Path.GetFileName(MacroShorcuts(0))
        mnMacroShorcut2.Text = "2. " & Path.GetFileName(MacroShorcuts(1))
        mnMacroShorcut3.Text = "3. " & Path.GetFileName(MacroShorcuts(2))
        mnMacroShorcut4.Text = "4. " & Path.GetFileName(MacroShorcuts(3))
        mnMacroShorcut5.Text = "5. " & Path.GetFileName(MacroShorcuts(4))
        mnMacroShorcut6.Text = "6. " & Path.GetFileName(MacroShorcuts(5))
        mnMacroShorcut7.Text = "7. " & Path.GetFileName(MacroShorcuts(6))
    End Sub



End Class

