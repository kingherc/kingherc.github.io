'Pocket Control PC - NetCf
'Copyright (C) 2004 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System
Imports System.Resources

Public Class WriteResources
    
    Public Shared Sub Main()

        Dim writer As New System.Resources.ResourceWriter("Main.resources")

        ' Adds resources to the resource writer.
        writer.AddResource("ApplicationIcon 16", New System.Drawing.Icon("Images\AppIcon16.ico"))
        writer.AddResource("ApplicationIcon", New System.Drawing.Icon("Images\AppIcon.ico"))
        writer.AddResource("Keyboard", new System.Drawing.Bitmap("Images\Keyboard.gif"))
        writer.AddResource("MouseDown", new System.Drawing.Bitmap("Images\MouseDown.jpg"))
        writer.AddResource("MouseIdle", new System.Drawing.Bitmap("Images\MouseIdle.jpg"))
        writer.AddResource("MouseLeft", new System.Drawing.Bitmap("Images\MouseLeft.jpg"))
        writer.AddResource("MouseLeftClick", new System.Drawing.Bitmap("Images\MouseLeftClick.jpg"))
        writer.AddResource("MouseMiddleClick", new System.Drawing.Bitmap("Images\MouseMiddleClick.jpg"))
        writer.AddResource("MouseRight", new System.Drawing.Bitmap("Images\MouseRight.jpg"))
        writer.AddResource("MouseRightClick", new System.Drawing.Bitmap("Images\MouseRightClick.jpg"))
        writer.AddResource("MouseUp", new System.Drawing.Bitmap("Images\MouseUp.jpg"))
        writer.AddResource("ScrollDown", new System.Drawing.Bitmap("Images\ScrollDown.jpg"))
        writer.AddResource("ScrollIdle", new System.Drawing.Bitmap("Images\ScrollIdle.jpg"))
        writer.AddResource("ScrollUp", new System.Drawing.Bitmap("Images\ScrollUp.jpg"))
        writer.AddResource("ScrollX1Button", new System.Drawing.Bitmap("Images\ScrollX1Button.jpg"))
        writer.AddResource("ScrollX2Button", New System.Drawing.Bitmap("Images\ScrollX2Button.jpg"))
        writer.AddResource("FolderClosed", New System.Drawing.Bitmap("Images\FolderClosed.gif"))
        writer.AddResource("FolderOpened", New System.Drawing.Bitmap("Images\FolderOpened.gif"))
        writer.AddResource("FileIcon", New System.Drawing.Bitmap("Images\File.gif"))

        ' Writes the resources to the file or stream, and closes it.
        writer.Close()


    End Sub
End Class

