'Pocket Control PC - NetCf
    'Copyright (C) 2004 Iraklis Psaroudakis

    'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
    'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

    'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.Windows.Forms

Public Class frmExplorer
    Inherits System.Windows.Forms.Form

    Dim hResources As New Hashtable
    Public DirPath As String = "MyDocuments" 'Can be Root, MyDocuments, Temp, Prompt or a usual directory path like 'C:\'.
    Public ShowNewFolder As Boolean = True
    Public WhatToReturn As String = "Fil" '"Dir" or "Fil"
    Public ShowFiles As Boolean = True
    Public AllowOtherDirs As Boolean = True
    Dim WorkingSize As Size
    Public ReadOnly Property SelectedPath() As String
        Get
            Return CStr(tvExplorer.SelectedNode.Tag).Substring(4)
        End Get
    End Property
    Public ReadOnly Property SelectedType() As String
        Get
            Return CStr(tvExplorer.SelectedNode.Tag).Substring(0, 3)
        End Get
    End Property

    Public Sub New()
        MyBase.New()
        Init()
    End Sub

    Friend WithEvents MainMenu As New System.Windows.Forms.MainMenu
    Friend WithEvents mnDone As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMenu As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCancel As New System.Windows.Forms.MenuItem
    Friend WithEvents tvExplorer As New System.Windows.Forms.TreeView
    Friend WithEvents ilIcons As New System.Windows.Forms.ImageList
    Friend WithEvents mnNewFolder As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSeperator2 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnShowFiles As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnLoadDirs As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDirRoot As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDirMyDocs As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDirCurrent As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDirTemp As New System.Windows.Forms.MenuItem
    
    Private Sub LoadUpResources
        Dim iStream As Stream = System.Reflection.Assembly.GetExecutingAssembly.GetManifestResourceStream(System.Reflection.Assembly.GetExecutingAssembly.GetManifestResourceNames(0))
        Dim rr As New System.Resources.ResourceReader(iStream)
        Dim id As IDictionaryEnumerator = rr.GetEnumerator()
        While id.MoveNext()
            hResources.Add(id.key, id.Value)
        End While
    End Sub

    Sub Init()
        If Not LCase(APICalls.GetPlatformName).IndexOf(LCase("WindowsPC")) = -1 Then
            WorkingSize = Main.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        Else
            WorkingSize = New Size(System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height)
            'WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        End If

        LoadUpResources()

        MainMenu.MenuItems.Add(mnDone)
        MainMenu.MenuItems.Add(mnMenu)

        mnDone.Text = "Done"

        mnMenu.MenuItems.Add(mnShowFiles)
        mnMenu.MenuItems.Add(mnLoadDirs)
        mnMenu.MenuItems.Add(mnSeperator1)
        mnMenu.MenuItems.Add(mnNewFolder)
        mnMenu.MenuItems.Add(mnSeperator2)
        mnMenu.MenuItems.Add(mnCancel)
        mnMenu.Text = "Menu"

        mnShowFiles.Enabled = False
        mnShowFiles.Text = "Show Files"

        mnLoadDirs.Text = "Load Directory"

        mnLoadDirs.MenuItems.Add(mnDirRoot)
        mnLoadDirs.MenuItems.Add(mnDirMyDocs)
        mnLoadDirs.MenuItems.Add(mnDirCurrent)
        mnLoadDirs.MenuItems.Add(mnDirTemp)

        mnDirRoot.Text = "Device Root"
        mnDirMyDocs.Text = "My Documents"
        mnDirCurrent.Text = "Current App Directory"
        mnDirTemp.Text = "Temporary Folder"

        mnSeperator1.Text = "-"

        mnNewFolder.Text = "New Folder"

        mnSeperator2.Text = "-"
        mnCancel.Text = "Cancel"
        tvExplorer.ImageList = ilIcons
        tvExplorer.Location = New System.Drawing.Point(-1, -1)
        tvExplorer.SelectedImageIndex = 1
        tvExplorer.Size = New System.Drawing.Size(WorkingSize.Width + 2, WorkingSize.Height + 2)
        ilIcons.ImageSize = New System.Drawing.Size(16, 14)
        ilIcons.Images.Add(CType(hResources("FolderClosed"), System.Drawing.Image))
        ilIcons.Images.Add(CType(hResources("FolderOpened"), System.Drawing.Image))
        ilIcons.Images.Add(CType(hResources("FileIcon"), System.Drawing.Image))
        'Create Error Image Bitmap
        Dim ErrorBmp As New Bitmap(ilIcons.ImageSize.Width, ilIcons.ImageSize.Height)
        Dim g As Graphics = Graphics.FromImage(ErrorBmp)
        g.FillRectangle(New SolidBrush(Color.White), 0, 0, ErrorBmp.Width, ErrorBmp.Height)
        g.DrawLine(New Pen(Color.Red), CInt(ErrorBmp.Width / 2 - 3), CInt(ErrorBmp.Height / 2 - 3), CInt(ErrorBmp.Width / 2 + 3), CInt(ErrorBmp.Height / 2 + 3))
        g.DrawLine(New Pen(Color.Red), CInt(ErrorBmp.Width / 2 - 3), CInt(ErrorBmp.Height / 2 + 3), CInt(ErrorBmp.Width / 2 + 3), CInt(ErrorBmp.Height / 2 - 3))
        g = Nothing
        'End Create Error Image Bitmap
        ilIcons.Images.Add(ErrorBmp)
        ErrorBmp = Nothing

        Me.Controls.Add(tvExplorer)
        Me.Menu = MainMenu
        Me.Text = "File Explorer"

    End Sub

    Private Sub frmExplorer_Resize(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        If Not Width > Main.SmartphonePanelsSize.Width Then
            Width = Main.SmartphonePanelsSize.Width
        Else 'Widths changes
            tvExplorer.Width = Me.ClientSize.Width + 2
        End If
        If Not Height > Main.SmartphonePanelsSize.Height Then
            Height = Main.SmartphonePanelsSize.Height
        Else 'Heights changes
            tvExplorer.Height = Me.ClientSize.Height + 2
        End If
    End Sub

    Private Sub mnDirTemp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDirTemp.Click
        MakeDirPathTempPath(False)
        LoadDir(DirPath)
    End Sub

    Private Sub mnDirCurrent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDirCurrent.Click
        MakeDirPathRunningPath(False)
        LoadDir(DirPath)
    End Sub

    Private Sub mnDirMyDocs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDirMyDocs.Click
        DirPath = APICalls.GetSpecialFolder(APICalls.CSIDL_PERSONAL)
        LoadDir(DirPath)
    End Sub

    Private Sub mnDirRoot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDirRoot.Click
        DirPath = "\"
        LoadDir(DirPath)
    End Sub

    Private Sub mnShowFiles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnShowFiles.Click
        If mnShowFiles.Checked Then
            mnShowFiles.Checked = False
        Else
            mnShowFiles.Checked = True
        End If
        ShowFiles = mnShowFiles.Checked
        LoadDir(DirPath)
    End Sub

    Private Sub mnDone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDone.Click
        If WhatToReturn = SelectedType Then
            If SelectedPath = "\\" Or tvExplorer.SelectedNode.Text = ":Device Root:" Then
                MessageBox.Show("You cannot select Device Root.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            Else
                Me.DialogResult = DialogResult.OK
            End If
        Else
            Select Case SelectedType
                Case "Dir"
                    System.Windows.Forms.MessageBox.Show("You must select a file, not a folder!", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                Case "Fil"
                    System.Windows.Forms.MessageBox.Show("You must select a folder, not a file!", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                Case "Err"
                    System.Windows.Forms.MessageBox.Show("You selected an error message. Select a file or a folder.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            End Select
        End If

    End Sub

    Private Sub mnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCancel.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

    Private Sub mnNewFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnNewFolder.Click
        Dim nn As New InputDialog
        nn.AssignedValue = "New Folder"
        nn.Description = "Enter the new name for the folder."
        If nn.ShowDialog = DialogResult.OK Then
            Directory.CreateDirectory(SelectedPath.Substring(0, SelectedPath.LastIndexOf("\")) & "\" & nn.AssignedValue)
            LoadDir(DirPath)
        End If
        nn = Nothing
    End Sub

    Private Sub frmExplorer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        tvExplorer.Bounds = New Rectangle(-1, -1, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width + 2, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height + 2)
        If WhatToReturn = "Fil" And Not ShowFiles Then
            ShowFiles = True
        End If
        Select Case DirPath 'frmMain.DefaultExplorerDir
            Case "Prompt"
                Select Case System.Windows.Forms.MessageBox.Show("Choose Yes to define the start folder of the search. Choose No to start the search in the application's folder. Choose Cancel to search all the system (can be slow on PCs).", "Search Start", System.Windows.Forms.MessageBoxButtons.YesNoCancel, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                    Case DialogResult.Yes
                        Dim nn As New InputDialog
                        nn.AssignedValue = "C:\"
                        nn.Description = "Only existing folders or hard disks will not trigger errors. The default value is usually the most safe option."
                        If nn.ShowDialog = DialogResult.OK Then
                            If Directory.Exists(nn.AssignedValue) Then
                                DirPath = nn.AssignedValue
                            Else
                                MakeDirPathRunningPath(True)
                            End If
                        Else
                            MakeDirPathRunningPath(True)
                        End If
                    Case DialogResult.No
                        MakeDirPathRunningPath(False)
                End Select
            Case "MyDocuments"
                DirPath = APICalls.GetSpecialFolder(APICalls.CSIDL_PERSONAL)
            Case "Root"
                DirPath = "\"
            Case "Current"
                MakeDirPathRunningPath(False)
        End Select
        Dim DoesDirExists As Boolean = Directory.Exists(DirPath)
        If Not LCase(APICalls.GetPlatformName).IndexOf(LCase("WindowsCE")) = -1 Then
            Try
                Dim TempPDirs() As String = Directory.GetDirectories(DirPath)
                DoesDirExists = True
                TempPDirs = Nothing
            Catch ex As Exception

            End Try
        End If
        If Not DoesDirExists Then
            Select Case System.Windows.Forms.MessageBox.Show("The given directory was not found. The directory will now be changed to the current application's running directory. Would you rather change it to System's temporary directory?", "Directory Error", System.Windows.Forms.MessageBoxButtons.YesNo, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                Case DialogResult.Yes
                    MakeDirPathTempPath(False)
                Case DialogResult.No
                    MakeDirPathRunningPath(False)
            End Select
        End If
        LoadDir(DirPath)
        mnNewFolder.Enabled = ShowNewFolder
        mnShowFiles.Enabled = ShowFiles
        mnShowFiles.Checked = ShowFiles
        tvExplorer.SelectedNode = tvExplorer.Nodes(0)
        mnLoadDirs.Enabled = AllowOtherDirs
        frmExplorer_Resize(Me, EventArgs.Empty)
    End Sub

    Sub MakeDirPathRunningPath(Optional ByVal ShowMessage As Boolean = False)
        If ShowMessage Then
            System.Windows.Forms.MessageBox.Show("The starting folder of the search will be changed to the executing application path because there was an error while querying the given directory.", "Info", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
        End If
        DirPath = CType(New Uri(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)), Uri).LocalPath
    End Sub

    Sub MakeDirPathTempPath(Optional ByVal ShowMessage As Boolean = False)
        If ShowMessage Then
            System.Windows.Forms.MessageBox.Show("The starting folder of the search will be changed to System's temporary directory because there was an error while querying the given directory.", "Info", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
        End If
        DirPath = Path.GetTempPath
    End Sub

    Sub LoadDir(ByVal DirStr As String)
        If DirStr.LastIndexOf("\") = DirStr.Length - 1 Then
            If Not DirStr = "\" Then
                DirStr = DirStr.Remove(DirStr.LastIndexOf("\"), 1)
            End If
        End If
        tvExplorer.Nodes.Clear()
        Try
            Dim ParentNode As New TreeNode(DirStr.Substring(DirStr.LastIndexOf("\") + 1))
            If DirStr = "\" Then
                ParentNode.Text = ":Device Root:"
            End If
            ParentNode.Tag = "Dir:" & DirStr & "\"
            Dim Dirs() As String
            Try
                Dirs = Directory.GetDirectories(DirStr)
            Catch ex As Exception

            End Try
            Dim i
            If Dirs.Length > 0 Then
                For i = 0 To (Dirs.Length - 1)
                    Dim nt As New System.Windows.Forms.TreeNode(Dirs(i).Substring(Dirs(i).LastIndexOf("\") + 1))
                    nt.Tag = "Dir:" & Dirs(i) & "\"
                    'Try
                    'PopulateDirs(nt)
                    'Catch ex As Exception
                    'Dim ErrNt As New System.Windows.Forms.TreeNode("SubDirectories reading error")
                    'ErrNt.Tag = "Err:" & ErrNt.Text
                    'ErrNt.ImageIndex = 3
                    'ErrNt.SelectedImageIndex = 3
                    'nt.Nodes.Add(ErrNt)
                    'ErrNt = Nothing
                    'End Try
                    'If ShowFiles Then
                    'Try
                    'PopulateFiles(nt)
                    'Catch ex As Exception
                    'Dim ErrNt As New System.Windows.Forms.TreeNode("Files reading error")
                    'ErrNt.Tag = "Err:" & ErrNt.Text
                    'ErrNt.ImageIndex = 3
                    'ErrNt.SelectedImageIndex = 3
                    'nt.Nodes.Add(ErrNt)
                    'ErrNt = Nothing
                    'End Try
                    'End If
                    ParentNode.Nodes.Add(nt)
                    nt = Nothing
                Next
            End If
            If ShowFiles Then
                Try
                    PopulateFiles(ParentNode)
                Catch ex As Exception
                    Dim ErrNt As New System.Windows.Forms.TreeNode("Files reading error")
                    ErrNt.Tag = "Err:" & ErrNt.Text
                    ErrNt.ImageIndex = 3
                    ErrNt.SelectedImageIndex = 3
                    ParentNode.Nodes.Add(ErrNt)
                    ErrNt = Nothing
                End Try
            End If
            If ParentNode.Nodes.Count = 0 Then
                MessageBox.Show("Error2")
                Dim ErrNt As New System.Windows.Forms.TreeNode("No Directories/Files or Read Error")
                ErrNt.Tag = "Err:" & ErrNt.Text
                ErrNt.ImageIndex = 3
                ErrNt.SelectedImageIndex = 3
                ParentNode.Nodes.Add(ErrNt)
                ErrNt = Nothing
            End If
            Dirs = Nothing
            i = Nothing
            tvExplorer.Nodes.Add(ParentNode)
        Catch ex As Exception

        End Try
        If tvExplorer.Nodes.Count = 0 Then
            Dim ErrNt As New System.Windows.Forms.TreeNode("No Directories/Files or Read Error")
            ErrNt.Tag = "Err:" & ErrNt.Text
            ErrNt.ImageIndex = 3
            ErrNt.SelectedImageIndex = 3
            tvExplorer.Nodes.Add(ErrNt)
            ErrNt = Nothing
        End If
    End Sub

    Sub PopulateDirs(ByRef tNode As System.Windows.Forms.TreeNode)
        Dim Dirs As String()
        Dirs = Directory.GetDirectories(CStr(tNode.Tag).Substring(4))
        Dim i
        For i = 0 To (Dirs.Length - 1)
            Dim nt As New System.Windows.Forms.TreeNode(Dirs(i).Substring(Dirs(i).LastIndexOf("\") + 1))
            nt.Tag = "Dir:" & Dirs(i) & "\"
            'Try
            'PopulateDirs(nt)
            'Catch ex As Exception
            'Dim ErrNt As New System.Windows.Forms.TreeNode("SubDirectories reading error")
            'ErrNt.Tag = "Err:" & ErrNt.Text
            'ErrNt.ImageIndex = 3
            'ErrNt.SelectedImageIndex = 3
            'nt.Nodes.Add(ErrNt)
            'ErrNt = Nothing
            'End Try
            If ShowFiles Then
                Try
                    PopulateFiles(nt)
                Catch ex As Exception
                    Dim ErrNt As New System.Windows.Forms.TreeNode("Files reading error")
                    ErrNt.Tag = "Err:" & ErrNt.Text
                    ErrNt.ImageIndex = 3
                    ErrNt.SelectedImageIndex = 3
                    nt.Nodes.Add(ErrNt)
                    ErrNt = Nothing
                End Try
            End If
            tNode.Nodes.Add(nt)
            nt = Nothing
        Next
        Dirs = Nothing
        i = Nothing
    End Sub

    Sub PopulateFiles(ByRef tNode As System.Windows.Forms.TreeNode)
        Dim Files As String()
        If Not tNode.Text = ":Device Root:" Then
            Files = Directory.GetFiles(CStr(tNode.Tag).Substring(4))
        Else
            Files = Directory.GetFiles("\")
        End If
        Dim i
        For i = 0 To (Files.Length - 1)
            Dim nt As New System.Windows.Forms.TreeNode(Files(i).Substring(Files(i).LastIndexOf("\") + 1))
            nt.Tag = "Fil:" & Files(i)
            nt.ImageIndex = 2
            nt.SelectedImageIndex = 2
            tNode.Nodes.Add(nt)
            nt = Nothing
        Next
        Files = Nothing
        i = Nothing
    End Sub

    Private Sub tvExplorer_BeforeExpand(ByVal sender As Object, ByVal e As TreeViewCancelEventArgs) Handles tvExplorer.BeforeExpand
        Dim nt As TreeNode
        For Each nt In e.Node.Nodes
            If CStr(nt.Tag).Substring(0, 3) = "Dir" Then
                Try
                    PopulateDirs(nt)
                Catch ex As Exception
                    Dim ErrNt As New System.Windows.Forms.TreeNode("Read/Access Error")
                    ErrNt.Tag = "Err:" & ErrNt.Text
                    ErrNt.ImageIndex = 3
                    ErrNt.SelectedImageIndex = 3
                    nt.Nodes.Add(ErrNt)
                    ErrNt = Nothing
                End Try
            End If
        Next
    End Sub

End Class

