'Pocket Control PC - NetCf
'Copyright (C) 2004 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Text
Imports System.IO
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.ValueType
Imports System.Windows.Forms

Public Class APICalls


    Public Shared PlatformName As String = ""
    Public Shared DoubleClickTm As Integer = 0

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function GetDoubleClickTime() As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("User32.dll", EntryPoint:="GetDoubleClickTime")> _
Public Shared Function GetWindowsDoubleClickTime() As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
    Public Shared Function SystemParametersInfo(ByVal uiAction As Integer, ByVal uiParam As Integer, ByVal pvParam As Byte(), ByVal fWinIni As Integer) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function GetLastError() As IntPtr
    End Function

    <System.Runtime.InteropServices.DllImport("Kernel32.dll", EntryPoint:="GetLastError")> _
Public Shared Function GetLastErrorWindows() As IntPtr
    End Function

    Public Shared Function GetPlatformName() As String
        Try
            If PlatformName = "" Then
                If Environment.OSVersion.Platform = PlatformID.WinCE Then
                    Dim buffer(29) As Byte
                    Dim rc As String = ""
                    SystemParametersInfo(257, buffer.Length, buffer, 0)
                    rc = Encoding.Unicode.GetString(buffer, 0, buffer.Length)
                    PlatformName = "WindowsCE" & rc
                    Return PlatformName
                Else
                    Select Case Environment.OSVersion.Platform
                        Case PlatformID.Win32NT
                            PlatformName = "WindowsPCNT"
                            Return PlatformName
                        Case PlatformID.Win32S
                            PlatformName = "WindowsPCS16For32Bit"
                            Return PlatformName
                        Case Else
                            PlatformName = "WindowsPC"
                            Return PlatformName
                    End Select
                End If
            Else
                Return PlatformName
            End If
        Catch ex As Exception
            Return "SmartPhone"
        End Try
    End Function

    Public Shared Function DoubleClickTime() As Integer
        If DoubleClickTm = 0 Then
            If Not LCase(GetPlatformName).IndexOf(LCase("WindowsPC")) = -1 Then
                DoubleClickTm = GetWindowsDoubleClickTime()
                Return DoubleClickTm
            Else
                DoubleClickTm = GetDoubleClickTime()
                Return DoubleClickTm
            End If
        Else
            Return DoubleClickTm
        End If
    End Function



    Public Const CSIDL_PERSONAL As Integer = &H5
    Public Const CSIDL_WINDOWS As Integer = &H24
    Public Const MAX_PATH As Integer = 260

    <System.Runtime.InteropServices.DllImport("coredll.dll")> _
    Public Shared Function SHGetSpecialFolderPath(ByVal hwndOwner As IntPtr, ByVal lpszPath As Byte(), ByVal nFolder As Integer, ByVal fCreate As Integer) As Boolean
    End Function

    <System.Runtime.InteropServices.DllImport("Winuser.dll")> _
Public Shared Function GetActiveWindow() As IntPtr
    End Function

    <System.Runtime.InteropServices.DllImport("shell32.dll", EntryPoint:="SHGetSpecialFolderPath")> _
Public Shared Function SHGetSpecialFolderPathWindows(ByVal hwndOwner As IntPtr, ByVal lpszPath As Byte(), ByVal nFolder As Integer, ByVal fCreate As Integer) As Boolean
    End Function

    <System.Runtime.InteropServices.DllImport("User32.dll", EntryPoint:="GetActiveWindow")> _
Public Shared Function GetActiveWindowWindows() As IntPtr
    End Function

    Public Shared Function GetSpecialFolder(Optional ByVal CSIDL As Integer = CSIDL_PERSONAL) As String
        Try
            Dim buffer(MAX_PATH) As Byte
            Dim rc As String = ""
            If Environment.OSVersion.Platform = PlatformID.WinCE Then
                'SHGetSpecialFolderPath(GetActiveWindow, buffer, CSIDL_PERSONAL, 0)
                SHGetSpecialFolderPath(Nothing, buffer, CSIDL, 0)
            Else
                'SHGetSpecialFolderPathWindows(GetActiveWindowWindows, buffer, CSIDL_PERSONAL, 0)
                SHGetSpecialFolderPathWindows(Nothing, buffer, CSIDL, 0)
            End If
            If Not LCase(GetPlatformName).IndexOf(LCase("WindowsPC")) = -1 Then
                rc = Encoding.ASCII.GetString(buffer, 0, buffer.Length)
            Else
                rc = Encoding.Unicode.GetString(buffer, 0, buffer.Length)
            End If
            'Remove illegal characters
            Dim ii
            For ii = 0 To Path.InvalidPathChars.Length - 1
                rc = rc.Replace(Path.InvalidPathChars(ii), "")
            Next
            ii = Nothing
            Return rc
        Catch ex As Exception
            Return "Error"
        End Try
    End Function


    'Not used yet

    Public Structure pPoint
        Public x As Int32
        Public y As Int32
    End Structure

    Public Structure MOUSEMOVEPOINT
        Public x As Integer
        Public y As Integer
        Public time As Integer
        Public dwExtraInfo As IntPtr
    End Structure

    <System.Runtime.InteropServices.DllImport("coredll.dll")> _
    Public Shared Function GetMouseMovePoints(ByVal pptBuf As pPoint(), ByVal nBufPoints As Integer, ByVal pnPointsRetrieved As Integer) As Boolean
    End Function

    <System.Runtime.InteropServices.DllImport("user32.dll")> _
Public Shared Function GetMouseMovePointsEx(ByVal cbSize As Integer, ByVal lppt As MOUSEMOVEPOINT, ByRef lpptBuf As MOUSEMOVEPOINT(), ByVal nBufPoints As Integer, ByVal resolution As Integer) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint:="GetCursorPos")> _
Public Shared Function GetCursorPosWindows(ByRef lpPoint As pPoint) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("cursor.dll")> _
Public Shared Function GetCursorPos(ByRef lpPoint As pPoint) As Integer
    End Function

    Public Shared Sub ShowLastMousePoints()
        If GetPlatformName.IndexOf("WindowsPC") = -1 Then
            Dim AllPoints(63) As pPoint
            Dim GotPoints As Integer
            If Not GetMouseMovePoints(AllPoints, AllPoints.Length * 2, GotPoints) Then
                MessageBox.Show(GetLastError.ToInt32)
            Else
                Dim i, strShow
                For i = 0 To AllPoints.Length - 1
                    strShow &= "Point " & (i + 1) & ": (" & AllPoints(i).x & ", " & AllPoints(i).y & ")"
                Next
                MessageBox.Show(strShow)
            End If
        Else
            'GMMP_USE_HIGH_RESOLUTION_POINTS 2
            Dim AllPoints(63) As MOUSEMOVEPOINT
            Dim CurrentPoint As MOUSEMOVEPOINT
            CurrentPoint.x = GetCurrentCursorPos.X
            CurrentPoint.y = GetCurrentCursorPos.Y
            CurrentPoint.time = Nothing
            CurrentPoint.dwExtraInfo = Nothing
            If GetMouseMovePointsEx(100, CurrentPoint, AllPoints, 2, 2) = -1 Then
                MessageBox.Show(GetLastErrorWindows.ToInt32)
            Else
                Dim i, strShow
                For i = 0 To AllPoints.Length - 1
                    strShow &= "Point " & (i + 1) & ": (" & AllPoints(i).x & ", " & AllPoints(i).y & ")"
                Next
                MessageBox.Show(strShow)
            End If
        End If
    End Sub

    Public Shared Function GetCurrentCursorPos() As Point
        If GetPlatformName.IndexOf("WindowsPC") = -1 Then
            Dim CurrPos As pPoint
            If GetCursorPos(CurrPos) = 0 Then
                Return New Point(0, 0)
            End If
            Return New Point(CurrPos.x, CurrPos.y)
        Else
            Dim CurrPos As pPoint
            If GetCursorPosWindows(CurrPos) = 0 Then
                Return New Point(0, 0)
            End If
            Return New Point(CurrPos.x, CurrPos.y)
        End If
    End Function



    Shared Function ReadTxt(ByVal TxtPath As String, Optional ByVal DoNotUseMapPath As Boolean = False) As String
        Dim Wt2Return As String
        Dim str2Validate As String
        If Not DoNotUseMapPath Then
            str2Validate = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase) & "\" & TxtPath
        Else
            str2Validate = TxtPath
        End If
        If File.Exists(str2Validate) Then
            Dim objStreamReader As StreamReader
            Dim strInput As String
            objStreamReader = File.OpenText(str2Validate)
            Wt2Return = objStreamReader.ReadToEnd()
            objStreamReader.Close()
            objStreamReader = Nothing
            strInput = Nothing
        Else
            Wt2Return = str2Validate
        End If
        Return Wt2Return
    End Function

    Shared Function Write2Txt(ByVal TxtPath As String, ByVal Wt2Write As String, Optional ByVal ReplaceIt As Boolean = True, Optional ByVal DoNotUseMapPath As Boolean = False) As Boolean
        If Not DoNotUseMapPath Then
            TxtPath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase) & "\" & TxtPath
        End If
        If File.Exists(TxtPath) Then
            Dim objStreamWriter As StreamWriter
            If Not ReplaceIt Then
                objStreamWriter = File.AppendText(TxtPath)
            Else
                objStreamWriter = File.CreateText(TxtPath)
            End If
            objStreamWriter.WriteLine(Wt2Write)
            objStreamWriter.Close()
            Return True
        Else
            If ReplaceIt Then
                Dim objStreamWriter As StreamWriter
                objStreamWriter = File.CreateText(TxtPath)
                objStreamWriter.WriteLine(Wt2Write)
                objStreamWriter.Close()
            End If
            Return False
        End If
    End Function


End Class


Public Class Reg

    Public Shared Function ValueExists(ByVal ValuePath As String) As Boolean
        If ValuePath.IndexOf("\") = -1 Then
            Return False
        Else
            Dim Keys() As String = InnerAPIRegistry.StringToKeys(ValuePath)
            Dim nn() As String = GetSubValueNames(ValuePath.Substring(0, ValuePath.LastIndexOf("\")))
            Try
                Dim i As Integer = 0
                For i = 0 To nn.Length - 1
                    If Not nn(i).IndexOf(Keys(Keys.Length - 1)) = -1 Then
                        Return True
                        Exit Function
                    End If
                Next
                Return False
            Catch ex As Exception
                Return False
            End Try
        End If
    End Function

    Public Shared Function GetSubValueNames(ByVal ValuePath As String) As String()
        Dim LastKeyRequired As IntPtr = InnerAPIRegistry.OpenKey(ValuePath)

        Return InnerAPIRegistry.GetRegValueNames(LastKeyRequired)

        InnerAPIRegistry.CloseKey(LastKeyRequired)
        LastKeyRequired = Nothing
    End Function

    Public Shared Function KeyExists(ByVal ValuePath As String) As Boolean
        If ValuePath.IndexOf("\") = -1 Then
            If Not ValuePath.IndexOf("HKEY_CLASSES_ROOT") = -1 Or Not ValuePath.IndexOf("HKEY_CURRENT_USER") = -1 Or Not ValuePath.IndexOf("HKEY_LOCAL_MACHINE") = -1 Or Not ValuePath.IndexOf("HKEY_USERS") = -1 Or Not ValuePath.IndexOf("HKEY_CURRENT_CONFIG") = -1 Then
                Return True
            Else
                Return False
            End If
        Else
            Dim Keys() As String = InnerAPIRegistry.StringToKeys(ValuePath)
            Dim nn() As String = GetSubKeyNames(ValuePath.Substring(0, ValuePath.LastIndexOf("\")))
            Try
                Dim i As Integer = 0
                For i = 0 To nn.Length - 1
                    If Not nn(i).IndexOf(Keys(Keys.Length - 1)) = -1 Then
                        Return True
                        Exit Function
                    End If
                Next
                Return False
            Catch ex As Exception
                Return False
            End Try
        End If
    End Function

    Public Shared Function GetSubKeyNames(ByVal ValuePath As String) As String()
        Dim LastKeyRequired As IntPtr = InnerAPIRegistry.OpenKey(ValuePath)

        Return InnerAPIRegistry.GetRegSubKeyNames(LastKeyRequired)

        InnerAPIRegistry.CloseKey(LastKeyRequired)
        LastKeyRequired = Nothing
    End Function

    Public Shared Function SetValue(ByVal ValuePath As String, ByVal Value As String) As Boolean
        'For now, All Values are set as REG_SZ type (that is as Strings).

        Dim Keys() As String = InnerAPIRegistry.StringToKeys(ValuePath)
        Dim LastKeyRequired As IntPtr = InnerAPIRegistry.OpenKey(ValuePath.Substring(0, ValuePath.LastIndexOf("\")))

        Return InnerAPIRegistry.SetRegValue(LastKeyRequired, Keys(Keys.Length - 1), Value)

        InnerAPIRegistry.CloseKey(LastKeyRequired)
        LastKeyRequired = Nothing
    End Function

    Public Shared Function DeleteValue(ByVal ValuePath As String) As Boolean
        Dim Keys() As String = InnerAPIRegistry.StringToKeys(ValuePath)
        Dim LastKeyRequired As IntPtr = InnerAPIRegistry.OpenKey(ValuePath.Substring(0, ValuePath.LastIndexOf("\")))

        Return InnerAPIRegistry.DeleteRegValue(LastKeyRequired, ValuePath.Substring(ValuePath.LastIndexOf("\") + 1))

        InnerAPIRegistry.CloseKey(LastKeyRequired)
        LastKeyRequired = Nothing
    End Function

    Public Shared Function DeleteKey(ByVal ValuePath As String) As Boolean
        Dim Keys() As String = InnerAPIRegistry.StringToKeys(ValuePath)
        Dim LastKeyRequired As IntPtr = InnerAPIRegistry.OpenKey(ValuePath.Substring(0, ValuePath.LastIndexOf("\")))

        Return InnerAPIRegistry.DeleteRegKey(LastKeyRequired, ValuePath.Substring(ValuePath.LastIndexOf("\") + 1))

        InnerAPIRegistry.CloseKey(LastKeyRequired)
        LastKeyRequired = Nothing
    End Function

    Public Shared Function CreateKey(ByVal ValuePath As String) As Boolean
        Dim Keys() As String = InnerAPIRegistry.StringToKeys(ValuePath)
        Dim LastKeyRequired As IntPtr = InnerAPIRegistry.OpenKey(ValuePath.Substring(0, ValuePath.LastIndexOf("\")))

        Dim CreatedKey As IntPtr = InnerAPIRegistry.CreateRegKey(LastKeyRequired, ValuePath.Substring(ValuePath.LastIndexOf("\") + 1))

        If CreatedKey.ToInt32 = 0 Then
            Return False
        Else
            Return True
            InnerAPIRegistry.CloseKey(CreatedKey)
        End If

        InnerAPIRegistry.CloseKey(LastKeyRequired)
        LastKeyRequired = Nothing
    End Function

    Public Shared Function GetValue(ByVal ValuePath As String) As Object
        Dim Keys() As String = InnerAPIRegistry.StringToKeys(ValuePath)
        Dim LastKeyRequired As IntPtr = InnerAPIRegistry.OpenKey(ValuePath.Substring(0, ValuePath.LastIndexOf("\")))

        Return InnerAPIRegistry.GetRegistryValue(LastKeyRequired, Keys(Keys.Length - 1))

        InnerAPIRegistry.CloseKey(LastKeyRequired)
        LastKeyRequired = Nothing
    End Function

    Public Shared Function GetKeyInfo(ByVal ValuePath As String, ByVal InfoFunction As String) As Object
        'InfoFunction:
        'NumberSubKeys - Returns an Integer indicating the number of subkeys
        'MaxKeyLength - Returns an Integer indicating the length of the longest subkey
        'NumberValues - Returns an Integer indicating the number of values contained in the key
        'LongestValueName - Returns an Integer indicating the length of the longest value name
        'LongestValue - Returns an Integer indicating the length of the longest value

        Dim Keys() As String = InnerAPIRegistry.StringToKeys(ValuePath)
        Dim LastKeyRequired As IntPtr = InnerAPIRegistry.OpenKey(ValuePath)

        Return InnerAPIRegistry.GetKeyInfo(LastKeyRequired, InfoFunction)

        InnerAPIRegistry.CloseKey(LastKeyRequired)
        LastKeyRequired = Nothing
    End Function

End Class

Public Class InnerAPIRegistry


    Public Const REG_OPTION_NON_VOLATILE As Integer = &H0L
    Public Const REG_OPTION_VOLATILE As Integer = &H1L
    Public Const REG_OPTION_BACKUP_RESTORE As Integer = &H4L
    Public Const REG_CREATED_NEW_KEY As Integer = &H1L
    Public Const REG_OPENED_EXISTING_KEY As Integer = &H2L

    Public Const REG_BINARY As Integer = 3
    Public Const REG_SZ As Integer = 1
    Public Const REG_EXPAND_SZ As Integer = 2
    Public Const REG_DWORD As Integer = 4
    Public Const REG_LINK As Integer = 6
    Public Const REG_MULTI_SZ As Integer = 7
    Public Const REG_RESOURCE_LIST As Integer = 8
    Public Const REG_NONE As Integer = 0

    Public Structure SECURITY_ATTRIBUTES
        Public nLength As Integer
        Public lpSecurityDescriptor As Object
        Public bInheritHandle As Boolean
    End Structure

    Public Structure FILETIME
        Public dwLowDateTime As Integer
        Public dwHighDateTime As Integer
    End Structure

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function RegEnumValue(ByVal hKey As IntPtr, ByVal dwIndex As Integer, ByVal lpValueName As Char(), ByRef lpcbValueName As Integer, ByVal lpReserved As Integer, ByVal lpType As Integer, ByVal lpData As Byte(), ByVal lpcbData As Integer) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Advapi32.dll", EntryPoint:="RegEnumValue")> _
Public Shared Function RegEnumValueWindows(ByVal hKey As IntPtr, ByVal dwIndex As Integer, ByVal lpValueName As Byte(), ByRef lpcbValueName As Integer, ByVal lpReserved As Integer, ByVal lpType As Integer, ByVal lpData As Byte(), ByRef lpcbData As Integer) As Integer
    End Function

    '<System.Runtime.InteropServices.DllImport("Advapi32.dll", EntryPoint:="RegEnumKeyEx")> _
    'Public Shared Function RegEnumKeyExWindows(ByVal hKey As IntPtr, ByVal dwIndex As Integer, ByVal lpName As Byte(), ByRef lpcbName As Integer, ByVal lpReserved As Integer, ByVal lpClass As Byte(), ByRef lpcbClass As Integer, ByRef lpftLastWriteTime As FILETIME) As Integer
    'End Function

    <System.Runtime.InteropServices.DllImport("Advapi32.dll", EntryPoint:="RegEnumKeyEx")> _
Public Shared Function RegEnumKeyExWindows(ByVal hKey As IntPtr, ByVal dwIndex As Integer, ByVal lpName As Byte(), ByRef lpcbName As Integer, ByVal lpReserved As Integer, ByVal lpClass As Byte(), ByRef lpcbClass As Integer, ByVal lpftLastWriteTime As Integer) As Integer
    End Function

    '<System.Runtime.InteropServices.DllImport("Advapi32.dll", EntryPoint:="RegEnumKey")> _
    'Public Shared Function RegEnumKeyWindows(ByVal hKey As IntPtr, ByVal dwIndex As Integer, ByVal lpName As Byte(), ByVal cchName As Integer) As Integer
    'End Function

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function RegEnumKeyEx(ByVal hKey As IntPtr, ByVal dwIndex As Integer, ByVal lpName As Char(), ByRef lpcbName As Integer, ByVal lpReserved As Integer, ByVal lpClass As Byte(), ByVal lpcbClass As Integer, ByVal lpftLastWriteTime As Integer) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Advapi32.dll", EntryPoint:="RegSetValueEx")> _
Public Shared Function RegSetValueExWindows(ByVal hkey As IntPtr, ByVal lpValueName As String, ByVal Reserved As Integer, ByVal dwType As Integer, ByVal lpData As Byte(), ByVal cbData As Integer) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function RegSetValueEx(ByVal hkey As IntPtr, ByVal lpValueName As String, ByVal Reserved As Integer, ByVal dwType As Integer, ByVal lpData As Byte(), ByVal cbData As Integer) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function RegDeleteKey(ByVal hkey As IntPtr, ByVal lpSubKey As String) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Advapi32.dll", EntryPoint:="RegDeleteKey")> _
Public Shared Function RegDeleteKeyWindows(ByVal hkey As IntPtr, ByVal lpSubKey As String) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function RegDeleteValue(ByVal hkey As IntPtr, ByVal lpValueName As String) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Advapi32.dll", EntryPoint:="RegDeleteValue")> _
Public Shared Function RegDeleteValueWindows(ByVal hkey As IntPtr, ByVal lpValueName As String) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function RegCreateKeyEx(ByVal hkey As IntPtr, ByVal lpSubKey As String, ByVal Reserved As Integer, ByVal lpClass As String, ByVal dwOptions As Integer, ByVal samDesired As Integer, ByRef lpSecurityAttributes As Object, ByRef phkResult As IntPtr, ByRef lpdwDisposition As Integer) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Advapi32.dll", EntryPoint:="RegCreateKeyEx")> _
Public Shared Function RegCreateKeyExWindows(ByVal hKey As IntPtr, ByVal lpSubKey As String, ByVal Reserved As Integer, ByVal lpClass As String, ByVal dwOptions As Integer, ByVal samDesired As Integer, ByRef lpSecurityAttributes As SECURITY_ATTRIBUTES, ByRef phkResult As IntPtr, ByRef lpdwDisposition As Integer) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
    Public Shared Function RegOpenKeyEx(ByVal hkey As IntPtr, ByVal lpSubKey As String, ByVal ulOptions As Integer, ByVal samDesired As Integer, ByRef phkResult As IntPtr) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Advapi32.dll", EntryPoint:="RegOpenKeyEx")> _
    Public Shared Function RegOpenKeyExWindows(ByVal hkey As IntPtr, ByVal lpSubKey As String, ByVal ulOptions As Integer, ByVal samDesired As Integer, ByVal phkResult As IntPtr) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Advapi32.dll", EntryPoint:="RegOpenKey")> _
Public Shared Function RegOpenKeyWindows(ByVal hkey As IntPtr, ByVal lpSubKey As String, ByRef phkResult As IntPtr) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function RegCloseKey(ByVal hkey As IntPtr) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Advapi32.dll", EntryPoint:="RegCloseKey")> _
Public Shared Function RegCloseKeyWindows(ByVal hkey As IntPtr) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function RegQueryValueEx(ByVal hkey As IntPtr, ByVal lpValueName As String, ByVal lpReserved As Object, ByRef lpType As IntPtr, ByVal lpData As Byte(), ByRef lpcbData As Integer) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Advapi32.dll", EntryPoint:="RegQueryValueEx")> _
    Public Shared Function RegQueryValueExWindows(ByVal hkey As IntPtr, ByVal lpValueName As String, ByVal lpReserved As Integer, ByVal lpType As Integer, ByVal lpData As Byte(), ByRef lpcbData As Integer) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function RegQueryInfoKey(ByVal hkey As IntPtr, ByVal lpClass As Byte(), ByVal lpcbClass As Integer, ByVal lpReserved As Integer, ByRef lpcSubKeys As Integer, ByRef lpcbMaxSubKeyLen As Integer, ByRef lpcbMaxClassLen As Integer, ByRef lpcValues As Integer, ByRef lpcbMaxValueNameLen As Integer, ByRef lpcbMaxValueLen As Integer, ByVal lpcbSecurityDescriptor As Integer, ByVal lpftLastWriteTime As Integer) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Advapi32.dll", EntryPoint:="RegQueryInfoKey")> _
Public Shared Function RegQueryInfoKeyWindows(ByVal hkey As IntPtr, ByVal lpClass As Byte(), ByVal lpcbClass As Integer, ByVal lpReserved As Integer, ByRef lpcSubKeys As Integer, ByRef lpcbMaxSubKeyLen As Integer, ByRef lpcbMaxClassLen As Integer, ByRef lpcValues As Integer, ByRef lpcbMaxValueNameLen As Integer, ByRef lpcbMaxValueLen As Integer, ByVal lpcbSecurityDescriptor As Integer, ByVal lpftLastWriteTime As Integer) As Integer
    End Function


    Public Shared Function GetRegValueNames(ByVal hKey As IntPtr) As String()
        Dim FunctionValue As Integer
        Dim TotalSubValues As Integer = GetKeyInfo(hKey, "NumberValues")
        Dim i As Integer
        Dim TotalSubNames As New ArrayList(TotalSubValues)

        If APICalls.GetPlatformName.IndexOf("WindowsPC") = -1 Then
            For i = 0 To TotalSubValues - 1
                Dim buffer(256) As Char
                Dim strRetrieved As String
                Dim bufflen As Integer = buffer.Length
                FunctionValue = RegEnumValue(hKey, i, buffer, bufflen, 0, Nothing, Nothing, Nothing)
                If FunctionValue = 0 Then
                    strRetrieved = New String(buffer, 0, bufflen)
                    TotalSubNames.Add(strRetrieved)
                Else
                    Exit For
                End If
            Next
            If FunctionValue = 0 Then
                TotalSubNames.Sort()
                Dim ArrToReturn(TotalSubValues) As String
                TotalSubNames.CopyTo(ArrToReturn)
                Return ArrToReturn
            Else
                Dim ErrorArr(1) As String
                ErrorArr.SetValue("Error " & FunctionValue, 0)
                Return ErrorArr
            End If
        Else
            For i = 0 To TotalSubValues - 1
                Dim buffer(256) As Byte
                Dim strRetrieved As String
                Dim bufflen As Integer = buffer.Length
                FunctionValue = RegEnumValueWindows(hKey, i, buffer, bufflen, 0, Nothing, Nothing, Nothing)
                If FunctionValue = 0 Then
                    strRetrieved = Encoding.ASCII.GetString(buffer, 0, buffer.Length)
                    TotalSubNames.Add(strRetrieved)
                Else
                    Exit For
                End If
            Next
            If FunctionValue = 0 Then
                TotalSubNames.Sort()
                Dim ArrToReturn(TotalSubValues) As String
                TotalSubNames.CopyTo(ArrToReturn)
                Return ArrToReturn
            Else
                Dim ErrorArr(1) As String
                ErrorArr.SetValue("Error " & FunctionValue, 0)
                Return ErrorArr
            End If
        End If
    End Function

    Public Shared Function GetRegSubKeyNames(ByVal hKey As IntPtr) As String()
        Dim FunctionValue As Integer
        Dim TotalSubKeys As Integer = GetKeyInfo(hKey, "NumberSubKeys")
        Dim i As Integer
        Dim TotalSubNames As New ArrayList(TotalSubKeys)

        If APICalls.GetPlatformName.IndexOf("WindowsPC") = -1 Then
            For i = 0 To TotalSubKeys - 1
                Dim buffer(256) As Char
                Dim strRetrieved As String
                Dim bufflen As Integer = buffer.Length
                FunctionValue = RegEnumKeyEx(hKey, i, buffer, bufflen, 0, Nothing, Nothing, Nothing)
                If FunctionValue = 0 Then
                    strRetrieved = New String(buffer, 0, bufflen)
                    TotalSubNames.Add(strRetrieved)
                Else
                    Exit For
                End If
            Next
            If FunctionValue = 0 Then
                TotalSubNames.Sort()
                Dim ArrToReturn(TotalSubKeys) As String
                TotalSubNames.CopyTo(ArrToReturn)
                Return ArrToReturn
            Else
                Dim ErrorArr(1) As String
                ErrorArr.SetValue("Error " & FunctionValue, 0)
                Return ErrorArr
            End If
        Else
            For i = 0 To TotalSubKeys - 1
                Dim buffer(256) As Byte
                Dim strRetrieved As String
                Dim bufflen As Integer = buffer.Length
                FunctionValue = RegEnumKeyExWindows(hKey, i, buffer, bufflen, 0, Nothing, Nothing, Nothing)
                If FunctionValue = 0 Then
                    strRetrieved = Encoding.ASCII.GetString(buffer, 0, buffer.Length)
                    TotalSubNames.Add(strRetrieved)
                Else
                    Exit For
                End If
            Next
            If FunctionValue = 0 Then
                TotalSubNames.Sort()
                Dim ArrToReturn(TotalSubKeys) As String
                TotalSubNames.CopyTo(ArrToReturn)
                Return ArrToReturn
            Else
                Dim ErrorArr(1) As String
                ErrorArr.SetValue("Error " & FunctionValue, 0)
                Return ErrorArr
            End If
        End If
    End Function

    Public Shared Function SetRegValue(ByVal hKey As IntPtr, ByVal regValueName As String, ByVal regValue As String) As Boolean
        Dim FunctionValue As Integer
        Dim buffer() As Byte

        If APICalls.GetPlatformName.IndexOf("WindowsPC") = -1 Then
            buffer = Encoding.Unicode.GetBytes(regValue)
            FunctionValue = RegSetValueEx(hKey, regValueName, 0, REG_SZ, buffer, buffer.Length)
            If FunctionValue = 0 Then
                Return True
            Else
                Return False
            End If
        Else
            buffer = Encoding.ASCII.GetBytes(regValue)
            FunctionValue = RegSetValueExWindows(hKey, regValueName, 0, REG_SZ, buffer, buffer.Length)
            If FunctionValue = 0 Then
                Return True
            Else
                Return False
            End If
        End If
    End Function

    Public Shared Function DeleteRegValue(ByVal hKey As IntPtr, ByVal regName As String) As Boolean
        Dim FunctionValue As Integer
        If APICalls.GetPlatformName.IndexOf("WindowsPC") = -1 Then
            FunctionValue = RegDeleteValue(hKey, regName)
            If FunctionValue = 0 Then
                Return True
            Else
                Return False
            End If
        Else
            FunctionValue = RegDeleteValueWindows(hKey, regName)
            If FunctionValue = 0 Then
                Return True
            Else
                Return False
            End If
        End If
    End Function

    Public Shared Function DeleteRegKey(ByVal hKey As IntPtr, ByVal regName As String) As Boolean
        Dim FunctionValue As Integer
        If APICalls.GetPlatformName.IndexOf("WindowsPC") = -1 Then
            FunctionValue = RegDeleteKey(hKey, regName)
            If FunctionValue = 0 Then
                Return True
            Else
                Return False
            End If
        Else
            FunctionValue = RegDeleteKeyWindows(hKey, regName)
            If FunctionValue = 0 Then
                Return True
            Else
                Return False
            End If
        End If
    End Function

    Public Shared Function CreateRegKey(ByVal hKey As IntPtr, ByVal regName As String) As IntPtr
        Dim ReturnedKey As IntPtr
        Dim ReturnedDisposition As Integer
        Dim FunctionValue As Integer
        If APICalls.GetPlatformName.IndexOf("WindowsPC") = -1 Then
            FunctionValue = RegCreateKeyEx(hKey, regName, 0, Nothing, 0, 0, Nothing, ReturnedKey, ReturnedDisposition)
            If FunctionValue = 0 Then
                Return ReturnedKey
            Else
                Return New IntPtr(0)
            End If
        Else
            FunctionValue = RegCreateKeyExWindows(hKey, regName, 0, Nothing, 0, 0, Nothing, ReturnedKey, ReturnedDisposition)
            If FunctionValue = 0 Then
                Return ReturnedKey
            Else
                Return New IntPtr(0)
            End If
        End If
    End Function

    Public Shared Function GetRegistryValue(ByVal hKey As IntPtr, ByVal ValueName As String) As String
        Dim BufferLength As Integer = 0
        If APICalls.GetPlatformName.IndexOf("WindowsPC") = -1 Then
            RegQueryValueEx(hKey, ValueName, Nothing, Nothing, Nothing, BufferLength)
            Dim vValue(BufferLength - 1) As Byte
            RegQueryValueEx(hKey, ValueName, Nothing, Nothing, vValue, BufferLength)
            Return Encoding.Unicode.GetString(vValue, 0, vValue.Length)
        Else
            RegQueryValueExWindows(hKey, ValueName, Nothing, Nothing, Nothing, BufferLength)
            Dim vValue(BufferLength - 1) As Byte
            RegQueryValueExWindows(hKey, ValueName, Nothing, Nothing, vValue, BufferLength)
            Return Encoding.ASCII.GetString(vValue, 0, vValue.Length)
        End If
    End Function

    Public Shared Function GetKeyInfo(ByVal hKey As IntPtr, ByVal InfoFunction As String) As Integer
        'InfoFunction:
        'NumberSubKeys - Returns an Integer indicating the number of subkeys
        'MaxKeyLength - Returns an Integer indicating the length of the longest subkey
        'NumberValues - Returns an Integer indicating the number of values contained in the key
        'LongestValueName - Returns an Integer indicating the length of the longest value name
        'LongestValue - Returns an Integer indicating the length of the longest value

        Dim intSubKeys As Integer
        Dim intMaxKeyLength As Integer
        Dim intValues As Integer
        Dim intLongestValueName As Integer
        Dim intLongestValue As Integer
        If APICalls.GetPlatformName.IndexOf("WindowsPC") = -1 Then
            RegQueryInfoKey(hKey, Nothing, Nothing, Nothing, intSubKeys, intMaxKeyLength, Nothing, intValues, intLongestValueName, intLongestValue, Nothing, Nothing)
        Else
            RegQueryInfoKeyWindows(hKey, Nothing, Nothing, Nothing, intSubKeys, intMaxKeyLength, Nothing, intValues, intLongestValueName, intLongestValue, Nothing, Nothing)
        End If

        Select Case InfoFunction
            Case "NumberSubKeys"
                Return intSubKeys
            Case "MaxKeyLength"
                Return intMaxKeyLength
            Case "NumberValues"
                Return intValues
            Case "LongestValueName"
                Return intLongestValueName
            Case "LongestValue"
                Return intLongestValue
            Case Else
                Return 0
        End Select
    End Function

    Public Shared Function OpenKey(ByVal ValuePath As String) As IntPtr
        Dim i
        Dim Keys() As String = StringToKeys(ValuePath)
        Dim LastOpenedKey As IntPtr
        Dim LastKeys(Keys.Length - 1) As IntPtr
        Select Case Keys(0)
            Case "HKEY_CLASSES_ROOT"
                LastOpenedKey = New IntPtr(&H80000000)
            Case "HKEY_CURRENT_USER"
                LastOpenedKey = New IntPtr(&H80000001)
            Case "HKEY_LOCAL_MACHINE"
                LastOpenedKey = New IntPtr(&H80000002)
            Case "HKEY_USERS"
                LastOpenedKey = New IntPtr(&H80000003)
            Case "HKEY_CURRENT_CONFIG"
                LastOpenedKey = New IntPtr(&H80000005)
            Case Else
                LastOpenedKey = New IntPtr(&H80000002) 'Default: HKEY_LOCAL_MACHINE
        End Select
        'MessageBox.Show("Key: " & Keys(i) & " - " & LastOpenedKey.ToInt32)
        For i = 1 To Keys.Length - 1 'Made 2 to 1 in length.
            If APICalls.GetPlatformName.IndexOf("WindowsPC") = -1 Then
                RegOpenKeyEx(LastOpenedKey, Keys(i), 0, 0, LastOpenedKey)
            Else
                'RegOpenKeyExWindows(LastOpenedKey, Keys(i), 0, 0, LastOpenedKey)
                RegOpenKeyWindows(LastOpenedKey, Keys(i), LastOpenedKey)
            End If
            If Not i = Keys.Length - 1 Then
                LastKeys.SetValue(LastOpenedKey, CInt(i - 1))
            End If
        Next
        For i = 0 To LastKeys.Length - 1
            CloseKey(LastKeys(i))
        Next
        Return LastOpenedKey
    End Function

    Public Shared Sub CloseKey(ByVal hkey As IntPtr)
        If APICalls.GetPlatformName.IndexOf("WindowsPC") = -1 Then
            RegCloseKey(hkey)
        Else
            RegCloseKeyWindows(hkey)
        End If
    End Sub

    Public Shared Function StringToKeys(ByVal ValuePath As String) As String()
        ValuePath = ValuePath.Replace("/", "\")
        Dim StrBackup As String = ValuePath
        Dim i As Integer = 0

        Do
            If Not ValuePath.IndexOf("\") = -1 And Not ValuePath = "" Then
                i += 1
                ValuePath = Replace(ValuePath, "\", "", 1, 1)
            Else
                Exit Do
            End If
        Loop
        Dim Keys(i) As String
        ValuePath = StrBackup
        i = 0
        Do
            If Not ValuePath.IndexOf("\") = -1 And Not ValuePath = "" Then 'Loop for adding each key to the string array
                Keys.SetValue(ValuePath.Substring(0, ValuePath.IndexOf("\")), i)
                ValuePath = ValuePath.Replace(ValuePath.Substring(0, ValuePath.IndexOf("\") + 1), "")
                i += 1
            Else
                If Not ValuePath = "" Then
                    Keys.SetValue(ValuePath, Keys.Length - 1)
                End If
                Exit Do
            End If
        Loop
        ValuePath = StrBackup
        i = 0
        Return Keys
    End Function

End Class



