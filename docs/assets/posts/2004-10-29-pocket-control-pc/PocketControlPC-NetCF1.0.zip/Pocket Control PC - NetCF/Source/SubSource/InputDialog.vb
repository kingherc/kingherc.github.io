'Pocket Control PC - NetCf
'Copyright (C) 2004 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Net.Sockets
Imports System.Net
Imports System.Threading
Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Runtime.InteropServices
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.Windows.Forms

Public Class InputDialog

    Inherits System.Windows.Forms.Form

    Friend WithEvents mnMenus As New System.Windows.Forms.MainMenu
    Friend WithEvents mnDone As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMenu As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCancel As New System.Windows.Forms.MenuItem
    Friend WithEvents Label1 As New System.Windows.Forms.Label
    Friend WithEvents txtField As New System.Windows.Forms.TextBox
    Friend WithEvents Label2 As New System.Windows.Forms.Label
    Friend WithEvents lblDescription As New System.Windows.Forms.Label
    Friend WithEvents mnHelp As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnInsertSpecial As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCharacter1 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCharacter2 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCharacter3 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCharacter4 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCharacter5 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCharacter6 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCharacter7 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnCharacter8 As New System.Windows.Forms.MenuItem

    Public RequiredType As TypeCode = TypeCode.String 'Still working on it... Avoid using this.
    Public RequireType As Boolean = True
    Public MultiLine As Boolean = False
    Public InsertSpecial As Boolean = False
    Dim WorkingSize As Size

    Public Property AssignedValue() As String
        Get
            Return txtField.Text
        End Get
        Set(ByVal Value As String)
            txtField.Text = Value
        End Set
    End Property
    Public Property Description() As String
        Get
            Return lblDescription.Text
        End Get
        Set(ByVal Value As String)
            lblDescription.Text = Value
        End Set
    End Property

    Public Sub New()
        MyBase.New()
        Init()
    End Sub

    Sub Init()
        If Not LCase(APICalls.GetPlatformName).IndexOf(LCase("WindowsPC")) = -1 Then
            WorkingSize = Main.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        Else
            WorkingSize = New Size(System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width, System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height)
            'WorkingSize = frmMain.SmartphonePanelsSize
            Me.ClientSize = WorkingSize
        End If

        mnMenus.MenuItems.Add(mnDone)
        mnMenus.MenuItems.Add(mnMenu)

        mnDone.Text = "Done"

        mnMenu.MenuItems.Add(mnInsertSpecial)
        mnMenu.MenuItems.Add(mnHelp)
        mnMenu.MenuItems.Add(mnSeperator1)
        mnMenu.MenuItems.Add(mnCancel)
        mnMenu.Text = "Menu"

        mnCancel.Text = "Cancel"

        Label1.Font = New System.Drawing.Font("Nina", 10.0!, System.Drawing.FontStyle.Bold)
        Label1.Size = New System.Drawing.Size(176, 22)
        Label1.Text = "Enter required value:"

        txtField.Location = New System.Drawing.Point(2, 22)
        txtField.Size = New System.Drawing.Size(172, 30)
        txtField.Text = ""

        Label2.Font = New System.Drawing.Font("Nina", 9.0!, System.Drawing.FontStyle.Bold)
        Label2.Location = New System.Drawing.Point(2, 52)
        Label2.Size = New System.Drawing.Size(172, 16)
        Label2.Text = "Description:"

        lblDescription.Font = New System.Drawing.Font("Nina", 9.0!, System.Drawing.FontStyle.Regular)
        lblDescription.Location = New System.Drawing.Point(2, 66)
        lblDescription.Size = New System.Drawing.Size(174, 112)
        lblDescription.Text = "None."

        mnHelp.Enabled = False
        mnHelp.Text = "Help"

        mnSeperator1.Text = "-"

        mnInsertSpecial.Enabled = False
        mnInsertSpecial.MenuItems.Add(mnCharacter1)
        mnInsertSpecial.MenuItems.Add(mnCharacter2)
        mnInsertSpecial.MenuItems.Add(mnCharacter3)
        mnInsertSpecial.MenuItems.Add(mnCharacter4)
        mnInsertSpecial.MenuItems.Add(mnCharacter5)
        mnInsertSpecial.MenuItems.Add(mnCharacter6)
        mnInsertSpecial.MenuItems.Add(mnCharacter7)
        mnInsertSpecial.MenuItems.Add(mnCharacter8)
        mnInsertSpecial.Text = "Insert Special"

        mnCharacter1.Text = "{}"

        mnCharacter2.Text = "+()"

        mnCharacter3.Text = "^()"

        mnCharacter4.Text = "%()"

        mnCharacter5.Text = "{ENTER}"

        mnCharacter6.Text = "{ESC}"

        mnCharacter7.Text = "{F10}"

        mnCharacter8.Text = "{SUBTRACT}"

        'ClientSize = New System.Drawing.Size(176, 819)
        Controls.Add(txtField)
        Controls.Add(lblDescription)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Menu = mnMenus
        Text = "Input Dialog"

    End Sub

    Private Sub mnDone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDone.Click
        If (txtField.Text).GetTypeCode = RequiredType Then
            Me.DialogResult = DialogResult.OK
        Else
            System.Windows.Forms.MessageBox.Show("The value you entered is not of the required type. Please enter another value." & vbCrLf & "Type Required: " & RequiredType, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
        End If
    End Sub

    Private Sub mnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCancel.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

    Private Sub mnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnHelp.Click
        System.Windows.Forms.MessageBox.Show(Description, "Description/Help", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1)
    End Sub

    Private Sub mnCharacter1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCharacter1.Click
        txtField.Text &= "{}"
    End Sub

    Private Sub mnCharacter2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCharacter2.Click
        txtField.Text &= "+()"
    End Sub

    Private Sub mnCharacter3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCharacter3.Click
        txtField.Text &= "^()"
    End Sub

    Private Sub mnCharacter4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCharacter4.Click
        txtField.Text &= "%()"
    End Sub

    Private Sub mnCharacter5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCharacter5.Click
        txtField.Text &= "{ENTER}"
    End Sub

    Private Sub mnCharacter6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCharacter6.Click
        txtField.Text &= "{ESC}"
    End Sub

    Private Sub mnCharacter7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCharacter7.Click
        txtField.Text &= "{F10}"
    End Sub

    Private Sub mnCharacter8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnCharacter8.Click
        txtField.Text &= "{SUBTRACT}"
    End Sub

    Private Sub InputDialog_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If MultiLine Then
            txtField.Multiline = True
            mnHelp.Enabled = True
            txtField.Location = New Point(0, -1)
            txtField.Size = New Size(Me.ClientSize.Width, Me.ClientSize.Height + 2)
            txtField.ScrollBars = ScrollBars.Both
        End If
        mnInsertSpecial.Enabled = InsertSpecial
    End Sub

    Private Sub frmExplorer_Resize(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        If Not Width > Main.SmartphonePanelsSize.Width Then
            Width = Main.SmartphonePanelsSize.Width
        Else 'Widths changes
            If MultiLine Then
                txtField.Size = New Size(Me.ClientSize.Width, txtField.Height)
            Else
                txtField.Width = Me.ClientSize.Width - 10
                lblDescription.Width = Me.ClientSize.Width
            End If
        End If
        If Not Height > Main.SmartphonePanelsSize.Height Then
            Height = Main.SmartphonePanelsSize.Height
        Else 'Heights changes
            If MultiLine Then
                txtField.Size = New Size(txtField.Width, Me.ClientSize.Height + 2)
            Else
                lblDescription.Height = Me.ClientSize.Height - lblDescription.Top
            End If
        End If
    End Sub

End Class

