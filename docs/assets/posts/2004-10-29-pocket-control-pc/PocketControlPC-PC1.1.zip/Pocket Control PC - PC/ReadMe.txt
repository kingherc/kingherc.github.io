Pocket Control PC - PC v1.1
by Kingherc
===========================

The folder Pocket Control PC - PC contains the executable form of the application.

The folder Source contains the Visual Basic .NET source of the application.

The ReadMe of the program can be found at Pocket Control PC - PC\ReadMe\Index.htm and can be viewed with any browser offline.

31/1/07: The website's address changed from http://www34.brinkster.com/kingherc/ to http://kherc.brinkster.net/.