'Pocket Control PC - PC
'Copyright (C) 2004 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Text
Imports System.IO
Imports System.Collections
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.ValueType
Imports System.Windows.Forms

Public Class APICalls


    Public Shared PlatformName As String = ""
    Public Shared DoubleClickTm As Integer = 0

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function GetDoubleClickTime() As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("User32.dll", EntryPoint:="GetDoubleClickTime")> _
Public Shared Function GetWindowsDoubleClickTime() As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
    Public Shared Function SystemParametersInfo(ByVal uiAction As Integer, ByVal uiParam As Integer, ByVal pvParam As Byte(), ByVal fWinIni As Integer) As Integer
    End Function

    <System.Runtime.InteropServices.DllImport("Coredll.dll")> _
Public Shared Function GetLastError() As IntPtr
    End Function

    <System.Runtime.InteropServices.DllImport("Kernel32.dll", EntryPoint:="GetLastError")> _
Public Shared Function GetLastErrorWindows() As IntPtr
    End Function

    Public Shared Function GetPlatformName() As String
        Try
            If PlatformName = "" Then
                If Environment.OSVersion.Platform = PlatformID.WinCE Then
                    Dim buffer(29) As Byte
                    Dim rc As String = ""
                    SystemParametersInfo(257, buffer.Length, buffer, 0)
                    rc = Encoding.Unicode.GetString(buffer, 0, buffer.Length)
                    PlatformName = "WindowsCE" & rc
                    Return PlatformName
                Else
                    Select Case Environment.OSVersion.Platform
                        Case PlatformID.Win32NT
                            PlatformName = "WindowsPCNT"
                            Return PlatformName
                        Case PlatformID.Win32S
                            PlatformName = "WindowsPCS16For32Bit"
                            Return PlatformName
                        Case Else
                            PlatformName = "WindowsPC"
                            Return PlatformName
                    End Select
                End If
            Else
                Return PlatformName
            End If
        Catch ex As Exception
            Return "SmartPhone"
        End Try
    End Function

    Public Shared Function DoubleClickTime() As Integer
        If DoubleClickTm = 0 Then
            If Not LCase(GetPlatformName).IndexOf(LCase("WindowsPC")) = -1 Then
                DoubleClickTm = GetWindowsDoubleClickTime()
                Return DoubleClickTm
            Else
                DoubleClickTm = GetDoubleClickTime()
                Return DoubleClickTm
            End If
        Else
            Return DoubleClickTm
        End If
    End Function



    Public Const CSIDL_PERSONAL As Integer = &H5
    Public Const CSIDL_WINDOWS As Integer = &H24
    Public Const MAX_PATH As Integer = 260

    <System.Runtime.InteropServices.DllImport("coredll.dll")> _
    Public Shared Function SHGetSpecialFolderPath(ByVal hwndOwner As IntPtr, ByVal lpszPath As Byte(), ByVal nFolder As Integer, ByVal fCreate As Integer) As Boolean
    End Function

    <System.Runtime.InteropServices.DllImport("Winuser.dll")> _
Public Shared Function GetActiveWindow() As IntPtr
    End Function

    <System.Runtime.InteropServices.DllImport("shell32.dll", EntryPoint:="SHGetSpecialFolderPath")> _
Public Shared Function SHGetSpecialFolderPathWindows(ByVal hwndOwner As IntPtr, ByVal lpszPath As Byte(), ByVal nFolder As Integer, ByVal fCreate As Integer) As Boolean
    End Function

    <System.Runtime.InteropServices.DllImport("User32.dll", EntryPoint:="GetActiveWindow")> _
Public Shared Function GetActiveWindowWindows() As IntPtr
    End Function

    Public Shared Function GetSpecialFolder(Optional ByVal CSIDL As Integer = CSIDL_PERSONAL) As String
        Try
            Dim buffer(MAX_PATH) As Byte
            Dim rc As String = ""
            If Environment.OSVersion.Platform = PlatformID.WinCE Then
                'SHGetSpecialFolderPath(GetActiveWindow, buffer, CSIDL_PERSONAL, 0)
                SHGetSpecialFolderPath(Nothing, buffer, CSIDL, 0)
            Else
                'SHGetSpecialFolderPathWindows(GetActiveWindowWindows, buffer, CSIDL_PERSONAL, 0)
                SHGetSpecialFolderPathWindows(Nothing, buffer, CSIDL, 0)
            End If
            If Not LCase(GetPlatformName).IndexOf(LCase("WindowsPC")) = -1 Then
                rc = Encoding.ASCII.GetString(buffer, 0, buffer.Length)
            Else
                rc = Encoding.Unicode.GetString(buffer, 0, buffer.Length)
            End If
            'Remove illegal characters
            Dim ii
            For ii = 0 To Path.InvalidPathChars.Length - 1
                rc = rc.Replace(Path.InvalidPathChars(ii), "")
            Next
            ii = Nothing
            Return rc
        Catch ex As Exception
            Return "Error"
        End Try
    End Function



    <System.Runtime.InteropServices.DllImport("user32.dll")> _
    Public Shared Sub mouse_event(ByVal dwFlags As UInt32, ByVal dx As UInt32, ByVal dy As UInt32, ByVal dwData As Int32, ByVal dwExtraInfo As IntPtr)
    End Sub

    Public Shared Sub DoMouse(ByVal MouseEvent As Integer, ByVal dX As Integer, ByVal dY As Integer, ByVal dWheel As Integer)
        mouse_event(Convert.ToUInt32(MouseEvent), Convert.ToUInt32(dX), Convert.ToUInt32(dY), Convert.ToInt32(dWheel), New System.IntPtr)
    End Sub

    <System.Runtime.InteropServices.DllImport("user32.dll")> _
    Public Shared Sub keybd_event(ByVal bVk As Byte, ByVal bScan As Byte, ByVal dwFlags As UInt32, ByVal dwData As Integer)
    End Sub

    Public Shared Sub DoKey(ByVal Key As Integer, ByVal Flags As Integer)
        keybd_event(CByte(Key), 0, Convert.ToUInt32(Flags), 0)
    End Sub



    Shared Function ReadTxt(ByVal TxtPath As String, Optional ByVal DoNotUseMapPath As Boolean = False) As String
        Dim Wt2Return As String
        Dim str2Validate As String
        If Not DoNotUseMapPath Then
            str2Validate = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase) & "\" & TxtPath
        Else
            str2Validate = TxtPath
        End If
        If File.Exists(str2Validate) Then
            Dim objStreamReader As StreamReader
            Dim strInput As String
            objStreamReader = File.OpenText(str2Validate)
            Wt2Return = objStreamReader.ReadToEnd()
            objStreamReader.Close()
            objStreamReader = Nothing
            strInput = Nothing
        Else
            Wt2Return = str2Validate
        End If
        Return Wt2Return
    End Function

    Shared Function Write2Txt(ByVal TxtPath As String, ByVal Wt2Write As String, Optional ByVal ReplaceIt As Boolean = True, Optional ByVal DoNotUseMapPath As Boolean = False) As Boolean
        If Not DoNotUseMapPath Then
            TxtPath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase) & "\" & TxtPath
        End If
        If File.Exists(TxtPath) Then
            Dim objStreamWriter As StreamWriter
            If Not ReplaceIt Then
                objStreamWriter = File.AppendText(TxtPath)
            Else
                objStreamWriter = File.CreateText(TxtPath)
            End If
            objStreamWriter.WriteLine(Wt2Write)
            objStreamWriter.Close()
            Return True
        Else
            If ReplaceIt Then
                Dim objStreamWriter As StreamWriter
                objStreamWriter = File.CreateText(TxtPath)
                objStreamWriter.WriteLine(Wt2Write)
                objStreamWriter.Close()
            End If
            Return False
        End If
    End Function


End Class

