'Pocket Control PC - PC
'Copyright (C) 2004 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System.Net.Sockets
Imports System.Net
Imports System.Threading
Imports System.Text
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Runtime.InteropServices
Imports Microsoft.Win32
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.Windows.Forms
Imports System.Collections

<Assembly: AssemblyTitle("Pocket Control PC - PC")> 
<Assembly: AssemblyDescription("Used along with Pocket Control PC client programs to control a PC from a remote device. E.g. Control PC's mouse and keyboard. More info possibly at http://www34.brinkster.com/kingherc/.")> 
<Assembly: AssemblyCompany("None")> 
<Assembly: AssemblyProduct("Pocket Control PC - PC")> 
<Assembly: AssemblyCopyright("2004 Iraklis Psaroudakis")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: AssemblyVersion("1.1.0")> 

Public Class Main
    Inherits System.Windows.Forms.Form


    Public Sub New()
        MyBase.New()
        Init()
    End Sub

    'Variables & Properties
    Dim PORT_NO As Integer = IPEndPoint.MaxPort
    Dim IPtoConnect As IPAddress
    Dim ProgramVersion As New Version(1, 1, 0)
    Dim con As New TcpListener(IPAddress.Any, PORT_NO)
    Dim ccon As TcpClient
    Dim bConnected As Boolean = False
    Dim conTries As Integer = 1 'Used for listening loop. Increased each 2 seconds. If an interval minute surpassed, loop is stopped.
    Dim ns As NetworkStream
    Dim LastCommand As String = ""
    Dim WasValidated As Boolean = False
    Dim LogFirstMessage As String = "Please see Help > Licence. The log will be shown below this line:"
    Dim RemoteScreenSize As Size = New Size(176, 180)
    Dim AppName As String = "Pocket Control PC - PC"
    Dim AlreadyLoaded As Boolean = False

    Dim IsMacroRec As Boolean = False
    Dim IsTimeMacroExe As Boolean = False
    Dim MacroRecText As String
    Dim TimeMacroComm As Hashtable
    Dim MacroShorcuts As New ArrayList(7)
    Dim MacroTimerDecimate As Double = 1

    Dim QMAction As String 'QM=QuickMouse mode
    Dim QMActionLast As String
    Dim QMStep As Integer
    Dim QMInterval As Integer

    'Constants for Mouse_event
    Const MOUSEEVENTF_MOVE As Integer = &H1
    Const MOUSEEVENTF_LEFTUP As Integer = &H4
    Const MOUSEEVENTF_LEFTDOWN As Integer = &H2
    Const MOUSEEVENTF_RIGHTDOWN As Integer = &H8
    Const MOUSEEVENTF_RIGHTUP As Integer = &H10
    Const MOUSEEVENTF_MIDDLEDOWN As Integer = &H20
    Const MOUSEEVENTF_MIDDLEUP As Integer = &H40
    Const MOUSEEVENTF_XDOWN As Integer = &H80
    Const MOUSEEVENTF_XUP As Integer = &H100
    Const MOUSEEVENTF_WHEEL As Integer = &H800
    Const MOUSEEVENTF_VIRTUALDESK As Integer = &H4000
    Const MOUSEEVENTF_ABSOLUTE As Integer = &H8000
    Const XBUTTON1 As Integer = &H1
    Const XBUTTON2 As Integer = &H2
    Const WHEEL_DELTA As Integer = 120

    Friend WithEvents txtLog As New System.Windows.Forms.TextBox
    Friend WithEvents tmrListenLoop As New System.Windows.Forms.Timer
    Friend WithEvents tmrListenCommandsLoop As New System.Windows.Forms.Timer
    Friend WithEvents mnFile As New System.Windows.Forms.MenuItem
    Friend WithEvents mnExit As New System.Windows.Forms.MenuItem
    Friend WithEvents mnConnection As New System.Windows.Forms.MenuItem
    Friend WithEvents mnBeginListening As New System.Windows.Forms.MenuItem
    Friend WithEvents mnDisconnect As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMenus As New System.Windows.Forms.MainMenu
    Friend WithEvents mnSendMessage As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSendTest As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSeperator1Con As New System.Windows.Forms.MenuItem
    Friend WithEvents sbrStatus As New System.Windows.Forms.StatusBar
    Friend WithEvents sbrStatusPanelInfo As New System.Windows.Forms.StatusBarPanel
    Friend WithEvents sbrStatusConInfoPanel As New System.Windows.Forms.StatusBarPanel
    Friend WithEvents mnSendCustom As New System.Windows.Forms.MenuItem
    Friend WithEvents mnLog As New System.Windows.Forms.MenuItem
    Friend WithEvents mnLogClear As New System.Windows.Forms.MenuItem
    Friend WithEvents mnLogSave As New System.Windows.Forms.MenuItem
    Friend WithEvents SaveFile As New System.Windows.Forms.SaveFileDialog
    Friend WithEvents OpenFile As New System.Windows.Forms.OpenFileDialog
    Friend WithEvents mnOptions As New System.Windows.Forms.MenuItem
    Friend WithEvents mnOIP As New System.Windows.Forms.MenuItem
    Friend WithEvents mnOEnsureConnection As New System.Windows.Forms.MenuItem
    Friend WithEvents mnConValidate As New System.Windows.Forms.MenuItem
    Friend WithEvents icoIdle As New System.Windows.Forms.NotifyIcon
    Friend WithEvents icoIdleTray As New System.Windows.Forms.NotifyIcon
    Friend WithEvents icoConnected As New System.Windows.Forms.NotifyIcon
    Friend WithEvents icoListening As New System.Windows.Forms.NotifyIcon
    Friend WithEvents icoSending As New System.Windows.Forms.NotifyIcon
    Friend WithEvents icoReceiving As New System.Windows.Forms.NotifyIcon
    Friend WithEvents icoExecuting As New System.Windows.Forms.NotifyIcon
    Friend WithEvents mnOptionsAutoListen As New System.Windows.Forms.MenuItem
    Friend WithEvents mnOptionsSeperator2 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnAutoListenNone As New System.Windows.Forms.MenuItem
    Friend WithEvents mnAutoListen1m As New System.Windows.Forms.MenuItem
    Friend WithEvents mnAutoListen5m As New System.Windows.Forms.MenuItem
    Friend WithEvents mnAutoListen10m As New System.Windows.Forms.MenuItem
    Friend WithEvents mnAutoListen25s As New System.Windows.Forms.MenuItem
    Friend WithEvents tmrAutoListen As New System.Windows.Forms.Timer
    Friend WithEvents mnStopAutoListenOnDisconnect As New System.Windows.Forms.MenuItem
    Friend WithEvents mnAutoListenSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents icoAppIcon As New System.Windows.Forms.NotifyIcon
    Friend WithEvents TrayIcon As New System.Windows.Forms.NotifyIcon
    Friend WithEvents mnFileSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMinimizeTray As New System.Windows.Forms.MenuItem
    Friend WithEvents cmnTrayMenu As New System.Windows.Forms.ContextMenu
    Friend WithEvents mnBeginListeningContext As New System.Windows.Forms.MenuItem
    Friend WithEvents mnExitContext As New System.Windows.Forms.MenuItem
    Friend WithEvents mnHelp As New System.Windows.Forms.MenuItem
    Friend WithEvents mnAbout As New System.Windows.Forms.MenuItem
    Friend WithEvents mnLicence As New System.Windows.Forms.MenuItem
    Friend WithEvents mnAutoListenOnTimeout As New System.Windows.Forms.MenuItem
    Friend WithEvents mnAutoListenOnStart As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMinimizeStart As New System.Windows.Forms.MenuItem
    Friend WithEvents mnOptionsSeperator1 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnSaveOptions As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacros As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroExe As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroSeperator2 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroRec As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroStop As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroTimeExeStop As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroSeperator As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroOptions As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroOExeIn As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroOExeOut As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroOExeTime As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroOInvCom As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroODecim As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcuts As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcut1 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcut2 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcut3 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcut4 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcut5 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcut6 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcut7 As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcutSeperator As New System.Windows.Forms.MenuItem
    Friend WithEvents mnMacroShorcutsManage As New System.Windows.Forms.MenuItem
    Friend WithEvents tmrTimeMacroExe As New System.Windows.Forms.Timer
    Friend WithEvents tmrQuickMouse As New System.Windows.Forms.Timer
    Friend WithEvents tmrEnsureConnection As New System.Windows.Forms.Timer
    Friend WithEvents tmrSendEnsureConnection As New System.Windows.Forms.Timer

    Sub Init()
        Dim Resources As New System.Resources.ResourceManager(GetType(Main))

        txtLog.BackColor = System.Drawing.Color.White
        txtLog.Location = New System.Drawing.Point(10, 10)
        txtLog.MaxLength = 0
        txtLog.Multiline = True
        txtLog.Name = "txtLog"
        txtLog.ReadOnly = True
        txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        txtLog.Size = New System.Drawing.Size(570, 245)
        txtLog.TabIndex = 3
        txtLog.Text = "Please see Help > Licence. The log will be shown below this line:"

        tmrListenLoop.Interval = 2000

        mnMenus.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {mnFile, mnConnection, mnMacros, mnOptions, mnHelp})

        mnFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {mnMinimizeTray, mnFileSeperator1, mnExit})
        mnFile.Text = "&File"

        mnMinimizeTray.Shortcut = System.Windows.Forms.Shortcut.CtrlM
        mnMinimizeTray.Text = "&Minimize to Tray"

        mnFileSeperator1.Text = "-"

        mnExit.Shortcut = System.Windows.Forms.Shortcut.AltF4
        mnExit.Text = "E&xit"

        mnConnection.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {mnBeginListening, mnSendMessage, mnSeperator1Con, mnDisconnect})
        mnConnection.Text = "Con&nection"

        mnBeginListening.Shortcut = System.Windows.Forms.Shortcut.F1
        mnBeginListening.Text = "&Begin Listening"

        mnSendMessage.Enabled = False
        mnSendMessage.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {mnSendTest, mnSendCustom})
        mnSendMessage.Text = "Send Message"

        mnSendTest.Shortcut = System.Windows.Forms.Shortcut.F12
        mnSendTest.Text = "Test"

        mnSendCustom.Text = "Custom..."

        mnSeperator1Con.Text = "-"

        mnDisconnect.Enabled = False
        mnDisconnect.Shortcut = System.Windows.Forms.Shortcut.F2
        mnDisconnect.Text = "Discon&nect"

        mnMacros.Text = "Macros"
        mnMacros.MenuItems.Add(mnMacroExe)
        mnMacros.MenuItems.Add(mnMacroShorcuts)
        mnMacros.MenuItems.Add(mnMacroSeperator2)
        mnMacros.MenuItems.Add(mnMacroRec)
        mnMacros.MenuItems.Add(mnMacroStop)
        mnMacros.MenuItems.Add(mnMacroSeperator)
        mnMacros.MenuItems.Add(mnMacroOptions)

        mnMacroOptions.MenuItems.Add(mnMacroOExeIn)
        mnMacroOptions.MenuItems.Add(mnMacroOExeOut)
        mnMacroOptions.MenuItems.Add(mnMacroOExeTime)
        mnMacroOptions.MenuItems.Add(mnMacroODecim)
        mnMacroOptions.MenuItems.Add(mnMacroOInvCom)

        mnMacroTimeExeStop.Text = "Stop Macro"
        mnMacroExe.Text = "Execute file..."
        mnMacroExe.Shortcut = Shortcut.F3
        mnMacroShorcuts.Text = "Shorcuts"
        mnMacroSeperator2.Text = "-"
        mnMacroRec.Text = "Start Recording"
        mnMacroRec.Shortcut = Shortcut.F4
        mnMacroStop.Text = "Stop Rec - Save..."
        mnMacroStop.Shortcut = Shortcut.F5
        mnMacroSeperator.Text = "-"
        mnMacroStop.Enabled = False

        mnMacroOptions.Text = "Options"
        mnMacroOExeIn.Text = "Execute Incoming commands"
        mnMacroOExeOut.Text = "Execute Outgoing commands"
        mnMacroOExeTime.Text = "Timeless execution"
        mnMacroOExeIn.Checked = True
        mnMacroOExeTime.Checked = False
        mnMacroOInvCom.Text = "Invert Incoming && Outgoing"
        mnMacroODecim.Text = "Decimate Timers by..."

        mnMacroShorcuts.MenuItems.Add(mnMacroShorcut1)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcut2)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcut3)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcut4)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcut5)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcut6)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcut7)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcutSeperator)
        mnMacroShorcuts.MenuItems.Add(mnMacroShorcutsManage)

        mnMacroShorcut1.Text = "1. Undefined"
        mnMacroShorcut1.Shortcut = Shortcut.Ctrl1
        mnMacroShorcut2.Text = "2. Undefined"
        mnMacroShorcut2.Shortcut = Shortcut.Ctrl2
        mnMacroShorcut3.Text = "3. Undefined"
        mnMacroShorcut3.Shortcut = Shortcut.Ctrl3
        mnMacroShorcut4.Text = "4. Undefined"
        mnMacroShorcut4.Shortcut = Shortcut.Ctrl4
        mnMacroShorcut5.Text = "5. Undefined"
        mnMacroShorcut5.Shortcut = Shortcut.Ctrl5
        mnMacroShorcut6.Text = "6. Undefined"
        mnMacroShorcut6.Shortcut = Shortcut.Ctrl6
        mnMacroShorcut7.Text = "7. Undefined"
        mnMacroShorcut7.Shortcut = Shortcut.Ctrl7
        mnMacroShorcutSeperator.Text = "-"
        mnMacroShorcutsManage.Text = "Manage Shorcuts..."

        tmrTimeMacroExe.Enabled = False

        mnOptions.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {mnLog, mnConValidate, mnOEnsureConnection, mnOIP, mnOptionsSeperator2, mnOptionsAutoListen, mnAutoListenOnStart, mnMinimizeStart, mnOptionsSeperator1, mnSaveOptions})
        mnOptions.Text = "&Options"

        mnOEnsureConnection.Text = "Ensure active connection"
        mnOEnsureConnection.Checked = True
        mnOEnsureConnection.Enabled = False

        mnOIP.Text = "Configure IP..."

        mnOptionsSeperator2.Text = "-"

        mnLog.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {mnLogClear, mnLogSave})
        mnLog.Text = "&Log"

        mnLogClear.Shortcut = System.Windows.Forms.Shortcut.Del
        mnLogClear.Text = "C&lear"

        mnLogSave.Shortcut = System.Windows.Forms.Shortcut.CtrlS
        mnLogSave.Text = "&Save..."

        mnOptionsAutoListen.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {mnAutoListenNone, mnAutoListenOnTimeout, mnAutoListen25s, mnAutoListen1m, mnAutoListen5m, mnAutoListen10m, mnAutoListenSeperator1, mnStopAutoListenOnDisconnect})
        mnOptionsAutoListen.Text = "Auto Listen"

        mnAutoListenNone.Checked = True
        mnAutoListenNone.RadioCheck = True
        mnAutoListenNone.Text = "None"

        mnAutoListenOnTimeout.RadioCheck = True
        mnAutoListenOnTimeout.Text = "On Listen Timeout"

        mnAutoListen25s.RadioCheck = True
        mnAutoListen25s.Text = "25 secon&ds"

        mnAutoListen1m.RadioCheck = True
        mnAutoListen1m.Text = "1 minute"

        mnAutoListen5m.RadioCheck = True
        mnAutoListen5m.Text = "5 minutes"

        mnAutoListen10m.RadioCheck = True
        mnAutoListen10m.Text = "10 minutes"

        mnAutoListenSeperator1.Text = "-"

        mnStopAutoListenOnDisconnect.Text = "Stop when Disconnect"

        mnAutoListenOnStart.Text = "Auto Listen on Start"

        mnMinimizeStart.Text = "Auto Minimize on Start"

        mnConValidate.Checked = True
        mnConValidate.Text = "&Validate Connection"

        mnOptionsSeperator1.Text = "-"

        mnSaveOptions.Text = "Save Options"

        mnHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {mnAbout, mnLicence})
        mnHelp.Text = "&Help"

        mnAbout.Shortcut = System.Windows.Forms.Shortcut.CtrlA
        mnAbout.Text = "A&bout"

        mnLicence.Shortcut = System.Windows.Forms.Shortcut.CtrlL
        mnLicence.Text = "Li&cence"

        sbrStatus.Location = New System.Drawing.Point(0, 264)
        sbrStatus.Name = "sbrStatus"
        sbrStatus.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {sbrStatusPanelInfo, sbrStatusConInfoPanel})
        sbrStatus.ShowPanels = True
        sbrStatus.Size = New System.Drawing.Size(587, 25)
        sbrStatus.TabIndex = 4
        sbrStatus.Text = "StatusBar1"

        sbrStatusPanelInfo.MinWidth = 200
        sbrStatusPanelInfo.Text = "Disconnected"
        sbrStatusPanelInfo.Width = 400

        sbrStatusConInfoPanel.Text = "Idle"
        sbrStatusConInfoPanel.Width = 36

        SaveFile.Filter = "Text files (*.txt)|*.txt"
        SaveFile.OverwritePrompt = False
        SaveFile.Title = "Save to..."

        icoIdle.Text = "Idle"
        icoIdle.Icon = Resources.GetObject("Idle Icon")

        icoIdleTray.Text = "Idle"
        icoIdleTray.Icon = Resources.GetObject("Idle Icon Tray")

        icoConnected.Text = "Connected"
        icoConnected.Icon = Resources.GetObject("Connected Icon")

        icoListening.Text = "Listening..."
        icoListening.Icon = Resources.GetObject("Listening Icon")

        icoSending.Text = "Sending..."
        icoSending.Icon = Resources.GetObject("Sending Icon")

        icoReceiving.Text = "Receiving..."
        icoReceiving.Icon = Resources.GetObject("Receiving Icon")

        icoExecuting.Text = "Executing..."
        icoExecuting.Icon = Resources.GetObject("Executing Icon")

        tmrAutoListen.Interval = 25000

        icoAppIcon.Text = "icoAppIcon"
        icoAppIcon.Icon = Resources.GetObject("Application Icon")
        Icon = icoAppIcon.Icon

        TrayIcon.ContextMenu = cmnTrayMenu
        TrayIcon.Text = "Pocket Control PC - PC"
        TrayIcon.Icon = icoAppIcon.Icon

        cmnTrayMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {mnBeginListeningContext, mnExitContext})

        mnBeginListeningContext.Text = "Begin Listening"

        mnExitContext.Text = "Exit"

        tmrQuickMouse.Interval = 300
        tmrQuickMouse.Enabled = False

        tmrListenCommandsLoop.Interval = 50

        tmrEnsureConnection.Interval = 20000
        tmrSendEnsureConnection.Interval = 17000

        AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        ClientSize = New System.Drawing.Size(587, 289)
        Controls.Add(sbrStatus)
        Controls.Add(txtLog)
        Menu = mnMenus
        Text = "Pocket Control PC - PC"
    End Sub



    Private Sub Main_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        If Not Me.Width < 300 Then
            txtLog.Width = Me.ClientSize.Width - 20
            txtLog.Height = (Me.ClientSize.Height - sbrStatus.Height) - 20
            txtLog.Left = 10
            txtLog.Top = 10
            sbrStatusPanelInfo.Width = sbrStatus.Width * 0.75
            sbrStatusConInfoPanel.Width = sbrStatus.Width * 0.25
        Else
            Me.Width = 300
        End If
    End Sub

    Private Sub Main_Closed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        TrayIcon_DoubleClick(Me, EventArgs.Empty)
        If mnDisconnect.Enabled Then
            mnDisconnect_Click(Me, EventArgs.Empty)
        End If
        mnSaveOptions_Click(Me, EventArgs.Empty)
    End Sub

    Private Sub Main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtLog.Text = LogFirstMessage
        Main_Resize(Me, EventArgs.Empty)
        If bConnected Then
            ShowConInfo("Connected")
        Else
            ShowConInfo("Idle")
        End If
        LoadOptions()
        If mnAutoListenOnStart.Checked Then
            If mnMinimizeStart.Checked Then
                mnBeginListeningContext_Click(Me, EventArgs.Empty)
            Else
                mnBeginListening_Click(Me, EventArgs.Empty)
            End If
        End If
    End Sub

    Private Sub Main_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        If Not AlreadyLoaded Then
            If mnMinimizeStart.Checked Then
                mnMinimizeTray_Click(Me, EventArgs.Empty)
            End If
            AlreadyLoaded = True
        End If
    End Sub

    Private Sub Main_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
        ShowInfo("Connection pending")
        If Not mnDisconnect.Enabled Then
            ShowInfo("Disconnected - No active connection")
        Else
            ShowInfo("Connection established - Listening for commands")
        End If
    End Sub




    'File > Minimize to Tray
    Private Sub mnMinimizeTray_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMinimizeTray.Click
        Me.Hide()
        TrayIcon.Visible = True
    End Sub

    'File > Exit
    Private Sub mnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnExit.Click
        Main_Closed(Me, EventArgs.Empty)
        End
    End Sub



    'This button activates the listening loop. The remote client must communicate before the timeout is reached.
    Private Sub mnBeginListening_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnBeginListening.Click
        Try
            con = New TcpListener(IPtoConnect, PORT_NO)
        Catch ex As Exception
            Exit Sub
            Out("An error occurred while trying to listen to " & IPtoConnect.ToString & " through port " & PORT_NO & ".")
        End Try
        Try
            con.Start()
        Catch ex As Exception
            Try
                con.Stop()
                Out("An error occurred while trying to listen to " & IPtoConnect.ToString & " through port " & PORT_NO & ".")
                Exit Sub
            Catch ex2 As Exception
                Exit Sub
            End Try
        End Try
        Out("Started Listening")
        ShowConInfo("Listening...")
        tmrListenLoop.Enabled = True
        mnBeginListening.Enabled = False
        mnBeginListeningContext.Enabled = False
    End Sub

    'Button which is clicked to disconnect from the remote client
    Private Sub mnDisconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnDisconnect.Click
        If bConnected Then
            If LastCommand.IndexOf("CloseConnection") = -1 Then
                Try
                    cOut("CloseConnection")
                Catch ex As Exception
                    Out("A problem occured while sending a CloseConnection message to remote client. Maybe the connection was closed prematurely.")
                End Try
            End If
            tmrEnsureConnection.Enabled = False
            tmrSendEnsureConnection.Enabled = False
            QMActionLast = ""
            tmrQuickMouse.Enabled = False
            ccon.Close()
            Out("Connection closed")
            mnDisconnect.Enabled = False
            mnBeginListening.Enabled = True
            mnBeginListeningContext.Enabled = True
            bConnected = False
            tmrListenCommandsLoop.Enabled = False
            mnSendMessage.Enabled = False
            mnOEnsureConnection.Enabled = False
            WasValidated = False
            ShowConInfo("Idle")
            If mnStopAutoListenOnDisconnect.Checked Then
                mnAutoListenNone_Click(Me, EventArgs.Empty)
            End If
            If mnAutoListenOnTimeout.Checked Then
                mnBeginListening_Click(Me, EventArgs.Empty)
            End If
        End If
    End Sub

    'Connection > Send Message > test
    'Menu item used for sending two test strings to the remote host
    Private Sub mnSendTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSendTest.Click
        cOut("{Is anybody there?}")
        cOut("{For crying out aloud!!!}")
    End Sub

    'Connection > Send message > Custom...
    Private Sub mnSendCustom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSendCustom.Click
        cOut("{" & Microsoft.VisualBasic.InputBox("Specify a phrase to send to the remote client. This will be shown on the client's log.", "Send a Custom Message", "Is anybody there?") & "}")
    End Sub



    Private Sub mnMacroTimeExeStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroTimeExeStop.Click
        MacroStopTimeExe()
    End Sub

    Private Sub mnMacroExe_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroExe.Click
        OpenFile.CheckFileExists = True

        If OpenFile.ShowDialog = DialogResult.OK Then
            'Try
            Out("Started executing macro " & OpenFile.FileName & ".")
            Dim AllText As String = APICalls.ReadTxt(OpenFile.FileName, True)
            If mnMacroOExeTime.Checked Then
                StartExeMacro(AllText)
            Else 'Execute with time
                StartExeTimeMacro(AllText)
            End If
            'Catch ex As Exception
            'Out("Execution of macro " & nn.SelectedPath & " was made with errors.")
            'End Try
        End If
    End Sub

    Private Sub mnMacroRec_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroRec.Click
        IsMacroRec = True
        Dim nowDate As DateTime = DateTime.Now
        Dim DateString As String = nowDate.Day & "/" & nowDate.Month & "/" & nowDate.Year & " " & nowDate.Hour & ":"
        If nowDate.Minute.ToString.Length = 1 Then
            DateString &= "0" & nowDate.Minute.ToString & ":"
        Else
            DateString &= nowDate.Minute.ToString & ":"
        End If
        If nowDate.Second.ToString.Length = 1 Then
            DateString &= "0" & nowDate.Second.ToString
        Else
            DateString &= nowDate.Second.ToString
        End If
        MacroRecText = "Pocket Control PC - PC Macro ##%%## " & DateString & " ##%%## " & ProgramVersion.ToString
        mnMacroStop.Enabled = True
        mnMacroRec.Enabled = False
        Out("Started recording a macro.")
    End Sub

    Private Sub mnMacroStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroStop.Click
        IsMacroRec = False
        If Not MacroRecText = "" Then
            If SaveFile.ShowDialog = DialogResult.OK Then
                APICalls.Write2Txt(SaveFile.FileName, MacroRecText, True, True)
            End If
            Out("Macro saved at " & SaveFile.FileName & ".")
        End If
        mnMacroStop.Enabled = False
        mnMacroRec.Enabled = True
        Out("Stopped recording a macro.")
        UpdateCurrentConInfo()
    End Sub

    Private Sub mnMacroOExeIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroOExeIn.Click
        If mnMacroOExeIn.Checked Then
            mnMacroOExeIn.Checked = False
        Else
            mnMacroOExeIn.Checked = True
        End If
    End Sub
    Private Sub mnMacroOExeOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroOExeOut.Click
        If mnMacroOExeOut.Checked Then
            mnMacroOExeOut.Checked = False
        Else
            mnMacroOExeOut.Checked = True
        End If
    End Sub
    Private Sub mnMacroOExeTime_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroOExeTime.Click
        If mnMacroOExeTime.Checked Then
            mnMacroOExeTime.Checked = False
        Else
            mnMacroOExeTime.Checked = True
        End If
    End Sub
    Private Sub mnMacroODecim_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroODecim.Click
        Dim nDbl As String = InputBox("Enter a number. The time between two commands of a macro will be divided by this number. e.g. " & CStr(CDbl(2.5)), "Decimate macro timers by...", MacroTimerDecimate)
        If IsNumeric(nDbl) Then
            MacroTimerDecimate = Math.Abs(CDbl(nDbl))
        End If
    End Sub
    Private Sub mnMacroOInvCom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroOInvCom.Click
        If mnMacroOInvCom.Checked Then
            mnMacroOInvCom.Checked = False
        Else
            mnMacroOInvCom.Checked = True
        End If
    End Sub


    Private Sub mnMacroShorcutsManage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcutsManage.Click
        Dim IntPl As Integer = InputBox("Enter the number of the shorcut (1-7) you wish to change.")

        If IsNumeric(IntPl) Then
            If IntPl >= 1 And IntPl <= 7 Then

                If MessageBox.Show("Click Yes to replace this shorcut with a new one." & vbCrLf & "Click No to delete this shorcut.", "Error", System.Windows.Forms.MessageBoxButtons.YesNo, System.Windows.Forms.MessageBoxIcon.Asterisk, System.Windows.Forms.MessageBoxDefaultButton.Button1) = DialogResult.Yes Then
                    OpenFile.CheckFileExists = True
                    If OpenFile.ShowDialog = DialogResult.OK Then
                        MacroShorcuts(IntPl - 1) = OpenFile.FileName
                        LoadMacroShorcutNames()
                    End If
                Else
                    MacroShorcuts(IntPl - 1) = "Undefined"
                    LoadMacroShorcutNames()
                End If

            Else
                MessageBox.Show("You need to input a number ranging from 1 to 7.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            End If
        Else
            MessageBox.Show("You need to input a number ranging from 1 to 7.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
        End If
    End Sub

    Private Sub mnMacroShorcut1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcut1.Click
        ExeMacroShorcut(0)
    End Sub

    Private Sub mnMacroShorcut2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcut2.Click
        ExeMacroShorcut(1)
    End Sub

    Private Sub mnMacroShorcut3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcut3.Click
        ExeMacroShorcut(2)
    End Sub

    Private Sub mnMacroShorcut4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcut4.Click
        ExeMacroShorcut(3)
    End Sub

    Private Sub mnMacroShorcut5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcut5.Click
        ExeMacroShorcut(4)
    End Sub

    Private Sub mnMacroShorcut6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcut6.Click
        ExeMacroShorcut(5)
    End Sub

    Private Sub mnMacroShorcut7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMacroShorcut7.Click
        ExeMacroShorcut(6)
    End Sub

    Sub ExeMacroShorcut(ByVal IntNo As Integer)
        Dim strPath As String = MacroShorcuts(IntNo)
        If Not strPath = "Undefined" And Not strPath = "" Then
            If File.Exists(strPath) Then
                Dim AllText As String = APICalls.ReadTxt(strPath, True)
                Out("Started executing shorcut macro " & strPath & ".")
                If mnMacroOExeTime.Checked Then
                    StartExeMacro(AllText)
                Else 'Execute with time
                    StartExeTimeMacro(AllText)
                End If
            Else
                Out("Macro shorcut was not found: " & strPath)
            End If
        End If
    End Sub





    'Log > Delete
    Private Sub mnLogClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnLogClear.Click
        txtLog.Text = LogFirstMessage
    End Sub

    'Log > Save...
    Private Sub mnLogSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnLogSave.Click
        SaveFile.Filter = "Text files (*.txt)|*.txt"
        If SaveFile.ShowDialog = DialogResult.OK Then
            Dim sw As StreamWriter = File.CreateText(SaveFile.FileName)
            sw.Write("Log made from " & Me.Text & " on " & DateTime.Now & ":" & sw.NewLine & sw.NewLine & txtLog.Text)
            sw.Close()
            sw = Nothing
        End If
    End Sub



    'Options > Auto Listen On Start
    Private Sub mnAutoListenOnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAutoListenOnStart.Click
        If mnAutoListenOnStart.Checked Then
            mnAutoListenOnStart.Checked = False
        Else
            mnAutoListenOnStart.Checked = True
        End If
    End Sub

    Private Sub mnAutoListenNone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAutoListenNone.Click
        mnAutoListenNone.Checked = True
        mnAutoListen25s.Checked = False
        mnAutoListen1m.Checked = False
        mnAutoListen5m.Checked = False
        mnAutoListen10m.Checked = False
        mnAutoListenOnTimeout.Checked = False
        ChangeAutoListenSets()
    End Sub

    Private Sub mnAutoListen25s_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAutoListen25s.Click
        mnAutoListenNone.Checked = False
        mnAutoListen25s.Checked = True
        mnAutoListen1m.Checked = False
        mnAutoListen5m.Checked = False
        mnAutoListen10m.Checked = False
        mnAutoListenOnTimeout.Checked = False
        ChangeAutoListenSets()
    End Sub

    Private Sub mnAutoListen1m_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAutoListen1m.Click
        mnAutoListenNone.Checked = False
        mnAutoListen25s.Checked = False
        mnAutoListen1m.Checked = True
        mnAutoListen5m.Checked = False
        mnAutoListen10m.Checked = False
        mnAutoListenOnTimeout.Checked = False
        ChangeAutoListenSets()
    End Sub

    Private Sub mnAutoListen5m_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAutoListen5m.Click
        mnAutoListenNone.Checked = False
        mnAutoListen25s.Checked = False
        mnAutoListen1m.Checked = False
        mnAutoListen5m.Checked = True
        mnAutoListen10m.Checked = False
        mnAutoListenOnTimeout.Checked = False
        ChangeAutoListenSets()
    End Sub

    Private Sub mnAutoListen10m_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAutoListen10m.Click
        mnAutoListenNone.Checked = False
        mnAutoListen25s.Checked = False
        mnAutoListen1m.Checked = False
        mnAutoListen5m.Checked = False
        mnAutoListen10m.Checked = True
        mnAutoListenOnTimeout.Checked = False
        ChangeAutoListenSets()
    End Sub

    Private Sub mnAutoListenOnTimeout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAutoListenOnTimeout.Click
        mnAutoListenNone.Checked = False
        mnAutoListen25s.Checked = False
        mnAutoListen1m.Checked = False
        mnAutoListen5m.Checked = False
        mnAutoListen10m.Checked = False
        mnAutoListenOnTimeout.Checked = True
        ChangeAutoListenSets()
    End Sub

    Private Sub mnStopAutoListenOnDisconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnStopAutoListenOnDisconnect.Click
        If mnStopAutoListenOnDisconnect.Checked Then
            mnStopAutoListenOnDisconnect.Checked = False
        Else
            mnStopAutoListenOnDisconnect.Checked = True
        End If
    End Sub

    Sub ChangeAutoListenSets()
        If mnAutoListenNone.Checked Or mnAutoListenOnTimeout.Checked Then
            tmrAutoListen.Enabled = False
        End If
        If mnAutoListen25s.Checked Then
            tmrAutoListen.Interval = 25000
            tmrAutoListen.Enabled = True
        End If
        If mnAutoListen1m.Checked Then
            tmrAutoListen.Interval = 60000
            tmrAutoListen.Enabled = True
        End If
        If mnAutoListen5m.Checked Then
            tmrAutoListen.Interval = 300000
            tmrAutoListen.Enabled = True
        End If
        If mnAutoListen10m.Checked Then
            tmrAutoListen.Interval = 600000
            tmrAutoListen.Enabled = True
        End If
    End Sub



    Private Sub mnOEnsureConnection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnOEnsureConnection.Click
        If mnOEnsureConnection.Checked Then
            mnOEnsureConnection.Checked = False
            tmrEnsureConnection.Enabled = False
            tmrSendEnsureConnection.Enabled = False
            If bConnected Then
                cOut("DisableEnsure_Connection")
            End If
        Else
            mnOEnsureConnection.Checked = True
            If bConnected Then
                cOut("EnableEnsure_Connection")
                tmrEnsureConnection.Enabled = False
                tmrSendEnsureConnection.Enabled = False
                tmrEnsureConnection.Enabled = True
                tmrSendEnsureConnection.Enabled = True
            End If
        End If
    End Sub

    'Options > Validate Connection
    Private Sub mnConValidate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnConValidate.Click
        If mnConValidate.Checked Then
            mnConValidate.Checked = False
        Else
            mnConValidate.Checked = True
        End If
    End Sub

    'Options > Auto Minimize on Start
    Private Sub mnMinimizeStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMinimizeStart.Click
        If mnMinimizeStart.Checked Then
            mnMinimizeStart.Checked = False
        Else
            mnMinimizeStart.Checked = True
        End If
    End Sub

    'Options > Save Options
    Private Sub mnSaveOptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSaveOptions.Click
        Try
            Dim shorcutPrefix As String = "MacroShorcut"
            Dim i
            For i = 0 To MacroShorcuts.Count - 1
                If MacroShorcuts(i) = "" Then
                    MacroShorcuts(i) = "Undefined"
                End If
            Next

            Dim CurrUsr As RegistryKey = Registry.CurrentUser
            Dim CurrUsrSft As RegistryKey = CurrUsr.OpenSubKey("Software", True)
            Dim AppRegKey As RegistryKey = CurrUsrSft.CreateSubKey(AppName)
            AppRegKey.SetValue("MinimizeOnStart", mnMinimizeStart.Checked)
            AppRegKey.SetValue("ListenOnStart", mnAutoListenOnStart.Checked)
            AppRegKey.SetValue("AutoListenDisabled", mnAutoListenNone.Checked)
            AppRegKey.SetValue("AutoListenOnTimeout", mnAutoListenOnTimeout.Checked)
            AppRegKey.SetValue("AutoListenMilliseconds", tmrAutoListen.Interval)
            AppRegKey.SetValue("AutoListenStopOnDisconnect", mnStopAutoListenOnDisconnect.Checked)
            AppRegKey.SetValue("ValidateConnection", mnConValidate.Checked)

            AppRegKey.SetValue("MacroExeIn", mnMacroOExeIn.Checked)
            AppRegKey.SetValue("MacroExeOut", mnMacroOExeOut.Checked)
            AppRegKey.SetValue("MacroExeTime", mnMacroOExeTime.Checked)
            AppRegKey.SetValue("OEnsureConnection", mnOEnsureConnection.Checked)
            AppRegKey.SetValue("MacroTimerDecimate", MacroTimerDecimate)
            AppRegKey.SetValue("MacroInvCom", mnMacroOInvCom.Checked)
            AppRegKey.SetValue(shorcutPrefix & "1", MacroShorcuts(0))
            AppRegKey.SetValue(shorcutPrefix & "2", MacroShorcuts(1))
            AppRegKey.SetValue(shorcutPrefix & "3", MacroShorcuts(2))
            AppRegKey.SetValue(shorcutPrefix & "4", MacroShorcuts(3))
            AppRegKey.SetValue(shorcutPrefix & "5", MacroShorcuts(4))
            AppRegKey.SetValue(shorcutPrefix & "6", MacroShorcuts(5))
            AppRegKey.SetValue(shorcutPrefix & "7", MacroShorcuts(6))
            AppRegKey.SetValue("IPtoConnect", IPtoConnect.ToString)
            AppRegKey.SetValue("PorttoConnect", PORT_NO)

            AppRegKey.Close()
            CurrUsrSft.Close()
            CurrUsr.Close()
            AppRegKey = Nothing
            CurrUsrSft = Nothing
            CurrUsr = Nothing

            Out("Options Saved")
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show("An error occurred while saving your options preferences to the registry.", "Registry Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error, System.Windows.Forms.MessageBoxDefaultButton.Button1)
        End Try
    End Sub

    Private Sub mnOIP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnOIP.Click

        Try
            Dim vv As String = InputBox("Enter the IP Address to connect to. Known IPs:" & vbCrLf & vbCrLf & "Any (default): " & IPAddress.Any.ToString & vbCrLf & "Broadcast: " & IPAddress.Broadcast.ToString, "IP Address", IPtoConnect.ToString)
            If Not vv = "" Then
                IPtoConnect = IPAddress.Parse(vv)
            End If
        Catch ex As Exception
            MessageBox.Show("You didn't enter a valid IP address.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            Exit Sub
        End Try

        Try
            Dim vvv As String = InputBox("Enter the port to connect to." & vbCrLf & "Max: " & IPEndPoint.MaxPort & vbCrLf & "Min: " & IPEndPoint.MinPort, "Port", PORT_NO)
            If Not vvv = "" Then
                If CInt(vvv) >= IPEndPoint.MinPort And CInt(vvv) <= IPEndPoint.MaxPort Then
                    PORT_NO = CInt(vvv)
                Else
                    MessageBox.Show("You didn't enter a valid port.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("You didn't enter a valid port.", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation, System.Windows.Forms.MessageBoxDefaultButton.Button1)
            Exit Sub
        End Try

    End Sub




    'Help > About
    Private Sub mnAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnAbout.Click
        System.Windows.Forms.MessageBox.Show("Pocket Control PC - PC v1.1" & vbCrLf & "Copyright (c) 2004 Iraklis Psaroudakis" & vbCrLf & vbCrLf & "More information, help, updates about the program go to http://www34.brinkster.com/kingherc/ or read the readme contained in the root directory of this program." & vbCrLf & vbCrLf & "To this program connects the device version (which runs on a remote device). The device then sends commands to this computer such as mouse clicks, key clicks etc.", "About Pocket Control PC - PC", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.DefaultDesktopOnly)
    End Sub

    'Help > Licence
    Private Sub mnLicence_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnLicence.Click
        System.Windows.Forms.MessageBox.Show("Pocket Control PC - PC" & vbCrLf & "Copyright (c) 2004 Iraklis Psaroudakis" & vbCrLf & vbCrLf & "This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version." & vbCrLf & "This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. " & vbCrLf & "" & vbCrLf & "You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA" & vbCrLf & vbCrLf & "* In the original distribution package, the GNU GPL Licence can be found at this program's root directory in text format.", "Licence Note", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.DefaultDesktopOnly)
    End Sub



    'cmnContextMenu > Exit
    Private Sub mnExitContext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnExitContext.Click
        mnExit_Click(Me, EventArgs.Empty)
    End Sub

    'cmnContextMenu > Begin Listening
    Private Sub mnBeginListeningContext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnBeginListeningContext.Click
        mnBeginListening_Click(Me, EventArgs.Empty)
    End Sub



    Private Sub mnOEnsureConnection_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnOEnsureConnection.Select
        ShowInfo("When checked, if connection is interrupted, the program disconnects.")
    End Sub

    Private Sub mnOIP_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnOIP.Select
        ShowInfo("Configure the IP and port to listen to.")
    End Sub

    Private Sub mnMacroOInvCom_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnMacroOInvCom.Select
        ShowInfo("Invert incoming and outgoing commands of macros.")
    End Sub

    Private Sub mnMacroODecim_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnMacroODecim.Select
        ShowInfo("If Timeless execution is not checked, intervals used will be divided by this number.")
    End Sub

    Private Sub mnMacroOptions_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnMacroOptions.Select
        ShowInfo("Options of execution and recording of macros.")
    End Sub

    Private Sub mnMacros_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnMacros.Select
        ShowInfo("Choices regarding the execution and recording of macros.")
    End Sub

    Private Sub mnMacroShorcutsManage_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnMacroShorcutsManage.Select
        ShowInfo("Manage the shorcuts of macros.")
    End Sub

    Private Sub mnMacroOExeTime_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnMacroOExeTime.Select
        ShowInfo("Execute the macro with timers.")
    End Sub

    Private Sub mnMacroOExeOut_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnMacroOExeOut.Select
        ShowInfo("Execute the outgoing commands of the macro.")
    End Sub

    Private Sub mnMacroOExeIn_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnMacroOExeIn.Select
        ShowInfo("Execute the incoming commands of the macro.")
    End Sub

    Private Sub mnMacroStop_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnMacroStop.Select
        ShowInfo("Stop recording a macro and save it to a text file.")
    End Sub

    Private Sub mnMacroRec_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnMacroRec.Select
        ShowInfo("Start recording a macro.")
    End Sub

    Private Sub mnMacroExe_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnMacroExe.Select
        ShowInfo("Execute a macro text file with the options you've selected.")
    End Sub

    Private Sub mnMacroTimeExeStop_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnMacroTimeExeStop.Select
        ShowInfo("Halt the execution of a macro with timers.")
    End Sub

    'Log
    Private Sub txtLog_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLog.MouseHover
        ShowInfo("This text box stores the log of the application")
    End Sub
    Private Sub txtLog_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txtLog.MouseMove
        ShowInfo("This text box stores the log of the application")
    End Sub

    'File
    Private Sub mnFile_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnFile.Select
        ShowInfo("Choices regarding the application in general.")
    End Sub

    'File > Exit
    Private Sub mnExit_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnExit.Select
        ShowInfo("Exit the application & close any active connection")
    End Sub

    'Connection
    Private Sub mnConnection_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnConnection.Select
        ShowInfo("Choices regarding the TCP/IP connection between the client - device and the host - PC")
    End Sub

    'Connection > Begin Listening
    Private Sub mnBeginListening_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnBeginListening.Select
        ShowInfo("Click to listen/wait for a connection request")
    End Sub

    'Connection > Send Message
    Private Sub mnSendMessage_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnSendMessage.Select
        ShowInfo("Send a message to the remote client")
    End Sub

    'Connection > Send Message > Test
    Private Sub mnSendTest_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnSendTest.Select
        ShowInfo("Send a test message to the remote client")
    End Sub

    'Connection > Disconnect
    Private Sub mnDisconnect_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnDisconnect.Select
        ShowInfo("Disconnect from the current active connection")
    End Sub

    'Log
    Private Sub mnLog_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnLog.Select
        ShowInfo("Choices regarding the log written")
    End Sub

    'Log > Clear
    Private Sub mnLogClear_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnLogClear.Select
        ShowInfo("Clear the log written")
    End Sub

    'Log > Save
    Private Sub mnLogSave_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnLogSave.Select
        ShowInfo("Save the log written to a text file")
    End Sub

    'Connection > Send Message > Custom...
    Private Sub mnSendCustom_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnSendCustom.Select
        ShowInfo("Send a custom message to the remote client's log")
    End Sub

    'Options
    Private Sub mnOptions_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnOptions.Select
        ShowInfo("Choices regarding the options of the application")
    End Sub

    'Options > Validate Connection
    Private Sub mnConValidate_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnConValidate.Select
        ShowInfo("Whether to communicate under a validated connection or not")
    End Sub

    'File > Minimize to Tray
    Private Sub mnMinimizeTray_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnMinimizeTray.Select
        ShowInfo("Minimization to tray for background activity")
    End Sub

    'Help
    Private Sub mnHelp_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnHelp.Select
        ShowInfo("Choices regarding the help context of the application")
    End Sub

    'Help > About
    Private Sub mnAbout_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnAbout.Select
        ShowInfo("A messagebox with general info about the application")
    End Sub

    'Help > Licence
    Private Sub mnLicence_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnLicence.Select
        ShowInfo("Shows the licence under which this program can be used")
    End Sub

    'Options > Auto Listen On Start
    Private Sub mnAutoListenOnStart_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnAutoListenOnStart.Select
        ShowInfo("When the application starts, Begin Listening.")
    End Sub

    'Options > Auto Listen
    Private Sub mnOptionsAutoListen_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnOptionsAutoListen.Select
        ShowInfo("Begin Listening automatically when/after...")
    End Sub

    'Options > Auto Listen > Stop on Disconnect
    Private Sub mnStopAutoListenOnDisconnect_Select(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnStopAutoListenOnDisconnect.Select
        ShowInfo("On Disconnect, set Auto Listen to None.")
    End Sub

    'Options > Auto minimize on start
    Private Sub mnMinimizeStart_Select(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnMinimizeStart.Select
        ShowInfo("Auto minimize to tray icon when the program starts")
    End Sub

    'Options > Save Options
    Private Sub mnSaveOptions_Select(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnSaveOptions.Select
        ShowInfo("Saves options to registry. Auto-loading occurs on program start.")
    End Sub





    'This function receives a command and executes it
    Sub TranslateCommand(ByVal strCommand As String)
        If WasValidated Or Not mnConValidate.Checked Then
            ShowConInfo("Executing...")
            'Command for closing the connection
            If Not strCommand.IndexOf("CloseConnection") = -1 Then
                mnDisconnect_Click(Me, EventArgs.Empty)
            End If
            'MOUSE Commands
            If Not strCommand.IndexOf("MouseLeftButtonDown") = -1 Then
                APICalls.DoMouse(MOUSEEVENTF_LEFTDOWN, 0, 0, 0)
            End If
            If Not strCommand.IndexOf("MouseLeftButtonUp") = -1 Then
                APICalls.DoMouse(MOUSEEVENTF_LEFTUP, 0, 0, 0)
            End If
            If Not strCommand.IndexOf("MouseMiddleButtonDown") = -1 Then
                APICalls.DoMouse(MOUSEEVENTF_MIDDLEDOWN, 0, 0, 0)
            End If
            If Not strCommand.IndexOf("MouseMiddleButtonUp") = -1 Then
                APICalls.DoMouse(MOUSEEVENTF_MIDDLEUP, 0, 0, 0)
            End If
            If Not strCommand.IndexOf("MouseRightButtonDown") = -1 Then
                APICalls.DoMouse(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0)
            End If
            If Not strCommand.IndexOf("MouseRightButtonUp") = -1 Then
                APICalls.DoMouse(MOUSEEVENTF_RIGHTUP, 0, 0, 0)
            End If
            If Not strCommand.IndexOf("MouseLeftMove") = -1 Then
                Cursor.Current.Position = New Point(Cursor.Current.Position.X - CInt(strCommand.Substring(strCommand.IndexOf(":") + 1, strCommand.IndexOf(".") - strCommand.IndexOf(":") - 1)), Cursor.Current.Position.Y)
                'cOutMouseLoc()
            End If
            If Not strCommand.IndexOf("MouseUpMove") = -1 Then
                Cursor.Current.Position = New Point(Cursor.Current.Position.X, Cursor.Current.Position.Y - CInt(strCommand.Substring(strCommand.IndexOf(":") + 1, strCommand.IndexOf(".") - strCommand.IndexOf(":") - 1)))
                'cOutMouseLoc()
            End If
            If Not strCommand.IndexOf("MouseRightMove") = -1 Then
                Cursor.Current.Position = New Point(Cursor.Current.Position.X + CInt(strCommand.Substring(strCommand.IndexOf(":") + 1, strCommand.IndexOf(".") - strCommand.IndexOf(":") - 1)), Cursor.Current.Position.Y)
                'cOutMouseLoc()
            End If
            If Not strCommand.IndexOf("MouseDownMove") = -1 Then
                Cursor.Current.Position = New Point(Cursor.Current.Position.X, Cursor.Current.Position.Y + CInt(strCommand.Substring(strCommand.IndexOf(":") + 1, strCommand.IndexOf(".") - strCommand.IndexOf(":") - 1)))
                'cOutMouseLoc()
            End If
            If Not strCommand.IndexOf("ScrollUp") = -1 Then
                APICalls.DoMouse(MOUSEEVENTF_WHEEL, 0, 0, CInt(strCommand.Substring(strCommand.IndexOf(":") + 1, strCommand.IndexOf(".") - strCommand.IndexOf(":") - 1)) * WHEEL_DELTA)
            End If
            If Not strCommand.IndexOf("ScrollDown") = -1 Then
                APICalls.DoMouse(MOUSEEVENTF_WHEEL, 0, 0, CInt(strCommand.Substring(strCommand.IndexOf(":") + 1, strCommand.IndexOf(".") - strCommand.IndexOf(":") - 1)) * WHEEL_DELTA * (-1))
            End If
            If Not strCommand.IndexOf("MouseX1ButtonDown") = -1 Then
                APICalls.DoMouse(MOUSEEVENTF_XDOWN, 0, 0, XBUTTON1)
            End If
            If Not strCommand.IndexOf("MouseX1ButtonUp") = -1 Then
                APICalls.DoMouse(MOUSEEVENTF_XUP, 0, 0, XBUTTON1)
            End If
            If Not strCommand.IndexOf("MouseX2ButtonDown") = -1 Then
                APICalls.DoMouse(MOUSEEVENTF_XDOWN, 0, 0, XBUTTON2)
            End If
            If Not strCommand.IndexOf("MouseX2ButtonUp") = -1 Then
                APICalls.DoMouse(MOUSEEVENTF_XUP, 0, 0, XBUTTON2)
            End If
            'Command fro sending out the mouse's location iformation along with the screen size
            If Not strCommand.IndexOf("RequestMouseLocation") = -1 Then
                cOutMouseLoc()
            End If
            'Command for changing mouse's coordinates
            If Not strCommand.IndexOf("InputMousePos:") = -1 Then
                Try
                    Dim coor As String = strCommand.Substring(strCommand.IndexOf(":") + 1, strCommand.IndexOf(".") - strCommand.IndexOf(":") - 1)
                    Dim tmpP As New Point(coor.Substring(1, coor.IndexOf(",") - 1), coor.Substring(coor.IndexOf(",") + 1, coor.IndexOf(")") - coor.IndexOf(",") - 1))
                    Cursor.Current.Position = tmpP
                Catch ex As Exception

                End Try
            End If
            'Commands for keystrokes
            If Not strCommand.IndexOf("KeyPress") = -1 Then
                APICalls.DoKey(CInt(strCommand.Substring(strCommand.IndexOf(":") + 1, strCommand.IndexOf(",") - strCommand.IndexOf(":") - 1)), CInt(strCommand.Substring(strCommand.IndexOf(",") + 1, strCommand.IndexOf(".") - strCommand.IndexOf(",") - 1)))
            End If
            If Not strCommand.IndexOf("ClientScreenSize") = -1 Then
                RemoteScreenSize = New Size(strCommand.Substring(strCommand.IndexOf(":") + 1, strCommand.IndexOf("x") - strCommand.IndexOf(":") - 1), strCommand.Substring(strCommand.IndexOf("x") + 1, strCommand.IndexOf(".") - 1 - strCommand.IndexOf("x")))
                cOutMouseLoc()
            End If
            If Not strCommand.IndexOf("SendKeys") = -1 Then
                Dim nn As System.Windows.Forms.SendKeys
                nn.Send(strCommand.Substring(strCommand.IndexOf(":") + 1, strCommand.IndexOf("%.PocketPCRemoteSendKeys.$") - 1 - strCommand.IndexOf(":")))
                nn = Nothing
            End If
            If Not strCommand.IndexOf("QuickMouseAction") = -1 Then
                QMActionLast = QMAction
                QMAction = strCommand.Substring(strCommand.IndexOf(":") + 1, strCommand.IndexOf(",") - strCommand.IndexOf(":") - 1)
                QMStep = strCommand.Substring(strCommand.IndexOf(",") + 1, strCommand.IndexOf(";") - strCommand.IndexOf(",") - 1)
                QMInterval = strCommand.Substring(strCommand.IndexOf(";") + 1, strCommand.IndexOf(".") - strCommand.IndexOf(";") - 1)

                tmrQuickMouse.Interval = QMInterval
                tmrQuickMouse.Enabled = True
            End If
            If Not strCommand.IndexOf("CancelQuickMouse") = -1 Then
                QMActionLast = ""
                tmrQuickMouse.Enabled = False
            End If
            If Not strCommand.IndexOf("EnsureConnection") = -1 Then
                tmrEnsureConnection.Enabled = False
                tmrEnsureConnection.Enabled = True
            End If
            If Not strCommand.IndexOf("DisableEnsure_Connection") = -1 Then
                If mnOEnsureConnection.Checked Then
                    mnOEnsureConnection_Click(Me, EventArgs.Empty)
                End If
            End If
            If Not strCommand.IndexOf("EnableEnsure_Connection") = -1 Then
                If Not mnOEnsureConnection.Checked Then
                    mnOEnsureConnection_Click(Me, EventArgs.Empty)
                End If
            End If
        Else
            If Not strCommand.IndexOf("ValidateHostConnection") = -1 Then
                WasValidated = True
                Out("Connection Validated")
            Else
                Out("Received Command was not executed because connection is not yet validated")
            End If
        End If
    End Sub



    Sub cOutMouseLoc() 'Send the location of the mouse
        cOutScreenSize()
        cOut("MouseLoc:" & Cursor.Current.Position.X & "," & Cursor.Current.Position.Y & ".")
    End Sub

    Sub cOutScreenSize() 'Send the screen's size
        cOut("ScreenSize:" & System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width & "x" & System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height & ".")
    End Sub


    'When connected, this timer listens for commands through the NetworkStream, logs them and executes them through another function
    Private Sub tmrListenCommandsLoop_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrListenCommandsLoop.Tick
        Try
            tmrListenCommandsLoop.Interval = 50
            If ns.CanRead And ns.DataAvailable Then
                ShowConInfo("Receiving...")
                Dim bytes(ccon.ReceiveBufferSize) As Byte
                ns.Read(bytes, 0, CInt(ccon.ReceiveBufferSize))
                Dim rc As String = Encoding.Unicode.GetString(bytes)
                If Not rc.IndexOf("PocketPCControl:") = -1 Then
                    'LastCommand = rc.Replace("PocketPCControl:", "")
                    'Out("Received: " & LastCommand)
                    'TranslateCommand(LastCommand)
                    rc = rc.Replace("PocketPCControl:", "")
                    Do
                        If Not rc.IndexOf("~~##COM##~~") = -1 Then
                            Dim tmpStr As String = rc.Substring(rc.IndexOf("~~##COM##~~"), rc.IndexOf("~~##COMEND##~~") + 14 - rc.IndexOf("~~##COM##~~"))
                            LastCommand = CStr(tmpStr.Replace("~~##COM##~~", "")).Replace("~~##COMEND##~~", "")
                            If LastCommand.IndexOf("EnsureConnection") = -1 Then
                                Out("Received: " & LastCommand)
                            End If
                            TranslateCommand(LastCommand)
                            If IsMacroRec Then
                                Dim DateNow As DateTime = DateTime.Now
                                'MacroRecText &= vbCrLf & "IN_:" & DateTime.Now.ToLongTimeString & ";" & LastCommand
                                MacroRecText &= vbCrLf & "IN_:" & CType(New TimeSpan(DateNow.Day, DateNow.Hour, DateNow.Minute, DateNow.Second), TimeSpan).ToString & ";" & LastCommand
                            End If
                            rc = rc.Replace(tmpStr, "")
                            tmpStr = Nothing
                        Else
                            Exit Do
                        End If
                    Loop
                Else
                    Out("Received Unidentified String: " & rc)
                End If
                If bConnected Then
                    ShowConInfo("Connected")
                End If
                bytes = Nothing
                rc = Nothing
            End If
        Catch ex As Exception
            Out("Failed to listen to remote host. Retry in 5 secs.")
            tmrListenCommandsLoop.Interval = 5000
        End Try
    End Sub

    'This timer is used in the beginning for finding a connection. When the listening loop is started, the timer is activated. Each interval, it searches for an available connection. If found, it connects to it. If not, it waits. If the timeout is reached, it stops searching.
    Private Sub tmrListenLoop_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrListenLoop.Tick
        If Not con.Pending Then
            If conTries > 10 Then
                conTries = 1
                bConnected = False
                con.Stop()
                Out("Connection failed because listening timeout surpassed. Ensure proper connection and try again.")
                tmrListenLoop.Enabled = False
                mnDisconnect.Enabled = False
                mnBeginListening.Enabled = True
                mnBeginListeningContext.Enabled = True
                ShowConInfo("Idle")
                If mnAutoListenOnTimeout.Checked Then
                    mnBeginListening_Click(Me, EventArgs.Empty)
                    Out(" (Auto)", False)
                End If
                Exit Sub
            End If
            Out(".", False)
            conTries += 1
        Else
            bConnected = True
            ccon = con.AcceptTcpClient
            con.Stop()
            Out("Connection found")
            ShowConInfo("Connected")
            mnDisconnect.Enabled = True
            tmrListenLoop.Enabled = False
            mnBeginListening.Enabled = False
            mnBeginListeningContext.Enabled = False
            ns = ccon.GetStream()
            tmrListenCommandsLoop.Interval = 50
            tmrListenCommandsLoop.Enabled = True
            mnSendMessage.Enabled = True
            cOut("ValidateClientConnection", True)
            mnOEnsureConnection.Enabled = True
            If mnOEnsureConnection.Checked Then
                tmrEnsureConnection.Enabled = True
                tmrSendEnsureConnection.Enabled = True
            End If
        End If
    End Sub

    'When connected, this function is used to send away commands to the remote client
    Private Function cOut(ByVal strTransfer As String, Optional ByVal DoNotValidate As Boolean = False) As Boolean
        Try
            If WasValidated Or DoNotValidate Or Not mnConValidate.Checked Then
                If bConnected Then
                    If ns.CanWrite Then
                        ShowConInfo("Sending...")
                        Dim sendBytes As [Byte]() = Encoding.Unicode.GetBytes("PocketPCControl:~~##COM##~~" & strTransfer & "~~##COMEND##~~")
                        Try
                            ns.Write(sendBytes, 0, sendBytes.Length)
                        Catch ex As Exception
                            Out("Transfer not executed because of a connection problem.")
                            Return False
                            Exit Function
                        End Try
                        If IsMacroRec Then
                            'MacroRecText &= vbCrLf & "OUT:" & DateTime.Now.ToLongTimeString & ";" & strTransfer
                            Dim DateNow As DateTime = DateTime.Now
                            'MacroRecText &= vbCrLf & "IN_:" & DateTime.Now.ToLongTimeString & ";" & LastCommand
                            MacroRecText &= vbCrLf & "OUT:" & CType(New TimeSpan(DateNow.Day, DateNow.Hour, DateNow.Minute, DateNow.Second), TimeSpan).ToString & ";" & strTransfer
                        End If
                        If strTransfer.IndexOf("EnsureConnection") = -1 Then
                            Out("Transfered: " & strTransfer)
                        End If
                        ShowConInfo("Connected")
                        Return True
                        sendBytes = Nothing
                    Else
                        Return False
                    End If
                Else
                    Out("Transfer was not executed because there is no connection.")
                    Return False
                End If
            Else
                Out("Transfer was not executed because connection is not yet validated")
                Return False
            End If
        Catch ex As Exception
            Out("Transfer was not executed because of an unrecognised error.")
            Return False
            Exit Function
        End Try
    End Function




    Sub StartExeMacro(ByVal txtMacro As String)
        Dim Comm As Hashtable = TextToCommands(txtMacro)
        Dim ComCount As Integer = Comm("Command Count")
        Dim i
        For i = 1 To ComCount
            Dim strCom As String = Comm(i)
            Dim clrCom As String = strCom.Substring(strCom.IndexOf(";") + 1)
            Select Case strCom.Substring(0, 3)
                Case "OUT"
                    If mnMacroOExeOut.Checked Then
                        If Not mnMacroOInvCom.Checked Then
                            If Not cOut(clrCom) Then
                                Out("Macro execution interrupted. Info: " & Comm("Program Name") & " v" & CType(Comm("Program Version"), Version).ToString & " created at " & Comm("Creation Date") & ".")
                                Exit Sub
                            End If
                        Else
                            TranslateCommand(clrCom)
                        End If
                    End If
                Case "IN_"
                    If mnMacroOExeIn.Checked Then
                        If mnMacroOInvCom.Checked Then
                            If Not cOut(clrCom) Then
                                Out("Macro execution interrupted. Info: " & Comm("Program Name") & " v" & CType(Comm("Program Version"), Version).ToString & " created at " & Comm("Creation Date") & ".")
                                Exit Sub
                            End If
                        Else
                            TranslateCommand(clrCom)
                        End If
                    End If
            End Select
        Next
        Out("Executed macro. Info: " & Comm("Program Name") & " v" & CType(Comm("Program Version"), Version).ToString & " created at " & Comm("Creation Date") & ".")
        UpdateCurrentConInfo()
    End Sub

    Sub StartExeTimeMacro(ByVal txtMacro As String)
        IsTimeMacroExe = True

        TimeMacroComm = TextToCommands(txtMacro)
        TimeMacroComm.Add("Time Count Position", 1)

        mnMenus.MenuItems.Add(0, mnMacroTimeExeStop)
        Dim i
        For i = 1 To mnMenus.MenuItems.Count - 1
            mnMenus.MenuItems(i).Enabled = False
        Next

        tmrTimeMacroExe.Interval = 5000
        tmrTimeMacroExe.Enabled = True

        Out("Execution of a macro with timers started. Info: " & TimeMacroComm("Program Name") & " v" & CType(TimeMacroComm("Program Version"), Version).ToString & " created at " & TimeMacroComm("Creation Date") & ".")
    End Sub

    Private Sub MacroStopTimeExe()
        tmrTimeMacroExe.Enabled = False

        mnMenus.MenuItems.RemoveAt(0)
        Dim i
        For i = 0 To mnMenus.MenuItems.Count - 1
            mnMenus.MenuItems(i).Enabled = True
        Next

        IsTimeMacroExe = False
        TimeMacroComm = Nothing
        Out("Execution of a macro with timers finished.")
        UpdateCurrentConInfo()
    End Sub

    Private Sub tmrTimeMacroExe_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles tmrTimeMacroExe.Tick
        Dim CurrTimePos As Integer = TimeMacroComm("Time Count Position")
        Dim CommCount As Integer = TimeMacroComm("Command Count")
        Dim strCom As String = TimeMacroComm(CurrTimePos)
        Dim clrCom As String = strCom.Substring(strCom.IndexOf(";") + 1)

        Select Case strCom.Substring(0, 3)
            Case "OUT"
                If mnMacroOExeOut.Checked Then
                    If Not mnMacroOInvCom.Checked Then
                        If Not cOut(clrCom) Then
                            MacroStopTimeExe()
                            Exit Sub
                        End If
                    Else
                        TranslateCommand(clrCom)
                    End If
                End If
            Case "IN_"
                If mnMacroOExeIn.Checked Then
                    If mnMacroOInvCom.Checked Then
                        If Not cOut(clrCom) Then
                            MacroStopTimeExe()
                            Exit Sub
                        End If
                    Else
                        TranslateCommand(clrCom)
                    End If
                End If
        End Select

        If Not CurrTimePos >= CommCount Then
            Dim strNextCom As String = TimeMacroComm(CurrTimePos + 1)

            Dim FirstTimeSpan As TimeSpan = TimeSpan.Parse(strCom.Substring(strCom.IndexOf(":") + 1, strCom.IndexOf(";") - strCom.IndexOf(":") - 1))
            Dim SecondTimeSpan As TimeSpan = TimeSpan.Parse(strNextCom.Substring(strNextCom.IndexOf(":") + 1, strNextCom.IndexOf(";") - strNextCom.IndexOf(":") - 1))
            Dim DiffTimeSpan As TimeSpan = SecondTimeSpan.Subtract(FirstTimeSpan)
            If DiffTimeSpan.TotalMilliseconds <= 0 Then
                DiffTimeSpan = New TimeSpan(0, 0, 0, 1)
            End If
            tmrTimeMacroExe.Interval = DiffTimeSpan.TotalMilliseconds / MacroTimerDecimate

            TimeMacroComm.Remove("Time Count Position")
            TimeMacroComm.Add("Time Count Position", CurrTimePos + 1)
        Else
            MacroStopTimeExe()
        End If
    End Sub

    Function TextToCommands(ByVal Txt As String) As Hashtable
        'Create Hashtable and store macro's info
        Dim Comm As New Hashtable
        Comm.Add("Program Name", Txt.Substring(0, Txt.IndexOf("##%%##") - 1))
        Txt = Replace(Txt, Txt.Substring(0, Txt.IndexOf("##%%##") + 7), "", 1, 1)
        Comm.Add("Creation Date", CType(Txt.Substring(0, Txt.IndexOf("##%%##") - 1), DateTime))
        Txt = Replace(Txt, Txt.Substring(0, Txt.IndexOf("##%%##") + 7), "", 1, 1)
        Comm.Add("Program Version", New Version(Txt.Substring(0, Txt.IndexOf(vbCrLf))))
        Txt = Replace(Txt, Txt.Substring(0, Txt.IndexOf(vbCrLf) + 2), "", 1, 1)
        'Start saving commands
        Dim i As Integer = 1
        While Txt <> ""
            If Not Txt.IndexOf(vbCrLf) = -1 Then
                Comm.Add(i, Txt.Substring(0, Txt.IndexOf(vbCrLf)))
                Txt = Replace(Txt, Txt.Substring(0, Txt.IndexOf(vbCrLf) + 2), "", 1, 1)
                i += 1
            Else
                Comm.Add(i, Txt)
                Txt = ""
                i += 1
            End If
        End While
        Comm.Add("Command Count", i - 1)

        Return Comm
        Comm = Nothing
        i = Nothing
    End Function


    'This function writes a message to the log
    Private Sub Out(ByVal str As String, Optional ByVal ChangeEvent As Boolean = True)
        If ChangeEvent Then
            txtLog.Text &= vbCrLf & DateTime.Now & ": "
        End If
        txtLog.Text &= str
        Try
            txtLog.Select(txtLog.Text.LastIndexOf(vbCrLf) + 2, 0)
            txtLog.ScrollToCaret()
        Catch ex As Exception
            txtLog.Select(txtLog.Text.Length - 1, 0)
            txtLog.ScrollToCaret()
        End Try
    End Sub

    'This routine changes the statusbar info panel text
    Sub ShowInfo(ByVal str2Show As String)
        sbrStatusPanelInfo.Text = str2Show
    End Sub

    Sub UpdateCurrentConInfo()
        If bConnected Then
            If Not tmrListenLoop.Enabled Then
                ShowConInfo("Connected")
            Else
                ShowConInfo("Listening...")
            End If
        Else
            ShowConInfo("Idle")
        End If
    End Sub

    'This routine changes the statusbar connection info panel text
    Sub ShowConInfo(ByVal str2Show As String)
        sbrStatusConInfoPanel.Text = str2Show
        TrayIcon.Text = Me.Text & ": " & str2Show
        Select Case sbrStatusConInfoPanel.Text
            Case "Idle"
                sbrStatusConInfoPanel.Icon = icoIdle.Icon
                TrayIcon.Icon = icoIdleTray.Icon
            Case "Connected"
                sbrStatusConInfoPanel.Icon = icoConnected.Icon
                TrayIcon.Icon = Me.Icon
            Case "Listening..."
                sbrStatusConInfoPanel.Icon = icoListening.Icon
                TrayIcon.Icon = icoListening.Icon
            Case "Executing..."
                sbrStatusConInfoPanel.Icon = icoExecuting.Icon
                TrayIcon.Icon = icoExecuting.Icon
            Case "Sending..."
                sbrStatusConInfoPanel.Icon = icoSending.Icon
                TrayIcon.Icon = icoSending.Icon
            Case "Receiving..."
                sbrStatusConInfoPanel.Icon = icoReceiving.Icon
                TrayIcon.Icon = icoReceiving.Icon
            Case Else
                Exit Sub
        End Select
    End Sub

    Sub LoadOptions()
        MacroShorcuts = New ArrayList(7)
        Dim shorcutPrefix As String = "MacroShorcut"

        Dim CurrUsr As RegistryKey = Registry.CurrentUser
        Dim CurrUsrSft As RegistryKey = CurrUsr.OpenSubKey("Software")
        Dim AllKeyNames As String() = CurrUsrSft.GetSubKeyNames

        If Not Array.IndexOf(AllKeyNames, AppName) = -1 Then
            Dim AppRegKey As RegistryKey = CurrUsrSft.OpenSubKey(AppName)

            If Not AppRegKey.GetValue("AutoListenDisabled") = True Then
                If AppRegKey.GetValue("AutoListenOnTimeout") = True Then
                    mnAutoListenOnTimeout_Click(Me, EventArgs.Empty)
                Else
                    Select Case AppRegKey.GetValue("AutoListenMilliseconds")
                        Case 25000
                            mnAutoListen25s_Click(Me, EventArgs.Empty)
                        Case 60000
                            mnAutoListen1m_Click(Me, EventArgs.Empty)
                        Case 300000
                            mnAutoListen5m_Click(Me, EventArgs.Empty)
                        Case 600000
                            mnAutoListen10m_Click(Me, EventArgs.Empty)
                    End Select
                End If
            End If
            If AppRegKey.GetValue("AutoListenStopOnDisconnect") = True Then
                mnStopAutoListenOnDisconnect_Click(Me, EventArgs.Empty)
            End If
            If AppRegKey.GetValue("MinimizeOnStart") = True Then
                mnMinimizeStart_Click(Me, EventArgs.Empty)
            End If
            If AppRegKey.GetValue("ListenOnStart") = True Then
                mnAutoListenOnStart_Click(Me, EventArgs.Empty)
            End If
            If Not AppRegKey.GetValue("ValidateConnection") = True Then
                mnConValidate_Click(Me, EventArgs.Empty)
            End If
            If Not AppRegKey.GetValue("MacroExeIn") = True Then
                mnMacroOExeIn_Click(Me, EventArgs.Empty)
            End If
            If AppRegKey.GetValue("OEnsureConnection") = False Then
                mnOEnsureConnection.Checked = False
            End If
            If AppRegKey.GetValue("MacroExeOut") = True Then
                mnMacroOExeOut_Click(Me, EventArgs.Empty)
            End If
            If AppRegKey.GetValue("MacroExeTime") = True Then
                mnMacroOExeTime_Click(Me, EventArgs.Empty)
            End If
            If IsNumeric(AppRegKey.GetValue("MacroTimerDecimate")) Then
                MacroTimerDecimate = AppRegKey.GetValue("MacroTimerDecimate")
            End If
            If AppRegKey.GetValue("MacroInvCom") = True Then
                mnMacroOInvCom_Click(Me, EventArgs.Empty)
            End If
            If Not AppRegKey.GetValue("IPtoConnect") = "" Then
                IPtoConnect = IPAddress.Parse(AppRegKey.GetValue("IPtoConnect"))
            Else
                Try
                    IPtoConnect = System.Net.Dns.GetHostByName("PPP_Peer").AddressList(0)
                Catch ex As Exception
                    IPtoConnect = IPAddress.None
                End Try
            End If
            Try
                PORT_NO = AppRegKey.GetValue("PorttoConnect")
            Catch ex As Exception

            End Try

            Dim i As Integer
            For i = 1 To 7
                Dim RegValPath As String = shorcutPrefix & i
                If Not AppRegKey.GetValue(RegValPath) = "" Then
                    MacroShorcuts.Add(AppRegKey.GetValue(RegValPath))
                Else
                    MacroShorcuts.Add("Undefined")
                End If
            Next

            AppRegKey.Close()
            AppRegKey = Nothing
            Out("Loaded Options")

        Else

            Try
                IPtoConnect = System.Net.Dns.GetHostByName("PPP_Peer").AddressList(0)
            Catch ex As Exception
                IPtoConnect = IPAddress.Any
            End Try

            Dim i As Integer
            For i = 1 To 7
                MacroShorcuts.Add("Undefined")
            Next

        End If

        Dim ii
        For ii = 0 To 6
            Dim iii
            For iii = 0 To Path.InvalidPathChars.Length - 1
                If Not CStr(MacroShorcuts(ii)).IndexOf(Path.InvalidPathChars(iii)) = -1 Then
                    MacroShorcuts(ii) = CStr(MacroShorcuts(ii)).Replace(Path.InvalidPathChars(iii), "")
                End If
            Next
        Next

        LoadMacroShorcutNames()

        CurrUsrSft.Close()
        CurrUsr.Close()
        CurrUsrSft = Nothing
        CurrUsr = Nothing
        AllKeyNames = Nothing
    End Sub

    Sub LoadMacroShorcutNames()
        mnMacroShorcut1.Text = "1. " & Path.GetFileName(MacroShorcuts(0))
        mnMacroShorcut2.Text = "2. " & Path.GetFileName(MacroShorcuts(1))
        mnMacroShorcut3.Text = "3. " & Path.GetFileName(MacroShorcuts(2))
        mnMacroShorcut4.Text = "4. " & Path.GetFileName(MacroShorcuts(3))
        mnMacroShorcut5.Text = "5. " & Path.GetFileName(MacroShorcuts(4))
        mnMacroShorcut6.Text = "6. " & Path.GetFileName(MacroShorcuts(5))
        mnMacroShorcut7.Text = "7. " & Path.GetFileName(MacroShorcuts(6))
    End Sub



    Private Sub tmrSendEnsureConnection_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrSendEnsureConnection.Tick
        cOut("EnsureConnection")
    End Sub

    Private Sub tmrEnsureConnection_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrEnsureConnection.Tick
        mnDisconnect_Click(Me, EventArgs.Empty)
        Out(" - No response received.", False)
    End Sub

    'Auto Start the listening process for connection
    Private Sub tmrQuickMouse_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrQuickMouse.Tick
        Dim toContinue As Boolean = True

        Select Case QMActionLast
            Case "Up"
                If QMAction = "Down" Then
                    toContinue = False
                End If
            Case "Down"
                If QMAction = "Up" Then
                    toContinue = False
                End If
            Case "Right"
                If QMAction = "Left" Then
                    toContinue = False
                End If
            Case "Left"
                If QMAction = "Right" Then
                    toContinue = False
                End If
        End Select

        If toContinue Then
            Select Case QMAction
                Case "Up"
                    TranslateCommand("MouseUpMove:" & QMStep & ".")
                Case "Down"
                    TranslateCommand("MouseDownMove:" & QMStep & ".")
                Case "Right"
                    TranslateCommand("MouseRightMove:" & QMStep & ".")
                Case "Left"
                    TranslateCommand("MouseLeftMove:" & QMStep & ".")
            End Select
        Else
            QMActionLast = ""
            tmrQuickMouse.Enabled = False
        End If
    End Sub

    'Auto Start the listening process for connection
    Private Sub tmrAutoListen_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrAutoListen.Tick
        If Not bConnected And Not tmrListenLoop.Enabled Then
            mnBeginListening_Click(Me, EventArgs.Empty)
            Out(" (Auto)", False)
        End If
    End Sub

    'When the tray icon is double clicked
    Private Sub TrayIcon_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles TrayIcon.DoubleClick
        Me.Show()
        TrayIcon.Visible = False
    End Sub


End Class

