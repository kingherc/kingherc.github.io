'Pocket Control PC - PC
'Copyright (C) 2004 Iraklis Psaroudakis

'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 
'This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Imports System
Imports System.Resources

Public Class WriteResources
    
    Public Shared Sub Main()

        Dim writer As New ResourceWriter("Main.resources")
        
        'Icons
        Dim icoAppIcon16 As New System.Drawing.Icon("Images\AppIcon16.ico")
        Dim icoAppIcon As New System.Drawing.Icon("Images\AppIcon.ico")
        Dim icoConnected As New System.Drawing.Icon("Images\Connected.ico")
        Dim icoExecuting As New System.Drawing.Icon("Images\Executing.ico")
        Dim icoIdle As New System.Drawing.Icon("Images\Idle.ico")
        Dim icoIdleTray As New System.Drawing.Icon("Images\TrayIdle.ico")
        Dim icoListening As New System.Drawing.Icon("Images\Listening.ico")
        Dim icoReceiving As New System.Drawing.Icon("Images\Receiving.ico")
        Dim icoSending As New System.Drawing.Icon("Images\Sending.ico")

        ' Adds resources to the resource writer.
        writer.AddResource("Application Icon 16", icoAppIcon16)
        writer.AddResource("Application Icon", icoAppIcon)
        writer.AddResource("Connected Icon", icoConnected)
        writer.AddResource("Executing Icon", icoExecuting)
        writer.AddResource("Idle Icon", icoIdle)
        writer.AddResource("Idle Icon Tray", icoIdleTray)
        writer.AddResource("Listening Icon", icoListening)
        writer.AddResource("Receiving Icon", icoReceiving)
        writer.AddResource("Sending Icon", icoSending)

        ' Writes the resources to the file or stream, and closes it.
        writer.Close()
    End Sub
End Class

